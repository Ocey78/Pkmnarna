// Private allied Latios/Latias encounter; native player combat and party rules.
(() => {
  'use strict';
  function createRocketEonBossCombat(){
    const worlds=new WeakMap(),clamp=(n,a,b)=>Math.max(a,Math.min(b,n)),pace=.8,size=1.25,power=1.3;
    const point=a=>({x:a.x,y:a.y}),center=a=>arenaBossRush.center(a);
    const muzzle=(actor,attack,facing=attack?.facing??actor.facing)=>rocketEonMouths.world(actor,attack,facing);
    const bosses=w=>[w.opponent,w.third],mega=a=>a.speciesId.endsWith('mega');
    const tempo=a=>(a.rocketEonDifficulty?.speed||1)*(a.rocketEonEnraged?1.25:1);
    const area=a=>(a.rocketEonDifficulty?.size||1)*(a.rocketEonEnraged?1.15:1);
    const strength=a=>power*(a.rocketEonDifficulty?.damage||1)*(a.rocketEonEnraged?1.25:1);
    const movable=a=>a.hp>0&&a.ailment!=='sleep'&&a.ailment!=='freeze'&&a.recoverMs<=0;
    const distance=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
    const constrain=(w,p,r=20)=>Ia(p.x,p.y,r,w.combat,p.x,p.y);
    function idle(actor,delay=400){return{actorId:actor.id,mega:mega(actor),enraged:!!actor.rocketEonEnraged,
      speedScale:tempo(actor),kind:'idle',phase:'idle',durationMs:delay/tempo(actor),
      elapsedMs:0,progress:0,from:center(actor),to:center(actor),facing:actor.facing,width:0,radius:0};}
    function reset(world){
      const state={clock:0,nextId:1,nextPairAt:3600*pace/tempo(world.opponent),pairMinimum:2,independentMoves:0,wantPair:false,pair:null,lastPair:null,enragedId:null,nextBeamHit:0,navigation:new Map(),
        random:lo(((Number(world.seed)||1)^0x43ea1075)>>>0),actors:new Map(),projectiles:[],zones:[],impacts:[],beams:[]};
      for(const actor of bosses(world))state.actors.set(actor.id,{species:actor.speciesId,last:null,lastCount:0,history:[],utilityAt:4500*pace/tempo(actor),nav:null,
        attack:idle(actor,(actor.id==='opponent'?450:950)*pace),hit:false});
      worlds.set(world,state);return state;
    }
    function phase(a,name,ms){
      if(name==='recover'&&rocketEonMouths.ranged(a))a.recoveryColumn=rocketEonMouths.pose(a,a.facing).column;
      a.phase=name;a.elapsedMs=0;a.progress=0;a.durationMs=Math.max(name==='windup'||name==='mark'?250:1,ms/(a.speedScale||1));
    }
    function impact(state,actor,kind,p,radius,lifeMs=450){
      state.impacts.push({id:state.nextId++,actorId:actor.id,kind,...point(p),radius,ageMs:0,lifeMs,mega:mega(actor),enraged:!!actor.rocketEonEnraged});
      if(state.impacts.length>30)state.impacts.shift();
    }
    function airborne(world,actor){
      const a=worlds.get(world)?.actors.get(actor.id)?.attack;
      return a?.kind==='dive'&&['rise','hover','mark','fall'].includes(a.phase);
    }
    function landing(world,actor,target){
      const c=world.combat,r=actor.radius+6;
      // Search solid-free feet positions instead of pushing a landing across a wall.
      for(let ring=0;ring<=12;ring++)for(let i=0;i<(ring?16:1);i++){
        const angle=i*Math.PI/8,p={x:clamp(target.x+Math.cos(angle)*ring*36,c.left+r,c.right-r),
          y:clamp(target.y+Math.sin(angle)*ring*36,c.top+r,c.bottom-r)};
        if(!blocked(world,p,p,r))return p;
      }
      return constrain(world,point(actor),actor.radius);
    }
    function cancelPair(world,state){
      if(!state.pair)return;
      for(const actor of bosses(world)){
        const memory=state.actors.get(actor.id);
        if(memory.attack.pairId===state.pair.id){
          if(memory.attack.kind==='dive'){const p=landing(world,actor,actor);actor.x=p.x;actor.y=p.y;}
          memory.attack=idle(actor,500);memory.nav=null;
        }
      }
      state.pair=null;state.nextPairAt=state.clock+2200/tempo(world.opponent);
    }
    function cancelled(world,state,actor){
      const memory=state.actors.get(actor.id);
      if(memory.attack.pairId)cancelPair(world,state);
      memory.attack=idle(actor,450);
      state.projectiles=state.projectiles.filter(shot=>shot.actorId!==actor.id);
    }
    function blocked(world,from,to,radius){
      return !!(world.combat.rocks?.length&&typeof arenaReferenceArenas!=='undefined'&&
        arenaReferenceArenas.blocksShot(world.combat.rocks,from.x,from.y,{...to,radius}));
    }
    function navigation(world,state,radius){
      const key=Math.ceil(radius),cached=state.navigation.get(key);if(cached)return cached;
      const c=world.combat,margin=key+8,points=[],links=new Map();
      for(const rock of c.rocks||[]){
        const left=Math.min(...rock.map(p=>p.x))-margin,right=Math.max(...rock.map(p=>p.x))+margin;
        const top=Math.min(...rock.map(p=>p.y))-margin,bottom=Math.max(...rock.map(p=>p.y))+margin;
        for(const p of [{x:left,y:top},{x:right,y:top},{x:right,y:bottom},{x:left,y:bottom}]){
          if(p.x<c.left+key+2||p.x>c.right-key-2||p.y<c.top+key+2||p.y>c.bottom-key-2||blocked(world,p,p,key+2))continue;
          if(!points.some(other=>distance(p,other)<5))points.push(p);
        }
      }
      const graph={radius:key,points,links};state.navigation.set(key,graph);return graph;
    }
    function route(world,state,actor,goal){
      const graph=navigation(world,state,actor.radius),points=[point(actor),goal,...graph.points],length=points.length;
      const costs=Array(length).fill(Infinity),parents=Array(length).fill(-1),visited=new Set();costs[0]=0;
      const clear=(a,b)=>{
        const key=a<b?a+':'+b:b+':'+a;
        if(a>1&&b>1&&graph.links.has(key))return graph.links.get(key);
        const result=!blocked(world,points[a],points[b],graph.radius+(a>1&&b>1?2:0));
        if(a>1&&b>1)graph.links.set(key,result);return result;
      };
      let best=0;
      for(let count=0;count<length;count++){
        let current=-1,score=Infinity;
        for(let i=0;i<length;i++)if(!visited.has(i)&&costs[i]+distance(points[i],goal)<score){current=i;score=costs[i]+distance(points[i],goal);}
        if(current<0)break;visited.add(current);
        if(distance(points[current],goal)<distance(points[best],goal))best=current;
        if(current===1){best=1;break;}
        for(let next=0;next<length;next++){
          if(visited.has(next))continue;
          const cost=costs[current]+distance(points[current],points[next]);
          if(cost<costs[next]&&clear(current,next)){costs[next]=cost;parents[next]=current;}
        }
      }
      const path=[];for(let node=best;node>0;node=parents[node]){path.unshift(points[node]);if(parents[node]<0)break;}
      return path;
    }
    function navigate(world,state,actor,dt){
      const memory=state.actors.get(actor.id),target=world.player,d=distance(actor,target);
      const shotRadius=Math.max(actor.radius,(mega(actor)?42:34)*size*area(actor));
      const shotFacing=Math.atan2(center(target).y-center(actor).y,target.x-actor.x);
      const shotPose={kind:'laser',phase:'active',progress:0};
      const obstructed=blocked(world,muzzle(actor,shotPose,shotFacing),center(target),shotRadius);
      if(d>=280&&d<=460&&!obstructed){memory.nav=null;return;}
      const angle=Math.atan2(actor.y-target.y,actor.x-target.x),side=actor.id==='third'?1:-1;
      if(!memory.goal||state.clock>=memory.goal.next||distance(memory.goal.target,target)>90){
        let chosen=null,best=Infinity;
        for(const turn of [.24*side,.65*side,-.65*side,1.15*side,-1.15*side,1.7*side,-1.7*side,Math.PI]){
          const p=constrain(world,{x:target.x+Math.cos(angle+turn)*360,y:target.y+Math.sin(angle+turn)*360},actor.radius+3);
          if(blocked(world,p,p,actor.radius))continue;
          const candidate={...actor,x:p.x,y:p.y},facing=Math.atan2(center(target).y-center(candidate).y,target.x-p.x);
          const clear=!blocked(world,muzzle(candidate,shotPose,facing),center(target),shotRadius);
          const score=distance(actor,p)+(clear?0:950)+Math.abs(turn)*12;
          if(score<best){best=score;chosen=p;}
        }
        memory.goal={point:chosen||constrain(world,{x:(world.combat.left+world.combat.right)/2,y:(world.combat.top+world.combat.bottom)/2},actor.radius+3),target:point(target),next:state.clock+500};
      }
      const goal=memory.goal.point;
      let path;
      if(!blocked(world,point(actor),goal,actor.radius)){path=[goal];memory.nav=null;}
      else{
        if(!memory.nav||state.clock>=memory.nav.repathAt&&distance(memory.nav.goal,goal)>90||!memory.nav.path.length&&state.clock>=memory.nav.repathAt)
          memory.nav={goal,path:route(world,state,actor,goal),repathAt:state.clock+650};
        path=memory.nav.path;
      }
      while(path.length&&distance(actor,path[0])<10)path.shift();
      let waypoint=path[0];
      if(!waypoint){
        // A local escape handles a knockback/size change right beside a corner;
        // every candidate is swept against the actual solids before moving.
        let best=Infinity;
        for(let i=0;i<16;i++){
          const turn=i*Math.PI/8,p={x:actor.x+Math.cos(turn)*36,y:actor.y+Math.sin(turn)*36};
          if(p.x<world.combat.left+actor.radius||p.x>world.combat.right-actor.radius||p.y<world.combat.top+actor.radius||p.y>world.combat.bottom-actor.radius||blocked(world,point(actor),p,actor.radius))continue;
          const score=distance(p,goal);if(score<best){best=score;waypoint=p;}
        }
      }
      if(!waypoint)return;
      const length=distance(actor,waypoint),step=Math.min(length,(mega(actor)?188:145)*tempo(actor)*dt/1000),from=point(actor);
      if(length<.001)return;
      const next=Ia(actor.x+(waypoint.x-actor.x)*step/length,actor.y+(waypoint.y-actor.y)*step/length,actor.radius,world.combat,actor.x,actor.y);
      actor.x=next.x;actor.y=next.y;
      if(memory.nav&&distance(from,next)<step*.3)memory.nav=null;
    }
    function chargeEnd(world,actor){
      const from=point(actor),angle=Math.atan2(world.player.y-actor.y,world.player.x-actor.x);
      const end=ray(world,from,angle,Math.min(1050*area(actor),distance(actor,world.player)+260*area(actor)),actor.radius*2),length=distance(from,end);
      const back=Math.min(10,length);
      return constrain(world,{x:end.x-Math.cos(angle)*back,y:end.y-Math.sin(angle)*back},actor.radius);
    }
    function clearMuzzle(world,actor,radius){
      const target=center(world.player),body=center(actor),angle=Math.atan2(target.y-body.y,target.x-body.x);
      const from=muzzle(actor,{kind:'laser',phase:'active',progress:0},angle);
      return !blocked(world,from,{x:from.x+Math.cos(angle)*130,y:from.y+Math.sin(angle)*130},radius);
    }
    function clip(world,from,to,radius=0){
      if(!blocked(world,from,to,radius))return to;
      let lo=0,hi=1;
      for(let i=0;i<11;i++){
        const t=(lo+hi)/2,p={x:from.x+(to.x-from.x)*t,y:from.y+(to.y-from.y)*t};
        if(blocked(world,from,p,radius))hi=t;else lo=t;
      }
      return{x:from.x+(to.x-from.x)*lo,y:from.y+(to.y-from.y)*lo};
    }
    function ray(world,from,angle,range,width){
      const dx=Math.cos(angle),dy=Math.sin(angle),c=world.combat;
      let length=range;
      for(const t of [dx>0?(c.right-from.x)/dx:dx<0?(c.left-from.x)/dx:Infinity,
        dy>0?(c.bottom-from.y)/dy:dy<0?(c.top-from.y)/dy:Infinity])if(t>=0)length=Math.min(length,t);
      return clip(world,from,{x:from.x+dx*length,y:from.y+dy*length},width/2);
    }
    function contact(from,to,target,radius){return oc(from,to,center(target),target.radius+radius)!==null;}
    function damage(world,actor,target,move,factor=1){
      if(world.phase!=='fight'||actor.hp<=0||target.hp<=0||target.iframeMs>0)return false;
      if(target.protectMs>0){world.events.push({type:'block',target:target.id,x:target.x,y:target.y});return true;}
      const amount=Math.max(0,Math.round(world.damage(actor,target,move,false)*factor*strength(actor)));
      world.landHit(actor,target,move,false,amount);return true;
    }
    function immune(world,actor){
      const state=worlds.get(world);
      return !!state?.zones.some(zone=>zone.ageMs<zone.lifeMs&&(zone.mapWide||distance(center(actor),zone)<=zone.radius));
    }
    function cleanse(world,actor){
      if(!immune(world,actor))return false;
      actor.ailment=null;actor.ailmentMs=actor.ailmentClock=0;
      actor.statusGraceMs=Math.max(actor.statusGraceMs,q*2);return true;
    }
    function begin(world,state,actor,kind,coordinated=false){
      const memory=state.actors.get(actor.id),fast=(mega(actor)?.77:1)*pace,from=center(actor),target=center(world.player);
      const a={...idle(actor),kind,phase:'windup',durationMs:750*fast,from,to:target,
        facing:Math.atan2(target.y-from.y,target.x-from.x),fast,pairId:null};
      memory.attack=a;memory.lastCount=memory.last===kind?memory.lastCount+1:1;memory.last=kind;memory.hit=false;
      memory.history.push(kind);if(memory.history.length>4)memory.history.shift();
      a.recoveryMs=(300+state.random()*260)*fast;
      if(!coordinated)state.independentMoves++;
      actor.facing=a.facing;
      if(kind==='laser'||kind==='ice'){
        a.aimAngle=a.facing;a.socketRow=rocketEonMouths.pose(a,a.facing).row;
        a.sweep=coordinated?0:(state.random()<.65?(state.random()<.5?-1:1)*(.12+state.random()*.2):0);
        a.from=muzzle(actor,a);
        a.width=(kind==='ice'?34:44)*(mega(actor)?1.2:1)*size*area(actor);a.range=1350*area(actor);
        a.to=ray(world,a.from,a.facing,a.range,a.width);a.durationMs=(kind==='ice'?680:880)*fast;
      }else if(kind==='plasma'||kind==='hurricane'){
        a.from=muzzle(actor,a);a.radius=(mega(actor)?42:34)*size*area(actor);a.durationMs=720*fast;
        if(kind==='hurricane'){a.radius=(mega(actor)?92:78)*area(actor);a.durationMs=820*fast;}
      }else if(kind==='orbit'){
        a.radius=(mega(actor)?29:25)*area(actor);a.durationMs=700*fast;
        a.orbitRadius=(mega(actor)?122:106)*area(actor);a.count=mega(actor)?7:5;
      }else if(kind==='charge'){
        a.radius=(actor.radius+12)*size*area(actor);a.width=a.radius*2;
        a.from=point(actor);a.to=chargeEnd(world,actor);a.facing=Math.atan2(a.to.y-a.from.y,a.to.x-a.from.x);a.durationMs=700*fast;
      }else{
        a.radius=kind==='field'?Math.hypot(world.combat.right-world.combat.left,world.combat.bottom-world.combat.top):actor.radius*2.4*size;a.durationMs=850*fast;
        a.mapWide=kind==='field';
        if(a.mapWide){const {left,top,right,bottom}=world.combat;a.bounds={left,top,right,bottom};}
        a.to=from;memory.utilityAt=state.clock+(kind==='field'?14000:12500)*pace/tempo(actor);
      }
      if(!coordinated)a.durationMs*=.88+state.random()*.26;
      a.durationMs=Math.max(250,a.durationMs/tempo(actor));
      if(kind==='laser'||kind==='ice')a.activeMs=(kind==='ice'?1000:1200)*fast*(.82+state.random()*.36);
      world.events.push({type:'cast',actor:actor.id,move:kind==='charge'?'steel-wing':kind==='ice'?'ice-beam':kind==='plasma'||kind==='orbit'?'psychic':kind==='hurricane'?'hurricane':kind==='heal'?'recover':'dragon-pulse',x:actor.x,y:actor.y});
    }
    function choose(world,state,actor){
      const memory=state.actors.get(actor.id),latias=actor.id==='third',d=distance(actor,world.player);
      const partner=latias?world.opponent:world.third,ownMissing=1-actor.hp/actor.maxHp;
      const urgency=Math.max(ownMissing,partner.hp>0?(1-partner.hp/partner.maxHp)*(latias?.7:.4):0);
      const weights={laser:d>450?2.2:1.5,[latias?'ice':'plasma']:2,[latias?'orbit':'hurricane']:2.15,charge:d<650?1.8:1.1};
      if(distance(actor,chargeEnd(world,actor))<160)delete weights.charge;
      if(!clearMuzzle(world,actor,22*(mega(actor)?1.2:1)*size*area(actor)))delete weights.laser;
      if(!clearMuzzle(world,actor,(latias?17*(mega(actor)?1.2:1):mega(actor)?42:34)*size*area(actor)))delete weights[latias?'ice':'plasma'];
      if(!latias&&!clearMuzzle(world,actor,(mega(actor)?92:78)*area(actor)))delete weights.hurricane;
      if(state.clock>=memory.utilityAt&&urgency>.2)weights[latias?'heal':'field']=urgency<.35?.18:.4+urgency*urgency*4;
      const pairRequired=bosses(world).every(other=>other.hp>0&&mega(other));
      if(pairRequired)delete weights.laser;
      const choices=Object.keys(weights);
      for(const kind of choices){
        const recent=memory.history.filter(item=>item===kind).length;
        weights[kind]*=(.7+state.random()*.6)/(1+recent*.3);
      }
      const weight=kind=>weights[kind]*(kind===memory.last?(memory.lastCount>=3?0:.42):1);
      let total=choices.reduce((sum,kind)=>sum+weight(kind),0);
      // Repeating the only clear ranged attack is preferable to a blocked dash.
      if(!choices.length)return null;
      if(!total)return choices[0];
      let roll=state.random()*total;
      for(const kind of choices){roll-=weight(kind);if(roll<0)return kind;}
      return choices[choices.length-1];
    }
    function ready(memory){const a=memory.attack;return a.phase==='idle'&&a.progress>=1||a.phase==='recover'&&a.durationMs-a.elapsedMs<160;}
    function beginBeamPair(world,state,pair){
      const actors=bosses(world),origin={x:(center(actors[0]).x+center(actors[1]).x)/2,y:(center(actors[0]).y+center(actors[1]).y)/2};
      const target=center(world.player),angle=Math.atan2(target.y-origin.y,target.x-origin.x);
      const bothMega=actors.every(mega),length=clamp(distance(origin,target)*(.46+state.random()*.22),200,520);
      Object.assign(pair,{origin,angle,length,sweep:(bothMega||state.random()<.35)?(state.random()<.5?-1:1)*(.18+state.random()*.2):0});
      const windup=(bothMega?760:900)*pace*(.92+state.random()*.2),active=(bothMega?1500:1250)*pace*(.85+state.random()*.3);
      for(const actor of actors){begin(world,state,actor,'laser',true);const a=state.actors.get(actor.id).attack;
        const join={x:origin.x+Math.cos(angle)*length,y:origin.y+Math.sin(angle)*length};
        a.facing=Math.atan2(join.y-center(actor).y,join.x-center(actor).x);
        delete a.socketRow;a.socketRow=rocketEonMouths.pose(a,a.facing).row;
        a.from=muzzle(actor,a);actor.facing=a.facing;
        a.pairId=pair.id;a.durationMs=Math.max(250,windup/tempo(actor));a.activeMs=active;}
    }
    function crossPaths(world,target=point(world.player)){
      return bosses(world).map(actor=>{
        const from=point(actor),angle=Math.atan2(target.y-from.y,target.x-from.x);
        const raw=ray(world,from,angle,Math.min(1100*area(actor),distance(from,target)+310*area(actor)),actor.radius*2+8);
        const to=constrain(world,{x:raw.x-Math.cos(angle)*Math.min(10,distance(from,raw)),
          y:raw.y-Math.sin(angle)*Math.min(10,distance(from,raw))},actor.radius);
        return{from,to,angle};
      });
    }
    function beginCross(world,state,pair){
      const paths=crossPaths(world),actors=bosses(world),warning=pair.pass>1?680:760;
      for(let i=0;i<actors.length;i++){
        const actor=actors[i],memory=state.actors.get(actor.id),path=paths[i];
        memory.attack={...idle(actor),kind:'cross',phase:'windup',durationMs:Math.max(250,warning/tempo(actor)),pairId:pair.id,
          from:path.from,to:path.to,facing:path.angle,pass:pair.pass,width:(mega(actor)?132:110)*area(actor),radius:(mega(actor)?66:55)*area(actor)};
        memory.hit=false;memory.nav=null;actor.facing=path.angle;
        world.events.push({type:'cast',actor:actor.id,move:'dragon-pulse',x:actor.x,y:actor.y});
      }
    }
    function beginPair(world,state){
      const actors=bosses(world),paths=crossPaths(world),choices=['dive'];
      if(actors.every(actor=>clearMuzzle(world,actor,22*(mega(actor)?1.2:1)*size*area(actor))))choices.push('laser');
      // Both paths must pass the target before a cross is selected. Clipped
      // paths still use their actual ends for telegraphs and swept movement.
      if(paths.every((path,i)=>distance(path.from,path.to)>distance(actors[i],world.player)+70)&&
        Math.abs(Math.sin(paths[0].angle-paths[1].angle))>.22)choices.push('cross');
      const fresh=choices.filter(kind=>kind!==state.lastPair),pool=fresh.length?fresh:choices;
      const kind=pool[Math.floor(state.random()*pool.length)];
      const pair={id:state.nextId++,kind,pass:1,mega:actors.every(mega)};
      state.pair=pair;state.lastPair=kind;state.wantPair=false;state.independentMoves=0;
      state.pairMinimum=2+Math.floor(state.random()*3);state.nextPairAt=state.clock+(3900+state.random()*3300)*pace/tempo(actors[0]);
      if(kind==='laser'){beginBeamPair(world,state,pair);return;}
      if(kind==='cross'){beginCross(world,state,pair);return;}
      for(const actor of actors){
        const memory=state.actors.get(actor.id);
        memory.attack={...idle(actor),kind:'dive',phase:'rise',durationMs:460/tempo(actor),pairId:pair.id,
          from:point(actor),to:point(actor),flyHeight:0,radius:(mega(actor)?148:122)*area(actor)};
        memory.hit=false;memory.nav=null;
      }
    }
    function markDive(world,state,actor){
      const a=state.actors.get(actor.id).attack,p=landing(world,actor,point(world.player));
      a.from=point(actor);a.to=p;a.flyHeight=240;a.facing=Math.atan2(world.player.y-a.from.y,world.player.x-a.from.x);
      actor.x=p.x;actor.y=p.y;actor.facing=a.facing;phase(a,'mark',550);
      world.events.push({type:'cast',actor:actor.id,move:'dragon-pulse',x:p.x,y:p.y});
    }
    function tickPair(world,state,dt){
      const pair=state.pair;if(!pair||pair.kind==='laser')return;
      const actors=bosses(world),attacks=actors.map(actor=>state.actors.get(actor.id).attack);
      if(actors.some(actor=>!movable(actor))||attacks.some(a=>a.pairId!==pair.id)){cancelPair(world,state);return;}
      if(pair.kind==='cross'){
        if(attacks.every(a=>a.phase==='windup'&&a.progress>=1)){
          const duration=Math.max(...attacks.map(a=>distance(a.from,a.to)))/(pair.mega?1750:1450)*1000;
          for(const a of attacks)phase(a,'active',Math.max(250,duration));
        }else if(attacks.every(a=>a.phase==='active')){
          for(let i=0;i<actors.length;i++){
            const actor=actors[i],a=attacks[i],memory=state.actors.get(actor.id),previous=point(actor);
            const p={x:a.from.x+(a.to.x-a.from.x)*a.progress,y:a.from.y+(a.to.y-a.from.y)*a.progress};
            const next=Ia(p.x,p.y,actor.radius,world.combat,actor.x,actor.y);actor.x=next.x;actor.y=next.y;
            if(!memory.hit&&contact(previous,next,world.player,a.radius)&&!blocked(world,center(actor),center(world.player),1)&&
              damage(world,actor,world.player,'dragon-pulse',1.15)){memory.hit=true;impact(state,actor,'cross',center(world.player),a.radius,550);}
          }
          if(attacks.every(a=>a.progress>=1)){
            if(pair.mega&&pair.pass===1){pair.pass=2;beginCross(world,state,pair);}
            else for(const a of attacks)phase(a,'recover',430);
          }
        }
      }else{
        for(let i=0;i<actors.length;i++){
          const actor=actors[i],a=attacks[i];
          if(a.phase==='rise'){
            a.flyHeight=240*(1-Math.pow(1-a.progress,2));actor.x=a.from.x;actor.y=a.from.y;
            if(a.progress>=1){phase(a,'hover',5000);a.flyHeight=240;}
          }else if(a.phase==='mark'){
            actor.x=a.to.x;actor.y=a.to.y;a.flyHeight=240;
            if(a.progress>=1)phase(a,'fall',400);
          }else if(a.phase==='fall'){
            actor.x=a.to.x;actor.y=a.to.y;a.flyHeight=240*(1-a.progress*a.progress);
            if(a.progress>=1){
              a.flyHeight=0;impact(state,actor,'dive',a.to,a.radius,650);
              if(distance(a.to,center(world.player))<=a.radius+world.player.radius&&!blocked(world,a.to,center(world.player),1))
                damage(world,actor,world.player,'dragon-pulse',1.6);
              phase(a,'recover',600);
              if(i===0&&attacks[1].phase==='hover')markDive(world,state,actors[1]);
            }
          }
        }
        if(attacks.every(a=>a.phase==='hover'))markDive(world,state,actors[0]);
      }
      if(attacks.every(a=>a.phase==='recover'&&a.progress>=1)){
        for(const actor of actors)state.actors.get(actor.id).attack=idle(actor,(180+state.random()*260)*pace);
        state.pair=null;
      }
    }
    function heal(world,state,actor){
      for(const [target,ratio]of [[actor,.08],[world.opponent,.04]]){
        if(target.hp<=0)continue;
        const amount=Math.max(0,Math.round((target.maxHp-target.hp)*ratio));
        if(!amount)continue;
        target.hp=Math.min(target.maxHp,target.hp+amount);world.rememberHp(target);
        world.events.push({type:'heal',actor:actor.id,target:target.id,amount,x:target.x,y:target.y});
        impact(state,target,'heal',center(target),target.radius*2.4*size,850);
      }
    }
    function orbit(world,state,actor,a){
      const order=Array.from({length:a.count},(_,i)=>i);
      for(let i=order.length-1;i>0;i--){const j=Math.floor(state.random()*(i+1));[order[i],order[j]]=[order[j],order[i]];}
      const turn=state.random()*Math.PI*2,spacing=mega(actor)?180:230,origin=center(actor);
      for(let i=0;i<a.count;i++){
        const angle=turn+i*Math.PI*2/a.count;
        state.projectiles.push({id:state.nextId++,actorId:actor.id,kind:'psy-bomb',phase:'orbit',
          x:origin.x+Math.cos(angle)*a.orbitRadius,y:origin.y+Math.sin(angle)*a.orbitRadius,vx:0,vy:0,
          radius:a.radius,ageMs:0,lifeMs:(450+spacing*a.count+2800*area(actor))/tempo(actor),mega:mega(actor),enraged:!!actor.rocketEonEnraged,
          speedScale:tempo(actor),orbitAngle:angle,orbitRadius:a.orbitRadius,orbitCenter:point(origin),launchMs:(450+order.indexOf(i)*spacing)/tempo(actor),
          curve:state.random()<.6?(state.random()<.5?-1:1)*(85+state.random()*125)*area(actor):0});
      }
    }
    function tickActor(world,state,actor,dt){
      const memory=state.actors.get(actor.id),a=memory.attack;
      if(a.phase==='mega'){if(a.progress>=1)memory.attack=idle(actor,300);return;}
      if(a.pairId&&['dive','cross'].includes(a.kind))return;
      if(a.kind==='idle'){
        const target=world.player,angle=Math.atan2(target.y-actor.y,target.x-actor.x);
        actor.facing=angle;
        navigate(world,state,actor,dt);
        a.from=a.to=center(actor);
        if(a.progress>=1){const kind=choose(world,state,actor);if(kind)begin(world,state,actor,kind);}
        return;
      }
      actor.facing=a.facing;
      if(['laser','ice','plasma','hurricane'].includes(a.kind))a.from=muzzle(actor,a);
      if(a.phase==='windup'&&a.progress>=1){
        phase(a,'active',a.kind==='charge'?clamp(distance(a.from,a.to)/(mega(actor)?1562:1250)*1000,210,720):
          a.kind==='laser'?(a.activeMs||1200*a.fast):a.kind==='ice'?(a.activeMs||1000*a.fast):
            a.kind==='orbit'?450+(mega(actor)?180:230)*a.count:280*pace);
        if(a.kind==='plasma'||a.kind==='hurricane'){
          const speed=(a.kind==='hurricane'?(mega(actor)?550:475):(mega(actor)?740:580)*1.25)*tempo(actor);
          // phase() resets the animation to its release frame before emission.
          a.from=muzzle(actor,a);
          state.projectiles.push({id:state.nextId++,actorId:actor.id,kind:a.kind,phase:'flying',...a.from,
            vx:Math.cos(a.facing)*speed,vy:Math.sin(a.facing)*speed,radius:a.radius,ageMs:0,
            lifeMs:(a.kind==='hurricane'?3400:2700)*area(actor)/tempo(actor),mega:mega(actor),enraged:!!actor.rocketEonEnraged});
        }else if(a.kind==='orbit'){
          orbit(world,state,actor,a);
        }else if(a.kind==='field'){
          const {left,top,right,bottom}=world.combat;
          state.zones.push({id:state.nextId++,actorId:actor.id,kind:'status-field',...center(actor),radius:a.radius,
            mapWide:true,bounds:{left,top,right,bottom},ageMs:0,lifeMs:5000,mega:mega(actor),enraged:!!actor.rocketEonEnraged});
          for(const fighter of world.fighters())cleanse(world,fighter);
        }else if(a.kind==='heal')heal(world,state,actor);
      }else if(a.phase==='active'){
        if(a.kind==='charge'){
          const previous=point(actor),p={x:a.from.x+(a.to.x-a.from.x)*a.progress,y:a.from.y+(a.to.y-a.from.y)*a.progress};
          const next=Ia(p.x,p.y,actor.radius,world.combat,actor.x,actor.y);actor.x=next.x;actor.y=next.y;
          if(!memory.hit&&contact(previous,next,world.player,a.radius)&&!blocked(world,center(actor),center(world.player),1)&&damage(world,actor,world.player,'steel-wing',1)){
            memory.hit=true;impact(state,actor,'charge',center(world.player),a.radius);
          }
        }
        if(a.progress>=1){memory.nav=null;phase(a,'recover',a.recoveryMs||420*a.fast);}
      }else if(a.phase==='recover'){
        navigate(world,state,actor,dt);
        if(a.progress>=1)memory.attack=idle(actor,(140+state.random()*470)*pace);
      }
    }
    function intersection(a,b){
      const ax=a.to.x-a.from.x,ay=a.to.y-a.from.y,bx=b.to.x-b.from.x,by=b.to.y-b.from.y,den=ax*by-ay*bx;
      if(Math.abs(den)<.001)return null;
      const dx=b.from.x-a.from.x,dy=b.from.y-a.from.y,t=(dx*by-dy*bx)/den,u=(dx*ay-dy*ax)/den;
      return t>.025&&t<.98&&u>.025&&u<.98?{x:a.from.x+ax*t,y:a.from.y+ay*t}:null;
    }
    function beamGeometry(world,state,sample=null){
      const raw=[],preview=Number.isFinite(sample)||typeof sample==='function',pair=state.pair;
      const progress=a=>typeof sample==='function'?sample(a):sample;
      let sharedJoin=null,outgoing=0;
      if(pair?.kind==='laser'){
        const attack=bosses(world).map(actor=>state.actors.get(actor.id).attack).find(a=>a.pairId===pair.id);
        if(attack){
          const t=preview?progress(attack):attack.phase==='active'?attack.progress:0,eased=t*t*(3-2*t),c=world.combat;
          outgoing=pair.angle+pair.sweep*(eased-.5);
          // One planned junction drives both beams. Scenery may block the
          // junction, but must never push it between unrelated nearby edges.
          sharedJoin={x:clamp(pair.origin.x+Math.cos(outgoing)*pair.length,c.left+40,c.right-40),
            y:clamp(pair.origin.y+Math.sin(outgoing)*pair.length,c.top+40,c.bottom-40)};
        }
      }
      for(const actor of bosses(world)){
        const a=state.actors.get(actor.id).attack;
        if(actor.hp<=0||!['laser','ice'].includes(a.kind)||!['windup','active'].includes(a.phase))continue;
        let from=muzzle(actor,a),angle=a.facing;
        if(a.pairId&&pair?.id===a.pairId&&sharedJoin){
          // socketRow stays fixed through this cast; looping mouth pixels cannot
          // feed back into an eight-way facing flip while the laser sweeps.
          angle=Math.atan2(sharedJoin.y-from.y,sharedJoin.x-from.x);
        }else if(a.sweep){
          const t=preview?progress(a):a.phase==='active'?a.progress:0,eased=t*t*(3-2*t);
          angle=a.aimAngle+a.sweep*(eased-.5);
        }
        from=muzzle(actor,a,angle);
        if(!preview){a.facing=angle;actor.facing=angle;a.from=point(from);}
        raw.push({id:'beam-'+actor.id,actorId:actor.id,kind:a.kind,from,to:ray(world,from,angle,a.range,a.width),
          width:a.width,pairId:a.pairId,merged:false,phase:a.phase,progress:a.progress,durationMs:a.durationMs,elapsedMs:a.elapsedMs,mega:mega(actor),enraged:!!actor.rocketEonEnraged});
      }
      if(raw.length===2&&raw.every(beam=>beam.kind==='laser')&&raw[0].phase===raw[1].phase){
        const coordinated=sharedJoin&&raw.every(beam=>beam.pairId===pair.id);
        const join=coordinated?
          (raw.every(beam=>distance(beam.from,sharedJoin)>1&&distance(beam.from,beam.to)+1>=distance(beam.from,sharedJoin)&&
            !blocked(world,beam.from,sharedJoin,beam.width/2))?sharedJoin:null):intersection(raw[0],raw[1]);
        if(join){
          const unit=beam=>{const d=Math.max(.001,distance(beam.from,join));return{x:(join.x-beam.from.x)/d,y:(join.y-beam.from.y)/d};};
          const first=unit(raw[0]),second=unit(raw[1]),direction={x:first.x+second.x,y:first.y+second.y};
          if(coordinated||Math.hypot(direction.x,direction.y)>.35){
            raw[0].to=raw[1].to=join;
            const width=Math.max(raw[0].width,raw[1].width)*2.1;
            raw.push({id:'beam-merged',actorId:'opponent',kind:'laser',from:join,
              to:ray(world,join,coordinated?outgoing:Math.atan2(direction.y,direction.x),1200*area(world.opponent),width),width,merged:true,
              phase:raw[0].phase,progress:raw[0].progress,durationMs:raw[0].durationMs,elapsedMs:raw[0].elapsedMs,mega:raw.some(beam=>beam.mega),enraged:raw.some(beam=>beam.enraged)});
          }
        }
      }
      return raw;
    }
    function beams(world,state){
      state.beams=beamGeometry(world,state);
      if(state.beams.some(beam=>beam.phase==='windup')&&(state.pair?.sweep||bosses(world).some(actor=>state.actors.get(actor.id).attack.sweep))){
        const samples=Array.from({length:7},(_,index)=>beamGeometry(world,state,index/6));
        for(const beam of state.beams){
          if(beam.phase!=='windup')continue;
          beam.sweepSamples=samples.map(segments=>segments.find(other=>other.id===beam.id)).filter(Boolean).map(segment=>({from:segment.from,to:segment.to}));
          beam.sweepEnd=beam.sweepSamples[beam.sweepSamples.length-1];
        }
      }
      if(state.clock<state.nextBeamHit)return;
      const target=world.player;
      const hits=state.beams.filter(beam=>beam.phase==='active'&&contact(beam.from,beam.to,target,beam.width/2));
      if(!hits.length)return;
      // One pulse at an intersection, including where its upstream segments meet.
      hits.sort((a,b)=>Number(b.merged)-Number(a.merged));const beam=hits[0],actor=world.fighterOf(beam.actorId);
      damage(world,actor,target,beam.kind==='ice'?'ice-beam':'dragon-pulse',beam.merged?.30:beam.kind==='ice'?.18:.16);
      // Active duration and pulse interval share one speed factor, preserving
      // the number of damage pulses per cast as attack cadence changes.
      state.nextBeamHit=state.clock+160*pace/tempo(actor);
    }
    function effects(world,state,dt){
      state.impacts=state.impacts.filter(effect=>(effect.ageMs+=dt)<effect.lifeMs);
      state.zones=state.zones.filter(zone=>(zone.ageMs+=dt)<zone.lifeMs);
      state.projectiles=state.projectiles.filter(shot=>{
        shot.ageMs+=dt;const actor=world.fighterOf(shot.actorId);
        if(shot.ageMs>=shot.lifeMs||actor.hp<=0)return false;
        if(shot.kind==='psy-bomb'&&shot.phase==='orbit'){
          const origin=center(actor),angle=shot.orbitAngle+shot.ageMs*.0018*shot.speedScale;
          shot.orbitCenter=point(origin);shot.x=origin.x+Math.cos(angle)*shot.orbitRadius;shot.y=origin.y+Math.sin(angle)*shot.orbitRadius;
          if(shot.ageMs<shot.launchMs)return true;
          shot.phase='flying';shot.from=point(shot);shot.to=point(center(world.player));shot.flightMs=0;
          const dx=shot.to.x-shot.x,dy=shot.to.y-shot.y,length=Math.max(1,Math.hypot(dx,dy)),speed=(mega(actor)?870:730)*shot.speedScale;
          shot.travelMs=clamp(length/speed*1000,280/shot.speedScale,1800/shot.speedScale);
          shot.control={x:(shot.x+shot.to.x)/2-dy/length*shot.curve,y:(shot.y+shot.to.y)/2+dx/length*shot.curve};
          shot.vx=(shot.to.x-shot.control.x)*2000/shot.travelMs;shot.vy=(shot.to.y-shot.control.y)*2000/shot.travelMs;
        }
        const from=point(shot);let to={x:shot.x+shot.vx*dt/1000,y:shot.y+shot.vy*dt/1000};
        if(shot.kind==='psy-bomb'){
          shot.flightMs+=dt;
          const t=Math.min(1,shot.flightMs/shot.travelMs),u=1-t,over=Math.max(0,shot.flightMs-shot.travelMs)/1000;
          // A fixed quadratic arc, then its exit tangent: never chase the player.
          to={x:u*u*shot.from.x+2*u*t*shot.control.x+t*t*shot.to.x+shot.vx*over,
            y:u*u*shot.from.y+2*u*t*shot.control.y+t*t*shot.to.y+shot.vy*over};
        }
        if(blocked(world,from,to,shot.radius)){impact(state,actor,shot.kind,clip(world,from,to,shot.radius),shot.radius);return false;}
        shot.x=to.x;shot.y=to.y;
        if(shot.x<0||shot.y<0||shot.x>Ca||shot.y>wa)return false;
        const move=shot.kind==='hurricane'?'hurricane':'psychic',factor=shot.kind==='hurricane'?1.5:shot.kind==='psy-bomb'?.62:1;
        if(contact(from,to,world.player,shot.radius)&&damage(world,actor,world.player,move,factor)){
          impact(state,actor,shot.kind,center(world.player),shot.radius);return false;
        }
        return true;
      });
    }
    function enrageSurvivor(world,state){
      if(state.enragedId)return;
      const alive=bosses(world).filter(actor=>actor.hp>0);
      if(alive.length!==1)return;
      const actor=alive[0],memory=state.actors.get(actor.id);
      cancelled(world,state,actor);
      state.projectiles=[];state.beams=[];state.zones=[];state.wantPair=false;
      state.enragedId=actor.id;actor.rocketEonEnraged=true;
      memory.utilityAt=state.clock+Math.max(0,memory.utilityAt-state.clock)/1.25;
      memory.attack=idle(actor,700);memory.nav=null;
      impact(state,actor,'enrage',center(actor),actor.radius*4*area(actor),1100);
    }
    function step(world,dt){
      const state=worlds.get(world)||reset(world);
      if(world.phase!=='fight'){cancelPair(world,state);state.beams=[];state.projectiles=[];state.zones=[];return;}
      if(!(dt>0))return;state.clock+=dt;enrageSurvivor(world,state);
      for(const actor of bosses(world)){
        const memory=state.actors.get(actor.id);
        if(actor.speciesId!==memory.species){
          cancelled(world,state,actor);memory.species=actor.speciesId;
          memory.attack={...idle(actor,700),phase:'mega'};impact(state,actor,'mega',center(actor),actor.radius*2,900);
        }
        if(!movable(actor)){if(memory.attack.phase!=='mega')cancelled(world,state,actor);continue;}
        const a=memory.attack;a.elapsedMs+=dt;a.progress=clamp(a.elapsedMs/a.durationMs,0,1);
      }
      effects(world,state,dt);
      const actors=bosses(world);
      if(!state.pair&&actors.every(actor=>actor.hp>0&&mega(actor))&&actors.some(actor=>state.actors.get(actor.id).attack.kind==='laser')){
        for(const actor of actors)if(state.actors.get(actor.id).attack.kind==='laser')cancelled(world,state,actor);
        state.wantPair=true;
      }
      const pairDue=actors.every(actor=>actor.hp>0)&&!state.pair&&state.independentMoves>=state.pairMinimum&&state.clock>=state.nextPairAt;
      const pairReady=actors.every(actor=>movable(actor)&&ready(state.actors.get(actor.id)));
      // One scheduled opportunity, never a fresh random roll every frame of
      // shared recovery. At least two independent moves separate coordinated moves.
      if(pairDue&&pairReady)beginPair(world,state);
      else if(pairDue&&actors.every(actor=>actor.hp>0))state.wantPair=true;
      tickPair(world,state,dt);
      for(const actor of actors){
        if(!movable(actor))continue;
        const memory=state.actors.get(actor.id);
        // Once due, let one partner finish its current move before pairing.
        const partner=actors.find(other=>other!==actor),partnerMemory=state.actors.get(partner.id),other=partnerMemory.attack;
        if(pairDue&&state.wantPair&&ready(memory)&&movable(partner)&&other.phase!=='mega'&&!ready(partnerMemory))continue;
        tickActor(world,state,actor,dt);
      }
      if(state.pair&&!actors.some(actor=>state.actors.get(actor.id).attack.pairId===state.pair.id))state.pair=null;
      beams(world,state);
    }
    function autoProtectThreat(world,horizonMs,predictPlayer){
      const state=worlds.get(world);
      if(!state||world.phase!=='fight'||world.player.hp<=0)return false;
      const probe=rocketBossAttacks.threatProbe(world,horizonMs,predictPlayer);
      const dangerous=(actor,move,factor=1,total=1)=>Math.round(probe.damage(actor,move)*factor*strength(actor))*total>12;
      const shotThreat=(shot,start=0)=>{
        const actor=world.fighterOf(shot.actorId);if(actor.hp<=0)return false;
        const kind=shot.kind,move=kind==='hurricane'?'hurricane':'psychic',factor=kind==='hurricane'?1.5:kind==='psy-bomb'?.62:1;
        if(!dangerous(actor,move,factor))return false;
        if(kind!=='psy-bomb')return probe.projectile(shot,start);
        let from=shot.from,to=shot.to,control=shot.control,travel=shot.travelMs,flight=shot.flightMs||0,vx=shot.vx,vy=shot.vy;
        if(shot.phase==='orbit'){
          start=Math.max(0,shot.launchMs-shot.ageMs);if(start>probe.horizon)return false;
          const origin=center(actor),angle=shot.orbitAngle+(shot.ageMs+start)*.0018*shot.speedScale;
          from={x:origin.x+Math.cos(angle)*shot.orbitRadius,y:origin.y+Math.sin(angle)*shot.orbitRadius};
          to=predictPlayer(start,true)||center(world.player);
          const dx=to.x-from.x,dy=to.y-from.y,length=Math.max(1,Math.hypot(dx,dy)),speed=(mega(actor)?870:730)*shot.speedScale;
          travel=clamp(length/speed*1000,280/shot.speedScale,1800/shot.speedScale);flight=0;
          control={x:(from.x+to.x)/2-dy/length*shot.curve,y:(from.y+to.y)/2+dx/length*shot.curve};
          vx=(to.x-control.x)*2000/travel;vy=(to.y-control.y)*2000/travel;
        }
        if(!from||!to||!control||!(travel>0))return false;
        return probe.sweep(time=>{
          const age=flight+time-start,t=Math.min(1,age/travel),u=1-t,over=Math.max(0,age-travel)/1000;
          return{x:u*u*from.x+2*u*t*control.x+t*t*to.x+vx*over,y:u*u*from.y+2*u*t*control.y+t*t*to.y+vy*over};
        },shot.radius,start,Math.min(probe.horizon,shot.lifeMs-shot.ageMs-q),true);
      };
      for(const shot of state.projectiles)if(shotThreat(shot))return true;
      for(const actor of bosses(world)){
        if(!movable(actor))continue;
        const memory=state.actors.get(actor.id),a=memory.attack,left=Math.max(0,a.durationMs-a.elapsedMs);
        if(['plasma','hurricane'].includes(a.kind)&&a.phase==='windup'&&left<=probe.horizon){
          const speed=(a.kind==='hurricane'?(mega(actor)?550:475):(mega(actor)?740:580)*1.25)*tempo(actor);
          const from=muzzle(actor,{...a,phase:'active',progress:0,elapsedMs:0});
          if(shotThreat({actorId:actor.id,kind:a.kind,...from,vx:Math.cos(a.facing)*speed,vy:Math.sin(a.facing)*speed,
            radius:a.radius,ageMs:0,lifeMs:(a.kind==='hurricane'?3400:2700)*area(actor)/tempo(actor)},left))return true;
        }
        if(['charge','cross'].includes(a.kind)&&['windup','active'].includes(a.phase)&&!memory.hit&&
          dangerous(actor,a.kind==='cross'?'dragon-pulse':'steel-wing',a.kind==='cross'?1.15:1)){
          const delay=a.phase==='windup'?left+q:0,elapsed=a.phase==='active'?a.elapsedMs:0;
          const crossLength=a.kind==='cross'?Math.max(...bosses(world).map(b=>{const attack=state.actors.get(b.id).attack;return distance(attack.from,attack.to);})):0;
          const duration=a.phase==='active'?a.durationMs:a.kind==='charge'?clamp(distance(a.from,a.to)/(mega(actor)?1562:1250)*1000,210,720)/tempo(actor):
            Math.max(250,crossLength/(state.pair?.mega?1750:1450)*1000)/tempo(actor);
          if(probe.sweep(time=>{const t=clamp((elapsed+time-delay)/duration,0,1);return{x:a.from.x+(a.to.x-a.from.x)*t,y:a.from.y+(a.to.y-a.from.y)*t};},
            a.radius,delay,delay+duration-elapsed,true))return true;
        }
        if(a.kind==='dive'&&['mark','fall'].includes(a.phase)&&dangerous(actor,'dragon-pulse',1.6)&&
          probe.disc(a.to,a.radius,left+(a.phase==='mark'?400/tempo(actor):0),true))return true;
      }
      // Predict each beam's own animation/sweep clock; never advance the live
      // mouth anchors, combined junction or random attack scheduler.
      for(let time=Math.max(q,state.nextBeamHit-state.clock);time<=probe.horizon;time+=q){
        const actors=new Map();
        for(const actor of bosses(world)){
          const memory=state.actors.get(actor.id),a=memory.attack;
          let next=a;
          if(['laser','ice'].includes(a.kind)&&['windup','active'].includes(a.phase)){
            const delay=a.phase==='windup'?Math.max(0,a.durationMs-a.elapsedMs):0;
            const duration=a.phase==='windup'?(a.activeMs||(a.kind==='ice'?1000:1200)*a.fast)/tempo(actor):a.durationMs;
            const elapsed=a.phase==='active'?a.elapsedMs+time:time-delay;
            next={...a,phase:elapsed<0?'windup':elapsed>=duration?'recover':'active',durationMs:duration,
              elapsedMs:Math.max(0,elapsed),progress:clamp(elapsed/duration,0,1)};
          }
          actors.set(actor.id,{...memory,attack:next});
        }
        const forecast={...state,actors};
        for(const beam of beamGeometry(world,forecast,a=>a.phase==='active'?a.progress:0)){
          if(beam.phase!=='active')continue;
          const actor=world.fighterOf(beam.actorId),a=actors.get(actor.id).attack;
          const count=Math.max(1,Math.ceil((a.durationMs-a.elapsedMs)/(160*pace/tempo(actor))));
          if(dangerous(actor,beam.kind==='ice'?'ice-beam':'dragon-pulse',beam.merged?.30:beam.kind==='ice'?.18:.16,count)&&
            probe.beam(beam.from,beam.to,beam.width,time))return true;
        }
      }
      return false;
    }
    function snapshot(world,result){
      const state=worlds.get(world);if(!state)return result;
      result.rocketEonBoss={bosses:bosses(world).map(actor=>({actorId:actor.id,speciesId:actor.speciesId,hp:actor.hp,maxHp:actor.maxHp,
        mega:mega(actor),enraged:!!actor.rocketEonEnraged,attack:structuredClone(state.actors.get(actor.id).attack)})),
        beams:structuredClone(state.beams),projectiles:structuredClone(state.projectiles),zones:structuredClone(state.zones),impacts:structuredClone(state.impacts)};
      return result;
    }
    return Object.freeze({reset,step,snapshot,immune,cleanse,airborne,autoProtectThreat,clear:world=>worlds.delete(world)});
  }
  function arenaEonBossWorldType(){
    return class RocketEonBossWorld extends bc {
      constructor(options={}){
        // Exact-form construction is an offline-AI option; disable native AI
        // immediately afterward and provide only our own boss choreography.
        super({...options,ai:true,playerAi:false,cpuSwitch:false,rosterForms:true,difficulty:'hard',clock:'countup',
          stageId:arenaEonBoss.stage,arenaCpuMode:null,thirdPartyIds:undefined,thirdPartyLoadouts:undefined,
          story:null,bossAdvantage:undefined,partyHpRatio:null,opponentSpeciesId:'latios',opponentPartyIds:['latios'],
          opponentPartyLoadouts:[un('latios').slice()]});
        this.bossDifficulty=arenaBossDifficulty.get('eon');
        this.arenaEonBoss=true;this.thirdPartyIds=['latias'];this.thirdPartyLoadouts=[un('latias').slice()];
        this.initThird();this.configureEon();
      }
      configureEon(){
        this.eonTransforming=new Set();this.ai=false;this.playerAi=false;this.cpuSwitch=false;
        this.eonSharedMega=false;
        this.foeMegaUsed=this.thirdMegaUsed=false;
        this.placeFighter('player',600,640);this.placeFighter('opponent',1420,500);this.placeFighter('third',1450,760);
        for(const actor of [this.opponent,this.third]){actor.rocketEonEnraged=false;this.resizeEon(actor);actor.hp=actor.maxHp;this.rememberHp(actor);}
        rocketEonBossCombat.reset(this);
      }
      resizeEon(actor){
        actor.rocketEonDifficulty=this.bossDifficulty;
        actor.maxHp=Math.round(arenaEonBoss.hp*(this.bossDifficulty?.health||1));actor.rocketBossScale=arenaEonBoss.visualScale(actor.speciesId);
        const species=dn(actor.speciesId);actor.radius=arenaEonBoss.radius;
        const p=Ia(actor.x,actor.y,actor.radius,this.combat,actor.x,actor.y);actor.x=p.x;actor.y=p.y;
        const member=this.partyOf(actor.id)[0];if(member)member.species={...species,maxHp:actor.maxHp,radius:actor.radius};
      }
      reset(){super.reset();if(this.arenaEonBoss)this.configureEon();}
      rocketAutoProtectThreat(horizonMs,predictPlayer){return rocketEonBossCombat.autoProtectThreat(this,horizonMs,predictPlayer);}
      adopt(actor,species,hp){super.adopt(actor,species,hp);if(this.arenaEonBoss&&actor.id!=='player')this.resizeEon(actor);}
      canMega(side){
        if(this.arenaEonBoss&&side!=='player')return this.eonTransforming?.has(side)&&this.phase==='fight'&&this.fighterOf(side).hp>0&&!this.megaUsedOf(side);
        return super.canMega(side);
      }
      enemies(actor){return this.arenaEonBoss?this.fighters().filter(other=>other.hp>0&&(actor.id==='player'?other.id!=='player':other.id==='player')):super.enemies(actor);}
      nearestEnemy(actor){return this.enemies(actor).sort((a,b)=>Math.hypot(a.x-actor.x,a.y-actor.y)-Math.hypot(b.x-actor.x,b.y-actor.y))[0]||(actor.id==='player'?this.opponent:this.player);}
      landHit(actor,target,...args){if(this.arenaEonBoss&&(actor.id!=='player'&&target.id!=='player'||rocketEonBossCombat.airborne(this,target)))return 0;return super.landHit(actor,target,...args);}
      landBasic(actor,target,...args){if(this.arenaEonBoss&&(actor.id!=='player'&&target.id!=='player'||rocketEonBossCombat.airborne(this,target)))return 0;return super.landBasic(actor,target,...args);}
      hurt(actor,amount,move,guard=true,detail={}){
        if(this.arenaEonBoss&&rocketEonBossCombat.airborne(this,actor))return;
        if(this.arenaEonBoss&&actor.id!=='player'&&detail.actor&&detail.actor!=='player'&&detail.actor!==actor.id)return;
        if(this.arenaEonBoss&&actor.id!=='player'&&amount>0)amount=Math.max(1,Math.round(amount/(4*(this.bossDifficulty?.health||1))));
        return super.hurt(actor,amount,move,guard,detail);
      }
      resistsHex(actor,move){return this.arenaEonBoss&&(rocketEonBossCombat.airborne(this,actor)||rocketEonBossCombat.immune(this,actor))||super.resistsHex(actor,move);}
      applyHex(actor,move){if(this.arenaEonBoss&&(rocketEonBossCombat.airborne(this,actor)||rocketEonBossCombat.cleanse(this,actor)))return;return super.applyHex(actor,move);}
      trySecondary(actor,move){if(this.arenaEonBoss&&(rocketEonBossCombat.airborne(this,actor)||rocketEonBossCombat.cleanse(this,actor)))return;return super.trySecondary(actor,move);}
      tickStatus(actor){if(this.arenaEonBoss)rocketEonBossCombat.cleanse(this,actor);super.tickStatus(actor);}
      evolveEon(actor){
        if(!this.eonSharedMega||actor.hp<=0||this.megaUsedOf(actor.id))return;
        const health=actor.hp,old={cast:actor.cast,pendingAction:actor.pendingAction,recoverMs:actor.recoverMs,iframeMs:actor.iframeMs,dodgeVx:actor.dodgeVx,dodgeVy:actor.dodgeVy};
        this.eonTransforming.add(actor.id);actor.cast=null;actor.pendingAction=null;actor.recoverMs=actor.iframeMs=actor.dodgeVx=actor.dodgeVy=0;
        try{super.tryMega(actor);}finally{this.eonTransforming.delete(actor.id);}
        if(actor.speciesId.endsWith('mega')){actor.hp=health;this.resizeEon(actor);this.rememberHp(actor);}else Object.assign(actor,old);
      }
      step(input=bo()){
        const previousTick=this.tick,result=super.step(input,bo(),bo());
        if(this.tick===previousTick)return result;
        const eventStart=this.events.length;
        if(this.phase==='fight'){
          const bosses=[this.opponent,this.third];
          if(bosses.some(actor=>actor.hp<=actor.maxHp*.4))this.eonSharedMega=true;
          if(this.eonSharedMega)for(const actor of bosses)this.evolveEon(actor);
        }
        rocketEonBossCombat.step(this,q);
        if(this.stopTicks===0&&this.phase==='fight')this.resolveKnockouts();
        if(result.events!==this.events)result.events.push(...this.events.slice(eventStart));
        result.state=this.getState();return result;
      }
      resolveKnockouts(){
        if(!this.arenaEonBoss)return super.resolveKnockouts();
        if(this.phase!=='fight')return;
        for(const actor of this.fighters()){
          this.rememberHp(actor);if(actor.hp>0)continue;
          actor.cast=null;actor.pendingAction=null;actor.recoverMs=0;
          this.bullets=this.bullets.filter(shot=>shot.owner!==actor.id);this.zones=this.zones.filter(zone=>zone.owner!==actor.id);
        }
        const next=this.player.hp<=0?nt(this.party,this.activeIndex):null;
        const defeated=this.player.hp<=0&&next===null,victory=this.opponent.hp<=0&&this.third.hp<=0;
        if(defeated||victory){
          this.phase=defeated&&victory?'draw':victory?'victory':'defeat';this.winner=victory?'player':'opponent';
          this.bullets=[];this.zones=[];this.supply=null;this.pendingKnocks=[];this.cancelBufferedInput();
          for(const actor of this.fighters()){actor.cast=null;actor.pendingAction=null;actor.recoverMs=0;}
          this.events.push({type:'match',result:this.phase});
        }else if(this.player.hp<=0)this.sendOut('player',next,'faint');
      }
      snapshot(actor){const state=super.snapshot(actor);if(this.arenaEonBoss&&actor.id!=='player')state.rocketBossScale=actor.rocketBossScale;return state;}
      aiBody(actor){const body=super.aiBody(actor);if(this.arenaEonBoss&&actor.id!=='player')body.rocketBossScale=actor.rocketBossScale;return body;}
      getState(){const state=super.getState();if(this.arenaEonBoss){delete state.ffa;state.rocketEonBossFight=true;rocketEonBossCombat.snapshot(this,state);}return state;}
      dispose(){rocketEonBossCombat.clear(this);this.events=[];this.bullets=[];this.zones=[];this.cancelBufferedInput();}
    };
  }
  function patch(source){return 'const rocketEonBossCombat=('+createRocketEonBossCombat.toString()+')();\n'+arenaEonBossWorldType.toString()+'\n'+source;}
  const api=Object.freeze({patch});globalThis.ArenaEonBossWorldAdapter=api;
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})();
