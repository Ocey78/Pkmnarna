// Battle presentation only. The native HUD snapshot supplies both teams.
(() => {
  'use strict';

  function arenaPartyHud(ui, state) {
    const hud = ui.hud;
    if (!hud) return;

    function node(tag, className) {
      const element = document.createElement(tag);
      element.className = className;
      return element;
    }

    function hpPanel(side) {
      const panel = node('div','rocket-active-health');
      panel.dataset.side = side;
      const label = node('div','rocket-hp-label');
      const name = node('strong','rocket-hp-name'), value = node('span','hptext');
      label.append(name,value);
      const frame = node('div','hp-frame');
      frame.append(node('i','hp-fill'));
      panel.append(label,frame);
      hud.append(panel);
      return {panel,name,value,frame};
    }

    function setPortrait(image, id, mobile) {
      const key = (mobile ? 'head:' : 'portrait:') + (id || '');
      if (image.dataset.key === key) return;
      image.dataset.key = key;
      image.hidden = !id;
      image.onerror = null;
      if (!id) { image.removeAttribute('src'); return; }
      const full = yp({id});
      if (mobile) image.onerror = () => {
        image.onerror = null;
        image.src = full;
        image.classList.add('use-full');
      };
      image.classList.remove('use-full');
      image.src = mobile ? Cm(id) : full;
    }

    let view = hud.rocketPartyHud;
    if (!view) {
      if (!document.getElementById('rocket-party-hud-style')) {
        const style = document.createElement('style');
        style.id = 'rocket-party-hud-style';
        style.textContent = `
          .hud.rocket-party-layout .cluster .hp-frame,.hud.rocket-party-layout .cluster .hptext{display:none}
          .hud .rocket-active-health{position:absolute;box-sizing:border-box;pointer-events:none;z-index:2;
            padding:3px 5px 4px;background:var(--ui-panel,#242940);border:2px solid var(--ui-outline,#080918);
            box-shadow:inset 2px 0 var(--side-me,#488cf0);color:var(--ui-text,#fff);image-rendering:pixelated}
          .hud .rocket-active-health[data-side="opponent"]{box-shadow:inset -2px 0 var(--side-rival,#f05a60)}
          .hud .rocket-active-health[data-side="third"]{box-shadow:inset -2px 0 var(--rw-gold,#eed058)}
          .hud .rocket-active-health[hidden]{display:none}
          .rocket-hp-label{display:flex;align-items:baseline;justify-content:space-between;gap:5px;white-space:nowrap}
          .rocket-hp-name{font:normal clamp(10px,1.15vw,14px)/1.05 Silkscreen,monospace;overflow:hidden;text-overflow:ellipsis}
          .hud .rocket-hp-label .hptext{margin:0;font:normal clamp(10px,1.1vw,14px)/1 Silkscreen,monospace;font-variant-numeric:tabular-nums}
          .hud .rocket-active-health .hp-frame{height:24px;margin:2px 0 0}
          .hud.is-mobile .rocket-active-health{padding:2px 4px}
          .hud.is-mobile .rocket-active-health .hp-frame{height:18px}
          .rocket-foe-party{position:absolute;pointer-events:none;z-index:2}
          .rocket-foe-party .party-cells,.rocket-foe-party .party-cell,.hud .rocket-foe-party .party-cell::after{pointer-events:none;cursor:default}
          .rocket-foe-party .party-cell.is-active::before{box-shadow:inset 0 0 0 2px var(--side-rival,#f05a60)}
          .rocket-foe-party .party-cell.is-fainted img{filter:grayscale(1);opacity:.45}
          .rocket-foe-party .party-cell[aria-label="?"]::after{content:"?";position:absolute;inset:0;transform:none;
            height:auto;width:auto;display:grid;place-items:center;font:14px Silkscreen,monospace;color:var(--ui-text-dim,#a9adbd)}
          .rocket-foe-party img[hidden],.hud.is-ffa .rocket-foe-party,.hud.rocket-cpu-battle .rocket-foe-party{display:none}
          .rocket-training-surface #overlay .hud>.rocket-foe-party{translate:0 var(--rocket-training-bar-height,0px)}
          .hud .rocket-foe-party img.use-full{object-fit:contain;object-position:center}
          .hud.rocket-party-layout.is-ffa .ffa-hp{display:none}
          .hud.rocket-party-layout .ffa-bench>span{position:relative;box-sizing:border-box;height:26px;min-width:0;
            overflow:hidden;background:var(--ui-panel-shade);border-color:var(--ui-frame)}
          .hud.rocket-party-layout .ffa-bench>span[data-active=true]{border-color:var(--ffa-side)}
          .hud.rocket-party-layout .ffa-bench>span[data-down=true] img{filter:grayscale(1);opacity:.4}
          .hud.rocket-party-layout .ffa-bench>span img{display:block;width:100%;height:calc(100% - 3px);object-fit:contain;image-rendering:pixelated}
          .hud.rocket-party-layout .ffa-bench>span img[hidden]{display:none}
          .hud.rocket-party-layout .ffa-bench>span i{position:absolute;bottom:0;left:0;height:3px}
          .hud.rocket-party-layout.is-mobile .ffa-bench>span{height:22px}
        `;
        document.head.append(style);
      }

      const foe = node('div','rocket-foe-party'), cells = node('div','party-cells');
      foe.setAttribute('role','group');
      foe.setAttribute('aria-label','Opponent team');
      foe.append(cells);
      const slots = Array.from({length:3},() => {
        const cell = node('span','party-cell');
        cell.setAttribute('role','img');
        const image = document.createElement('img');
        image.alt = '';
        image.draggable = false;
        const track = node('i','party-hp'), fill = node('i','party-hp-fill');
        track.append(fill);
        cell.append(image,track);
        cells.append(cell);
        return {cell,image,fill};
      });
      hud.append(foe);
      hud.classList.add('rocket-party-layout');
      view = hud.rocketPartyHud = {foe,slots,panels:['player','opponent','third'].map(hpPanel),layoutKey:'',ffaRows:new WeakMap()};
    }

    const mobile = hud.classList.contains('is-mobile');
    const player = state.fighters[0];
    const rival = state.cpuBattle ? Ac(state) || state.fighters.find(f => f.arenaCpuTeam !== player.arenaCpuTeam) : state.fighters[1];
    const third = state.ffa ? state.fighters[2] : null;
    const count = third ? 3 : 2;
    const fighters = [player,rival,third];
    for (let index = 0; index < view.panels.length; index++) {
      const record = view.panels[index], fighter = fighters[index];
      record.panel.hidden = !fighter;
      if (!fighter) continue;
      const hp = Math.max(0,Math.ceil(fighter.hp)), max = fighter.maxHp;
      if (record.species === fighter.speciesId && record.hp === hp && record.max === max) continue;
      record.species = fighter.speciesId; record.hp = hp; record.max = max;
      const name = Jy(fighter.speciesId), ratio = max > 0 ? Math.max(0,Math.min(1,hp/max)) : 0;
      record.name.textContent = name;
      record.value.textContent = hp + '/' + max;
      record.panel.setAttribute('aria-label',name + ', ' + hp + ' of ' + max + ' HP');
      record.frame.className = 'hp-frame is-' + (hp === 0 ? 'fainted' : tb(ratio));
      record.frame.style.setProperty('--hp',String(ratio));
    }

    if (state.ffa) {
      // Each native brawl card already carries three stable slots and health fills.
      const rows = hud.querySelector('.ffa-hud')?.children;
      if (rows) state.fighters.forEach((fighter,index) => {
        const row = rows[index], team = state.ffa.teams.find(entry => entry.id === fighter.id);
        if (!row || !team) return;
        let images = view.ffaRows.get(row);
        if (!images) {
          images = Array.from(row.querySelectorAll('.ffa-bench>span'), box => {
            const img = document.createElement('img'); img.alt = ''; img.draggable = false; box.append(img); return img;
          });
          view.ffaRows.set(row,images);
        }
        images.forEach((img,slot) => setPortrait(img,team.party[slot]?.speciesId,false));
      });
    } else if (!state.cpuBattle) {
      view.slots.forEach(({cell,image,fill},i) => {
        const member = state.foeParty?.[i];
        const id = member?.speciesId;
        const active = i === state.foeActiveSlot && !!id;
        const old = cell.dataset.state;
        const signature = [id,member?.hp,member?.maxHp,active,mobile].join('|');
        if (old === signature) return;
        cell.dataset.state = signature;
        setPortrait(image,id,mobile);
        const hp = member?.hp, max = member?.maxHp;
        const ratio = max > 0 ? Math.max(0,Math.min(1,hp/max)) : 0;
        cell.classList.toggle('is-active',active);
        cell.classList.toggle('is-fainted',!!id && hp <= 0);
        const label = id ? Jy(id) + (active ? ' · Active' : '') + ' · ' + Math.ceil(hp) + '/' + max + ' HP' : '?';
        cell.setAttribute('aria-label',label);
        cell.title = label;
        fill.className = 'party-hp-fill is-' + tb(ratio);
        fill.style.width = ratio*100 + '%';
      });
    }

    const metrics = hud.rocketCpuLayout;
    if (!metrics) return;
    const {layout,width,height} = metrics;
    const attacks = layout.attacks;
    const layoutKey = [width,height,count,mobile,attacks[0].x,attacks[0].y,attacks[2].x,attacks[0].w].join('|');
    if (layoutKey === view.layoutKey) return;
    view.layoutKey = layoutKey;
    view.foe.style.top = layout.party.y + 'px';
    view.foe.style.right = layout.party.x + 'px';
    const margin = Math.max(5,Math.round(layout.player.x)), gap = mobile ? 4 : 8;
    const movesLeft = Math.min(...attacks.map(rect => rect.x));
    const movesRight = Math.max(...attacks.map(rect => rect.x + rect.w));
    const movesTop = Math.min(...attacks.map(rect => rect.y));
    function place(index,x,w,bottom) {
      const style = view.panels[index].panel.style;
      style.left = Math.round(x)+'px'; style.width = Math.round(w)+'px'; style.bottom = Math.round(bottom)+'px';
    }
    if (!mobile && count === 2 && Math.min(movesLeft-margin,width-margin-movesRight) >= 102) {
      const w = Math.min(layout.player.w,movesLeft-margin-gap,width-margin-movesRight-gap);
      place(0,margin,w,margin); place(1,width-margin-w,w,margin);
      return;
    }
    let left = margin, right = width-margin, bottom = margin;
    if (mobile) {
      const stick = layout.joystick;
      if (movesLeft >= stick.x + stick.w) { left=stick.x+stick.w+gap; right=movesLeft-gap; }
      else { left=movesRight+gap; right=stick.x-gap; }
      if (right-left >= 72 && right-left < count*78 + (count-1)*gap) {
        const w = Math.min(layout.player.w,right-left);
        const step = Math.max(...view.panels.slice(0,count).map(record => record.panel.offsetHeight)) + gap;
        for (let index=0;index<count;index++) place(index,(left+right-w)/2,w,bottom+(count-index-1)*step);
        return;
      }
    }
    // Where the controls leave too little horizontal room, clear the move labels as well.
    if (!mobile || right-left < count*78 + (count-1)*gap) {
      left=margin; right=width-margin;
      bottom=height-movesTop+(mobile ? 64 : Math.max(54,32*layout.k));
    }
    const w = Math.min(layout.player.w,(right-left-(count-1)*gap)/count);
    const start = (left+right-count*w-(count-1)*gap)/2;
    for (let index=0;index<count;index++) place(index,start+index*(w+gap),w,bottom);
  }

  function patch(source) {
    const sync = 'this.renderParty(t),this.syncMegaPress(t)';
    const obstacles = 'hudObstacles(){let e=[`.ffa-hud`,';
    for (const anchor of [sync,obstacles]) {
      if (source.split(anchor).length !== 2) throw Error('Unsupported battle HUD for party health layout.');
    }
    return arenaPartyHud.toString() + '\n' + source.replace(sync,sync+',arenaPartyHud(this,t)')
      .replace(obstacles,obstacles+'`.rocket-active-health`,`.rocket-foe-party`,');
  }

  const api = Object.freeze({patch});
  globalThis.ArenaPartyHudAdapter = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})();
