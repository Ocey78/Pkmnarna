'use strict';
// These names live only inside the verified game module. The content script
// stores settings in Firefox and synchronizes live options through the DOM.
function installArenaModBridge() {
  // Read the current value when the engine needs it. The game and the Firefox
  // UI run in different JS worlds and do not need a change event to stay in sync.
  document.documentElement.setAttribute('data-arena-mod-build','1.9.56');
  document.dispatchEvent(new Event('arena-mod-ready'));
  return key => key!=='aim' && globalThis.ArenaRocketAccess?.isUnlocked()===true &&
    document.documentElement.getAttribute('data-arena-mod-'+key)==='on';
}

function arenaMenuReadback(world,fighter) {
  const solo=world.arenaSoloMods===true;
  if(!solo && (typeof hO==='undefined'||hO?.authority?.world!==world))return;
  const local=(!solo && hO.you==='B')?world.opponent:world.player;
  if(fighter!==local)return;
  const now=performance.now();
  if(now<(world.arenaMenuNextReadback||0))return;
  world.arenaMenuNextReadback=now+200;
  const doc=document.documentElement, keys=['cooldowns','aim','god','speed','rapidfire','norecovery','supereffective'];
  const mask=keys.reduce((bits,key,index)=>bits|(world.localOption(local,key)?1<<index:0),0);
  let hostTimers='';
  if(!solo && world.arenaHostCooldownSeat===hO.you && hO.battle?.matchId===hO.directStart?.matchId){
    const clear=local.cds.every(value=>value<=0) && local.basicCd<=0 && local.dodgeCd<=0;
    hostTimers=(mask&1) ? (clear?'waived':'clearing') : 'standard';
    doc.setAttribute('data-arena-host-sampled',String(now));
  }
  if(doc.getAttribute('data-arena-engine-mask')!==String(mask) ||
      (doc.getAttribute('data-arena-host-timers')||'')!==hostTimers){
    doc.setAttribute('data-arena-engine-mask',String(mask));
    if(hostTimers)doc.setAttribute('data-arena-host-timers',hostTimers);
    else doc.removeAttribute('data-arena-host-timers');
    document.dispatchEvent(new Event('arena-engine-readback'));
  }
}

function patchModMenu(source) {
  // Build 631D906 presents pending save imports as soon as the menu is laid out.
  source = source.replace('this.layout(),this.showCollectionNotice(),this.collectionUnsub',
    'this.layout(),this.presentNotice(),this.collectionUnsub');
  const roster = ArenaRosterAdapter.patch(ArenaGraphicsAdapter.patch(source));
  const combat = ArenaCombatAdapter.patch(ArenaCooldownAdapter.patch(roster));
  const rapid = ArenaRapidFireAdapter.patch(ArenaPrivateCombatAdapter.patch(combat));
  const recovery = ArenaNoRecoveryAdapter.patch(rapid);
  const effectiveness = ArenaSuperEffectiveAdapter.patch(recovery);
  const privateMatch = ArenaFriendAdapter.patch(effectiveness);
  const game = ArenaOnlineAimAdapter.patch(privateMatch);
  const shared = ArenaLineupShareAdapter.patch(game);
  const invited = ArenaLineupInviteAdapter.patch(shared);
  const preview = ArenaLineupViewAdapter.patch(invited);
  const names = ArenaNamesAdapter.patch(preview);
  const lobby = ArenaDirectStabilityAdapter.patch(ArenaLobbyAdapter.patch(names));
  const anyMoves = ArenaAnyMoveAdapter.patch(lobby);
  const duplicates = ArenaDuplicateMovesAdapter.patch(anyMoves);
  const sorted = ArenaMoveSortAdapter.patch(duplicates);
  const named = ArenaAuthorityMovesAdapter.patch(sorted);
  const teams = ArenaTeamWorkshopAdapter.patch(named);
  const maps = ArenaMapPickerAdapter.patch(teams);
  const presets = ArenaMovePresetsAdapter.patch(maps);
  const filtered = ArenaGmaxFilterAdapter.patch(presets);
  const audio = ArenaAudioWorkshopAdapter.patch(filtered);
  const uiAudio = ArenaUiAudioAdapter.patch(audio);
  const moveHud = ArenaMoveEffectivenessAdapter.patch(uiAudio);
  const profile = ArenaRocketProfileAdapter.patch(moveHud);
  const careerChart = ArenaCareerChartAdapter.patch(profile);
  const dataSettings = ArenaDataSettingsAdapter.patch(careerChart);
  const slots = ArenaFixedTeamSlotsAdapter.patch(dataSettings);
  const keybinds = ArenaKeybindsAdapter.patch(slots);
  const deviceAim = ArenaDeviceAimAdapter.patch(keybinds);
  const menuLayout = ArenaMenuLayoutAdapter.patch(deviceAim);
  const menuBattle = ArenaMenuBattleAdapter.patch(menuLayout);
  const menuContent = ArenaMenuContentAdapter.patch(menuBattle);
  const menuVfx = ArenaMenuVfxAdapter.patch(menuContent);
  const replaySprites = ArenaReplaySpritesAdapter.patch(menuVfx);
  const replayVfx = ArenaReplayVfxAdapter.patch(replaySprites);
  const history = ArenaMatchHistoryAdapter.patch(replayVfx);
  const menuOnline = ArenaMainMenuOnlineAdapter.patch(history);
  const cpuPicker = ArenaCpuModePickerAdapter.patch(menuOnline);
  const cpuWorld = ArenaCpuBattleAdapter.patch(cpuPicker);
  const cpuScene = ArenaCpuSceneAdapter.patch(cpuWorld);
  const cpuFinish = ArenaCpuFinishAdapter.patch(cpuScene);
  const trainingWorld = ArenaTrainingWorldAdapter.patch(cpuFinish);
  const trainingScene = ArenaTrainingSceneAdapter.patch(trainingWorld);
  const trainingUi = ArenaTrainingUiAdapter.patch(trainingScene);
  const trainingLobby = ArenaTrainingLobbyAdapter.patch(trainingUi);
  const healthCues = ArenaHealthCuesAdapter.patch(trainingLobby);
  const compactControls = ArenaCompactControlsAdapter.patch(healthCues);
  const partyHud = ArenaPartyHudAdapter.patch(compactControls);
  const arenas = ArenaCustomArenasAdapter.patch(partyHud, rocketArenaArt, rocketArenaScenery);
  const skyPillar = ArenaSkyPillarAdapter.patch(arenas);
  const citySquare = ArenaCitySquareAdapter.patch(skyPillar);
  const psychicCave = ArenaPsychicCaveAdapter.patch(citySquare);
  const shaded = ArenaShadingAdapter.patch(psychicCave, globalThis.rocketPaintStageLight, globalThis.rocketFighterMaterial);
  const battleEffects = ArenaBattleEffectsAdapter.patch(shaded, globalThis.rocketDrawArenaFx);
  const autoProtect = ArenaAutoProtectAdapter.patch(battleEffects);
  const autoStatus = ArenaAutoStatusAdapter.patch(autoProtect);
  const smartAim = ArenaSmartAimAdapter.patch(autoStatus);
  const connectionMode = ArenaConnectionModeAdapter.patch(smartAim);
  const gameSettings = ArenaGameSettingsAdapter.patch(connectionMode);
  const closetSettings = ArenaClosetSettingsAdapter.patch(gameSettings);
  const lobbyStreak = ArenaLobbyStreakAdapter.patch(closetSettings);
  const backgroundPlay = ArenaBackgroundPlayAdapter.patch(lobbyStreak);
  const bulkPacks = ArenaBulkPacksAdapter.patch(backgroundPlay);
  const faintedBodies = ArenaFaintedBodiesAdapter.patch(bulkPacks);
  const lobbyMenus = ArenaLobbyMenusAdapter.patch(faintedBodies);
  const combinedSave = ArenaCombinedSaveAdapter.patch(lobbyMenus);
  const bossAttacks = ArenaBossAttacksAdapter.patch(combinedSave);
  const bossVfx = ArenaBossVfxAdapter.patch(bossAttacks);
  const bossRush = ArenaBossRushAdapter.patch(bossVfx);
  const eonMouths = ArenaEonMouthsAdapter.patch(bossRush);
  const eonWorld = ArenaEonBossWorldAdapter.patch(eonMouths);
  const eonVfx = ArenaEonVfxAdapter.patch(eonWorld);
  const eonBoss = ArenaEonBossAdapter.patch(eonVfx);
  const mewtwoWorld = ArenaMewtwoWorldAdapter.patch(eonBoss);
  const mewtwoVfx = ArenaMewtwoVfxAdapter.patch(mewtwoWorld);
  const mewtwoBoss = ArenaMewtwoBossAdapter.patch(mewtwoVfx);
  const bossTeams = ArenaBossTeamsAdapter.patch(mewtwoBoss);
  const bossMoves = ArenaBossMovesAdapter.patch(bossTeams);
  const bossMovePicker = ArenaBossMovePickerAdapter.patch(bossMoves);
  const bossPlayerVfx = ArenaBossPlayerVfxAdapter.patch(bossMovePicker);
  const megaSelector = ArenaMegaSelectorAdapter.patch(bossPlayerVfx);
  const megaOnline = ArenaMegaOnlineAdapter.patch(megaSelector);
  const autoEvolve = ArenaAutoEvolveAdapter.patch(megaOnline);
  const tick='advance(e,t,n,r,i){if(this.waivesLocalCooldowns(e))';
  const parts=autoEvolve.split(tick);
  if(parts.length!==2)throw Error('This build has a different local fighter update.');
  const withReadback=parts.join('advance(e,t,n,r,i){arenaMenuReadback(this,e);if(this.waivesLocalCooldowns(e))');
  const releaseInfo={version:'1.9.56',targetBuild:rocketGameBuilds.targetBuild||'Unknown'};
  return ArenaRocketAccessAdapter.prelude()+'const arenaModEnabled = ('+installArenaModBridge.toString()+')();\n'+
    'globalThis.ArenaRocketRelease=Object.freeze('+JSON.stringify(releaseInfo)+');\n'+
    ArenaFriendAdapter.prelude()+arenaMenuReadback.toString()+'\n'+withReadback;
}
if (typeof module !== 'undefined' && module.exports) module.exports={patchModMenu};
