// Live battle HUD only: native type matchups, with no combat or network changes.
(() => {
  'use strict';
  function arenaMoveMatchup(role,own,target){
    if(!role||!own||!target||own.hp<=0||target.hp<=0||role.dash)return null;
    let type,name,id;
    if(role.basicFallback){type=dn(own.speciesId).types[0]??'normal';name='ATTACK';id=null;}
    else{
      const equipped=role.loadoutIndex===null?null:own.moves[role.loadoutIndex];
      if(!equipped||role.moveId===null)return null;
      const move=V(equipped.id);if(move.power<=0||move.category==='status')return null;
      type=Dc(move);name=move.name;id=move.id;
    }
    const multiplier=Ba(type,dn(target.speciesId).types);
    const kind=multiplier<=0?'immune':multiplier>1?'super':multiplier<1?'resisted':'neutral';
    return{kind,multiplier,type,name,id,stab:dn(own.speciesId).types.includes(type),label:multiplier>=4?'2× SUPER EFFECTIVE':{immune:'NO EFFECT',super:'SUPER EFFECTIVE',resisted:'NOT VERY EFFECTIVE',neutral:'EFFECTIVE'}[kind],targetId:target.id,targetSpecies:target.speciesId,targetName:dn(target.speciesId).name};
  }
  function arenaMoveEffectivenessHud(view,state,plan){
    const hud=view.hud,root=view.root,own=state.fighters[0];if(!hud||!root||!own)return;
    const mobile=hud.classList.contains('is-mobile'),target=state.phase==='fight'&&own.hp>0?Ac(state):null;
    if(!document.getElementById('arena-move-effectiveness-style')){
      const style=document.createElement('style');style.id='arena-move-effectiveness-style';style.textContent=`
        .hud .attack{overflow:visible}
        .hud .arena-move-effectiveness{box-sizing:border-box;position:absolute;z-index:3;display:flex;flex-direction:column;justify-content:center;align-items:center;gap:2px;padding:2px;border:1px solid #b8d8ee;border-radius:0;background:#213d52;color:#eaf8ff;font-family:Silkscreen,monospace;font-weight:400;line-height:1.05;text-align:center;text-shadow:none;text-transform:uppercase;white-space:nowrap;box-shadow:1px 1px 0 #080b18;user-select:none}
        .hud .arena-move-effectiveness,.hud .arena-move-effectiveness *{pointer-events:none!important}
        .hud .arena-move-effectiveness[hidden],.hud .arena-move-effectiveness [hidden]{display:none!important}
        .hud .arena-move-effectiveness[data-kind=super]{background:#173f25;color:#aeffaf;border-color:#80da8a}
        .hud .arena-move-effectiveness[data-kind=resisted]{background:#513c10;color:#ffe39b;border-color:#e8bd62}
        .hud .arena-move-effectiveness[data-kind=immune]{background:#4e2130;color:#ffd3df;border-color:#ed93ad}
        .hud .arena-move-effectiveness-name{display:none;max-width:100%;overflow:hidden;text-overflow:ellipsis;font-size:8px;line-height:10px;color:inherit}
        .hud .arena-move-effectiveness[data-mobile=true] .arena-move-effectiveness-name{display:block}
        .hud .arena-move-effectiveness[data-mobile=true] .arena-move-effectiveness-label{white-space:pre-line;line-height:9px}
        .hud .arena-move-effectiveness-target{position:absolute;width:1px;height:1px;overflow:hidden;clip-path:inset(50%);white-space:nowrap}
        .hud .arena-move-effectiveness-stab{box-sizing:border-box;position:absolute;top:calc(100% + 3px);left:0;right:0;display:block;padding:2px;border:1px solid #eecb73;border-radius:0;background:#3d3216;color:#ffe6a6;font:inherit;line-height:1;text-align:center;white-space:nowrap;box-shadow:1px 1px 0 #080b18}
      `;document.head.append(style);
    }
    const active=[],all=[],layout=(badge,css)=>{if(badge.dataset.layout!==css){badge.style.cssText=css;badge.dataset.layout=css;}};
    for(const button of root.querySelectorAll('.attack')){
      let badge=button.querySelector('.arena-move-effectiveness');
      const selected=mobile===(button.closest('.dock.mobile')!==null),role=plan[Number(button.dataset.slot)];
      const matchup=selected&&target?arenaMoveMatchup(role,own,target):null;
      const point=selected?view.buttonPoint(button):null;
      if(selected)all.push({x:point.x,y:point.y,w:button.clientWidth,h:button.clientHeight});
      if(!matchup){
        if(badge){badge.hidden=true;const tokens=(button.getAttribute('aria-describedby')||'').split(/\s+/).filter(id=>id&&id!==badge.id);if(tokens.length)button.setAttribute('aria-describedby',tokens.join(' '));else button.removeAttribute('aria-describedby');}
        continue;
      }
      if(!badge){
        badge=document.createElement('span');badge.className='arena-move-effectiveness';badge.id='arena-move-matchup-'+(arenaMoveEffectivenessHud.nextId=(arenaMoveEffectivenessHud.nextId||0)+1);
        for(const name of ['name','label','target','stab']){const child=document.createElement('span');child.className='arena-move-effectiveness-'+name;badge.append(child);}
        button.append(badge);
      }
      badge.hidden=false;for(const [key,value]of Object.entries({kind:matchup.kind,multiplier:String(matchup.multiplier),target:matchup.targetId,targetSpecies:matchup.targetSpecies,mobile:String(mobile),stab:String(matchup.stab)}))if(badge.dataset[key]!==value)badge.dataset[key]=value;
      const name=badge.children[0],label=badge.children[1],description=badge.children[2],stab=badge.children[3];
      stab.hidden=!matchup.stab;if(stab.textContent!=='S.T.A.B')stab.textContent='S.T.A.B';
      const nameText=matchup.name.toUpperCase(),labelText=mobile?matchup.label.replace('SUPER EFFECTIVE','SUPER\nEFFECTIVE').replace('NOT VERY EFFECTIVE','NOT VERY\nEFFECTIVE'):matchup.label,targetText=' against closest foe '+matchup.targetName+' ('+matchup.type+' type matchup).';
      if(name.textContent!==nameText)name.textContent=nameText;if(label.textContent!==labelText)label.textContent=labelText;if(description.textContent!==targetText)description.textContent=targetText;
      const described=(button.getAttribute('aria-describedby')||'').split(/\s+/).filter(Boolean);if(!described.includes(badge.id))button.setAttribute('aria-describedby',[...described,badge.id].join(' '));
      if(mobile)active.push({badge,point,stab:matchup.stab});
      else{
        const font=Math.min(12,Math.max(8,Math.floor(button.clientWidth/12)));
        layout(badge,'left:2px;right:2px;top:auto;bottom:calc(100% + 8 * var(--px,1px)'+(matchup.stab?' + '+(font+9)+'px':'')+');width:auto;height:auto;font-size:'+font+'px');
      }
    }
    if(mobile&&active.length){
      // The native touch fan has almost no space between circular buttons.
      // Move-named badges share one strip above it; no art, ring, or hit target
      // is covered or resized. Coordinates use the native HUD's local space.
      const gap=4,width=Math.min(92,Math.max(36,Math.floor((hud.clientWidth-8-gap*(active.length-1))/active.length))),height=36+(active.some(row=>row.stab)?17:0),total=active.length*width+(active.length-1)*gap;
      const left=Math.min(...all.map(rect=>rect.x)),right=Math.max(...all.map(rect=>rect.x+rect.w));
      const x=Math.max(4,Math.min((left+right-total)/2,hud.clientWidth-total-4)),y=Math.max(4,Math.min(...all.map(rect=>rect.y))-height-8);
      active.forEach(({badge,point},index)=>{layout(badge,'left:'+Math.round(x+index*(width+gap)-point.x)+'px;top:'+Math.round(y-point.y)+'px;right:auto;bottom:auto;width:'+width+'px;height:36px;font-size:8px');});
    }
  }
  function patch(original){
    let source=original;
    if(source.includes('function arenaMoveMatchup('))throw Error('Move effectiveness HUD already applied.');
    const replace=(before,after)=>{const parts=source.split(before);if(parts.length!==2)throw Error('Unsupported move effectiveness HUD anchor: '+before);source=parts.join(after);};
    replace('function mb(e,t,n,r,i){',arenaMoveMatchup.toString()+'\n'+arenaMoveEffectivenessHud.toString()+'\nfunction mb(e,t,n,r,i){');
    replace('mb(e,t,s[t],r,c)}),this.renderParty(t)', 'mb(e,t,s[t],r,c)}),arenaMoveEffectivenessHud(this,t,s),this.renderParty(t)');
    return source;
  }
  const api=Object.freeze({patch,arenaMoveMatchup,arenaMoveEffectivenessHud});globalThis.ArenaMoveEffectivenessAdapter=api;
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})();
