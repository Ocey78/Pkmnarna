// Private two-boss encounter selection, scene lifecycle and individual health bars.
(() => {
  'use strict';
  function createArenaEonBoss(){
    const source='rocket-eon-boss',stage='rocket-city-square',hp=4000,scale=1.25,radius=30;
    // Stock Latios is size L and Latias M; equal multipliers do not make equal bodies.
    const visualScale=species=>Qs.M*scale/Qs[ec(species)];
    function register(scene){if(!scene.scene.manager.keys[source])scene.scene.manager.add(source,arenaEonBossSceneType(),false);}
    function start(scene){arenaBossDifficulty.choose(scene,'eon',()=>{register(scene);scene.scene.start('pick',{source});});}
    function launch(scene,team){
      if(scene.started||!Array.isArray(team)||team.length!==3)return;
      register(scene);scene.started=true;TT.ui('confirm');
      scene.scene.start(source,{source,stageId:stage,difficulty:'hard',seed:Rk(team[0]),
        playerSpeciesId:team[0],partyIds:team.slice(),partyLoadouts:arenaBossTeams.loadouts(team),
        opponentSpeciesId:'latios',opponentPartyIds:['latios']});
    }
    function hud(scene,state){
      if(!Z.hud)return;
      let view=scene.rocketEonHud;
      if(!view){
        if(!document.getElementById('rocket-eon-hud-style')){
          const style=document.createElement('style');style.id='rocket-eon-hud-style';
          style.textContent=`
            .hud.rocket-eon-boss .timer,.hud.rocket-eon-boss .cluster.foe,.hud.rocket-eon-boss .rocket-foe-party,
            .hud.rocket-eon-boss .rocket-active-health[data-side="opponent"],.hud.rocket-eon-boss .ffa-hud{display:none!important}
            .hud.rocket-eon-boss .cluster.player,.hud.rocket-eon-boss>.party{translate:0 var(--rocket-eon-offset,90px)}
            .rocket-eon-health{position:absolute;left:50%;top:8px;transform:translateX(-50%);display:grid;
              grid-template-columns:1fr 1fr;gap:8px;width:min(780px,calc(100% - 100px));z-index:4;pointer-events:none;
              color:var(--ui-text,#fff);font:700 12px/1.4 Silkscreen,monospace}
            .rocket-eon-health[hidden]{display:none}.rocket-eon-bar{box-sizing:border-box;min-width:0;padding:7px 9px;
              border:3px solid var(--ui-frame-hi,#61799e);background:var(--ui-panel,#192c4c);box-shadow:0 0 0 2px #071326}
            .rocket-eon-heading{display:flex;align-items:center;justify-content:space-between;gap:6px;margin-bottom:5px}
            .rocket-eon-heading img{width:29px;height:29px;object-fit:contain;image-rendering:pixelated}
            .rocket-eon-name{color:#8ddcff;flex:1}.rocket-eon-bar[data-id="third"] .rocket-eon-name{color:#ff9faf}
            .rocket-eon-level{color:var(--ui-text-dim,#a5bbd7);font-size:9px;margin-top:2px}
            .rocket-eon-value{font-size:10px;white-space:nowrap}.rocket-eon-track{height:24px;background:#071326;border:2px solid #071326;overflow:hidden}
            .rocket-eon-fill{height:100%;background:linear-gradient(#c4f4ff 0 25%,#55b3ef 25% 75%,#2772ac 75%);transform-origin:left}
            .rocket-eon-bar[data-id="third"] .rocket-eon-fill{background:linear-gradient(#ffd1df 0 25%,#e57495 25% 75%,#a73a68 75%)}
            .rocket-eon-bar.is-mega{border-color:#bca3ef}.rocket-eon-bar.is-fainted{opacity:.55}
            .rocket-eon-bar.is-enraged{border-color:#ef995d}.rocket-eon-bar.is-enraged .rocket-eon-name{color:#ffbc76}
            .rocket-eon-bar.is-enraged .rocket-eon-fill{background:linear-gradient(#ffdaa1 0 25%,#ee8652 25% 75%,#af3e3e 75%)}
            @media(max-width:680px){.rocket-eon-health{grid-template-columns:1fr;gap:4px;font-size:10px}.rocket-eon-heading img{width:20px;height:20px}
              .rocket-eon-bar{padding:4px 6px}.rocket-eon-track{height:18px}.rocket-eon-heading{margin-bottom:2px}}
          `;document.head.append(style);
        }
        const root=document.createElement('section');root.className='rocket-eon-health';root.setAttribute('aria-label','Latios and Latias boss health');
        const bars=new Map();
        for(const id of ['opponent','third']){
          const bar=document.createElement('div');bar.className='rocket-eon-bar';bar.dataset.id=id;
          bar.setAttribute('role','progressbar');bar.setAttribute('aria-valuemin','0');bar.setAttribute('aria-valuemax',String(hp));
          const heading=document.createElement('div');heading.className='rocket-eon-heading';
          const portrait=document.createElement('img');portrait.alt='';
          const name=document.createElement('span');name.className='rocket-eon-name';
          const value=document.createElement('span');value.className='rocket-eon-value';heading.append(portrait,name,value);
          const track=document.createElement('div');track.className='rocket-eon-track';
          const level=document.createElement('div');level.className='rocket-eon-level';
          const fill=document.createElement('div');fill.className='rocket-eon-fill';track.append(fill);bar.append(heading,track,level);root.append(bar);
          bars.set(id,{bar,portrait,name,value,fill,level,key:''});
        }
        const host=Z.hud;host.classList.add('rocket-eon-boss');host.append(root);
        view=scene.rocketEonHud={root,bars,host,layoutAt:0};
        scene.events.once('shutdown',()=>{root.remove();host.classList.remove('rocket-eon-boss');host.style.removeProperty('--rocket-eon-offset');scene.rocketEonHud=null;});
      }
      view.root.hidden=state.phase!=='fight';
      for(const [id,row] of view.bars){
        const fighter=state.fighters.find(actor=>actor.id===id);if(!fighter)continue;
        const maximum=fighter.maxHp,difficulty=scene.world.bossDifficulty||arenaBossDifficulty.get('eon');
        const enraged=!!state.rocketEonBoss?.bosses.find(boss=>boss.actorId===id)?.enraged;
        const health=Math.max(0,Math.ceil(fighter.hp)),mega=/mega$/.test(fighter.speciesId),key=health+':'+fighter.speciesId+':'+maximum+':'+enraged+':'+difficulty.id;
        if(row.key===key)continue;row.key=key;
        const title=(mega?'MEGA ':'')+(id==='opponent'?'LATIOS':'LATIAS');
        row.portrait.src=yp({id:fighter.speciesId});row.name.textContent=title;
        row.level.textContent=difficulty.label.toUpperCase()+(enraged?' · ENRAGED':'');
        row.value.textContent=health?health.toLocaleString()+' / '+maximum.toLocaleString():'DEFEATED';
        row.fill.style.transform='scaleX('+Math.max(0,Math.min(1,fighter.hp/maximum))+')';
        row.bar.classList.toggle('is-mega',mega);row.bar.classList.toggle('is-fainted',!health);
        row.bar.classList.toggle('is-enraged',enraged);row.bar.setAttribute('aria-valuemax',String(maximum));
        row.bar.setAttribute('aria-valuenow',String(health));row.bar.setAttribute('aria-label',title+' boss health');
      }
      if(!view.root.hidden&&performance.now()>=view.layoutAt){
        view.layoutAt=performance.now()+250;
        const width=view.host.clientWidth;let left=12,right=width-12;
        for(const node of view.host.querySelectorAll('.party,.cluster.player'))if(node.offsetWidth&&node.offsetHeight)left=Math.max(left,node.offsetLeft+node.offsetWidth+12);
        const pause=view.host.querySelector('.pause');if(pause?.offsetWidth)right=Math.min(right,pause.offsetLeft-10);
        const beside=right-left>=540;
        view.root.style.left=(beside?(left+right)/2:width/2)+'px';
        view.root.style.width=(beside?Math.min(780,right-left):Math.max(180,width-(pause?.offsetWidth?112:24)))+'px';
        view.host.style.setProperty('--rocket-eon-offset',beside?'0px':(view.root.offsetHeight+10)+'px');
      }
    }
    return Object.freeze({source,stage,hp,scale,radius,visualScale,start,launch,hud});
  }
  function arenaEonBossSceneType(){
    return class RocketEonScene extends RY {
      constructor(){super('rocket-eon-boss');this.rocketEonBoss=true;}
      init(data){
        super.init({...data,net:null,source:'cpu',difficulty:'hard',cpuSwitch:false,arenaCpuMode:null,
          stageId:arenaEonBoss.stage,story:null,run:null,encounter:null});
        this.battleSource=arenaEonBoss.source;this.aiEnabled=true;this.assist=null;
        this.rocketBossBadgeGranted=false;
        this.debugKo=this.debugUlt=false;this.debugFaint=this.debugBall=null;this.debugSwitchSlot=null;
      }
      async create(){
        arenaAudioWorkshop.prepareEonMusic();
        const epoch=this.loadEpoch;await super.create();
        if(!this.alive||!this.ready||epoch!==this.loadEpoch)return;
        Z.onRepick=()=>{Lq();Z.hideResult();this.scene.start('pick',{source:arenaEonBoss.source});};
        arenaEonBoss.hud(this,this.world.getState());
      }
      draw(state){
        rocketEonVfx.beforeDraw(this);super.draw(state);rocketEonVfx.draw(this,state);arenaEonBoss.hud(this,state);
        if(state.phase==='fight')arenaAudioWorkshop.eonMusic();
      }
      stackAnchor(species,x,y){
        const player=this.world?.player;
        const boss=[this.world?.opponent,this.world?.third].filter(actor=>actor?.speciesId===species)
          .sort((a,b)=>Math.hypot(a.x-x,a.y-y)-Math.hypot(b.x-x,b.y-y))[0];
        if(boss&&(species!==player?.speciesId||Math.hypot(x-boss.x,y-boss.y)<Math.hypot(x-player.x,y-player.y)))
          return this.hudPoint(x,y-Qs[ec(species)]*arenaEonBoss.visualScale(species));
        return super.stackAnchor(species,x,y);
      }
      settleMatch(phase){
        Fl(phase,0);Z.setResultCoins(null,false);Z.setResultStars(null);
        if(phase!=='victory'){this.rocketBossBadgeGranted=false;return;}
        const level=this.world?.bossDifficulty?.id,profile=globalThis.ArenaRocketProfile;
        if(!this.rocketBossBadgeGranted&&['expert','champion'].includes(level)&&profile?.awardBadge){
          this.rocketBossBadgeGranted=true;
          try{profile.awardBadge('eon-'+level);}catch(error){console.warn('[rocket-profile] Boss badge could not be recorded',error);}
        }
      }
      noteCollection(){} lightRow(){} noteOwnRow(){}
    };
  }
  function patch(source){
    const once=(before,after)=>{const chunks=source.split(before);if(chunks.length!==2)throw Error('Unsupported Eon boss anchor: '+before.slice(0,90));source=chunks.join(after);};
    once('launch(e,t){if(this.source===arenaBossRush.source)',
      'launch(e,t){if(this.source===arenaEonBoss.source){arenaEonBoss.launch(this,e);return}if(this.source===arenaBossRush.source)');
    once('this.rocketBossPick=t===arenaBossRush.source;',
      'this.rocketBossPick=t===arenaBossRush.source||t===arenaEonBoss.source;');
    once('let e=t===arenaBossRush.source?',
      'let e=t===arenaEonBoss.source?`BOSS RUSH - LATIOS & LATIAS / NIGHT CITY SQUARE`:t===arenaBossRush.source?');
    once('this.world=new (this.rocketBossRush?',
      'this.world=new (this.rocketEonBoss?arenaEonBossWorldType():this.rocketBossRush?');
    once('hudObstacles(){let e=[','hudObstacles(){let e=[`.rocket-eon-health`,');
    // Dive VFX owns the altitude shadow; exclude the ordinary grounded one.
    once('Wk(this.worldGraphics,n,t)',
      'this.rocketEonBoss&&e.rocketEonBoss?.bosses.forEach(b=>{if(b.attack.kind===`dive`&&b.attack.flyHeight>0)t.add(b.actorId)}),Wk(this.worldGraphics,n,t)');
    return 'const arenaEonBoss=('+createArenaEonBoss.toString()+')();globalThis.arenaEonBoss=arenaEonBoss;\n'+arenaEonBossSceneType.toString()+'\n'+source;
  }
  globalThis.ArenaEonBossAdapter=Object.freeze({patch});
  if(typeof module!=='undefined'&&module.exports)module.exports={patch};
})();
