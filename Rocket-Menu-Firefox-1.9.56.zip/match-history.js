// Local, sampled online replays. No game simulation or online commands are run by playback.
(() => {
  'use strict';
  function createRocketReplayTools() {
    const seats=['A','B','C'], roles=['player','opponent','third'];
    const finite=(value,fallback=0)=>Number.isFinite(value)?value:fallback;
    const text=(value,max=100)=>typeof value==='string'?value.slice(0,max):'';
    const hp=value=>Number.isFinite(value)&&value>=0?value:null;
    function order(meta){return [meta.ownSeat,...seats.filter(seat=>seat!==meta.ownSeat&&meta.teams?.[seat])];}
    function seatOf(meta,actor){const index=roles.indexOf(actor);return index<0?null:order(meta)[index]||null;}
    function parties(meta,state){
      const result={};
      for(const seat of seats){
        if(!meta.teams?.[seat])continue;
        const role=roles[order(meta).indexOf(seat)];
        const party=state?.ffa?.teams?.find(team=>team.id===role)?.party||
          (role==='player'?state?.party:role==='opponent'?state?.foeParty:null);
        result[seat]=meta.teams[seat].map((species,index)=>{
          const row=party?.find(mon=>mon.slot===index)||party?.[index];
          // History identifies the starting party slot. Its observed Mega form
          // remains in replay fighters, while HP comes only from the native row.
          return {species:text(species,40),hp:hp(row?.hp),maxHp:hp(row?.maxHp)};
        });
      }
      return result;
    }
    const eventTypes=new Set(['cast','hit','block','status','faint','switch','mega','dodge','ultZone','itemWarn','itemSpawn','itemExpire','itemPick','heal','knockout']);
    function packEvent(meta,event,state,t){
      if(!event||!eventTypes.has(event.type))return null;
      const exact=Number.isFinite(event.arenaReplayTick)&&Number.isFinite(event.arenaReplayElapsedMs);
      const result={type:event.type,t:Math.max(0,t-(exact?state.elapsedMs-event.arenaReplayElapsedMs:0)),tick:exact?event.arenaReplayTick:finite(state.tick),inputFrame:finite(event.arenaReplayInputFrame,finite(state.inputFrame,finite(state.tick))),exact,
        seat:seatOf(meta,event.actor||event.target)};
      for(const key of ['actor','target']){const seat=seatOf(meta,event[key]);if(seat)result[key]=seat;}
      for(const key of ['move','result','effect','speciesId','cause','from','to','kind'])if(typeof event[key]==='string')result[key]=text(event[key],50);
      for(const key of ['id','slot','x','y','r','amount','warnTicks','segment'])if(Number.isFinite(event[key]))result[key]=event[key];
      for(const key of ['basic','weak','chip','zone','crit','arenaUltimate'])if(typeof event[key]==='boolean')result[key]=event[key];
      if(Array.isArray(event.hitTicks))result.hitTicks=event.hitTicks.slice(0,32).filter(Number.isFinite);
      return result;
    }
    function snapshot(meta,state,t,events=[],packed=false){
      if(!state||!Array.isArray(state.fighters)||!Number.isFinite(state.elapsedMs))return null;
      const fighters=state.fighters.slice(0,3).map(f=>({seat:seatOf(meta,f.id),species:text(f.speciesId,40),entry:finite(f.entry),
        x:finite(f.x),y:finite(f.y),facing:finite(f.cast!=='idle'?f.castFacing:f.facing),radius:finite(f.radius,24),
        hp:hp(f.hp),maxHp:hp(f.maxHp),cast:text(f.cast,16),move:text(f.castMove,50),shot:finite(f.justShotMs),iframe:finite(f.iframeMs),
        bodyFacing:finite(f.facing),castMs:finite(f.castMs),castBasic:f.castBasic===true,lungeTick:Number.isFinite(f.lungeTick)?f.lungeTick:null,
        walkSpeed:finite(f.walkSpeed),recoverMs:finite(f.recoverMs),switchMs:finite(f.switchMs),ultCharge:finite(f.ultCharge),
        ailment:typeof f.ailment==='string'?text(f.ailment,20):null,ailmentMs:finite(f.ailmentMs),itemSpeedMs:finite(f.itemSpeedMs),
        basicCooldownMs:finite(f.basicCooldownMs),dodgeCooldownMs:finite(f.dodgeCooldownMs),energy:finite(f.energy),
        moves:(f.moves||[]).slice(0,5).map(m=>[text(m.id,50),finite(m.cooldownMs),finite(m.maxCooldownMs)]),
        ...(typeof f.arenaCastUltimate==='boolean'?{arenaCastUltimate:f.arenaCastUltimate}:{})})).filter(f=>f.seat);
      const projectiles=(state.projectiles||[]).slice(0,200).map(p=>({id:finite(p.id),seat:seatOf(meta,p.owner),move:text(p.move,50),x:finite(p.x),y:finite(p.y),r:finite(p.radius,5),vx:finite(p.vx),vy:finite(p.vy),basic:p.basic===true}));
      const zones=(state.zones||[]).slice(0,100).map(z=>({id:finite(z.id),seat:seatOf(meta,z.owner),move:text(z.move,50),x:finite(z.x),y:finite(z.y),r:finite(z.r),age:finite(z.age),warn:finite(z.warnTicks),hitTicks:(z.hitTicks||[]).slice(0,32).filter(Number.isFinite)}));
      const items=(state.items||[]).slice(0,8).map(item=>({id:finite(item.id),kind:text(item.kind,20),phase:text(item.phase,12),msLeft:finite(item.msLeft),x:finite(item.x),y:finite(item.y)}));
      const changes=packed?events.slice(-100).map(e=>structuredClone(e)):events.slice(-100).map(event=>packEvent(meta,event,state,t)).filter(Boolean);
      return {native:2,t:Math.max(0,Math.round(t)),elapsed:state.elapsedMs,tick:finite(state.tick),inputFrame:finite(state.inputFrame,finite(state.tick)),hitStopFrames:finite(state.hitStopFrames),remainingMs:finite(state.remainingMs),phase:text(state.phase,20),fighters,projectiles,zones,items,events:changes,parties:parties(meta,state)};
    }
    function matches(meta,replay){return !!replay&&(replay.v===1||replay.v===2)&&replay.id===meta.id&&replay.matchId===meta.matchId&&replay.roomCode===meta.roomCode&&replay.ownSeat===meta.ownSeat&&seats.every(seat=>JSON.stringify(replay.teams?.[seat]||null)===JSON.stringify(meta.teams?.[seat]||null));}
    function merge(meta,previous,later){
      if(!matches(meta,previous)||!previous.frames?.length)return later;
      if(!later.frames.length)return previous;
      const copy=structuredClone(previous),last=copy.frames.at(-1),first=later.frames[0],offset=last.elapsed>first.elapsed?last.t:last.t-last.elapsed+first.elapsed;let bytes=JSON.stringify(copy).length;
      for(const frame of later.frames){const next={...frame,t:Math.max(last.t,Math.round(offset+frame.t)),events:(frame.events||[]).map(event=>Number.isFinite(event.t)?{...event,t:Math.max(0,offset+event.t)}:{...event})},size=JSON.stringify(next).length;if(copy.frames.length>=9000||bytes+size>12000000){copy.truncated=true;break;}if(next.t===copy.frames.at(-1).t)copy.frames[copy.frames.length-1]=next;else{copy.frames.push(next);bytes+=size;}}
      copy.v=Math.max(previous.v,later.v);
      copy.durationMs=copy.frames.at(-1).t;copy.truncated||=later.truncated;
      if(copy.frames.length>9000){copy.frames=copy.frames.slice(0,9000);copy.durationMs=copy.frames.at(-1).t;copy.truncated=true;}
      return copy;
    }
    function capture(meta,previous=null){
      const replay=previous?structuredClone(previous):{v:2,id:meta.id,matchId:meta.matchId,roomCode:meta.roomCode,startedAt:meta.startedAt,stage:meta.stage,ownSeat:meta.ownSeat,teams:structuredClone(meta.teams),names:{...meta.names},arena:{width:2048,height:1280,combat:null},frames:[],durationMs:0,truncated:false};
      replay.v=2;
      let origin=replay.frames.at(-1)?.elapsed??null,lastElapsed=origin,offset=replay.durationMs,lastSample=replay.frames.at(-1)?.t??-Infinity,bytes=JSON.stringify(replay).length,pending=[];
      function add(state,events=[],force=false){
        if(!state||!Number.isFinite(state.elapsedMs))return false;
        if(origin===null){origin=state.elapsedMs;lastElapsed=state.elapsedMs;}
        // A reconnect can restart the presentation clock. Preserve sample order.
        if(state.elapsedMs<lastElapsed-1000){offset=replay.durationMs;origin=state.elapsedMs;}
        lastElapsed=state.elapsedMs;
        const t=Math.max(replay.durationMs,offset+state.elapsedMs-origin);
        pending.push(...events.map(event=>packEvent(meta,event,state,t)).filter(Boolean));if(pending.length>100){replay.eventsDropped=(replay.eventsDropped||0)+pending.length-100;pending=pending.slice(-100);}
        if(!force&&t-lastSample<200)return false;
        const frame=snapshot(meta,state,t,pending,true);if(!frame)return false;
        pending=[];
        if(replay.frames.length>=9000||bytes+JSON.stringify(frame).length>12000000){replay.truncated=true;return false;}
        const last=replay.frames.at(-1);
        if(last&&last.t===frame.t){replay.frames[replay.frames.length-1]=frame;}
        else{replay.frames.push(frame);bytes+=JSON.stringify(frame).length;}
        lastSample=t;replay.durationMs=t;
        if(Number.isFinite(state.arena?.width)&&Number.isFinite(state.arena?.height))replay.arena={width:state.arena.width,height:state.arena.height,combat:state.arena.combat?{...state.arena.combat}:null};
        return true;
      }
      return{add,replay,remaining:state=>parties(meta,state)};
    }
    function sample(replay,time){
      const frames=replay.frames;if(!frames.length)return null;
      let low=0,high=frames.length-1;
      while(low<high){const mid=Math.ceil((low+high)/2);if(frames[mid].t<=time)low=mid;else high=mid-1;}
      const a=frames[low],b=frames[low+1];
      if(!b||time<=a.t||b.t-a.t>1000)return a;
      const ratio=Math.min(1,(time-a.t)/(b.t-a.t));
      return {...a,fighters:a.fighters.map(f=>{
        const next=b.fighters.find(other=>other.seat===f.seat&&other.entry===f.entry&&other.species===f.species);
        return next?{...f,x:f.x+(next.x-f.x)*ratio,y:f.y+(next.y-f.y)*ratio}:f;
      }),projectiles:a.projectiles.map(p=>{const next=b.projectiles.find(other=>other.id===p.id&&other.seat===p.seat&&other.move===p.move);return next?{...p,x:p.x+(next.x-p.x)*ratio,y:p.y+(next.y-p.y)*ratio}:p;})};
    }
    // Playback IDs are fixed to real seats, not the recording client's camera:
    // A=player, B=opponent, C=third. This also keeps FFA effects correctly owned.
    function roleOf(seat){return roles[seats.indexOf(seat)]||null;}
    function nativeState(replay,frame){
      if(!frame)return null;
      const fighters=(frame.fighters||[]).map(f=>({id:roleOf(f.seat),entry:finite(f.entry),speciesId:f.species,name:f.species,
        x:finite(f.x),y:finite(f.y),facing:finite(f.bodyFacing,finite(f.facing)),radius:finite(f.radius,24),hp:finite(f.hp),maxHp:finite(f.maxHp),
        cast:f.cast||'idle',castMove:f.move||null,castFacing:finite(f.facing),castMs:finite(f.castMs),castBasic:f.castBasic===true,
        lungeTick:Number.isFinite(f.lungeTick)?f.lungeTick:null,walkSpeed:finite(f.walkSpeed),recoverMs:finite(f.recoverMs),
        switchMs:finite(f.switchMs),justShotMs:finite(f.shot),iframeMs:finite(f.iframe),ultCharge:finite(f.ultCharge),
        ailment:f.ailment||null,ailmentMs:finite(f.ailmentMs),itemSpeedMs:finite(f.itemSpeedMs),
        basicCooldownMs:finite(f.basicCooldownMs),dodgeCooldownMs:finite(f.dodgeCooldownMs),
        moves:(f.moves||[]).map(m=>({id:m[0],cooldownMs:finite(m[1]),maxCooldownMs:finite(m[2]),energy:0})),
        energy:finite(f.energy),maxEnergy:100,heat:0,heatLock:false,...(typeof f.arenaCastUltimate==='boolean'?{arenaCastUltimate:f.arenaCastUltimate}:{})
      })).filter(f=>f.id).sort((a,b)=>roles.indexOf(a.id)-roles.indexOf(b.id));
      const party=seat=>(frame.parties?.[seat]||[]).map((f,index)=>({slot:index,speciesId:f.species,hp:f.hp,maxHp:f.maxHp}));
      return {tick:finite(frame.tick),inputFrame:finite(frame.inputFrame,finite(frame.tick)),elapsedMs:finite(frame.elapsed),remainingMs:finite(frame.remainingMs),
        hitStopFrames:finite(frame.hitStopFrames),seed:1,clock:'countdown',phase:frame.phase||'fight',arena:structuredClone(replay.arena||{width:2048,height:1280}),fighters,
        projectiles:(frame.projectiles||[]).map(p=>({id:p.id,owner:roleOf(p.seat),move:p.move,x:p.x,y:p.y,vx:finite(p.vx),vy:finite(p.vy),radius:p.r,basic:p.basic===true})).filter(p=>p.owner),
        zones:(frame.zones||[]).map(z=>({id:z.id,owner:roleOf(z.seat),move:z.move,x:z.x,y:z.y,r:z.r,age:z.age,warnTicks:z.warn,hitTicks:[...(z.hitTicks||[])]})).filter(z=>z.owner),
        items:(frame.items||[]).map(item=>({...item})),party:party('A'),foeParty:party('B'),
        ...(replay.teams?.C?{ffa:{teams:seats.filter(seat=>replay.teams[seat]).map(seat=>({id:roleOf(seat),party:party(seat)})),winner:null}}:{})};
    }
    function nativeEvents(replay,frame){
      if(!frame)return [];
      return (frame.events||[]).flatMap(event=>{
        if(!eventTypes.has(event.type))return [];
        if(frame.native!==2){
          // Version 1 did not distinguish the actor from the hit target. Keep
          // its unambiguous casts; do not invent targets or original timing.
          if(!['cast','dodge'].includes(event.type)||!roleOf(event.seat))return [];
          return [{type:event.type,actor:roleOf(event.seat),move:event.move,x:event.x,y:event.y,replayTime:frame.t,tick:frame.tick,inputFrame:finite(frame.inputFrame,frame.tick),replayExact:false}];
        }
        const {t,tick,inputFrame,exact,seat,actor,target,...fields}=event;
        return [{...structuredClone(fields),...(roleOf(actor)?{actor:roleOf(actor)}:{}),...(roleOf(target)?{target:roleOf(target)}:{}),
          replayTime:finite(t,frame.t),tick:finite(tick,frame.tick),inputFrame:finite(inputFrame,frame.inputFrame),replayExact:exact===true}];
      });
    }
    function retained(rows,maxCount=20,maxBytes=80000000){
      const sorted=[...rows].sort((a,b)=>b.startedAt-a.startedAt||(a.id<b.id?-1:1)),keep=[],drop=[];let size=0;
      for(const row of sorted){if(keep.length<maxCount&&size+row.bytes<=maxBytes){keep.push(row.id);size+=row.bytes;}else drop.push(row.id);}
      return{keep,drop,bytes:size};
    }
    return{order,seatOf,parties,snapshot,capture,sample,retained,matches,merge,nativeState,nativeEvents};
  }
  function createRocketReplayStore(indexedDB,tools) {
    let connection=null;
    function open(){
      if(connection)return connection;
      connection=new Promise((resolve,reject)=>{
        if(!indexedDB){reject(Error('Local replay storage is unavailable.'));return;}
        const request=indexedDB.open('rocket-menu-replays',2);
        request.onupgradeneeded=()=>{const table=request.result.objectStoreNames.contains('matches')?request.transaction.objectStore('matches'):request.result.createObjectStore('matches',{keyPath:'id'});if(!table.indexNames.contains('summary'))table.createIndex('summary',['startedAt','bytes']);};
        request.onerror=()=>reject(request.error||Error('Local replay storage is unavailable.'));
        request.onblocked=()=>reject(Error('Another game tab is using replay storage.'));
        request.onsuccess=()=>{const db=request.result;db.onversionchange=()=>{db.close();connection=null;};resolve(db);};
      }).catch(error=>{connection=null;throw error;});
      return connection;
    }
    async function transaction(mode,run){
      const db=await open();return new Promise((resolve,reject)=>{
        const tx=db.transaction('matches',mode),store=tx.objectStore('matches');let result;
        tx.oncomplete=()=>resolve(result);tx.onerror=tx.onabort=()=>reject(tx.error||Error('The replay could not be saved.'));
        try{run(store,value=>{result=value;});}catch(error){tx.abort();reject(error);}
      });
    }
    async function save(replay){
      if(!replay?.frames?.length)return false;
      const bytes=new TextEncoder().encode(JSON.stringify(replay)).byteLength;
      if(bytes>13000000)throw Error('This replay is too large to save.');
      return transaction('readwrite',(store,done)=>{
        const current=store.get(replay.id);current.onsuccess=()=>{
          const prior=current.result?.replay,last=prior?.frames?.at(-1),incoming=replay.frames.at(-1);
          // Compare inside this transaction: a retired tab's late pagehide must
          // not overwrite the more complete recording saved by its successor.
          if(tools.matches(replay,prior)&&last&&prior.durationMs>=replay.durationMs&&last.elapsed>=incoming.elapsed&&last.tick>=incoming.tick){done(true);return;}
          store.put({id:replay.id,startedAt:replay.startedAt,bytes,replay});
          summaries(store,rows=>{const result=tools.retained(rows);for(const id of result.drop)store.delete(id);done(result.keep.includes(replay.id));});
        };
      });
    }
    function summaries(store,done){const rows=[],request=store.index('summary').openKeyCursor();request.onsuccess=()=>{const cursor=request.result;if(cursor){rows.push({id:cursor.primaryKey,startedAt:cursor.key[0],bytes:cursor.key[1]});cursor.continue();}else done(rows);};}
    const read=id=>transaction('readonly',(store,done)=>{const request=store.get(id);request.onsuccess=()=>done(request.result?.replay||null);});
    const stats=()=>transaction('readonly',(store,done)=>summaries(store,rows=>done({count:rows.length,bytes:rows.reduce((sum,row)=>sum+row.bytes,0),ids:rows.map(row=>row.id)})));
    return{save,read,stats,clear:()=>transaction('readwrite',(store,done)=>{store.clear();done(true);})};
  }
  function createArenaMatchHistory() {
    const tools=createRocketReplayTools(),store=createRocketReplayStore(globalThis.indexedDB,tools),active=new Map();
    let view=null,profile=null,writeQueue=Promise.resolve(),lastWrite=0;
    const colors={A:'#68d3ff',B:'#ff8a9a',C:'#ffe06c'};
    const monName=id=>{try{return dn(id).name;}catch{return id||'Unknown Pokémon';}};
    function element(tag,className,text){const node=document.createElement(tag);if(className)node.className=className;if(text!==undefined)node.textContent=text;return node;}
    function button(text,fn){const node=element('button','rocket-history-button',text);node.type='button';node.onclick=fn;return node;}
    function persist(record){
      writeQueue=writeQueue.catch(()=>{}).then(async()=>{
        try{await record.ready;const replay=structuredClone(record.capture.replay);if(await store.save(replay))profile?.updateHistory(record.meta.id,{replayId:record.meta.id});}
        catch{document.documentElement.dataset.rocketReplayStorage='unavailable';}
      });
    }
    function event(event){
      if(event.type==='start'){
        if(event.endedAt!==null)return;
        if(active.has(event.id))return;
        for(const [id,record]of active){persist(record);active.delete(id);}
        const record={meta:structuredClone(event),capture:tools.capture(event),state:null,ready:null};active.set(event.id,record);
        record.ready=store.read(event.id).then(previous=>{if(tools.matches(event,previous))record.capture=tools.capture(event,tools.merge(event,previous,record.capture.replay));}).catch(()=>{});
      }else if(event.type==='frame'){
        const record=active.get(event.id);if(!record)return;
        record.state=event.state;record.capture.add(event.state,event.events);
        if(Date.now()-lastWrite>15000){lastWrite=Date.now();persist(record);profile?.updateHistory(event.id,{remainingHp:record.capture.remaining(event.state)});}
      }else if(event.type==='end'){
        const record=active.get(event.id);if(!record)return;
        const state=event.state||record.state;
        if(state){record.capture.add(state,event.events,true);profile?.updateHistory(event.id,{remainingHp:record.capture.remaining(state)});}
        persist(record);active.delete(event.id);
      }
    }
    function close(){
      if(!view)return;
      const prior=view;view=null;
      prior.dispose?.();
      prior.root.remove();
    }
    function mountPage(panel){
      close();
      const root=element('section','rocket-history-shell'),body=element('div','rocket-history-body');
      root.dataset.rocketHistory='';root.setAttribute('aria-label','Match history');
      const header=element('header','rocket-history-header'),title=element('h2');
      const backButton=button('BACK TO HISTORY',()=>renderList());
      header.hidden=true;header.append(title,backButton);root.append(header,body);panel.append(root);
      body.tabIndex=0;body.setAttribute('aria-label','Recorded matches');
      const current={root,body,header,title,backButton,dispose:null,replayId:null,listScroll:0,revision:0};
      view=current;
      renderList();
      return {
        back(){if(view!==current||!current.replayId)return false;renderList();return true;},
        dispose(){if(view===current)close();}
      };
    }
    function open(){globalThis.ArenaRocketProfile?.open('history');}
    async function renderList(){
      const current=view;if(!current)return;const revision=++current.revision,restoreMatch=current.replayId;
      current.replayId=null;current.dispose?.();current.dispose=null;current.root.classList.remove('is-replay');current.header.hidden=true;current.body.replaceChildren();
      current.body.setAttribute('aria-label','Recorded matches');
      if(restoreMatch)current.body.focus({preventScroll:true});
      const info=element('p','rocket-history-note','Last 200 online matches. Up to 20 replays stay on this device (80 MB total). Rocket codes include match details, not replays.');current.body.append(info);
      const rows=profile?.listHistory()||[];
      if(!rows.length){current.body.append(element('p','','Your online matches will appear here.'));return;}
      const replayButtons=[];
      for(const match of rows){
        const article=element('article','rocket-history-match');article.dataset.matchId=match.id;
        const heading=element('div','rocket-history-match-head'),time=element('time','',''+new Date(match.startedAt).toLocaleString());time.dateTime=new Date(match.startedAt).toISOString();
        const lobby=element('strong','',match.roomName||match.roomCode||'Online room');heading.append(lobby,time);
        const result=match.result==='nocontest'||match.reason==='nocontest'?'No Contest':match.winner?(match.names[match.winner]||'Player '+match.winner)+' won':match.result==='draw'?'Draw':match.reason==='forfeit'?'You forfeited':'Result unknown';
        article.append(heading,element('p','rocket-history-outcome',result));
        const teams=element('div','rocket-history-teams');
        for(const seat of ['A','B','C']){
          if(!match.teams[seat])continue;
          const team=element('section','rocket-history-team');team.style.setProperty('--seat-color',colors[seat]);
          team.append(element('h2','',(match.names[seat]||'Name unavailable')+(match.ownSeat===seat?' · You':'')));
          const party=match.remainingHp?.[seat]||match.teams[seat].map(species=>({species,hp:null,maxHp:null}));
          for(const mon of party){
            const row=element('div','rocket-history-mon'),image=element('img');image.alt='';image.loading='lazy';image.src=yp({id:mon.species});image.onerror=()=>image.remove();
            const name=element('span','',monName(mon.species)),health=element('span','rocket-history-hp',mon.hp===null?'HP unknown':mon.hp+(mon.maxHp===null?'':' / '+mon.maxHp)+' HP');row.append(image,name,health);team.append(row);
          }
          teams.append(team);
        }
        article.append(teams,element('p','rocket-history-note','Last recorded HP'));
        const replay=button('REPLAY',()=>play(match));replay.disabled=true;article.append(replay);current.body.append(article);
        replayButtons.push({match,replay});
      }
      current.body.scrollTop=current.listScroll;
      let ids=new Set;try{ids=new Set((await store.stats()).ids);}catch{}
      if(view!==current||current.revision!==revision)return;
      for(const {match,replay} of replayButtons){
        const available=ids.has(match.replayId||match.id);
        replay.disabled=!available;
        if(!available)replay.textContent='REPLAY NOT ON THIS DEVICE';
        if(match.id===restoreMatch&&available&&document.activeElement===current.body)replay.focus({preventScroll:true});
      }
    }
    async function play(match){
      const current=view;if(!current)return;const revision=++current.revision;current.replayId=match.id;current.listScroll=current.body.scrollTop;
      current.dispose?.();current.dispose=null;current.header.hidden=false;current.title.textContent=match.roomName||'MATCH REPLAY';
      current.body.setAttribute('aria-label','Match replay');current.body.replaceChildren(element('p','','Loading replay…'));current.backButton.focus({preventScroll:true});
      let replay;try{replay=await store.read(match.replayId||match.id);}catch{}
      if(view!==current||current.revision!==revision)return;
      if(!tools.matches(match,replay)||!replay?.frames?.length){current.body.replaceChildren(element('p','','This replay is not available for this match on this device.'));return;}
      current.body.replaceChildren();current.root.classList.add('is-replay');
      const toolbar=element('div','rocket-replay-controls'),canvas=element('canvas','rocket-replay-canvas');canvas.tabIndex=0;canvas.setAttribute('aria-label','Replay arena. Drag to pan; use zoom controls or the mouse wheel.');
      const stageView=element('div','rocket-replay-stage'),teamHud=element('aside','rocket-replay-teams'),teamRows=new Map();teamHud.setAttribute('aria-label','Teams and remaining health');
      for(const seat of ['A','B','C']){
        if(!match.teams[seat])continue;
        const team=element('section','rocket-replay-team');team.style.setProperty('--seat-color',colors[seat]);team.append(element('h2','',match.names[seat]||'Player '+seat));
        const rows=match.teams[seat].map(species=>{
          const row=element('div','rocket-replay-team-mon'),image=element('img');image.alt=monName(species);image.src=yp({id:species});image.onerror=()=>{image.hidden=true;};
          const info=element('div','rocket-replay-team-health'),bar=element('div','rocket-replay-team-bar'),fill=element('span'),hpText=element('span','rocket-replay-team-hp');
          bar.append(fill);info.append(bar,hpText);row.append(image,info);team.append(row);return{row,fill,hpText,species};
        });teamRows.set(seat,rows);teamHud.append(team);
      }
      const artworkError=element('p','rocket-replay-error','Battle artwork could not load. Reopen this replay to retry.');artworkError.hidden=true;
      stageView.append(canvas,teamHud,artworkError);
      const timeline=element('input','rocket-replay-timeline');timeline.type='range';timeline.min='0';timeline.max=String(replay.durationMs);timeline.step='1';timeline.value='0';timeline.setAttribute('aria-label','Replay time');
      const timeLabel=element('output','rocket-replay-clock'),playButton=button('PLAY',()=>{playing=!playing;playButton.textContent=playing?'PAUSE':'PLAY';if(time>=replay.durationMs)time=0;});
      const speed=element('select');speed.setAttribute('aria-label','Playback speed');for(const n of [.25,.5,1,1.5,2,4]){const option=element('option','',n+'×');option.value=String(n);option.selected=n===1;speed.append(option);}
      const follow=element('select');follow.setAttribute('aria-label','Camera target');for(const seat of ['all',...Object.keys(match.teams)]){const option=element('option','',seat==='all'?'Whole arena':'Follow '+(match.names[seat]||seat));option.value=seat;follow.append(option);}
      toolbar.append(playButton,speed,follow,button('−',()=>{zoom=Math.max(1,zoom/1.25);}),button('+',()=>{zoom=Math.min(5,zoom*1.25);}),button('FIT',()=>{zoom=1;panX=panY=0;follow.value='all';}));
      let preferences={names:true,damage:true,status:true};
      try{const saved=JSON.parse(localStorage.getItem('rocket.replay.display')||'{}');for(const key of Object.keys(preferences))if(typeof saved[key]==='boolean')preferences[key]=saved[key];}catch{}
      for(const [key,title]of [['names','Hide Nametags'],['damage','Hide Damage'],['status','Hide Status']]){
        const label=element('label','rocket-replay-toggle'),input=element('input');input.type='checkbox';input.checked=!preferences[key];input.dataset.replayHide=key;
        input.onchange=()=>{preferences[key]=!input.checked;try{localStorage.setItem('rocket.replay.display',JSON.stringify(preferences));}catch{}};label.append(input,document.createTextNode(title));toolbar.append(label);
      }
      const transport=element('div','rocket-replay-transport');transport.append(timeline,timeLabel);
      current.body.append(toolbar,stageView,transport);
      let disposed=false,playing=false,time=0,zoom=1,panX=0,panY=0,lastTime=performance.now(),raf=0,drag=null;
      const assets=new Map,images=new Set,visuals=createArenaReplayVfx(replay,tools,canvas);
      const events=replay.frames.flatMap(frame=>tools.nativeEvents(replay,frame)).filter(event=>['hit','heal','status'].includes(event.type)).sort((a,b)=>a.replayTime-b.replayTime);
      const roleSeats={player:'A',opponent:'B',third:'C'},seatRoles={A:'player',B:'opponent',C:'third'};
      function paintTeams(frame){
        for(const [seat,rows]of teamRows){
          const active=frame.fighters.find(f=>f.seat===seat);
          rows.forEach((entry,index)=>{
            const mon=frame.parties?.[seat]?.[index],known=Number.isFinite(mon?.hp)&&Number.isFinite(mon?.maxHp)&&mon.maxHp>0,ratio=known?Math.max(0,Math.min(1,mon.hp/mon.maxHp)):0;
            entry.fill.style.width=(ratio*100)+'%';entry.fill.style.background=ratio>.5?'#78d868':ratio>.2?'#f8d858':'#f87070';
            entry.hpText.textContent=known?Math.ceil(mon.hp)+' / '+Math.ceil(mon.maxHp):'HP ?';entry.row.classList.toggle('is-fainted',known&&mon.hp<=0);
            let selected=active?.species===entry.species;try{selected||=Sp(active?.species||'')===entry.species;}catch{}
            entry.row.classList.toggle('is-active',selected);entry.row.title=monName(entry.species)+(known?' · '+entry.hpText.textContent+' HP':'');
          });
        }
      }
      function paintFloats(ctx,frame){
        // Event clocks remain frozen while paused and reconstruct after any seek.
        let low=0,high=events.length;while(low<high){const mid=(low+high)>>1;if(events[mid].replayTime<time-1200)low=mid+1;else high=mid;}
        let count=0;
        for(let i=low;i<events.length&&events[i].replayTime<=time;i++){
          const event=events[i],status=event.type==='status',age=time-event.replayTime,life=status?1200:900;
          if(age>life||(status?!preferences.status:!preferences.damage))continue;
          const target=frame.fighters.find(f=>f.seat===roleSeats[event.target||event.actor]);
          const x=Number.isFinite(event.x)?event.x:target?.x,y=Number.isFinite(event.y)?event.y:target?.y;
          if(!Number.isFinite(x)||!Number.isFinite(y))continue;
          const label=status?String(event.effect||event.result||'').replaceAll('_',' ').toUpperCase():event.amount>0?(event.type==='heal'?'+':'−')+Math.ceil(event.amount):'';
          if(!label)continue;
          ctx.save();ctx.globalAlpha=Math.min(1,(life-age)/220);ctx.font='700 '+(status?19:24)+'px Silkscreen,monospace';ctx.textAlign='center';ctx.lineWidth=4;ctx.strokeStyle='#10142a';ctx.fillStyle=status?'#e4c0ff':event.type==='heal'?'#9bf79f':event.crit?'#ffe26e':'#fff';
          const top=y-(status?92:48)-age/life*34;ctx.strokeText(label,x,top);ctx.fillText(label,x,top);ctx.restore();count++;
        }
        canvas.dataset.replayFloats=String(count);
      }
      function loadImage(url){
        if(assets.has(url))return assets.get(url);
        const promise=new Promise((resolve,reject)=>{const image=new Image;images.add(image);image.onload=()=>disposed?reject(Error('Closed')):resolve(image);image.onerror=()=>reject(Error('Art unavailable'));image.src=url;});
        assets.set(url,promise);return promise;
      }
      let arenaImage=null;const stage=ou.find(stage=>stage.id===replay.stage);if(stage)loadImage(ai(stage.file)).then(image=>{
        if(disposed)return;
        const art=stage.art;
        arenaImage=rocketArenaMaterial.surface(image,stage.id,art?[art.x/Ca,art.y/wa,art.w/Ca,art.h/wa]:undefined);
      }).catch(()=>{});
      timeline.oninput=()=>{time=Number(timeline.value);playing=false;playButton.textContent='PLAY';};
      follow.onchange=()=>{panX=panY=0;if(follow.value!=='all')zoom=Math.max(zoom,2);};
      canvas.addEventListener('wheel',e=>{e.preventDefault();zoom=Math.max(1,Math.min(5,zoom*(e.deltaY<0?1.12:1/1.12)));},{passive:false});
      canvas.addEventListener('pointerdown',e=>{drag={x:e.clientX,y:e.clientY};follow.value='all';canvas.setPointerCapture(e.pointerId);});
      canvas.addEventListener('pointermove',e=>{if(drag){panX+=e.clientX-drag.x;panY+=e.clientY-drag.y;drag={x:e.clientX,y:e.clientY};}});
      const stopDrag=()=>{drag=null;};canvas.addEventListener('pointerup',stopDrag);canvas.addEventListener('pointercancel',stopDrag);
      const format=n=>Math.floor(n/60000)+':'+String(Math.floor(n/1000)%60).padStart(2,'0');
      function draw(now){
        if(disposed||view!==current)return;
        const delta=Math.max(0,Math.min(100,now-lastTime));lastTime=now;
        if(playing&&!document.hidden)time=Math.min(replay.durationMs,time+delta*Number(speed.value));
        if(time>=replay.durationMs){playing=false;playButton.textContent='PLAY';}
        timeline.value=String(Math.round(time));timeLabel.textContent=format(time)+' / '+format(replay.durationMs);
        const box=canvas.getBoundingClientRect(),width=Math.max(1,Math.round(box.width)),height=Math.max(1,Math.round(box.height));
        if(canvas.width!==width||canvas.height!==height){canvas.width=width;canvas.height=height;}
        const ctx=canvas.getContext('2d'),frame=tools.sample(replay,time);if(ctx&&frame){
          const scale=Math.min(width/replay.arena.width,height/replay.arena.height)*zoom,target=frame.fighters.find(f=>f.seat===follow.value);
          const x=target?width/2-target.x*scale:(width-replay.arena.width*scale)/2+panX,y=target?height/2-target.y*scale:(height-replay.arena.height*scale)/2+panY;
          ctx.setTransform(1,0,0,1,0,0);ctx.fillStyle='#11151b';ctx.fillRect(0,0,width,height);ctx.imageSmoothingEnabled=false;ctx.translate(x,y);ctx.scale(scale,scale);
          if(arenaImage){
            const art=stage?.art;
            ctx.drawImage(arenaImage,art?.x??0,art?.y??0,art?.w??replay.arena.width,art?.h??replay.arena.height);
          }else{ctx.fillStyle=stage?.backdrop||'#294137';ctx.fillRect(0,0,replay.arena.width,replay.arena.height);const bounds=replay.arena.combat;if(bounds){ctx.strokeStyle='#97aa8b';ctx.lineWidth=3;ctx.strokeRect(bounds.left,bounds.top,bounds.right-bounds.left,bounds.bottom-bounds.top);}}
          visuals.setOptions?.({statusEffects:preferences.status});
          visuals.update(time,frame);
          visuals.paint(ctx,false);
          visuals.paint(ctx,true);
          canvas.dataset.replayVfx=visuals.error?'unavailable':'native';
          canvas.dataset.replayError=visuals.error||'';
          canvas.dataset.replayActors=String(visuals.actors?.size||0);
          canvas.dataset.replayGeneration=String(visuals.generation);
          canvas.dataset.replaySwitches=String(visuals.hiddenActors?.size||0);
          artworkError.hidden=!visuals.error;paintTeams(frame);paintFloats(ctx,frame);
          for(const fighter of [...frame.fighters].sort((a,b)=>a.y-b.y)){
            if(visuals.hiddenActors?.has(seatRoles[fighter.seat]))continue;
            ctx.globalAlpha=1;ctx.font='700 20px Silkscreen,monospace';ctx.textAlign='center';ctx.lineWidth=5;ctx.strokeStyle='#141923';ctx.fillStyle='#fff';
            if(preferences.names){const label=monName(fighter.species);ctx.strokeText(label,fighter.x,fighter.y-75);ctx.fillText(label,fighter.x,fighter.y-75);}
            ctx.fillStyle='#171a20';ctx.fillRect(fighter.x-45,fighter.y-66,90,8);ctx.fillStyle=colors[fighter.seat];ctx.fillRect(fighter.x-45,fighter.y-66,90*(fighter.maxHp>0?Math.max(0,fighter.hp/fighter.maxHp):0),8);
          }
          ctx.setTransform(1,0,0,1,0,0);
        }
        raf=requestAnimationFrame(draw);
      }
      current.dispose=()=>{disposed=true;cancelAnimationFrame(raf);visuals.dispose();for(const image of images){image.onload=image.onerror=null;image.removeAttribute('src');}images.clear();assets.clear();};
      raf=requestAnimationFrame(draw);
    }
    function mount(section){
      if(section.querySelector('[data-rocket-history-open]'))return;
      const launch=button('MATCH HISTORY',open);launch.dataset.rocketHistoryOpen='';launch.classList.add('px-btn');section.querySelector('.row')?.append(launch);
    }
    function boot(){
      profile=globalThis.ArenaRocketProfile;if(!profile?.subscribeBattle)return;profile.subscribeBattle(event);
      const style=element('style');style.textContent=`
        .rocket-history-shell{box-sizing:border-box;display:flex;flex-direction:column;flex:1 1 auto;width:100%;height:100%;min-height:0;min-width:0;overflow:hidden;background:var(--ui-bg,#11172b);color:var(--ui-text,#f8f8f8);font:700 14px/1.45 Silkscreen,monospace;font-synthesis:none;text-rendering:optimizeSpeed;image-rendering:pixelated}
        .rocket-history-header[hidden]{display:none}
        .rocket-history-shell *{box-sizing:border-box}
        .rocket-history-header{display:flex;align-items:center;justify-content:space-between;flex:0 0 auto;gap:12px;padding:14px 18px;border-bottom:4px solid var(--ui-frame,#8b94b9);background:var(--ui-panel,#272f55)}
        .rocket-history-header h2{min-width:0;margin:0;font:700 22px/1.3 Silkscreen,monospace;text-transform:uppercase;overflow-wrap:anywhere}
        .rocket-history-header>.rocket-history-button{flex:0 0 auto}
        .rocket-history-body{flex:1 1 auto;min-width:0;min-height:0;overflow:auto;overscroll-behavior:contain;scrollbar-gutter:stable;padding:18px;scroll-padding:14px;overflow-wrap:anywhere}
        .rocket-history-button,.rocket-replay-controls select{max-width:100%;min-width:0;min-height:40px;padding:9px 12px;border:2px solid var(--ui-frame-hi,#b4b8d3);border-radius:0;background:var(--ui-panel,#272f55);color:var(--ui-text,#f8f8f8);box-shadow:2px 2px 0 var(--ui-outline,#080b18);font:700 14px/1.35 Silkscreen,monospace;cursor:pointer}
        .rocket-history-button{white-space:normal;overflow-wrap:anywhere}.rocket-replay-controls select{padding-right:24px;text-overflow:ellipsis}
        .rocket-history-button:hover:not(:disabled),.rocket-replay-controls select:hover{background:var(--ui-cell-selected,#343e70)}
        .rocket-history-button:active:not(:disabled){box-shadow:none;transform:translate(1px,1px)}
        .rocket-history-button:disabled{opacity:.5;cursor:default}
        .rocket-history-shell :focus-visible{outline:3px solid var(--ui-cursor,#f87818);outline-offset:-3px}
        .rocket-history-match{min-width:0;padding:16px;margin-bottom:16px;border:2px solid var(--ui-frame-hi,#b4b8d3);border-radius:0;background:var(--ui-panel,#272f55);box-shadow:inset 0 0 0 2px var(--ui-outline,#080b18),2px 2px 0 var(--ui-outline,#080b18)}
        .rocket-history-match-head{display:flex;justify-content:space-between;gap:8px 16px;flex-wrap:wrap}.rocket-history-match-head>*{min-width:0;overflow-wrap:anywhere}
        .rocket-history-match-head time,.rocket-history-note{color:var(--ui-text-muted,#bbc1df);font-size:12px;line-height:1.5}
        .rocket-history-outcome{font-weight:700;color:var(--ui-accent,#f8d830)}
        .rocket-history-teams{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,260px),1fr));gap:16px}
        .rocket-history-team{min-width:0;border-top:3px solid var(--seat-color);padding-top:10px}.rocket-history-team h2{font:700 14px/1.4 Silkscreen,monospace;margin:0 0 9px;overflow-wrap:anywhere}
        .rocket-history-mon{display:grid;grid-template-columns:32px minmax(0,1fr) auto;align-items:center;gap:8px;min-height:36px}.rocket-history-mon>span{min-width:0;overflow-wrap:anywhere}.rocket-history-mon>span:not(.rocket-history-hp){grid-column:2}
        .rocket-history-mon img{width:32px;height:32px;object-fit:contain;image-rendering:pixelated}.rocket-history-hp{justify-self:end;white-space:nowrap;font-size:12px;font-variant-numeric:tabular-nums}
        .rocket-replay-controls{display:flex;gap:8px;flex-wrap:wrap;align-items:center;min-width:0;margin-bottom:14px}.rocket-replay-controls select[aria-label="Camera target"]{flex:0 1 auto;max-width:100%}
        .rocket-replay-canvas{box-sizing:border-box;display:block;width:100%;max-width:100%;height:clamp(240px,62vh,900px);border:2px solid var(--ui-frame-hi,#b4b8d3);background:var(--ui-input-bg,#10152a);touch-action:none;cursor:grab}
        .rocket-replay-timeline{appearance:none;-webkit-appearance:none;display:block;width:100%;min-width:0;height:26px;margin:12px 0;padding:0;border:0;border-radius:0;background:transparent;cursor:pointer}
        .rocket-replay-timeline::-moz-range-track{height:10px;border:2px solid var(--ui-outline,#080b18);border-radius:0;background:var(--ui-panel,#272f55)}
        .rocket-replay-timeline::-moz-range-progress{height:8px;border-radius:0;background:var(--ui-accent,#f8d830)}
        .rocket-replay-timeline::-moz-range-thumb{width:16px;height:20px;border:2px solid var(--ui-outline,#080b18);border-radius:0;background:var(--ui-frame-hi,#b4b8d3);box-shadow:inset 0 0 0 2px var(--ui-text,#f8f8f8)}
        .rocket-replay-timeline::-webkit-slider-runnable-track{height:10px;border:2px solid var(--ui-outline,#080b18);border-radius:0;background:var(--ui-panel,#272f55)}
        .rocket-replay-timeline::-webkit-slider-thumb{appearance:none;-webkit-appearance:none;width:20px;height:24px;margin-top:-9px;border:2px solid var(--ui-outline,#080b18);border-radius:0;background:var(--ui-frame-hi,#b4b8d3);box-shadow:inset 0 0 0 2px var(--ui-text,#f8f8f8)}
        .rocket-replay-clock{display:block;color:var(--ui-text,#f8f8f8);font-variant-numeric:tabular-nums}
        .rocket-history-shell.is-replay .rocket-history-body{display:flex;flex-direction:column;gap:10px;overflow:hidden;scrollbar-gutter:auto;padding:12px}
        .rocket-history-shell.is-replay .rocket-replay-controls{flex:0 0 auto;margin:0;gap:6px}
        .rocket-replay-toggle{display:inline-flex;align-items:center;gap:6px;min-height:30px;padding:4px 7px;border:2px solid var(--ui-frame-hi,#b4b8d3);background:var(--ui-panel,#272f55);font:700 11px/1.2 Silkscreen,monospace;cursor:pointer;white-space:nowrap}
        .rocket-replay-toggle input{margin:0;width:14px;height:14px;accent-color:var(--ui-cursor,#f87818);cursor:pointer}
        .rocket-replay-stage{position:relative;flex:1 1 auto;min-height:0;min-width:0;overflow:hidden;background:var(--ui-input-bg,#10152a);border:2px solid var(--ui-frame-hi,#b4b8d3)}
        .rocket-history-shell.is-replay .rocket-replay-canvas{position:absolute;inset:0;width:100%;height:100%;border:0;max-width:none}
        .rocket-replay-teams{position:absolute;right:8px;top:8px;display:flex;align-items:flex-start;gap:6px;max-width:70%;pointer-events:none;image-rendering:pixelated}
        .rocket-replay-team{width:154px;max-width:calc(50vw - 44px);padding:5px;border:2px solid var(--seat-color);background:#151d39e8;box-shadow:2px 2px 0 #080b18}
        .rocket-replay-team h2{font:700 11px/1.2 Silkscreen,monospace;text-overflow:ellipsis;white-space:nowrap;overflow:hidden;margin:0 0 4px;color:var(--seat-color)}
        .rocket-replay-team-mon{display:flex;align-items:center;gap:5px;padding:2px;border-left:2px solid transparent;min-width:0}.rocket-replay-team-mon.is-active{border-left-color:var(--seat-color);background:#ffffff0c}.rocket-replay-team-mon.is-fainted{opacity:.4}
        .rocket-replay-team-mon img{width:28px;height:28px;object-fit:contain;image-rendering:pixelated;flex:none}.rocket-replay-team-health{flex:1;min-width:0}
        .rocket-replay-team-bar{height:8px;border:2px solid #080b18;background:#080b18;overflow:hidden}.rocket-replay-team-bar>span{display:block;height:100%}.rocket-replay-team-hp{display:block;font:700 9px/1.2 Silkscreen,monospace;text-align:right;margin-top:2px;color:#fff}
        .rocket-replay-transport{display:flex;align-items:center;gap:14px;flex:0 0 auto;min-height:26px}.rocket-replay-transport .rocket-replay-timeline{flex:1;min-width:0;margin:0}.rocket-replay-transport .rocket-replay-clock{flex:none;font-size:12px;white-space:nowrap}
        .rocket-replay-error{position:absolute;top:12px;left:12px;max-width:45%;margin:0;padding:8px;background:#10152a;color:#fff;font-size:12px}
        @media(max-width:800px),(max-height:500px){.rocket-history-shell.is-replay .rocket-history-header{padding:8px 12px}.rocket-history-shell.is-replay .rocket-history-body{padding:8px;gap:6px}.rocket-history-shell.is-replay .rocket-history-button,.rocket-history-shell.is-replay .rocket-replay-controls select{min-height:30px;padding:4px 8px;font-size:11px}.rocket-replay-toggle{font-size:10px;padding:3px 5px;min-height:30px}.rocket-replay-team{width:118px;padding:4px}.rocket-replay-team h2{font-size:9px}.rocket-replay-team-mon{gap:3px;padding:1px}.rocket-replay-team-mon img{width:22px;height:22px}.rocket-replay-team-hp{font-size:8px}.rocket-replay-teams{right:5px;top:5px;gap:4px}}
        @media(max-width:650px){.rocket-history-header,.rocket-history-body{padding:12px}.rocket-history-header h2{font-size:18px}.rocket-history-teams{grid-template-columns:minmax(0,1fr)}.rocket-history-match{padding:12px}.rocket-replay-canvas{height:50vh}.rocket-history-button,.rocket-replay-controls select{font-size:12px;padding:8px 10px}.rocket-replay-controls select{padding-right:22px}}
        @media(max-width:420px){.rocket-history-header{gap:8px}.rocket-history-header h1{font-size:16px}.rocket-history-mon{grid-template-columns:32px minmax(0,1fr);gap:2px 8px;margin-bottom:7px}.rocket-history-mon img{grid-row:span 2}.rocket-history-hp{grid-column:2;justify-self:start}.rocket-replay-controls select[aria-label="Camera target"]{flex-basis:100%}}
      `;document.head.append(style);
      window.addEventListener('pagehide',()=>{for(const record of active.values())persist(record);close();});
      document.addEventListener('visibilitychange',()=>{if(document.hidden)for(const record of active.values())persist(record);});
    }
    globalThis.ArenaRocketReplays=Object.freeze({clear:()=>store.clear(),stats:()=>store.stats(),open,mountPage});queueMicrotask(boot);
    return{mount};
  }
  function patch(source){
    if(source.includes('function createRocketReplayTools('))throw Error('Match history already applied.');
    const before='e.appendChild(i),i.querySelector(`[data-action="create-open"]`)';
    const parts=source.split(before);if(parts.length!==2)throw Error('Unsupported match history lobby anchor.');
    source=parts.join('e.appendChild(i),arenaMatchHistory.mount(i),i.querySelector(`[data-action="create-open"]`)');
    // Stamp the already-cloned presentation events before the 15 Hz observer
    // batches them. Nothing in the packet, simulation or command path changes.
    const eventAnchor='this.events.push(...Zw(this.you,e.ev,e.ffa))',eventParts=source.split(eventAnchor);
    if(eventParts.length!==2)throw Error('Unsupported replay event timing anchor.');
    source=eventParts.join('this.events.push(...Zw(this.you,e.ev,e.ffa).map(t=>({...t,arenaReplayTick:e.tick,arenaReplayElapsedMs:e.elapsedMs,arenaReplayInputFrame:e.inputFrame})))');
    return createRocketReplayTools.toString()+'\n'+createRocketReplayStore.toString()+'\nconst arenaMatchHistory=('+createArenaMatchHistory.toString()+')();\n'+source;
  }
  const api={patch,createRocketReplayTools,createRocketReplayStore,createArenaMatchHistory};globalThis.ArenaMatchHistoryAdapter=Object.freeze(api);
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})();
