// Offline Mewtwo encounter. Player attacks, Protect, party switching and results
// remain native; only the boss choreography and illusion targets are custom.
(() => {
  'use strict';
  function createRocketMewtwoCombat(){
    const worlds=new WeakMap(),tau=Math.PI*2,clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
    const point=a=>({x:a.x,y:a.y}),center=a=>arenaBossRush.center(a);
    const size=w=>w.bossDifficulty.size,speed=w=>w.bossDifficulty.speed,mega=w=>w.mewtwoMega===true;
    const facing=(a,b)=>Math.atan2(b.y-a.y,b.x-a.x),distance=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
    function constrain(w,p,r=w.opponent.radius){
      const c=w.combat,margin=r+8;
      const bounded={x:clamp(p.x,c.left+margin,c.right-margin),y:clamp(p.y,c.top+margin,c.bottom-margin)};
      return Ia(bounded.x,bounded.y,r,c,bounded.x,bounded.y);
    }
    function blocked(w,a,b,r=0){return !!(w.combat.rocks?.length&&typeof arenaReferenceArenas!=='undefined'&&arenaReferenceArenas.blocksShot(w.combat.rocks,a.x,a.y,{...b,radius:r}));}
    function attack(w,kind,phase,durationMs){return{kind,phase,durationMs,elapsedMs:0,progress:0,facing:w.opponent.facing,origin:center(w.opponent),target:center(w.player),alpha:1,mega:mega(w)};}
    function phase(a,name,ms){a.phase=name;a.durationMs=Math.max(1,ms);a.elapsedMs=0;a.progress=0;}
    function reset(w){
      const s={clock:0,nextId:1,random:lo(((Number(w.seed)||1)^0x51ab07f3)>>>0),history:[],nextTeleportAt:2200,
        attack:attack(w,'idle','idle',800/speed(w)),clones:[],projectiles:[],beams:[],impacts:[],nextBeamHit:0,entry:w.player.entry,illusionResolved:true,illusionFailure:false};
      worlds.set(w,s);return s;
    }
    function impact(s,kind,p,radius,lifeMs=500){s.impacts.push({id:s.nextId++,kind,...point(p),radius,ageMs:0,lifeMs});if(s.impacts.length>40)s.impacts.shift();}
    function idle(w,s,delay=420){s.attack=attack(w,'idle','idle',delay/speed(w));s.clones=[];s.beams=[];s.illusionFailure=false;}
    function recover(w,s,delay=500){phase(s.attack,'recover',delay/speed(w));s.attack.alpha=1;s.beams=[];s.clones=[];}
    function illusion(w){const s=worlds.get(w);return !!(s&&!s.illusionResolved&&s.attack.kind==='illusion'&&['windup','active'].includes(s.attack.phase));}
    function intangible(w){const a=worlds.get(w)?.attack;return !!(a?.kind==='teleport'&&(a.phase==='fadeout'&&a.progress>.55||a.phase==='fadein'&&a.progress<.45));}
    function keepContact(w){const a=worlds.get(w)?.attack;return !!(a&&(a.kind==='crunch'&&a.phase==='active'||a.kind==='teleport'&&a.crunch));}
    function alpha(w){const a=worlds.get(w)?.attack;if(!a)return 1;if(a.kind==='teleport')return a.phase==='fadeout'?1-a.progress:a.phase==='fadein'?a.progress:1;if(a.kind==='illusion'&&a.phase==='windup')return a.progress;return 1;}
    function hit(w,move,factor=1){
      const actor=w.opponent,target=w.player;
      if(w.phase!=='fight'||actor.hp<=0||target.hp<=0||target.iframeMs>0)return false;
      if(target.protectMs>0){w.events.push({type:'block',target:target.id,x:target.x,y:target.y});return true;}
      const damage=Math.max(1,Math.round(w.damage(actor,target,move,false)*factor*w.bossDifficulty.damage));
      w.landHit(actor,target,move,false,damage);return true;
    }
    function shot(w,s,kind,from,to,offset=0){
      const angle=facing(from,to)+offset,velocity=(kind==='shadow'?(mega(w)?810:570):kind==='rock'?600:760)*speed(w);
      const radius=(kind==='shadow'?22:kind==='rock'?40:35)*size(w);
      s.projectiles.push({id:s.nextId++,kind,x:from.x,y:from.y,prevX:from.x,prevY:from.y,vx:Math.cos(angle)*velocity,vy:Math.sin(angle)*velocity,radius,ageMs:0,lifeMs:5000/speed(w),mega:mega(w)});
      if(s.projectiles.length>90)s.projectiles.shift();
    }
    function resolveIllusion(w,success){
      const s=worlds.get(w);if(!illusion(w))return false;
      // Finish all collisions before punishing a fake hit: a real hit from the
      // same spread/area attack or simulation frame always wins the challenge.
      if(!success){s.illusionFailure=true;return true;}
      finishIllusion(w,s,true);return true;
    }
    function finishIllusion(w,s,success){
      if(!illusion(w))return;s.illusionResolved=true;s.illusionFailure=false;
      if(!success){
        phase(s.attack,'retaliate',mega(w)?200:175);
        s.attack.shadowLeft=mega(w)?2:1;s.attack.shadowNext=s.clock+(mega(w)?60:95);
        shadowVolley(w,s);impact(s,'illusion-fail',center(w.player),80*size(w),600);
      }else{impact(s,'illusion-clear',center(w.opponent),65*size(w),650);recover(w,s,900);}
    }
    function shadowVolley(w,s){
      const target=center(w.player),origins=[center(w.opponent),...s.clones.map(c=>center({...w.opponent,...c}))];
      for(const from of origins)shot(w,s,'shadow',from,target);
    }
    function makeClones(w,s,count,kind){
      const target=w.player,c=w.combat,margin=w.opponent.radius+12;
      const radius=Math.min((kind==='illusion'?200:300)*Math.min(1.15,size(w)),(c.right-c.left)/2-margin,(c.bottom-c.top)/2-margin);
      const pivot={x:clamp(target.x,c.left+radius+margin,c.right-radius-margin),y:clamp(target.y,c.top+radius+margin,c.bottom-radius-margin)};
      const total=kind==='illusion'?count+1:count,offset=s.random()*tau,real=kind==='illusion'?Math.floor(s.random()*total):-1,orbitDirection=s.random()<.5?-1:1;
      s.clones=[];
      for(let i=0;i<total;i++){
        const angle=offset+i*tau/total,p=constrain(w,{x:pivot.x+Math.cos(angle)*radius,y:pivot.y+Math.sin(angle)*radius});
        if(i===real){w.opponent.x=p.x;w.opponent.y=p.y;w.opponent.facing=facing(p,target);continue;}
        s.clones.push({id:'mewtwo-clone-'+s.nextId++,kind,...point(p),facing:facing(p,target),speciesId:w.opponent.speciesId,alpha:0,
          ageMs:0,lifeMs:kind==='illusion'?5200:4000,real:false,rocketBossScale:w.opponent.rocketBossScale,radius:w.opponent.radius,
          ...(kind==='turret'?{orbitCenter:point(pivot),orbitRadius:radius,orbitAngle:angle,orbitDirection,aimPoint:center(target)}:{})});
      }
      s.attack.origin=center(w.opponent);s.attack.target=center(w.player);s.attack.facing=w.opponent.facing;
      // Freeze every silhouette during the guessing window, including the real one.
      w.opponent.dodgeVx=w.opponent.dodgeVy=0;w.opponent.cast=null;w.opponent.pendingAction=null;
    }
    function beam(w,s,id,kind,from,angle,length,width,phaseName,progress){
      const c=w.combat,dx=Math.cos(angle),dy=Math.sin(angle);let limit=length;
      if(dx>0)limit=Math.min(limit,(c.right-from.x)/dx);else if(dx<0)limit=Math.min(limit,(c.left-from.x)/dx);
      if(dy>0)limit=Math.min(limit,(c.bottom-from.y)/dy);else if(dy<0)limit=Math.min(limit,(c.top-from.y)/dy);
      s.beams.push({id,kind,from:point(from),to:{x:from.x+dx*Math.max(0,limit),y:from.y+dy*Math.max(0,limit)},width,phase:phaseName,progress,mega:mega(w)});
    }
    function beams(w,s){
      s.beams=[];const a=s.attack,active=a.phase==='active',warning=a.phase==='windup';
      if(a.kind==='radial'&&(warning||active)){
        const origin=center(w.opponent),count=mega(w)?10:6;
        const angle=a.facing+(active?a.elapsedMs*(mega(w)?.0012:.00027)*speed(w)*a.spin:0);
        for(let i=0;i<count;i++)beam(w,s,'radial-'+i,'radial',origin,angle+i*tau/count,1100,16*size(w),active?'active':'warning',a.progress);
      }else if(a.kind==='turrets'&&(warning||active)){
        for(const clone of s.clones)beam(w,s,clone.id,'turret',center({...w.opponent,...clone}),clone.facing,1100,24*size(w),active?'active':'warning',a.progress);
      }
      if(active&&s.beams.length&&s.clock>=s.nextBeamHit){
        s.nextBeamHit=s.clock+Math.max(115,200/speed(w));
        // One shared pulse; overlapping spokes/clones cannot multiply damage.
        const p=center(w.player);
        if(s.beams.some(b=>oc(b.from,b.to,p,b.width/2+w.player.radius)!==null&&!blocked(w,b.from,p,3)))hit(w,'psychic',a.kind==='radial'?.2:.24);
      }
    }
    function threat(w){
      const p=center(w.opponent);
      return w.bullets.some(b=>{
        if(b.owner!=='player'||b.ttl<=100)return false;
        const end={x:b.x+b.vx*.24,y:b.y+b.vy*.24};
        return oc(b,end,p,w.opponent.radius+b.radius+12)!==null&&!blocked(w,b,p,b.radius);
      });
    }
    function teleport(w,s){
      s.attack=attack(w,'teleport','fadeout',350);const a=s.attack,boss=w.opponent,target=w.player;
      a.origin=point(boss);a.target=point(target);a.crunch=mega(w);
      const angle=mega(w)?target.facing+Math.PI:facing(target,boss)+(s.random()<.5?-1:1)*(1.1+s.random()*.9);
      const dist=mega(w)?110:290+s.random()*100;
      a.destination=a.crunch?constrain(w,point(target)):constrain(w,{x:target.x+Math.cos(angle)*dist,y:target.y+Math.sin(angle)*dist});
      if(a.crunch)a.radius=120*size(w);
      s.nextTeleportAt=s.clock+Math.max(3800,6200/speed(w));
      impact(s,'teleport',center(boss),70*size(w),700);
    }
    function choose(w,s){
      const pool=['illusion','radial','rock','aura','rock','aura'];
      if(mega(w))pool.push('turrets','turrets');
      if(s.clock>=s.nextTeleportAt)pool.push('teleport');
      const choices=pool.filter(k=>k!==s.history[s.history.length-1]);
      const kind=choices[Math.floor(s.random()*choices.length)];s.history.push(kind);if(s.history.length>4)s.history.shift();
      if(kind==='teleport'){teleport(w,s);return;}
      s.attack=attack(w,kind,'windup',kind==='aura'?1000:Math.max(380,(kind==='radial'?800:kind==='illusion'?480:680)/speed(w)));
      const a=s.attack;a.facing=facing(center(w.opponent),center(w.player));w.opponent.facing=a.facing;
      if(kind==='illusion'){s.illusionResolved=false;s.illusionFailure=false;makeClones(w,s,mega(w)?9:6,'illusion');}
      else if(kind==='turrets'){makeClones(w,s,w.bossDifficulty.speed>=1.3?8:6,'turret');a.durationMs=Math.max(550,1000/speed(w));}
      else if(kind==='radial')a.spin=s.random()<.5?-1:1;
      w.events.push({type:'cast',actor:'opponent',move:kind==='aura'?'aura-sphere':kind==='rock'?'rock-slide':'psychic',x:w.opponent.x,y:w.opponent.y});
    }
    function holdOrigin(w,a){
      const p=center(w.opponent),back=a.kind==='aura'?53:65,side=a.kind==='aura'?30:-28;
      return{x:p.x-Math.cos(a.facing)*back-Math.sin(a.facing)*side,y:p.y-Math.sin(a.facing)*back+Math.cos(a.facing)*side-8};
    }
    function turretRock(w,s,a,dt){
      let rock=a.rock;
      if(!rock)rock=a.rock=attack(w,'rock','windup',Math.max(240,420/speed(w)));
      rock.elapsedMs+=dt;rock.progress=clamp(rock.elapsedMs/rock.durationMs,0,1);
      if(rock.phase==='windup'){
        if(rock.durationMs-rock.elapsedMs>120){rock.target=center(w.player);rock.facing=facing(center(w.opponent),rock.target);}
        w.opponent.facing=rock.facing;rock.origin=holdOrigin(w,rock);
        if(rock.progress>=1){shot(w,s,'rock',rock.origin,rock.target);impact(s,'rock-release',rock.origin,60*size(w),320);phase(rock,'release',Math.max(120,200/speed(w)));}
      }else if(rock.progress>=1)a.rock=null;
    }
    function effects(w,s,dt){
      s.impacts=s.impacts.filter(e=>(e.ageMs+=dt)<e.lifeMs);
      s.projectiles=s.projectiles.filter(p=>{
        p.ageMs+=dt;if(p.ageMs>=p.lifeMs||w.opponent.hp<=0)return false;
        const old=point(p),next={x:p.x+p.vx*dt/1000,y:p.y+p.vy*dt/1000};p.prevX=p.x;p.prevY=p.y;p.x=next.x;p.y=next.y;
        if(!Number.isFinite(p.x+p.y)||blocked(w,old,next,p.radius)){impact(s,p.kind,old,p.radius);return false;}
        const c=w.combat;if(p.x<c.left-p.radius||p.x>c.right+p.radius||p.y<c.top-p.radius||p.y>c.bottom+p.radius)return false;
        if(oc(old,next,center(w.player),p.radius+w.player.radius)!==null&&hit(w,p.kind==='shadow'?'shadow-ball':p.kind==='rock'?'rock-slide':'aura-sphere',p.kind==='shadow'?.75:p.kind==='rock'?1.1:1.5)){
          impact(s,p.kind,center(w.player),p.radius*1.8);return false;
        }
        return true;
      });
    }
    function step(w,dt){
      const s=worlds.get(w)||reset(w),boss=w.opponent;
      if(w.phase!=='fight'||boss.hp<=0){s.clones=[];s.beams=[];s.projectiles=[];s.illusionFailure=false;s.attack=attack(w,'idle','idle',1);return;}
      if(!(dt>0))return;s.clock+=dt;
      if(s.entry!==w.player.entry){s.entry=w.player.entry;s.clones=[];s.beams=[];s.projectiles=[];s.illusionResolved=true;idle(w,s,950);}
      if(s.illusionFailure)finishIllusion(w,s,false);
      effects(w,s,dt);
      let a=s.attack;
      if(a.kind!=='illusion'&&a.kind!=='teleport'&&a.kind!=='mega'&&(boss.ailment==='sleep'||boss.ailment==='freeze')){
        s.clones=[];s.beams=[];idle(w,s,300);return;
      }
      if((a.kind==='idle'||a.phase==='recover')&&s.clock>=s.nextTeleportAt&&boss.recoverMs<=0&&threat(w)){teleport(w,s);a=s.attack;}
      a.elapsedMs+=dt;a.progress=clamp(a.elapsedMs/a.durationMs,0,1);a.alpha=alpha(w);a.origin=a.kind==='aura'||a.kind==='rock'?holdOrigin(w,a):center(boss);
      if(a.kind==='teleport'&&a.crunch&&a.phase==='fadein')a.target=center(boss);
      if(a.kind==='idle'){
        const d=distance(boss,w.player);
        if(d<220||d>470){const angle=facing(w.player,boss),goal=constrain(w,{x:w.player.x+Math.cos(angle)*360,y:w.player.y+Math.sin(angle)*360});
          const length=distance(boss,goal),amount=Math.min(length,105*speed(w)*dt/1000);
          if(length>1){const p=Ia(boss.x+(goal.x-boss.x)/length*amount,boss.y+(goal.y-boss.y)/length*amount,boss.radius,w.combat,boss.x,boss.y);boss.x=p.x;boss.y=p.y;}}
        boss.facing=facing(center(boss),center(w.player));if(a.progress>=1&&boss.recoverMs<=0)choose(w,s);
      }else if(a.kind==='mega'){if(a.progress>=1)idle(w,s,180);}
      else if(a.phase==='recover'){if(a.progress>=1)idle(w,s,160+s.random()*180);}
      else if(a.kind==='illusion'){
        for(const c of s.clones){c.ageMs+=dt;c.alpha=a.phase==='windup'?a.progress:1;}
        if(a.phase==='windup'&&a.progress>=1)phase(a,'active',4000);
        else if(a.phase==='active'&&a.progress>=1)finishIllusion(w,s,false);
        else if(a.phase==='retaliate'){
          if(a.shadowLeft>0&&s.clock>=a.shadowNext){shadowVolley(w,s);a.shadowLeft--;a.shadowNext+=mega(w)?60:95;}
          if(a.shadowLeft===0&&a.progress>=1)recover(w,s,170);
        }
      }else if(a.kind==='radial'){
        if(a.phase==='windup'&&a.progress>=1){phase(a,'active',2400/speed(w));s.nextBeamHit=s.clock;}
        else if(a.phase==='active'&&a.progress>=1)recover(w,s,600);
      }else if(a.kind==='rock'||a.kind==='aura'){
        if(a.phase==='windup'){
          // Only the early charge tracks. The final 250ms gives an honest aim cue.
          if(a.durationMs-a.elapsedMs>250){a.target=center(w.player);a.facing=facing(center(boss),a.target);boss.facing=a.facing;a.origin=holdOrigin(w,a);}
          if(a.progress>=1){shot(w,s,a.kind,a.origin,a.target);impact(s,a.kind+'-release',a.origin,(a.kind==='aura'?52:60)*size(w),320);phase(a,'release',220/speed(w));}
        }else if(a.phase==='release'&&a.progress>=1)recover(w,s,420);
      }else if(a.kind==='turrets'){
        for(const c of s.clones){c.ageMs+=dt;c.alpha=a.phase==='windup'?clamp(a.progress*2,0,1):a.phase==='fade'?1-a.progress:1;
          c.orbitAngle+=dt*.00065*speed(w)*c.orbitDirection;
          const p=constrain(w,{x:c.orbitCenter.x+Math.cos(c.orbitAngle)*c.orbitRadius,y:c.orbitCenter.y+Math.sin(c.orbitAngle)*c.orbitRadius});
          c.x=p.x;c.y=p.y;
          if(a.phase==='windup'&&a.durationMs-a.elapsedMs>300)c.aimPoint=center(w.player);
          c.facing=facing(center({...boss,...c}),c.aimPoint);}
        if(a.phase==='windup'&&a.progress>=1){phase(a,'active',2200);s.nextBeamHit=s.clock;}
        if(a.phase==='active'){
          if(a.progress>=1){phase(a,'fade',350);a.rock=null;s.beams=[];}
          else turretRock(w,s,a,dt);
        }
        else if(a.phase==='fade'&&a.progress>=1)recover(w,s,450);
      }else if(a.kind==='teleport'){
        if(a.phase==='fadeout'&&a.progress>=1){
          // Lock the landing point only when he vanishes, so movement during
          // fade-out cannot leave the contact attack behind the player.
          if(a.crunch)a.destination=constrain(w,point(w.player));
          boss.x=a.destination.x;boss.y=a.destination.y;boss.facing=facing(center(boss),center(w.player));a.facing=boss.facing;
          if(a.crunch)a.target=center(boss);
          phase(a,'fadein',a.crunch?220:350);
        }
        else if(a.phase==='fadein'&&a.progress>=1){
          if(a.crunch){
            s.attack=attack(w,'crunch','active',200);s.attack.radius=a.radius;s.attack.facing=boss.facing;
            const p=center(boss),target=center(w.player);s.attack.target=point(p);
            impact(s,'crunch',p,a.radius,400);
            if(distance(p,target)<=a.radius+w.player.radius&&!blocked(w,p,target,4))hit(w,'crunch',1.4);
          }
          else recover(w,s,400);
        }
      }else if(a.kind==='crunch'){
        if(a.phase==='active'&&a.progress>=1)recover(w,s,650);
      }
      beams(w,s);
    }
    function evolved(w){const s=worlds.get(w)||reset(w);s.clones=[];s.beams=[];s.projectiles=[];s.illusionResolved=true;s.illusionFailure=false;s.attack=attack(w,'mega','active',900);impact(s,'mega',center(w.opponent),140,1000);}
    function clonesHit(w,predicate){
      const s=worlds.get(w);if(!illusion(w))return false;
      const real=w.opponent;
      if(real.hp>0&&real.iframeMs<=0&&real.protectMs<=0&&predicate(real)){resolveIllusion(w,true);return false;}
      if(s.clones.some(c=>predicate({...w.opponent,...c}))){resolveIllusion(w,false);return true;}
      return false;
    }
    function interceptBullets(w){
      const s=worlds.get(w);if(!illusion(w))return;
      const kept=[];
      for(const b of w.bullets){
        if(!illusion(w)||b.owner!=='player'||b.ttl<=q){kept.push(b);continue;}
        const to={x:b.x+b.vx*Sa,y:b.y+b.vy*Sa};
        if(b.basic&&(b.flown||0)+distance(b,to)>=380||blocked(w,b,to,b.radius)){kept.push(b);continue;}
        const targets=[{actor:w.opponent,real:true},...s.clones.map(c=>({actor:{...w.opponent,...c},real:false}))];
        const hits=targets.map(t=>({...t,t:oc(b,to,center(t.actor),b.radius+t.actor.radius)})).filter(t=>t.t!==null).sort((a,b)=>a.t-b.t);
        const target=hits[0];if(!target){kept.push(b);continue;}
        if(!target.real){resolveIllusion(w,false);continue;}
        if(w.opponent.iframeMs>0||intangible(w)){kept.push(b);continue;}
        if(w.opponent.protectMs>0){w.events.push({type:'block',target:'opponent',x:w.opponent.x,y:w.opponent.y});continue;}
        resolveIllusion(w,true);
        if(b.basic)w.landBasic(w.player,w.opponent,b.move,b.basicType,b.basicPct);
        else{const move=V(b.move);if(move.shape==='hex'){if(!w.resistsHex(w.opponent,move))w.applyHex(w.opponent,move);}else w.landHit(w.player,w.opponent,b.move,b.ult);}
        w.knock(w.opponent,b.vx,b.vy,b.knockback);
      }
      w.bullets=kept;
    }
    function aimTarget(w,actor,target){
      const s=worlds.get(w);if(actor.id!=='player'||!illusion(w))return target;
      // Aim assistance sees equally plausible silhouettes, never a hidden real ID.
      return [w.opponent,...s.clones.map(c=>({...w.opponent,...c}))].sort((a,b)=>distance(a,actor)-distance(b,actor))[0];
    }
    function autoProtectThreat(w,horizonMs,predictPlayer){
      const s=worlds.get(w),boss=w.opponent;
      if(!s||w.phase!=='fight'||boss.hp<=0||w.player.hp<=0)return false;
      const probe=rocketBossAttacks.threatProbe(w,horizonMs,predictPlayer),a=s.attack,left=Math.max(0,a.durationMs-a.elapsedMs);
      const dangerous=(move,factor=1,total=1)=>Math.max(1,Math.round(probe.damage(boss,move)*factor*w.bossDifficulty.damage))*total>12;
      const projectile=(p,start=0)=>dangerous(p.kind==='shadow'?'shadow-ball':p.kind==='rock'?'rock-slide':'aura-sphere',p.kind==='shadow'?.75:p.kind==='rock'?1.1:1.5)&&probe.projectile(p,start);
      const pendingShot=(kind,from,to,time)=>{
        const angle=facing(from,to),velocity=(kind==='shadow'?(mega(w)?810:570):kind==='rock'?600:760)*speed(w);
        return projectile({kind,...point(from),vx:Math.cos(angle)*velocity,vy:Math.sin(angle)*velocity,
          radius:(kind==='shadow'?22:kind==='rock'?40:35)*size(w),ageMs:0,lifeMs:5000/speed(w)},time);
      };
      for(const p of s.projectiles)if(projectile(p))return true;
      if((a.kind==='rock'||a.kind==='aura')&&a.phase==='windup'&&left<=probe.horizon&&pendingShot(a.kind,holdOrigin(w,a),a.target,left))return true;
      const rock=a.rock;
      if(a.kind==='turrets'&&a.phase==='active'&&rock?.phase==='windup'){
        const due=Math.max(0,rock.durationMs-rock.elapsedMs);
        if(due<left&&pendingShot('rock',holdOrigin(w,rock),rock.target,due))return true;
      }
      if(a.kind==='illusion'){
        // Successful guesses clear these before retaliation; prediction never
        // resolves the challenge or advances its random sequence.
        const due=s.illusionFailure?0:a.phase==='active'&&!s.illusionResolved?left:
          a.phase==='retaliate'&&a.shadowLeft>0?Math.max(0,a.shadowNext-s.clock):Infinity;
        if(due<=probe.horizon){
          const target=predictPlayer(due,true)||center(w.player);
          for(const from of [center(boss),...s.clones.map(c=>center({...boss,...c}))])
            if(pendingShot('shadow',from,target,due))return true;
        }
      }
      if((a.kind==='radial'||a.kind==='turrets')&&['windup','active'].includes(a.phase)){
        const delay=a.phase==='windup'?left:0,duration=a.phase==='windup'?(a.kind==='radial'?2400/speed(w):2200):a.durationMs;
        const elapsed=a.phase==='active'?a.elapsedMs:0,interval=Math.max(115,200/speed(w));
        const first=a.phase==='windup'?delay:Math.max(q,s.nextBeamHit-s.clock);
        if(dangerous('psychic',a.kind==='radial'?.2:.24,Math.max(1,Math.ceil((duration-elapsed)/interval))))
          for(let time=first;time<=Math.min(probe.horizon,delay+duration-elapsed);time+=interval){
            if(a.kind==='radial'){
              const from=center(boss),count=mega(w)?10:6,angle=a.facing+(elapsed+time-delay)*(mega(w)?.0012:.00027)*speed(w)*a.spin;
              for(let i=0;i<count;i++){
                const facing=angle+i*tau/count,to={x:from.x+Math.cos(facing)*1100,y:from.y+Math.sin(facing)*1100};
                if(probe.beam(from,to,16*size(w),time))return true;
              }
            }else for(const c of s.clones){
              const angle=c.orbitAngle+time*.00065*speed(w)*c.orbitDirection;
              const feet=constrain(w,{x:c.orbitCenter.x+Math.cos(angle)*c.orbitRadius,y:c.orbitCenter.y+Math.sin(angle)*c.orbitRadius});
              const from=center({...boss,...c,...feet}),aim=c.aimPoint||center(w.player),angleTo=facing(from,aim);
              if(probe.beam(from,{x:from.x+Math.cos(angleTo)*1100,y:from.y+Math.sin(angleTo)*1100},24*size(w),time))return true;
            }
          }
      }
      if(a.kind==='teleport'&&a.crunch&&dangerous('crunch',1.4)){
        const due=left+(a.phase==='fadeout'?220:0);
        const destination=a.phase==='fadeout'?(predictPlayer(left,false)||point(w.player)):point(boss);
        if(probe.disc(center({...boss,...destination}),a.radius,due,true))return true;
      }
      return false;
    }
    function snapshot(w,result){
      const s=worlds.get(w);if(!s)return result;
      result.rocketMewtwoBoss={hp:w.opponent.hp,maxHp:w.opponent.maxHp,mega:mega(w),illusion:s.attack.kind==='illusion'&&['windup','active'].includes(s.attack.phase),
        attack:structuredClone({...s.attack,alpha:alpha(w)}),clones:structuredClone(s.clones),projectiles:structuredClone(s.projectiles),beams:structuredClone(s.beams),impacts:structuredClone(s.impacts)};
      return result;
    }
    return Object.freeze({reset,step,snapshot,evolved,intangible,keepContact,alpha,illusion,resolveIllusion,clonesHit,interceptBullets,aimTarget,autoProtectThreat,clear:w=>worlds.delete(w)});
  }
  function arenaMewtwoBossWorldType(){
    return class RocketMewtwoWorld extends bc {
      constructor(options={}){
        super({...options,ai:true,playerAi:false,cpuSwitch:false,rosterForms:true,difficulty:'hard',clock:'countup',
          stageId:arenaMewtwoBoss.stage,arenaCpuMode:null,thirdPartyIds:undefined,thirdPartyLoadouts:undefined,
          story:null,bossAdvantage:undefined,partyHpRatio:null,opponentSpeciesId:'mewtwo',opponentPartyIds:['mewtwo'],opponentPartyLoadouts:[un('mewtwo').slice()]});
        this.bossDifficulty=arenaBossDifficulty.get('mewtwo');this.arenaMewtwoBoss=true;this.configureMewtwo();
      }
      configureMewtwo(){
        this.ai=false;this.playerAi=false;this.cpuSwitch=false;this.foeMegaUsed=false;this.mewtwoMega=false;
        this.placeFighter('player',680,740);this.placeFighter('opponent',1370,590);this.resizeMewtwo(this.opponent);
        this.opponent.hp=this.opponent.maxHp;this.rememberHp(this.opponent);rocketMewtwoCombat.reset(this);
      }
      resizeMewtwo(actor){
        actor.maxHp=Math.round(arenaMewtwoBoss.hp*this.bossDifficulty.health);actor.radius=arenaMewtwoBoss.radius;
        actor.rocketBossScale=arenaMewtwoBoss.visualScale(actor.speciesId);
        const p=Ia(actor.x,actor.y,actor.radius,this.combat,actor.x,actor.y);actor.x=p.x;actor.y=p.y;
        if(this.foeParty?.[0])this.foeParty[0].species={...dn(actor.speciesId),maxHp:actor.maxHp,radius:actor.radius};
      }
      reset(){super.reset();if(this.arenaMewtwoBoss)this.configureMewtwo();}
      adopt(actor,species,hp){super.adopt(actor,species,hp);if(this.arenaMewtwoBoss&&actor.id==='opponent')this.resizeMewtwo(actor);}
      canMega(side){return this.arenaMewtwoBoss&&side==='opponent'?false:super.canMega(side);}
      rocketAutoProtectThreat(horizonMs,predictPlayer){return rocketMewtwoCombat.autoProtectThreat(this,horizonMs,predictPlayer);}
      arenaTypeMultiplier(actor,type,types){
        const value=super.arenaTypeMultiplier(actor,type,types);
        // Boss and clone hits share this actor and the native damage/immunity gate.
        return this.arenaMewtwoBoss&&actor===this.opponent&&value===0?1:value;
      }
      evolveMewtwo(){
        const actor=this.opponent;if(this.mewtwoMega||actor.hp<=0||actor.hp>=actor.maxHp*.5)return;
        const health=actor.hp,from=actor.speciesId,loadout=actor.loadout.slice(),species=dn('mewtwomegax');
        // Explicit X: native Mewtwo's special-heavy moveset would choose Y.
        this.foeParty[0].species=species;this.adopt(actor,species,health);actor.loadout=loadout;
        actor.cast=null;actor.pendingAction=null;actor.dodgeVx=actor.dodgeVy=0;actor.iframeMs=Math.max(actor.iframeMs,700);actor.recoverMs=700;
        this.mewtwoMega=true;this.setMegaUsed('opponent');this.rememberHp(actor);
        this.events.push({type:'mega',actor:'opponent',from,to:'mewtwomegax',x:actor.x,y:actor.y});rocketMewtwoCombat.evolved(this);
      }
      hurt(actor,amount,move,guard=true,detail={}){
        if(this.arenaMewtwoBoss&&actor.id==='opponent'){
          if(rocketMewtwoCombat.intangible(this))return;
          if(amount>0&&detail.direct&&detail.actor==='player'&&actor.iframeMs<=0&&actor.protectMs<=0)rocketMewtwoCombat.resolveIllusion(this,true);
          if(amount>0)amount=Math.max(1,Math.round(amount/(6.5*this.bossDifficulty.health)));
        }
        return super.hurt(actor,amount,move,guard,detail);
      }
      landHit(actor,target,...args){
        if(this.arenaMewtwoBoss&&target.id==='opponent'){
          if(rocketMewtwoCombat.intangible(this))return 0;
          if(actor.id==='player'&&target.hp>0&&target.iframeMs<=0&&target.protectMs<=0)rocketMewtwoCombat.resolveIllusion(this,true);
        }
        return super.landHit(actor,target,...args);
      }
      landBasic(actor,target,...args){
        if(this.arenaMewtwoBoss&&target.id==='opponent'){
          if(rocketMewtwoCombat.intangible(this))return 0;
          if(actor.id==='player'&&target.hp>0&&target.iframeMs<=0&&target.protectMs<=0)rocketMewtwoCombat.resolveIllusion(this,true);
        }
        return super.landBasic(actor,target,...args);
      }
      applyHex(actor,move){if(this.arenaMewtwoBoss&&actor.id==='opponent'){if(rocketMewtwoCombat.intangible(this))return;rocketMewtwoCombat.resolveIllusion(this,true);}return super.applyHex(actor,move);}
      trySecondary(actor,move){if(this.arenaMewtwoBoss&&actor.id==='opponent'&&rocketMewtwoCombat.intangible(this))return;return super.trySecondary(actor,move);}
      updateBullets(){if(this.arenaMewtwoBoss)rocketMewtwoCombat.interceptBullets(this);return super.updateBullets();}
      applyMelee(actor,target,move,angle,ult=false){
        if(this.arenaMewtwoBoss&&actor.id==='player'&&rocketMewtwoCombat.clonesHit(this,c=>Math.hypot(c.x-actor.x,c.y-actor.y)<=move.range+c.radius&&sc(c.x-actor.x,c.y-actor.y,angle,c.radius)))return;
        return super.applyMelee(actor,target,move,angle,ult);
      }
      applyBasicMelee(actor,target,cast){
        if(this.arenaMewtwoBoss&&actor.id==='player'&&rocketMewtwoCombat.clonesHit(this,c=>{const p=rc(actor.speciesId,actor.x,actor.y),t=arenaBossRush.center(c);return Math.hypot(t.x-p.x,t.y-p.y)<=100+c.radius&&sc(t.x-p.x,t.y-p.y,cast.facing,c.radius);}))return;
        return super.applyBasicMelee(actor,target,cast);
      }
      applyRing(actor,target,move,ult=false){
        if(this.arenaMewtwoBoss&&actor.id==='player'&&rocketMewtwoCombat.clonesHit(this,c=>Math.hypot(c.x-actor.x,c.y-actor.y)<=move.range))return;
        return super.applyRing(actor,target,move,ult);
      }
      streamTick(actor,target,cast){
        if(this.arenaMewtwoBoss&&actor.id==='player'&&rocketMewtwoCombat.clonesHit(this,c=>xa(actor,cast.facing,cast.range,cast.halfAngle,c))){cast.ticksLeft--;return;}
        return super.streamTick(actor,target,cast);
      }
      applyDash(actor,cast,target){
        if(this.arenaMewtwoBoss&&actor.id==='player'&&!cast.hit&&rocketMewtwoCombat.clonesHit(this,c=>oc(actor,{x:actor.x+cast.vx*Sa,y:actor.y+cast.vy*Sa},c,actor.radius+c.radius+6)!==null)){cast.hit=true;}
        return super.applyDash(actor,cast,target);
      }
      strikeZone(zone,index){
        if(this.arenaMewtwoBoss&&zone.owner==='player'&&rocketMewtwoCombat.clonesHit(this,c=>Math.hypot(c.x-zone.x,c.y-zone.y)<=zone.r))return;
        return super.strikeZone(zone,index);
      }
      direction(actor,input,target,move){return super.direction(actor,input,this.arenaMewtwoBoss?rocketMewtwoCombat.aimTarget(this,actor,target):target,move);}
      basicDirection(actor,input,target,move){return super.basicDirection(actor,input,this.arenaMewtwoBoss?rocketMewtwoCombat.aimTarget(this,actor,target):target,move);}
      knock(actor,...args){if(this.arenaMewtwoBoss&&actor.id==='opponent'&&(rocketMewtwoCombat.illusion(this)||rocketMewtwoCombat.intangible(this)))return;return super.knock(actor,...args);}
      separate(){if(this.arenaMewtwoBoss&&(rocketMewtwoCombat.illusion(this)||rocketMewtwoCombat.intangible(this)||rocketMewtwoCombat.keepContact(this)))return;return super.separate();}
      step(input=bo()){
        const tick=this.tick,result=super.step(input,bo());if(this.tick===tick)return result;
        const start=this.events.length;if(this.phase==='fight')this.evolveMewtwo();rocketMewtwoCombat.step(this,q);
        if(this.phase==='fight'&&this.stopTicks===0)this.resolveKnockouts();
        if(this.phase!=='fight')rocketMewtwoCombat.step(this,0);
        if(result.events!==this.events)result.events.push(...this.events.slice(start));result.state=this.getState();return result;
      }
      snapshot(actor){const state=super.snapshot(actor);if(this.arenaMewtwoBoss&&actor.id==='opponent'){state.rocketBossScale=actor.rocketBossScale;state.rocketMewtwoAlpha=rocketMewtwoCombat.alpha(this);state.rocketMewtwoIllusion=rocketMewtwoCombat.illusion(this);}return state;}
      aiBody(actor){const body=super.aiBody(actor);if(this.arenaMewtwoBoss&&actor.id==='opponent')body.rocketBossScale=actor.rocketBossScale;return body;}
      getState(){const state=super.getState();if(this.arenaMewtwoBoss){state.rocketMewtwoBossFight=true;rocketMewtwoCombat.snapshot(this,state);}return state;}
      dispose(){rocketMewtwoCombat.clear(this);this.events=[];this.bullets=[];this.zones=[];this.cancelBufferedInput();}
    };
  }
  function patch(source){return 'const rocketMewtwoCombat=('+createRocketMewtwoCombat.toString()+')();\n'+arenaMewtwoBossWorldType.toString()+'\n'+source;}
  const api=Object.freeze({patch});globalThis.ArenaMewtwoWorldAdapter=api;
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})();
