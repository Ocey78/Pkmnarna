// Run a local practice arena alongside the official waiting-room scene.
(() => {
  'use strict';

  function createArenaTrainingLobby() {
    const key = 'rocket-training';
    let current = null;

    function waiting(room) {
      return room?.state === 'open' || room?.state === 'lobby';
    }

    function allReady(room) {
      const count = room.mode === 'ffa3' ? 3 : 2;
      return Array.from({length: count}, (_, index) => room.seats?.[index])
        .every(seat => seat?.present === true && seat.ready === true && !seat.editing);
    }

    function inRoom(controller) {
      return !!controller?.active && controller === hO && controller.mode === 'room' &&
        !controller.battle && waiting(controller.room) && controller.room.code === controller.code &&
        controller.room.seats?.[Fc(controller.you)]?.present === true && controller.client?.ws?.readyState === 1;
    }

    function canBegin(controller = hO) {
      return !current && inRoom(controller) && !allReady(controller.room) &&
        !controller.room.seats[Fc(controller.you)].editing && uT(controller.team);
    }

    function canEdit(session) {
      return current === session && !session.editing && inRoom(session.controller) &&
        !allReady(session.controller.room) && session.scene?.ready === true;
    }

    function clearInput(scene) {
      const controls = scene?.controls;
      if (!controls) return;
      controls.setEnabled(false);
      controls.keyboard.held.clear();
      controls.releaseAttacks();
      controls.clearPreview();
      controls.switchSlot = null;
      controls.megaLatch = false;
      scene.world.cancelBufferedInput();
    }

    function editStart(session) {
      if (!canEdit(session)) return false;
      session.editing = true;
      session.savedTeam = JSON.stringify([session.controller.team, session.controller.moves]);
      clearInput(session.scene);
      // Native movement listens directly on window even when its scene is paused.
      session.scene.controls.keyboard.destroy();
      session.manager.pause(key);
      Z.hideBattleHud();
      return true;
    }

    function editEnd(session) {
      if (current !== session || !session.editing) return;
      session.editing = false;
      const controller = session.controller;
      if (!inRoom(controller) || allReady(controller.room)) {
        close(session, true, false);
        return;
      }
      try {
        if (session.savedTeam !== JSON.stringify([controller.team, controller.moves])) {
          session.scene.rocketApplyTeam(controller.team.slice(), copyMoves(controller.moves));
        }
        clearInput(session.scene);
        session.scene.controls.keyboard.attach(window);
        Z.bindControls(session.scene.controls);
        session.manager.resume(key);
        arenaTrainingUi.update(controller);
      } catch (error) {
        console.warn('[arena] Could not resume practice with the selected team', error);
        close(session, true, true);
        fO(ZD(), 'Your room is open. Reopen Training to practice with this team.');
      }
    }

    function copyMoves(moves) {
      return [0, 1, 2].map(index => Array.isArray(moves?.[index]) ? moves[index].slice() : null);
    }

    function openOptions(session) {
      if (!editStart(session)) return null;
      session.optionsOpen = true;
      return {...session.practice, opponentPartyIds:session.practice.opponentPartyIds.slice()};
    }

    function closeOptions(session) {
      if (current !== session || !session.optionsOpen) return;
      session.optionsOpen = false;
      editEnd(session);
    }

    function applyOptions(session, draft) {
      if (current !== session || !session.optionsOpen) return;
      if (!inRoom(session.controller) || allReady(session.controller.room)) {
        close(session, true);
        return;
      }
      if (typeof draft?.ai !== 'boolean' || !['easy','normal','hard'].includes(draft.difficulty))
        throw Error('Choose a CPU difficulty.');
      if (!ou.some(stage => stage.id === draft.stageId)) throw Error('Choose an arena map.');
      const party = draft.opponentPartyIds;
      if (!Array.isArray(party) || party.length !== 3 || new Set(party).size !== 3 ||
          party.some(id => !hn.has(id) || arenaGmaxSpecies(dn(id)))) throw Error('Choose three different Pokémon.');
      const previous = session.practice;
      const next = {ai:draft.ai, difficulty:draft.difficulty, stageId:draft.stageId, opponentPartyIds:party.slice()};
      if (previous.stageId !== next.stageId) {
        session.practice = next;
        session.editing = session.optionsOpen = false;
        session.manager.stop(key);
        session.scene = null;
        launch(session);
        return;
      }
      if (party.some((id, index) => id !== previous.opponentPartyIds[index])) {
        session.scene.rocketApplyTeam(next.opponentPartyIds, [null,null,null], 'opponent');
      }
      if (previous.ai !== next.ai || previous.difficulty !== next.difficulty) {
        session.scene.rocketConfigureCpu(next.ai, next.difficulty);
      }
      session.practice = next;
      closeOptions(session);
    }

    function launch(session) {
      const {controller, manager} = session;
      session.frame = 0;
      if (current !== session) return;
      if (!inRoom(controller) || allReady(controller.room)) {
        close(session, true, false);
        return;
      }
      // Add/start outside Phaser's scene-queue iteration. A countdown can cancel
      // this frame before an asynchronous load or new arena has been scheduled.
      if (manager.isProcessing || !manager.isBooted) {
        session.frame = requestAnimationFrame(() => launch(session));
        return;
      }
      try {
        const seed = crypto.getRandomValues(new Uint32Array(1))[0];
        const partyIds = controller.team.slice();
        session.practice ??= {ai:true, difficulty:'hard', stageId:fu(), opponentPartyIds:yo(partyIds, seed)};
        const {ai, difficulty, stageId, opponentPartyIds} = session.practice;
        if (!manager.keys[key]) manager.add(key, arenaTrainingSceneType(), false);
        session.scene = manager.keys[key];
        manager.start(key, {
          source: 'cpu', arenaTraining: true, rocketLobbyTraining: true,
          trainingAi:ai, difficulty, cpuSwitch:true, seed, stageId,
          playerSpeciesId: partyIds[0], partyIds, partyLoadouts: copyMoves(controller.moves),
          opponentSpeciesId: opponentPartyIds[0], opponentPartyIds
        });
        manager.bringToTop(key);
      } catch (error) {
        console.warn('[arena] Could not open room practice', error);
        close(session, true, true);
        fO(ZD(), 'Training could not open. Your room is still available.');
      }
    }

    function begin(controller = hO) {
      if (!canBegin(controller)) return false;
      const session = {
        controller, manager: controller.scene.game.scene, scene: null,
        code: controller.code, seat: controller.you, frame: 0, editing: false, savedTeam: null,
        practice: null, optionsOpen: false
      };
      current = session;
      // The native controller backgrounds its connection when the page is hidden.
      session.visibility = () => { if (document.hidden) close(session, true, false); };
      document.addEventListener('visibilitychange', session.visibility);
      try {
        arenaTrainingUi.open(controller, {
          back: () => close(session, true, true), canEdit: () => canEdit(session),
          editStart: () => editStart(session), editEnd: () => editEnd(session),
          openOptions: () => openOptions(session), closeOptions: () => closeOptions(session),
          applyOptions: draft => applyOptions(session, draft)
        });
        launch(session);
      } catch (error) {
        console.warn('[arena] Could not open room practice', error);
        close(session, true, true);
        fO(ZD(), 'Training could not open. Your room is still available.');
      }
      return current === session;
    }

    function close(session, repaint, allowNativeCancel = false) {
      if (!session || current !== session) return false;
      const {controller, manager} = session;
      current = null;
      if (session.frame) cancelAnimationFrame(session.frame);
      document.removeEventListener('visibilitychange', session.visibility);
      try {
        arenaTrainingUi.close(controller, {allowNativeCancel: allowNativeCancel && inRoom(controller)});
      } finally {
        if (session.scene) manager.stop(key);
        if (controller.active && controller === hO && controller.mode === 'room') {
          controller.scene.game.canvas.dataset.mode = 'room';
          if (repaint) controller.paintRoom();
        }
      }
      return true;
    }

    function beforePacket(controller, packet) {
      const session = current;
      if (!session || session.controller !== controller) return;
      // The server can send a stand-alone countdown/start before a final room
      // snapshot. Release all practice UI and input before the native handler.
      if (packet.t === 'room') {
        if (!waiting(packet) || packet.code !== session.code || packet.you !== session.seat ||
            !packet.seats?.[Fc(session.seat)]?.present || allReady(packet)) close(session, false);
      } else if (['countdown','start','resume','dissolved','kicked','error'].includes(packet.t)) {
        close(session, false);
      }
    }

    function roomPainted(controller) {
      if (current?.controller === controller) arenaTrainingUi.update(controller);
      else if (canBegin(controller)) arenaTrainingUi.room(controller, {start: () => begin(controller)});
    }

    function closed(controller, repaint) {
      if (current?.controller === controller) close(current, repaint);
    }

    return {
      beforePacket, roomPainted, closed, begin, canBegin,
      active: (controller = hO) => !!current && current.controller === controller,
      editing: (controller = hO) => !!current?.editing && current.controller === controller,
      exit: (controller = hO) => !!current && current.controller === controller && close(current, true, true),
      isEditing: scene => !!current?.editing && current.scene === scene,
      leaveActive: scene => !!current && current.scene === scene && close(current, true, true),
      sceneReady(scene) { if (current?.scene === scene) arenaTrainingUi.update(current.controller); }
    };
  }

  function patch(original) {
    let source = original;
    function replace(before, after) {
      const parts = source.split(before);
      if (parts.length !== 2) throw Error('Unsupported game build for waiting-room training.');
      source = parts.join(after);
    }
    const message = 'onMessage(e){if(this.active){if(e.t===`cloud-plan`)';
    replace(message, 'onMessage(e){if(this.active){arenaTrainingLobby.beforePacket(this,e);if(e.t===`cloud-plan`)');
    const paint = '},{connection:this.connectionLabel})}sendCurrentTeam(){';
    replace(paint, '},{connection:this.connectionLabel});arenaTrainingLobby.roomPainted(this)}sendCurrentTeam(){');
    const closed = 'this.client.onClose(this.lifetime.guard(e=>{';
    replace(closed, closed + 'arenaTrainingLobby.closed(this,e===`drop`);');
    const stop = 'this.networkSetup?.finish(`leave`),this.finishNetwork(`leave`),this.lifetime.close()';
    replace(stop, 'arenaTrainingLobby.closed(this,false),' + stop);
    return 'const arenaTrainingLobby=(' + createArenaTrainingLobby.toString() + ')();\n' + source;
  }

  const api = Object.freeze({patch});
  globalThis.ArenaTrainingLobbyAdapter = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})();
