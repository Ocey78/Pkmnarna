// Project the current animation frame onto the floor and let elemental attacks light nearby ground.
(() => {
  'use strict';

  function rocketPaintStageLight(ctx, state, options = {}) {
    if (!ctx || !Array.isArray(state?.fighters)) return;
    const cache = rocketPaintStageLight.cache ||= {
      silhouettes: new Map(),
      lamps: new Map(),
      colors: {
        fire: '#ff9952', water: '#6edafc', electric: '#ffe868', ice: '#a6faff',
        poison: '#cb88f5', psychic: '#ff86d8', ghost: '#aa88ff', dragon: '#9c8bff',
        fairy: '#ffbce5', grass: '#9bd876', steel: '#b2d6ed'
      }
    };
    const opacity = ctx.globalAlpha;
    const reduced = Boolean(options.reduced);
    const clock = Number.isFinite(options.timeMs) ? options.timeMs : 0;

    function bitmap(width, height) {
      if (typeof OffscreenCanvas === 'function') return new OffscreenCanvas(width, height);
      const image = document.createElement('canvas');
      image.width = width;
      image.height = height;
      return image;
    }

    function silhouette(frame) {
      if (cache.silhouettes.has(frame)) return cache.silhouettes.get(frame);
      const source = frame.source?.image;
      if (!source || source.complete === false || !frame.canvasData ||
          !(frame.cutWidth > 0 && frame.cutHeight > 0)) return null;
      const ratio = Math.min(1, 96 / Math.max(frame.cutWidth, frame.cutHeight));
      const stamp = bitmap(Math.max(1, Math.ceil(frame.cutWidth * ratio)), Math.max(1, Math.ceil(frame.cutHeight * ratio)));
      const brush = stamp.getContext('2d');
      if (!brush) return null;
      brush.imageSmoothingEnabled = false;
      brush.drawImage(source, frame.canvasData.x, frame.canvasData.y, frame.cutWidth, frame.cutHeight,
        0, 0, stamp.width, stamp.height);
      brush.globalCompositeOperation = 'source-in';
      brush.fillStyle = '#1c273c';
      brush.fillRect(0, 0, stamp.width, stamp.height);
      if (cache.silhouettes.size >= 96) cache.silhouettes.delete(cache.silhouettes.keys().next().value);
      cache.silhouettes.set(frame, stamp);
      return stamp;
    }

    function shadow(fighter, radius, sprite) {
      if (sprite && (sprite.visible === false || sprite.alpha <= 0)) return;
      const frame = sprite?.frame;
      const stamp = frame ? silhouette(frame) : null;
      if (stamp) {
        const resolution = frame.source.resolution || 1;
        const xScale = Math.abs(sprite.scaleX || 1), yScale = Math.abs(sprite.scaleY || 1);
        const xOrigin = (sprite.displayOriginX - frame.x) * xScale;
        const yOrigin = (sprite.displayOriginY - frame.y) * yScale;
        // Pixel rows higher on the actual Pokémon project farther southeast from its feet.
        ctx.save();
        ctx.translate(fighter.x, fighter.y + radius * .13);
        ctx.transform(sprite.flipX ? -.79 : .79, 0, -.48, -.24, 0, 0);
        ctx.globalAlpha = opacity * .24 * (sprite.alpha ?? 1);
        ctx.imageSmoothingEnabled = false;
        ctx.drawImage(stamp, -xOrigin, -yOrigin, frame.cutWidth / resolution * xScale, frame.cutHeight / resolution * yScale);
        ctx.restore();
      } else {
        // DOM menu actors have their own contact oval. Extend its shadow in the same direction.
        const x = fighter.x, y = fighter.y + radius * .12;
        ctx.fillStyle = '#253047';
        ctx.globalAlpha = opacity * .19;
        ctx.beginPath();
        ctx.moveTo(x - radius * .61, y);
        ctx.quadraticCurveTo(x + radius * .04, y - radius * .23, x + radius * .91, y + radius * .12);
        ctx.quadraticCurveTo(x + radius * 2.1, y + radius * .49, x + radius * 1.24, y + radius * .77);
        ctx.quadraticCurveTo(x + radius * .76, y + radius * .83, x - radius * .61, y);
        ctx.fill();
      }
    }

    function lamp(type) {
      const color = cache.colors[type];
      if (!color) return null;
      if (cache.lamps.has(type)) return cache.lamps.get(type);
      const stamp = bitmap(64, 64), brush = stamp.getContext('2d');
      if (!brush) return null;
      const falloff = brush.createRadialGradient(32, 32, 0, 32, 32, 32);
      falloff.addColorStop(0, '#fff5e9e8');
      falloff.addColorStop(.15, color + 'da');
      falloff.addColorStop(.38, color + '79');
      falloff.addColorStop(.72, color + '20');
      falloff.addColorStop(1, color + '00');
      brush.fillStyle = falloff;
      brush.fillRect(0, 0, 64, 64);
      cache.lamps.set(type, stamp);
      return stamp;
    }

    function glow(x, y, radius, type, power) {
      const stamp = lamp(type);
      if (!stamp) return;
      const h = radius * .67;
      ctx.save();
      ctx.imageSmoothingEnabled = true;
      // Screen blending keeps the floor texture visible through the soft light.
      ctx.globalCompositeOperation = 'screen';
      const intensity = opacity * power * (reduced ? .64 : 1);
      ctx.globalAlpha = intensity * .76;
      ctx.drawImage(stamp, x - radius, y - h, radius * 2, h * 2);
      ctx.globalAlpha = intensity * .27;
      ctx.drawImage(stamp, x - radius * .46, y - h * .46, radius * .92, h * .92);
      ctx.restore();
    }

    ctx.save();
    try {
      for (const fighter of state.fighters) {
        if (!(fighter.hp > 0) || !Number.isFinite(fighter.x) || !Number.isFinite(fighter.y) ||
            options.hiddenFighter?.(fighter.id)) continue;
        const radius = Math.min(76, Math.max(8, fighter.radius || 18));
        const sprite = options.spriteFor?.(fighter.id);
        if (sprite && (sprite.visible === false || sprite.alpha <= 0)) continue;
        shadow(fighter, radius, sprite);
        if (typeof fighter.castMove !== 'string' || !fighter.castMove || fighter.switchMs > 0 ||
            (fighter.cast !== 'active' && fighter.cast !== 'windup')) continue;
        const type = V(fighter.castMove).typeName;
        const angle = Number.isFinite(fighter.castFacing) ? fighter.castFacing : fighter.facing || 0;
        const active = fighter.cast === 'active';
        const shimmer = reduced ? 1 : .96 + .04 * Math.sin(clock * .006 + radius);
        glow(fighter.x + Math.cos(angle) * radius * .85, fighter.y + Math.sin(angle) * radius * .85,
          radius * (active ? 2.75 : 1.75), type, (active ? .46 : .23) * shimmer);
      }
      const shots = state.projectiles || [];
      // Budget simultaneous floor lights during a crowded rapid-fire exhibition.
      for (let i = Math.max(0, shots.length - 16); i < shots.length; i++) {
        const shot = shots[i];
        if (typeof shot.move !== 'string' || !shot.move || !Number.isFinite(shot.x) || !Number.isFinite(shot.y)) continue;
        const type = V(shot.move).typeName;
        const radius = Math.min(96, Math.max(20, (shot.radius || 7) * 3.5));
        glow(shot.x, shot.y + radius * .12, radius, type, shot.basic ? .25 : .43);
      }
    } finally {
      ctx.restore();
    }
  }

  globalThis.rocketPaintStageLight = rocketPaintStageLight;
})();
