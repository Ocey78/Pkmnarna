// A room keeps its chosen transport policy until it is left.
(() => {
  'use strict';

  function createRocketConnectionMode() {
    const key = 'rocket-connection-mode-v1';
    const rooms = new WeakMap();
    let preferred = 'auto';
    try {
      const saved = localStorage.getItem(key);
      if (saved === 'cloud' || saved === 'direct') preferred = saved;
    } catch {}

    function get() { return preferred; }
    function set(mode) {
      preferred = mode === 'cloud' || mode === 'direct' ? mode : 'auto';
      try { localStorage.setItem(key,preferred); } catch {}
    }
    function policy(controller) {
      let room = rooms.get(controller);
      if (!room) {
        room = {mode:preferred,rejected:false};
        rooms.set(controller,room);
      }
      return room;
    }
    function reject(controller, message) {
      const room = policy(controller);
      if (room.rejected || !controller.active) return true;
      room.rejected = true;
      // Consume a quick-join request before showing the native connection error.
      arenaMainMenuOnline.confirmed(controller);
      controller.client?.send({t:'leave'});
      controller.end(message,'connection-mode');
      return true;
    }
    function beforePacket(controller, packet) {
      if (!['room','peer-offer','peer-mode','start','resume'].includes(packet.t)) return false;
      const room = policy(controller);
      if (room.rejected) return true;
      if (room.mode !== 'direct') return false;
      if (packet.t === 'room' && packet.mode === 'ffa3') {
        return reject(controller,'Force Direct requires a two-player room. Change Connection in Settings > Game to join a brawl.');
      }
      if (typeof RTCPeerConnection !== 'function') {
        return reject(controller,'Direct connections are unavailable in this browser. Change Connection in Settings > Game.');
      }
      if (packet.t === 'peer-mode' && packet.mode === 'cloud' && controller.peer?.offer.id === packet.id) {
        return reject(controller,'A Direct connection could not be established. Choose Auto or Force Cloud in Settings > Game to play this connection.');
      }
      return false;
    }
    function capable(controller) {
      return policy(controller).mode !== 'cloud' && typeof RTCPeerConnection === 'function';
    }
    function acceptOffer(controller, offer) {
      if (policy(controller).mode !== 'cloud') return true;
      controller.closePeer();
      controller.connectionLabel = 'CLOUD';
      controller.client?.send({t:'peer-vote',id:offer.id,rtt:null});
      return false;
    }
    function acceptStart(controller, start) {
      const room = policy(controller);
      if (room.rejected) return false;
      if (room.mode === 'direct' && !start.direct) {
        reject(controller,'The service selected Cloud for this battle. Force Direct is enabled. Choose Auto or Force Cloud in Settings > Game to continue.');
        return false;
      }
      if (room.mode === 'cloud' && start.direct) {
        reject(controller,'This room selected Direct while Force Cloud is enabled. Rejoin the room to negotiate a Cloud connection.');
        return false;
      }
      return true;
    }
    return {get,set,beforePacket,capable,acceptOffer,acceptStart};
  }

  function patch(source) {
    const replace = (before,after) => {
      const parts=source.split(before);
      if(parts.length!==2)throw Error('Unsupported connection-mode anchor: '+before);
      source=parts.join(after);
    };
    replace('onMessage(e){if(this.active){arenaTrainingLobby.beforePacket(this,e);',
      'onMessage(e){if(this.active){if(rocketConnectionMode.beforePacket(this,e))return;arenaTrainingLobby.beforePacket(this,e);');
    replace('supported:typeof RTCPeerConnection==`function`','supported:rocketConnectionMode.capable(this)');
    replace('offerPeer(e){if(this.mode===`fight`&&!this.result||this.mode===`vs`)return;',
      'offerPeer(e){if(this.mode===`fight`&&!this.result||this.mode===`vs`)return;if(!rocketConnectionMode.acceptOffer(this,e))return;');
    const start='beginMatch(e,t){if(!this.client||!this.active||this.battle?.matchId===e.matchId)return;';
    replace(start,start+'if(!rocketConnectionMode.acceptStart(this,e))return;');
    return 'const rocketConnectionMode=('+createRocketConnectionMode.toString()+')();\n'+source;
  }
  globalThis.ArenaConnectionModeAdapter=Object.freeze({patch});
})();
