// Sort the complete native candidate list before it is divided into pages.
// Keep the game's slot validation, current selection and type swatches.
(() => {
  'use strict';

  function arenaMoveSortCompare(left, right, lookup) {
    if (left.kind === 'dash' || right.kind === 'dash') {
      return Number(right.kind === 'dash') - Number(left.kind === 'dash');
    }
    const a = lookup(left.id), b = lookup(right.id);
    return a.typeName.localeCompare(b.typeName, 'en', {sensitivity:'base'}) ||
      a.name.localeCompare(b.name, 'en', {sensitivity:'base'}) ||
      left.id.localeCompare(right.id, 'en');
  }

  function arenaMovePlacementText(plan, requestedSlot, lookup, keys) {
    if (!plan) return '';
    const other = Number.isInteger(plan.replacedSlot) &&
      plan.replacedSlot !== requestedSlot && plan.replacedMoveId;
    const lines = [];
    if (plan.slot !== requestedSlot || other) lines.push('Equips on ' + keys[plan.slot]);
    if (other) lines.push('Replaces ' + keys[plan.replacedSlot] + ' ' + lookup(plan.replacedMoveId).name);
    return lines.join('\n');
  }

  function patch(original) {
    let source = original;
    function replace(anchor, replacement) {
      const at = source.indexOf(anchor);
      if (at < 0 || source.indexOf(anchor, at + anchor.length) !== -1) {
        throw new Error('Unsupported game build. Missing or ambiguous move-sort anchor: ' + anchor.slice(0, 80));
      }
      source = source.slice(0, at) + replacement + source.slice(at + anchor.length);
    }
    replace('b.sort((e,t)=>Number(t.current)-Number(e.current));',
      'b.sort((e,t)=>arenaMoveSortCompare(e,t,V));');
    replace('let a=V(e.id);t.dataset.move=e.id,n.style.background=',
      'let a=V(e.id);t.dataset.move=e.id,t.dataset.moveType=a.typeName,t.title=a.typeName.toUpperCase()+` · `+a.name,n.style.background=');
    replace(',t.setAttribute(`aria-label`,`${a.name} ${i.textContent}`)',
      ';let planned=!e.current&&this.movePick&&typeof arenaPlanMove===`function`?arenaPlanMove(this.detailId,this.pickMoves[this.pickTeam.indexOf(this.detailId)],this.movePick.slot,e.id):null;let placement=arenaMovePlacementText(planned,this.movePick?.slot,V,Ym);i.textContent=a.typeName.toUpperCase()+` · `+i.textContent+(placement?`\\n`+placement:``);if(placement){t.dataset.equipsOn=String(planned.slot);t.title+=`\\n`+placement}t.setAttribute(`aria-label`,`${a.name} · ${i.textContent}`)');
    replace('i[n]=r.moves?[...r.moves]:null,this.pickMoves=i,this.candidatePage=0,this.persistMoves(),this.renderPick()}saveParty()',
      'i[n]=r.moves?[...r.moves]:null,this.pickMoves=i,this.candidatePage=0,this.persistMoves(),Number.isInteger(r.slot)&&(this.movePick={slot:r.slot}),this.renderPick(),Number.isInteger(r.slot)&&this.pick?.querySelector(`[data-editor-slot="${r.slot}"]`)?.focus({preventScroll:!0})}saveParty()');
    // A third metadata line names a replacement when the selected control is
    // indispensable. Reserve its height in the native pagination calculation.
    replace('let e=this.phonePick?32:48,t=T.clientWidth>=400?2:1',
      'let e=56,t=T.clientWidth>=400?2:1');
    replace('.candidate-meta { flex: none; text-transform: none; font: 8px/8px var(--font-ui); color: var(--ui-text-dim); }',
      '.candidate-meta { flex: none; max-width: 62%; white-space: pre-line; text-transform: none; font: 9px/11px var(--font-ui); color: var(--ui-text-dim); }');
    replace('.pick.is-phone .detail-candidate { display: grid; grid-template-columns: 6px minmax(0, 1fr); grid-template-rows: 14px 12px; gap: 0 4px; padding: 1px 4px; }',
      '.pick.is-phone .detail-candidate { display: grid; grid-template-columns: 6px minmax(0, 1fr); grid-template-rows: 14px minmax(0, 1fr); gap: 0 4px; padding: 1px 4px; }');
    replace('.pick.is-phone .candidate-meta { line-height: 12px; }',
      '.pick.is-phone .candidate-meta { max-width: none; line-height: 11px; align-self: start; }');
    return arenaMoveSortCompare.toString() + '\n' + arenaMovePlacementText.toString() + '\n' + source;
  }

  const api = Object.freeze({patch, compareCandidates:arenaMoveSortCompare, placementText:arenaMovePlacementText});
  globalThis.ArenaMoveSortAdapter = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})();
