// Practice uses the stock arena renderer and its own Phaser scene and local world.
(() => {
  'use strict';

  function arenaTrainingSceneType() {
    return class RocketLobbyPractice extends RY {
      constructor() {
        super('rocket-training');
        this.rocketLobbyTraining = true;
        this.onPause = () => {
          if (!arenaTrainingLobby.isEditing(this)) arenaTrainingLobby.leaveActive(this);
        };
        this.onPageHide = () => {};
      }

      init(data) {
        super.init({...data, net:null, source:'cpu', difficulty:data.difficulty ?? 'hard', cpuSwitch:true,
          story:null, run:null, encounter:null, arenaCpuMode:null});
        this.battleSource = 'training';
        this.rocketConfigureCpu(data.trainingAi !== false, this.difficulty);
      }

      async create() {
        const epoch = this.loadEpoch;
        try {
          await super.create();
          if (this.alive && this.ready && this.loadEpoch === epoch) arenaTrainingLobby.sceneReady(this);
        } catch (error) {
          if (this.alive && this.loadEpoch === epoch) {
            console.warn('[Rocket Menu] Could not start lobby training.', error);
            arenaTrainingLobby.leaveActive(this);
          }
        }
      }

      update(time, delta) {
        if (arenaTrainingLobby.isEditing(this)) return;
        super.update(time, delta);
      }

      draw(state) {
        if (state.phase === 'fight') {
          for (const fighter of state.fighters) {
            const ghost = this.finisher?.ghosts.get(fighter.id);
            if (!ghost || fighter.hp <= 0 || ghost.speciesId !== fighter.speciesId) continue;
            const pose = this.balls?.poseFor(fighter.id);
            // Native KO ghosts hide actors by ID/species, which practice reuses.
            // Retire the old body only when the incoming sprite may be drawn;
            // leave the old-body and hidden Poké Ball phases to the renderer.
            if (pose && pose.sprite?.who !== 'new') continue;
            ghost.ghost.destroy();
            this.finisher.ghosts.delete(fighter.id);
          }
        }
        super.draw(state);
      }

      rocketConfigureCpu(ai, difficulty) {
        this.world.configureCpu(ai, difficulty);
        this.difficulty = difficulty;
        this.aiEnabled = ai;
      }

      rocketApplyTeam(slots, moves, side = 'player') {
        const world = this.world;
        if (!this.alive || !world?.arenaTraining) return;
        world.applyTrainingTeam(side, {slots, moves});
        if (side === 'player') Z.noteBattleLoadouts(slots, moves);
        const loader = cH(this);
        const species = new Set([...slots, ...Vk(slots)]);
        const moveIds = [...new Set(world.partyOf(side).flatMap(member => member.loadout))];
        // The renderer also requests sprites on switch. Warm the new art without
        // delaying room updates or making an exit wait on a slow download.
        void Promise.allSettled([
          ...Array.from(species, id => ok(loader, id)), Rz(loader, moveIds), qV(loader, moveIds)
        ]);
      }

      // Practice has no result or collection rewards and can repeat indefinitely.
      settleMatch() {}
      noteCollection() {}
      lightRow() {}
      noteOwnRow() {}
    };
  }

  function patch(source) {
    const once = (before, after) => {
      const first = source.indexOf(before);
      if (first < 0 || source.indexOf(before, first + before.length) >= 0) {
        throw Error('Unsupported arena scene for lobby training: ' + before.slice(0,75));
      }
      source = source.slice(0,first) + after + source.slice(first + before.length);
    };
    once('constructor(){super(`arena`)}init(e){','constructor(sceneKey=`arena`){super(sceneKey)}init(e){');
    once('this.world=new (arenaCpuWorldType())({arenaCpuMode:',
      'this.world=new (this.rocketLobbyTraining?arenaTrainingWorldType():arenaCpuWorldType())({arenaCpuMode:');
    once('i.cpuBattle?i.fighters.flatMap(e=>e.moves.map(e=>e.id)):null)',
      'i.training?[...this.world.party,...this.world.foeParty].flatMap(member=>member.loadout):i.cpuBattle?i.fighters.flatMap(e=>e.moves.map(e=>e.id)):null)');
    once('if(!e?.net)arenaFriendBridge.link.solo();','if(!this.rocketLobbyTraining&&!e?.net)arenaFriendBridge.link.solo();');
    once('this.aiEnabled=a===`0`?!1:a===`1`||!i&&qJ(this.battleSource)',
      'this.aiEnabled=this.rocketLobbyTraining||((a===`0`)?!1:a===`1`||!i&&qJ(this.battleSource))');
    once('this.assist=this.net||i||!this.aiEnabled||this.run?null:',
      'this.assist=this.rocketLobbyTraining||this.net||i||!this.aiEnabled||this.run?null:');
    once('yf(s),Z.noteBattleLoadouts(s,','this.rocketLobbyTraining||yf(s),Z.noteBattleLoadouts(s,');
    once('Z.setResultStars(null),jl({mode:this.encounter?', 'Z.setResultStars(null),this.rocketLobbyTraining||jl({mode:this.encounter?');
    once('&&(Ml(),this.lightRow(r.fighters[0]?.speciesId)', '&&(this.rocketLobbyTraining||Ml(),this.lightRow(r.fighters[0]?.speciesId)');
    once('()=>{Ll(),window.removeEventListener(`pagehide`,this.onPageHide)', '()=>{this.rocketLobbyTraining||Ll(),window.removeEventListener(`pagehide`,this.onPageHide)');
    // The lobby continues to own its waiting/player-found music through practice.
    once('async create(){let e=this.loadEpoch;mi.countdown(),zY(!0)',
      'async create(){let e=this.loadEpoch;this.rocketLobbyTraining||mi.countdown(),zY(!0)');
    once('Lq(),TT.endMatch(),mi.countdown(),this.ready=!1',
      'Lq(),TT.endMatch(),this.rocketLobbyTraining||mi.countdown(),this.ready=!1');
    once('if(r.phase===`fight`?mi.battle():this.net&&mi.result(r.phase)',
      'if(r.phase===`fight`?(!this.rocketLobbyTraining&&mi.battle()):this.net&&mi.result(r.phase)');
    // Both Back on the loading card and Cancel after a failed asset download
    // must restore the current room rather than start a second main menu.
    const leave='this.net?CO():this.scene.start(KJ(this.story,this.run))';
    const branches=source.split(leave);
    if(branches.length!==3)throw Error('Unsupported arena load cancellation for lobby training.');
    source=branches.join('this.rocketLobbyTraining?arenaTrainingLobby.leaveActive(this):'+leave);
    return arenaTrainingSceneType.toString() + '\n' + source;
  }

  globalThis.ArenaTrainingSceneAdapter = Object.freeze({patch});
  if (typeof module !== 'undefined' && module.exports) module.exports = {patch};
})();
