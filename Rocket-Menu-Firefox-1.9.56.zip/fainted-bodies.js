// Detached render sprites only: fainted bodies never enter the battle world.
(() => {
  'use strict';
  function createRocketFaintedBodies() {
    const storageKey='arena.rocket.keep-fainted.v1',scenes=new WeakMap(),active=new Set();
    let enabled=false;
    try{enabled=localStorage.getItem(storageKey)==='on';}catch{}
    function clear(record){
      for(const body of record.bodies.values())body.actor.sprite.destroy();
      record.bodies.clear();record.seen.clear();
    }
    function set(value){
      enabled=value===true;
      try{localStorage.setItem(storageKey,enabled?'on':'off');}catch{}
      if(!enabled)for(const record of active)clear(record);
    }
    window.addEventListener('storage',event=>{
      if(event.key!==storageKey&&event.key!==null)return;
      enabled=event.key!==null&&event.newValue==='on';
      if(!enabled)for(const record of active)clear(record);
    });
    function memory(scene,state){
      let record=scenes.get(scene);
      if(!record){
        record={bodies:new Map(),seen:new Set(),world:scene.world,epoch:scene.loadEpoch,tick:state.tick};
        scenes.set(scene,record);active.add(record);
        const dispose=()=>{
          clear(record);active.delete(record);
          if(scenes.get(scene)===record)scenes.delete(scene);
          scene.events.off('shutdown',dispose);scene.events.off('destroy',dispose);
        };
        scene.events.once('shutdown',dispose);scene.events.once('destroy',dispose);
      }
      if(record.world!==scene.world||record.epoch!==scene.loadEpoch||state.tick<record.tick){
        clear(record);record.world=scene.world;record.epoch=scene.loadEpoch;
      }
      record.tick=state.tick;
      return record;
    }
    function add(scene,record,fighter,point,tick){
      const key=fighter.id+':'+fighter.entry+':'+fighter.speciesId;
      if(record.seen.has(key))return;
      record.seen.add(key);
      const source=scene.actors.get(fighter.id);
      if(!source?.sprite?.scene||source.speciesId!==fighter.speciesId)return;
      const snapshot={...fighter,x:point.x,y:point.y,hp:0,cast:'idle',justShotMs:0,iframeMs:0};
      const sprite=scene.add.sprite(point.x,point.y,source.sprite.texture.key,source.sprite.frame.name)
        .setOrigin(source.sprite.originX,source.sprite.originY);
      const actor={...source,sprite,pose:'faint',poseTick:tick,lastX:NaN,lastY:NaN,ownTint:null,savedTint:null};
      pk(actor,snapshot,tick,false,true,false,false,{pose:'faint',x:point.x,y:point.y,scaleStep:1,
        pinColumn:Math.max(0,(source.clips.faint?.clip.frames||1)-1),visible:true});
      sprite.setDepth(3.9+Math.max(0,point.y)/1e6).setVisible(false);
      record.bodies.set(key,{actor,fighter:snapshot,revealed:false});
    }
    function note(scene,before,after,events){
      if(!enabled||scene.artVariant||!before?.fighters||!after?.fighters)return;
      const record=memory(scene,after),fainted=new Set();
      for(const event of events){
        if(event.type==='faint')fainted.add(event.target);
        if(event.type==='switch'&&event.cause==='faint')fainted.add(event.actor);
      }
      for(const old of before.fighters){
        const next=after.fighters.find(fighter=>fighter.id===old.id);
        if(!(old.hp>0)||!fainted.has(old.id)&&!(next?.entry===old.entry&&next.hp<=0))continue;
        const hit=[...events].reverse().find(event=>event.type==='hit'&&event.target===old.id&&event.amount>0);
        const point=next?.entry===old.entry?next:hit&&Number.isFinite(hit.x)&&Number.isFinite(hit.y)?hit:old;
        add(scene,record,old,point,after.tick);
      }
    }
    function paint(scene,state){
      if(!enabled||scene.artVariant)return;
      const record=memory(scene,state);
      for(const body of record.bodies.values()){
        const {actor,fighter}=body;
        const current=state.fighters.find(item=>item.id===fighter.id),live=scene.actors.get(fighter.id);
        const nativeFaint=current?.entry===fighter.entry&&current.hp<=0&&live?.sprite.visible;
        const ball=scene.balls?.poseFor(fighter.id);
        // Let the native faint/switch animation finish before revealing its body.
        const oldPose=live?.speciesId===fighter.speciesId&&ball?.sprite?.who==='old'&&live.sprite.visible;
        if(!nativeFaint&&!oldPose)body.revealed=true;
        actor.sprite.setVisible(body.revealed);
      }
    }
    return Object.freeze({get:()=>enabled,set,note,paint});
  }
  function patch(source){
    const replace=(before,after)=>{
      const parts=source.split(before);
      if(parts.length!==2)throw Error('Unsupported fainted-bodies anchor: '+before);
      source=parts.join(after);
    };
    replace('this.artFx?.note(e,c,t.events)', 'rocketFaintedBodies.note(this,e,c,t.events),this.artFx?.note(e,c,t.events)');
    replace('this.ffaLabels.forEach((e,r)=>{let i=n.fighters[r];',
      'rocketFaintedBodies.paint(this,e),this.ffaLabels.forEach((e,r)=>{let i=n.fighters[r];');
    return 'const rocketFaintedBodies=('+createRocketFaintedBodies.toString()+')();globalThis.rocketFaintedBodies=rocketFaintedBodies;\n'+source;
  }
  const api=Object.freeze({patch});
  globalThis.ArenaFaintedBodiesAdapter=api;
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})();
