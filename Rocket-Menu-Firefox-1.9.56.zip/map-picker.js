// Native arena thumbnails for the local team picker.
(() => {
  'use strict';

  function createArenaMapPicker() {
    const enabled = ui => ui.arenaRosterOffline === true;
    function metrics(ui) {
      if (!enabled(ui)) return {width:0,height:0,reserve:0};
      const width = Math.min(132, Math.max(24, Math.floor(((ui.pick?.clientWidth || 800) - 72) / 6)));
      const height = Math.ceil(width * 9 / 16);
      return {width,height,reserve:height + 20};
    }
    function height(ui) {
      return Math.max(0, (ui.pick?.clientHeight || 0) - metrics(ui).reserve);
    }
    function compact(ui, available) {
      const desktop = J_.padTop + J_.banner + J_.header + J_.headerGap +
        q_.rows * q_.cellH + (q_.rows - 1) * q_.gap + J_.footGap + J_.foot + J_.padBottom;
      return available <= 600 || enabled(ui) && available < desktop;
    }
    function choose(ui, id) {
      if (!enabled(ui) || !ou.some(stage => stage.id === id)) return;
      // A stage query takes precedence over the native saved stage. Keep an
      // explicitly selected map effective when opening the game from a link.
      try {
        const url = new URL(location.href);
        if (url.searchParams.has('stage')) {
          url.searchParams.set('stage', id);
          history.replaceState(history.state, '', url.href);
        }
      } catch {}
      arenaReferenceArenas.remember(id);
      if (arenaReferenceArenas.stages.has(id)) {
        ui.paintStages();
        ui.notifyRoster();
      } else ui.chooseStage(id);
    }
    function paint(ui) {
      const pick = ui.pick;
      if (!pick) return;
      const visible = enabled(ui);
      pick.classList.toggle('rocket-has-map-picker', visible);
      let row = pick.querySelector('.rocket-map-area');
      if (!visible) { if (row) row.hidden = true; return; }
      const foot = pick.querySelector('.pick-foot');
      if (!foot) return;
      if (!document.getElementById('rocket-map-picker-style')) {
        const style = document.createElement('style'); style.id = 'rocket-map-picker-style';
        style.textContent = `
          .pick.rocket-has-map-picker{overflow-y:auto;overscroll-behavior:contain}
          .pick .rocket-map-area{box-sizing:border-box;display:flex;flex:1 0 var(--rocket-map-reserve);min-height:var(--rocket-map-reserve);min-width:0;width:100%;align-items:stretch;justify-content:safe center;gap:8px;padding:10px 12px;overflow-x:auto;scrollbar-width:thin}
          .pick .rocket-map-area[hidden]{display:none}
          .pick .rocket-map-preview{position:relative;box-sizing:border-box;display:block;flex:1 1 0;width:auto;height:auto;min-width:88px;min-height:0;margin:0;padding:2px;border:2px solid var(--ui-frame-hi,#aeb1cb);border-radius:0;box-shadow:3px 3px 0 var(--ui-outline,#0a0c18);cursor:pointer;overflow:hidden}
          .pick .rocket-map-preview img{position:absolute;inset:2px;display:block;width:calc(100% - 4px);height:calc(100% - 4px);object-fit:cover;image-rendering:pixelated;pointer-events:none}
          .pick .rocket-map-name{position:absolute;z-index:1;top:5px;left:50%;transform:translateX(-50%);box-sizing:border-box;max-width:calc(100% - 8px);padding:3px 6px;border:1px solid var(--ui-frame-hi,#aeb1cb);background:var(--ui-panel,#272f55);color:var(--ui-text,#fff);font:700 clamp(8px,1vw,11px)/1.2 Silkscreen,monospace;text-transform:uppercase;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;pointer-events:none}
          .pick .rocket-map-preview:hover{border-color:var(--ui-text,#fff)}
          .pick .rocket-map-preview.is-on{border-color:var(--ui-cursor,#f87818);box-shadow:inset 0 0 0 2px var(--ui-cursor,#f87818),3px 3px 0 var(--ui-outline,#0a0c18)}
          .pick .rocket-map-preview.is-on .rocket-map-name{border-color:var(--ui-cursor,#f87818)}
          .pick .rocket-map-preview:focus-visible{outline:2px solid var(--ui-text,#fff);outline-offset:2px}
        `;
        document.head.append(style);
      }
      if (!row) {
        row = document.createElement('div'); row.className = 'rocket-map-area';
        row.setAttribute('role', 'group'); row.setAttribute('aria-label', 'Arena map');
        for (const stage of ou) {
          const button = document.createElement('button'); button.type = 'button';
          button.className = 'rocket-map-preview'; button.dataset.arenaMap = stage.id;
          button.style.background = stage.backdrop;
          const image = document.createElement('img'); image.src = ai(stage.file);
          image.alt = ''; image.draggable = false; image.loading = 'lazy'; image.decoding = 'async';
          const name = document.createElement('span'); name.className = 'rocket-map-name';
          button.append(image, name); button.addEventListener('click', () => choose(ui, stage.id)); row.append(button);
        }
        row.addEventListener('keydown', event => {
          if (event.ctrlKey || event.metaKey || event.altKey) return;
          if (!['ArrowLeft','ArrowRight','Home','End'].includes(event.key)) return;
          const buttons = [...row.querySelectorAll('button')], index = buttons.indexOf(document.activeElement);
          if (index < 0) return;
          event.preventDefault(); event.stopPropagation();
          const next = event.key === 'Home' ? 0 : event.key === 'End' ? buttons.length - 1 :
            (index + (event.key === 'ArrowLeft' ? -1 : 1) + buttons.length) % buttons.length;
          buttons[next]?.focus();
        });
        foot.after(row);
      }
      row.hidden = false;
      const size = metrics(ui);
      row.style.setProperty('--rocket-map-reserve', size.reserve + 'px');
      const selected = arenaReferenceArenas.selected();
      for (const button of row.querySelectorAll('[data-arena-map]')) {
        const stage = ou.find(item => item.id === button.dataset.arenaMap), active = stage.id === selected;
        button.classList.toggle('is-on', active); button.setAttribute('aria-pressed', String(active));
        const name = K(stage.labelKey);
        button.title = name; button.setAttribute('aria-label', name);
        button.querySelector('.rocket-map-name').textContent = name;
      }
    }
    return {paint,height,compact};
  }

  function patch(source) {
    const replace = (before, after) => {
      const parts = source.split(before);
      if (parts.length !== 2) throw Error('Unsupported arena map picker anchor: ' + before.slice(0,75));
      source = parts.join(after);
    };
    replace('renderPick(){this.syncPickMode();', 'renderPick(){arenaMapPicker.paint(this);this.syncPickMode();');
    replace('paintStages(){this.pick?.querySelectorAll(`[data-roster-sort]`)', 'paintStages(){arenaMapPicker.paint(this);this.pick?.querySelectorAll(`[data-roster-sort]`)');
    replace('placeFooter(){let e=this.pick?.querySelector(`.pick-foot`)', 'placeFooter(){arenaMapPicker.paint(this);let e=this.pick?.querySelector(`.pick-foot`)');
    replace('this.phonePick?ov(e.clientWidth,e.clientHeight):null', 'this.phonePick?ov(e.clientWidth,arenaMapPicker.height(this)):null');
    replace('syncPickMode(){let e=this.pick?.clientHeight??0,t=this.pick?.clientWidth??0;',
      'syncPickMode(){let e=arenaMapPicker.height(this),t=this.pick?.clientWidth??0;');
    replace('let n=e<=600,r=(n?ov(t,e):null)?.metrics', 'let n=arenaMapPicker.compact(this,e),r=(n?ov(t,e):null)?.metrics');
    return 'const arenaMapPicker=(' + createArenaMapPicker.toString() + ')();\n' + source;
  }
  const api = Object.freeze({patch}); globalThis.ArenaMapPickerAdapter = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})();
