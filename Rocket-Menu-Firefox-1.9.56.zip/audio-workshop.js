// Local song replacements use the game's own music mixer and decoding context.
(() => {
  'use strict';

  function createBossTransitions(player, env) {
    const isBoss = track => env.tracks.includes(track), buffers = new Map();
    const play = player.play.bind(player), reconcile = player.reconcile.bind(player);
    let pending = null, syncData = null, syncPromise = null;
    const loadSync = () => syncPromise || (syncPromise = fetch('/play-online/rocket-menu-audio/boss-sync.json', {
      credentials: 'omit', signal: AbortSignal.timeout(5000)
    }).then(response => response.ok ? response.json() : null).then(data => {
      if (data?.version === 1 && data.pairs) syncData = data;
    }).catch(() => {}));

    function bufferFor(track) {
      const key = env.keyFor(track), cached = buffers.get(track);
      if (cached?.key === key) return cached.promise;
      const entry = {key, promise: null};
      entry.promise = player.file(track, 'mp3').then(data => env.decode(player.ctx, data, track, 'mp3'));
      buffers.set(track, entry);
      entry.promise.catch(() => { if (buffers.get(track) === entry) buffers.delete(track); });
      return entry.promise;
    }
    function position(voice, now) {
      const elapsed = voice.source ? Math.max(0, now - voice.startedAt) : 0;
      const end = voice.source?.loopEnd || voice.buffer.duration;
      return ((voice.offset + elapsed) % end + end) % end;
    }
    function matchedOffset(voice, track, buffer, now) {
      const from = position(voice, now);
      // Uploaded replacements can be completely different music; only the
      // bundled recordings have measured phrase correspondences.
      const pair = !env.keyFor(voice.track) && !env.keyFor(track) && syncData?.pairs[voice.track + '>' + track];
      if (!pair?.points?.length || !(pair.step > 0)) return 0;
      const sourceDuration = syncData.tracks?.[voice.track]?.duration, targetDuration = syncData.tracks?.[track]?.duration;
      if (!Number.isFinite(sourceDuration) || !Number.isFinite(targetDuration) ||
          Math.abs(sourceDuration - voice.buffer.duration) > .3 || Math.abs(targetDuration - buffer.duration) > .3) return 0;
      const i = Math.min(pair.points.length - 1, Math.floor(from / pair.step));
      const a = pair.points[i], b = pair.points[i + 1];
      if (!Array.isArray(a) || !Number.isFinite(a[0]) || a[1] < .35) return 0;
      const fraction = (from - i * pair.step) / pair.step;
      // Do not interpolate across a repeat/section boundary in the arrangement.
      const continuous = b && b[1] >= .35 && b[0] >= a[0] && b[0] - a[0] <= pair.step * 2;
      const offset = continuous ? a[0] + (b[0] - a[0]) * fraction : a[0] + fraction * pair.step;
      return Math.max(0, Math.min(buffer.duration - .1, offset));
    }
    function matchingDelay(voice, track) {
      if (env.keyFor(voice.track) || env.keyFor(track)) return 0;
      const pair = syncData?.pairs[voice.track + '>' + track];
      if (!pair?.points?.length || !(pair.step > 0)) return 0;
      const from = position(voice, player.ctx.currentTime), index = Math.floor(from / pair.step);
      if (pair.points[index]?.[1] >= .35) return 0;
      // A nearby shared phrase is a better handoff than restarting an intro.
      // Hold the old music for at most three seconds; game phases never wait.
      for (let i = index + 1; i < pair.points.length && i * pair.step - from <= 3; i++) {
        const a = pair.points[i], b = pair.points[i + 1];
        if (a?.[1] >= .35 && b?.[1] >= .35 && b[0] >= a[0] && b[0] - a[0] <= pair.step * 2)
          return Math.max(0, i * pair.step - from + .02) * 1000;
      }
      return 0;
    }
    function crossfade(old, track, buffer) {
      const context = player.ctx, now = context.currentTime, duration = 2.1;
      const source = context.createBufferSource(), gain = context.createGain();
      const offset = matchedOffset(old, track, buffer, now);
      source.buffer = buffer; source.loop = true; source.loopEnd = buffer.duration;
      source.connect(gain); gain.connect(player.bus);
      const voice = {track, format:'mp3', buffer, gain, source, offset, startedAt:now, ended:false};
      const fadeIn = new Float32Array(65), fadeOut = new Float32Array(65);
      const oldLevel = Math.max(0, Math.min(1, old.gain.gain.value));
      for (let i = 0; i < fadeIn.length; i++) {
        const angle = i / (fadeIn.length - 1) * Math.PI / 2;
        fadeIn[i] = Math.sin(angle); fadeOut[i] = oldLevel * Math.cos(angle);
      }
      gain.gain.setValueAtTime(0, now);
      gain.gain.setValueCurveAtTime(fadeIn, now, duration);
      source.onended = () => { if (voice.source === source) { source.disconnect(); voice.source = null; voice.ended = true; } };
      source.start(now, offset);
      // Keep the old voice alive throughout loading; fade it only once the
      // decoded replacement is actually scheduled in the same audio context.
      old.gain.gain.cancelScheduledValues(now);
      old.gain.gain.setValueAtTime(oldLevel, now);
      old.gain.gain.setValueCurveAtTime(fadeOut, now, duration);
      player.voice = voice; player.fading.add(old);
      if (old.source) old.source.stop(now + duration + .03);
      setTimeout(() => {
        player.stop(old); old.gain.disconnect(); player.fading.delete(old);
      }, (duration + .08) * 1000);
    }
    player.reconcile = function () {
      const old = this.voice, track = this.target;
      if (!isBoss(track) || !isBoss(old?.track) || track === old.track) return reconcile();
      if (!this.ctx || this.held || this.ctx.state !== 'running') return;
      if (pending?.track === track && pending.generation === this.generation) return pending.promise;
      if (!old.source && !old.ended) this.start(old);
      const request = {track, generation:this.generation, promise:null}; pending = request;
      const current = () => pending === request && this.generation === request.generation && this.target === track && !this.held && this.ctx.state === 'running' && this.voice === old;
      request.promise = Promise.all([bufferFor(track), loadSync()]).then(async ([buffer]) => {
        if (!current()) return;
        const delay = matchingDelay(old, track);
        if (delay) await new Promise(resolve => setTimeout(resolve, delay));
        if (!current()) return;
        crossfade(old, track, buffer); this.lastError = null;
      }).catch(error => {
        if (this.generation === request.generation && this.target === track) {
          this.lastError = {track, stage:'boss-transition', message:String(error?.message || error)};
          // A missing song must not cut the currently playing phase to silence.
          env.report(track, 'Could not load this phase song. Keeping the previous music.');
        }
      }).finally(() => { if (pending === request) pending = null; });
      return request.promise;
    };
    player.play = function (track) {
      if (isBoss(track) && isBoss(this.voice?.track) && this.voice.track !== track) {
        if (this.target !== track) { this.target = track; this.generation++; this.lastError = null; }
        return this.reconcile();
      }
      if (!isBoss(track) && isBoss(this.target)) {
        // End a phase overlap promptly when a result, retry or menu takes over.
        for (const voice of this.fading) if (isBoss(voice.track)) {
          const now = this.ctx.currentTime;
          voice.gain.gain.cancelScheduledValues(now);
          voice.gain.gain.setValueAtTime(voice.gain.gain.value, now);
          voice.gain.gain.linearRampToValueAtTime(0, now + .25);
          if (voice.source) voice.source.stop(now + .26);
        }
        buffers.clear();
      }
      return play(track);
    };
    return {prepare() {
      void loadSync();
      for (const track of env.tracks) {
        if (player.ctx) void bufferFor(track).catch(() => {});
        else player.prefetch(track);
      }
    }};
  }

  function createWorkshop(player, env) {
    const tracks = Object.freeze([
      { id: 'menu', label: 'Menu' },
      { id: 'redline-circuit', label: 'Battle · Redline Circuit' },
      { id: 'battle-2', label: 'Battle · Track 2' },
      { id: 'boss-rayquaza-1', label: 'Boss Rush · Phase 1 · Rayquaza', reference: 'https://www.youtube.com/watch?v=r2BWx32tXXo' },
      { id: 'boss-rayquaza-2', label: 'Boss Rush · Phase 2 · Mega · 50% HP', reference: 'https://www.youtube.com/watch?v=Jq7zkIH6NOI' },
      { id: 'boss-rayquaza-3', label: 'Boss Rush · Phase 3 · Enraged · 25% HP', reference: 'https://www.youtube.com/watch?v=zXW0OPjWh0Y' },
      { id: 'boss-eon', label: 'Boss Rush · Latios & Latias' },
      { id: 'lobby-joined', label: 'Lobby · Player Joined' },
      { id: 'lobby-waiting', label: 'Lobby · Waiting for Players' },
      { id: 'team-builder', label: 'Team Editor' },
      { id: 'victory', label: 'Battle · Victory' },
      { id: 'defeat', label: 'Battle · Loss' }
    ]);
    const trackIds = new Set(tracks.map(track => track.id));
    const resultTracks = new Set(['victory', 'defeat']), loops = new Map();
    const records = new Map(), bytes = new Map(), busy = new Set(), messages = new Map();
    const customBytes = new WeakMap(), customBuffers = new WeakSet(), bundledBytes = new Map();
    const originalFile = player.file.bind(player);
    const document = env.document;
    let dbPromise, mounted = null, storageIssue = '', lobby = null, builderOpen = false;
    const localTracks = new Set(['lobby-joined', 'lobby-waiting', 'team-builder']);
    const bossTracks = ['boss-rayquaza-1', 'boss-rayquaza-2', 'boss-rayquaza-3'];
    const bundledTracks = [...bossTracks, 'boss-eon'];
    const fallbackTrack = track => localTracks.has(track) ? 'menu' : bundledTracks.includes(track) ? 'redline-circuit' : track;
    const waiting = controller => controller?.active && controller.mode === 'room' && ['open', 'lobby'].includes(controller.room?.state);
    const contextMusic = () => player.target === 'menu' || localTracks.has(player.target);

    function selectContextMusic() {
      let track = builderOpen ? 'team-builder' : 'menu';
      if (waiting(lobby)) {
        const capacity = lobby.room.mode === 'ffa3' ? 3 : 2;
        const present = lobby.room.seats.slice(0, capacity).filter(seat => seat?.present === true).length;
        if (present >= capacity && lobby.room.host === lobby.you) track = 'lobby-joined';
        else if (!builderOpen && present < capacity) track = 'lobby-waiting';
      }
      env.selectLobby(records.has(track) ? track : 'menu');
    }

    function roomMusic(controller = lobby) {
      lobby = controller;
      selectContextMusic();
    }

    function teamMusic(open) {
      if (builderOpen === open) return;
      builderOpen = open;
      if (open || contextMusic()) selectContextMusic();
    }

    function bossMusic(phase) {
      const track = bossTracks[phase - 1];
      if (track) env.selectBoss(track);
    }

    function prepareBossMusic() {
      // Read the local package during the countdown, ahead of the phase changes.
      void ready.then(() => bossMixer.prepare());
    }

    function eonMusic() { env.selectBoss('boss-eon'); }
    function prepareEonMusic() { void ready.then(() => player.prefetch('boss-eon')); }

    async function defaultFile(track, format) {
      if (!bundledTracks.includes(track)) return originalFile(track, format);
      let pending = bundledBytes.get(track);
      if (!pending) {
        pending = fetch('/play-online/rocket-menu-audio/' + track + '.mp3', {
          credentials: 'omit', signal: AbortSignal.timeout(8000)
        }).then(response => {
          if (!response.ok) throw Error('Bundled song unavailable');
          return response.arrayBuffer();
        }).then(data => {
          customBytes.set(data, {track, record: null, decoded: null});
          return data;
        });
        bundledBytes.set(track, pending);
      }
      try { return await pending; }
      catch {
        bundledBytes.delete(track);
        report(track, 'Bundled MP3 unavailable. Using the original battle music.');
        return originalFile(fallbackTrack(track), format);
      }
    }

    function database() {
      if (dbPromise) return dbPromise;
      dbPromise = new Promise((resolve, reject) => {
        let finished = false, request;
        const finish = (error, db) => {
          if (finished) { if (db) db.close(); return; }
          finished = true;
          clearTimeout(timer);
          if (error) reject(error); else resolve(db);
        };
        const timer = setTimeout(() => finish(Error('Local music storage is unavailable.')), 5000);
        try {
          if (!env.indexedDB) throw Error('Local music storage is unavailable.');
          request = env.indexedDB.open('rocket-menu-local-music', 1);
          request.onupgradeneeded = () => {
            if (!request.result.objectStoreNames.contains('tracks')) request.result.createObjectStore('tracks', { keyPath: 'id' });
          };
          request.onsuccess = () => {
            const db = request.result;
            db.onversionchange = () => { db.close(); dbPromise = null; };
            finish(null, db);
          };
          request.onerror = () => finish(Error('Local music storage is unavailable.'));
          request.onblocked = () => finish(Error('Close other game tabs and try again.'));
        } catch (error) { finish(error); }
      }).catch(error => { dbPromise = null; throw error; });
      return dbPromise;
    }

    async function transaction(mode, action) {
      const db = await database();
      return new Promise((resolve, reject) => {
        let tx, request, timer;
        const fail = () => reject(Error('Could not save music on this device. Check available storage and try again.'));
        try {
          tx = db.transaction('tracks', mode);
          request = action(tx.objectStore('tracks'));
          timer = setTimeout(() => { try { tx.abort(); } catch {} fail(); }, 5000);
          tx.oncomplete = () => { clearTimeout(timer); resolve(request?.result); };
          tx.onabort = tx.onerror = () => { clearTimeout(timer); fail(); };
        } catch { clearTimeout(timer); fail(); }
      });
    }

    function refresh(track) {
      for (const format of ['m4a', 'mp3']) {
        player.unsupported.delete(`${track}.${format}`);
        player.loadFailures.delete(`${track}.${format}`);
      }
      player.failures.delete(track);
      if (localTracks.has(track) && (builderOpen || waiting(lobby)) && contextMusic()) {
        const previous = player.target;
        selectContextMusic();
        if (player.target !== previous) return;
      }
      if (player.target !== track) return;
      player.generation += 1;
      player.lastError = null;
      player.retire();
      // reconcile already honors the native paused/hidden state and generation.
      player.reconcile();
    }

    function report(track, message) {
      messages.set(track, message);
      repaint();
    }

    function discardBroken(track, record) {
      if (records.get(track) !== record) return;
      records.delete(track);
      bytes.delete(track);
      if (localTracks.has(track) && (builderOpen || waiting(lobby)) && player.target === track) selectContextMusic();
      report(track, 'Saved MP3 could not be read. Using the original song; choose the file again.');
    }

    const ready = transaction('readonly', store => store.getAll()).then(saved => {
      for (const record of saved || []) {
        const loopTrack = typeof record?.id === 'string' && record.id.startsWith('loop:') ? record.id.slice(5) : null;
        if (resultTracks.has(loopTrack)) { loops.set(loopTrack, record.enabled === true); continue; }
        if (!trackIds.has(record?.id)) continue;
        if (!(record.blob instanceof Blob) || record.blob.size === 0 || record.blob.size > 50 * 1024 * 1024 || typeof record.name !== 'string') {
          messages.set(record.id, 'Saved MP3 could not be read. Using the original song; choose the file again.');
          continue;
        }
        records.set(record.id, record);
      }
      const previous = player.target;
      if ((builderOpen || waiting(lobby)) && contextMusic()) selectContextMusic();
      if (player.target === previous && (records.has(player.target) || loops.get(player.target))) refresh(player.target);
      repaint();
    }).catch(() => {
      storageIssue = 'Local music storage is unavailable. Original songs still play.';
      repaint();
    });

    player.file = async function (track, format = 'm4a') {
      const record = records.get(track);
      if (!record) return defaultFile(localTracks.has(track) ? 'menu' : track, format);
      let pending = bytes.get(track);
      if (!pending) {
        pending = record.blob.arrayBuffer().then(data => {
          customBytes.set(data, { track, record, decoded: null });
          return data;
        });
        bytes.set(track, pending);
      }
      try { return await pending; }
      catch { discardBroken(track, record); return defaultFile(localTracks.has(track) ? 'menu' : track, format); }
    };

    async function decode(context, data, track, format) {
      const custom = customBytes.get(data);
      if (!custom) return context.decodeAudioData(data.slice(0));
      try {
        const buffer = custom.decoded || await context.decodeAudioData(data.slice(0));
        if (!Number.isFinite(buffer.duration) || buffer.duration <= 0) throw Error('Empty audio');
        custom.decoded = buffer;
        customBuffers.add(buffer);
        return buffer;
      } catch {
        if (custom.record) discardBroken(track, custom.record);
        else report(track, 'Bundled MP3 could not be decoded. Using the original battle music.');
        const fallback = custom.record ? await defaultFile(localTracks.has(track) ? 'menu' : track, format) : await originalFile(fallbackTrack(track), format);
        // A broken replacement can fall back to a bundled boss song, which also
        // needs its full duration and decoder metadata rather than native timing.
        if (custom.record && customBytes.has(fallback)) return decode(context, fallback, track, format);
        return context.decodeAudioData(fallback.slice(0));
      }
    }

    async function replace(track, file) {
      if (!trackIds.has(track) || busy.has(track)) return false;
      busy.add(track);
      messages.delete(track);
      repaint();
      try {
        if (!(file instanceof Blob) || !/\.mp3$/i.test(file.name || '') && file.type !== 'audio/mpeg') throw Error('Choose an MP3 file.');
        if (!file.size) throw Error('This MP3 is empty. Choose another file.');
        if (file.size > 50 * 1024 * 1024) throw Error('Choose an MP3 smaller than 50 MB.');
        // Called directly from the user file-selection gesture, before awaiting.
        const unlocked = env.unlock();
        const context = player.ctx || unlocked;
        if (!context) throw Error('Audio is unavailable. Start the game and try again.');
        if (!player.ctx) player.unlock(context);
        const data = await file.arrayBuffer();
        let decoded;
        try { decoded = await context.decodeAudioData(data.slice(0)); }
        catch { throw Error('This file could not be decoded as audio. Choose another MP3.'); }
        if (!Number.isFinite(decoded.duration) || decoded.duration <= 0) throw Error('This MP3 has no playable audio.');
        await ready;
        const record = { id: track, name: String(file.name || 'Custom MP3').slice(0, 250), blob: file };
        await transaction('readwrite', store => store.put(record));
        records.set(track, record);
        customBytes.set(data, { track, record, decoded });
        customBuffers.add(decoded);
        bytes.set(track, Promise.resolve(data));
        storageIssue = '';
        messages.delete(track);
        refresh(track);
        return true;
      } catch (error) {
        report(track, error.message || 'Could not replace this song. Try another MP3.');
        return false;
      } finally { busy.delete(track); repaint(); }
    }

    async function reset(track) {
      if (!trackIds.has(track) || busy.has(track)) return false;
      busy.add(track);
      repaint();
      try {
        await ready;
        await transaction('readwrite', store => {
          if (resultTracks.has(track)) store.delete('loop:' + track);
          return store.delete(track);
        });
        records.delete(track);
        loops.delete(track);
        bytes.delete(track);
        messages.delete(track);
        storageIssue = '';
        refresh(track);
        return true;
      } catch (error) { report(track, error.message); return false; }
      finally { busy.delete(track); repaint(); }
    }

    async function setLoop(track, enabled) {
      if (!resultTracks.has(track) || busy.has(track)) return false;
      busy.add(track);
      repaint();
      try {
        await ready;
        const value = enabled === true;
        await transaction('readwrite', store => store.put({id:'loop:' + track, enabled:value}));
        loops.set(track, value);
        messages.delete(track);
        storageIssue = '';
        refresh(track);
        return true;
      } catch (error) { report(track, error.message); return false; }
      finally { busy.delete(track); repaint(); }
    }

    function repaint() {
      if (!mounted?.isConnected) return;
      for (const track of tracks) {
        const row = mounted.querySelector(`[data-song="${track.id}"]`);
        if (!row) continue;
        const record = records.get(track.id), message = messages.get(track.id);
        const filename = record?.name || (track.id==='boss-eon' ? 'latios and latias.mp3 · bundled' : bossTracks.includes(track.id) ? `phase ${bossTracks.indexOf(track.id) + 1}.mp3 · bundled` : localTracks.has(track.id) ? 'Menu song' : resultTracks.has(track.id) ? 'Original sound' : 'Original song');
        row.querySelector('.rocket-song-file').textContent = filename;
        row.querySelector('.rocket-song-file').title = filename;
        row.querySelector('.rocket-song-replace').disabled = busy.has(track.id);
        row.querySelector('.rocket-song-reset').disabled = busy.has(track.id) || !record && !message && !loops.get(track.id);
        const loop = row.querySelector('[data-song-loop]');
        if (loop) { loop.checked = loops.get(track.id) === true; loop.disabled = busy.has(track.id); }
        row.querySelector('.rocket-song-message').textContent = busy.has(track.id) ? 'Saving…' : message || '';
      }
      mounted.querySelector('.rocket-audio-storage').textContent = storageIssue;
    }

    function mount(settings, group) {
      if (!document || !settings || group !== 'audio') { mounted = null; return; }
      const rows = settings.querySelector('.rows');
      if (!rows) return;
      if (!document.getElementById('rocket-audio-style')) {
        const style = document.createElement('style');
        style.id = 'rocket-audio-style';
        style.textContent = "#settings:has([data-arena-audio-workshop]) .shell {\n  grid-template-rows: auto minmax(0, 1fr);\n}\n#settings:has([data-arena-audio-workshop]) .panel {\n  height: auto;\n  min-height: 0;\n  align-self: stretch;\n}\n#settings:has([data-arena-audio-workshop]) .rows {\n  flex: 1 1 0;\n  min-height: 0;\n  overflow-y: auto;\n  overflow-x: hidden;\n  overscroll-behavior: contain;\n  scrollbar-gutter: stable;\n  scroll-padding-block: 12px;\n}\n#settings:has([data-arena-audio-workshop]) .rows > * {\n  flex-shrink: 0;\n}\n#settings [data-arena-audio-workshop] {\n  box-sizing: border-box;\n  display: grid;\n  gap: 10px;\n  width: 100%;\n  min-width: 0;\n  margin: 14px 0 10px;\n  padding: 14px 0 0;\n  border-top: 2px solid var(--ui-frame-hi, #aeb1cb);\n  color: var(--ui-text, #f8f8f8);\n  font: 12px/1.5 Silkscreen, monospace;\n}\n#settings .rocket-audio-heading {\n  margin: 0 0 2px;\n  color: var(--ui-text, #f8f8f8);\n  font: 700 16px/1.4 Silkscreen, monospace;\n  text-transform: uppercase;\n}\n#settings .rocket-song {\n  box-sizing: border-box;\n  display: grid;\n  grid-template-columns: minmax(0, 1fr) auto;\n  align-items: center;\n  gap: 5px 12px;\n  min-width: 0;\n  padding: 10px;\n  border: 2px solid var(--ui-frame-hi, #aeb1cb);\n  border-radius: 0;\n  background: var(--ui-panel, #272f55);\n  box-shadow: inset 0 0 0 2px var(--ui-outline, #0a0c18);\n}\n#settings .rocket-song-name {\n  min-width: 0;\n  overflow-wrap: anywhere;\n  font: 700 14px/1.4 Silkscreen, monospace;\n}\n#settings .rocket-song-file {\n  grid-column: 1;\n  min-width: 0;\n  max-height: 3em;\n  overflow: hidden;\n  overflow-wrap: anywhere;\n  white-space: normal;\n  color: var(--ui-text, #f8f8f8);\n  font: 12px/1.5 Silkscreen, monospace;\n}\n#settings .rocket-song-actions {\n  grid-column: 2;\n  grid-row: 1 / 3;\n  display: flex;\n  flex-wrap: wrap;\n  align-items: center;\n  justify-content: flex-end;\n  gap: 8px;\n  min-width: 0;\n  max-width: 320px;\n}\n#settings .rocket-song-actions button {\n  position: static;\n  box-sizing: border-box;\n  display: inline-block;\n  width: auto;\n  min-width: 0;\n  max-width: 100%;\n  height: auto;\n  min-height: 34px;\n  padding: 6px 8px;\n  border: 2px solid var(--ui-frame-hi, #aeb1cb);\n  border-radius: 0;\n  background: var(--ui-panel, #272f55);\n  box-shadow: 2px 2px 0 var(--ui-outline, #0a0c18);\n  color: var(--ui-text, #f8f8f8);\n  font: 700 12px/1.4 Silkscreen, monospace;\n  white-space: normal;\n  overflow-wrap: anywhere;\n  cursor: pointer;\n}\n#settings .rocket-song-actions button:enabled:hover {\n  border-color: var(--ui-text, #f8f8f8);\n}\n#settings .rocket-song-actions button:enabled:active {\n  transform: translate(1px, 1px);\n  box-shadow: 1px 1px 0 var(--ui-outline, #0a0c18);\n}\n#settings .rocket-song-actions button:disabled,\n#settings .rocket-song-loop:has(input:disabled) {\n  opacity: .45;\n  cursor: default;\n}\n#settings .rocket-song-loop {\n  display: inline-flex;\n  align-items: center;\n  gap: 8px;\n  min-height: 32px;\n  min-width: 0;\n  margin: 0;\n  color: var(--ui-text, #f8f8f8);\n  font: 700 12px/1.4 Silkscreen, monospace;\n  cursor: pointer;\n}\n#settings .rocket-song > .rocket-song-loop {\n  grid-column: 1 / -1;\n}\n#settings .rocket-song-loop input[type=\"checkbox\"] {\n  appearance: none;\n  box-sizing: border-box;\n  flex: 0 0 20px;\n  width: 20px;\n  height: 20px;\n  margin: 0;\n  padding: 0;\n  border: 2px solid var(--ui-frame-hi, #aeb1cb);\n  border-radius: 0;\n  background-color: var(--ui-bg, #10142a);\n  box-shadow: inset 0 0 0 1px var(--ui-outline, #0a0c18);\n  cursor: inherit;\n}\n#settings .rocket-song-loop input[type=\"checkbox\"]:checked {\n  background-image:\n    linear-gradient(45deg, transparent 40%, var(--ui-text, #f8f8f8) 40%, var(--ui-text, #f8f8f8) 60%, transparent 60%),\n    linear-gradient(-45deg, transparent 40%, var(--ui-text, #f8f8f8) 40%, var(--ui-text, #f8f8f8) 60%, transparent 60%);\n  background-size: 10px 10px;\n  background-position: center;\n  background-repeat: no-repeat;\n}\n#settings .rocket-song-actions button:focus-visible,\n#settings .rocket-song-loop input:focus-visible {\n  outline: 2px solid var(--ui-cursor, #f87818);\n  outline-offset: 3px;\n}\n#settings .rocket-song-message,\n#settings .rocket-audio-storage {\n  grid-column: 1 / -1;\n  min-width: 0;\n  margin: 3px 0 0;\n  color: var(--ui-text, #f8f8f8);\n  font: 12px/1.5 Silkscreen, monospace;\n  white-space: normal;\n  overflow-wrap: anywhere;\n}\n#settings .rocket-song-message:empty,\n#settings .rocket-audio-storage:empty,\n#settings .rocket-song-picker {\n  display: none;\n}\n@media (max-width: 1000px) {\n  #settings .rocket-song {\n    grid-template-columns: minmax(0, 1fr);\n    padding: 8px;\n  }\n  #settings .rocket-song-actions {\n    grid-column: 1;\n    grid-row: auto;\n    justify-content: flex-start;\n    max-width: none;\n    margin-top: 3px;\n  }\n}\n";
        document.head.appendChild(style);
      }
      mounted = rows.querySelector('[data-arena-audio-workshop]');
      if (!mounted) {
        mounted = document.createElement('section');
        mounted.dataset.arenaAudioWorkshop = '';
        mounted.setAttribute('aria-label', 'Sound changer');
        const heading = document.createElement('h2');
        heading.className = 'rocket-audio-heading';
        heading.textContent = 'Sound changer';
        mounted.appendChild(heading);
        for (const track of tracks) {
          const row = document.createElement('div');
          row.className = 'rocket-song'; row.dataset.song = track.id;
          const name = document.createElement('div'); name.className = 'rocket-song-name'; name.textContent = track.label;
          const filename = document.createElement('div'); filename.className = 'rocket-song-file';
          const actions = document.createElement('div'); actions.className = 'rocket-song-actions';
          const picker = document.createElement('input'); picker.className = 'rocket-song-picker'; picker.type = 'file'; picker.accept = '.mp3,audio/mpeg'; picker.setAttribute('aria-label', `${track.label} MP3`);
          const choose = document.createElement('button'); choose.className = 'rocket-song-replace'; choose.type = 'button'; choose.textContent = 'Replace MP3'; choose.setAttribute('aria-label', `Replace ${track.label} MP3`);
          const restore = document.createElement('button'); restore.className = 'rocket-song-reset'; restore.type = 'button'; restore.textContent = 'Reset'; restore.setAttribute('aria-label', `Reset ${track.label} to ${localTracks.has(track.id) ? 'menu song' : 'original'}`);
          const message = document.createElement('div'); message.className = 'rocket-song-message'; message.setAttribute('role', 'status');
          choose.addEventListener('click', () => picker.click());
          picker.addEventListener('change', () => { const file = picker.files?.[0]; picker.value = ''; if (file) void replace(track.id, file); });
          restore.addEventListener('click', () => { void reset(track.id); });
          actions.append(choose, restore, picker); row.append(name, filename, actions);
          if (track.reference) {
            const reference = document.createElement('a');
            reference.className = 'rocket-song-reference'; reference.textContent = 'Song reference';
            reference.style.cssText = 'grid-column:1/-1;color:inherit;font:inherit;';
            reference.href = track.reference; reference.target = '_blank'; reference.rel = 'noopener noreferrer';
            reference.setAttribute('aria-label', `${track.label} song reference on YouTube`);
            row.append(reference);
          }
          if (resultTracks.has(track.id)) {
            const label = document.createElement('label'); label.className = 'rocket-song-loop';
            const loop = document.createElement('input'); loop.type = 'checkbox'; loop.dataset.songLoop = track.id;
            loop.setAttribute('aria-label', `Loop ${track.label}`);
            loop.addEventListener('change', () => { void setLoop(track.id, loop.checked); });
            const text = document.createElement('span'); text.textContent = 'LOOP';
            label.append(loop, text); row.append(label);
          }
          row.append(message); mounted.appendChild(row);
        }
        const storage = document.createElement('div'); storage.className = 'rocket-audio-storage'; storage.setAttribute('role', 'status'); mounted.appendChild(storage);
        rows.appendChild(mounted);
      }
      repaint();
    }

    const bossMixer = createRocketBossTransitions(player, {tracks:bossTracks, decode, report, keyFor:track=>records.get(track) || null});
    return Object.freeze({
      ready, tracks, replace, reset, decode, mount, roomMusic, teamMusic, bossMusic, prepareBossMusic, eonMusic, prepareEonMusic, setLoop,
      shouldLoop: track => !resultTracks.has(track) || loops.get(track) === true,
      loopEnd: (buffer, nativeEnd) => customBuffers.has(buffer) || !Number.isFinite(nativeEnd) ? buffer.duration : Math.min(nativeEnd, buffer.duration)
    });
  }

  function patch(source) {
    const replace = (before, after) => {
      const parts = source.split(before);
      if (parts.length !== 2) throw Error('Unsupported game build. Could not add local music replacements.');
      source = parts.join(after);
    };
    replace('mi=new fi(pi);function hi()', `mi=new fi(pi);si['lobby-joined']=si['lobby-waiting']=si['team-builder']=si.menu;si['boss-eon']=si['boss-rayquaza-1']=si['boss-rayquaza-2']=si['boss-rayquaza-3']=si['redline-circuit'];var arenaAudioWorkshop=(${createWorkshop.toString()})(pi,{document,get indexedDB(){return globalThis.indexedDB},unlock:()=>{b();hi();return n},selectLobby:track=>{mi.battleStarted=false;mi.setPaused(false);mi.select(track)},selectBoss:track=>{mi.battleStarted=true;mi.select(track)}});function hi()`);
    replace('e.state!==`countdown`&&(window.clearInterval(this.countTimer),mi.menu()),this.paintRoom()', 'e.state!==`countdown`&&(window.clearInterval(this.countTimer),arenaAudioWorkshop.roomMusic(this)),this.paintRoom()');
    replace('this.renderPick(),this.setTurnHint(!1),this.keyHandler||', 'this.renderPick(),arenaAudioWorkshop.teamMusic(true),this.setTurnHint(!1),this.keyHandler||');
    replace('hidePick(){this.pick?.classList.add(`is-hidden`)', 'hidePick(){arenaAudioWorkshop.teamMusic(false);this.pick?.classList.add(`is-hidden`)');
    replace('r=await e.decodeAudioData(s.slice(0))', 'r=await arenaAudioWorkshop.decode(e,s,t,i)');
    replace('n.loop=e.track!==`victory`&&e.track!==`defeat`', 'n.loop=arenaAudioWorkshop.shouldLoop(e.track)');
    replace('n.loopEnd=Math.min(si[e.track],e.buffer.duration)', 'n.loopEnd=arenaAudioWorkshop.loopEnd(e.buffer,si[e.track])');
    replace('s&&(s.value=TE),pD(),requestAnimationFrame', 's&&(s.value=TE),arenaAudioWorkshop.mount(lE,hE),pD(),requestAnimationFrame');
    // Native settings keyboard navigation must leave the new native buttons usable.
    replace('function GD(e){', 'function GD(e){if(pE&&e.key!==`Escape`&&e.target instanceof Element&&e.target.closest(`[data-arena-audio-workshop]`))return;');
    return 'const createRocketBossTransitions='+createBossTransitions.toString()+';\n'+source;
  }

  globalThis.ArenaAudioWorkshopAdapter = Object.freeze({ patch });
  if (typeof module !== 'undefined' && module.exports) module.exports = Object.freeze({ patch, createWorkshop });
})();
