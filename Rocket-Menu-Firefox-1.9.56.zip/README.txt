ROCKET MENU 1.9.56 — ROOM AND PROFILE UPDATE

Room: Copy Link is inside Invite. Removed Copy invite + my team and the
external sharing destinations. Invite sits below Ready with matching sizing.
Change Team, Train and Browse Menus share one row with equal sizing.
On narrow displays Ready and Invite occupy equal full-width rows.

Previous teams: confirmed battle-start teams are remembered locally by trainer
ID, never by display name. Updated Rocket clients exchange their persistent
client IDs over an established DIRECT connection. Room-provided trainer/client/
player IDs are also supported when present. Stock clients and cloud-only rooms
cannot be recognized unless the server exposes an ID. Clearing a player's
browser data changes their client ID. PREVIOUS TEAM is historical, not a claim
about the current selection. Nothing is retrospectively recovered from old
battle history, which did not store opponent IDs.

Profile: updated requested captions; Playtime label; removed history disclaimer.
Showcase has three selectable slots, using existing earned/equipped badge data.
Choose a slot to pick an earned badge; select a populated slot to replace it,
or use its X to remove it. Collection follows Stats and displays native unlocked
cards, all badges (unearned badges are locked), and a Shinies empty state.
The supported game build has no shiny ownership data or shiny assets; this
release does not invent shiny unlocks or recolor normal Pokemon as shinies.

Validation: full adapter pipeline against the supported engine; JS syntax;
DOM tests for room/profile flows; persistent ID memory and direct-ID handshake.
No live two-player Firefox battle or visual browser check was completed here.

Rocket Menu 1.9.55 • Team Rocket theme

Install in desktop Firefox
Open about:debugging#/runtime/this-firefox, click Load Temporary Add-on
and select Rocket-Menu-Firefox-1.9.55.zip. Open the official game at
https://poke2darena.com/play-online/. Rocket Menu and Full Roster load
together and use the same site's saves. The red R stays hidden until you
enter SNEAKYGIO14 in Settings > Data > Save name, then click Export XML. After unlocking,
click it to open the menu, or use Firefox's extensions menu.
Ctrl+R hides or shows the unlocked red R while the game has focus. Hiding it closes
the panel too. Plain R keeps its normal game action; F5 still refreshes.
Leave an older online game tab before joining another room. After a Firefox
restart, load the ZIP again.

Boss Rush
Choose Singleplayer > Boss Rush, select a boss and difficulty, select your team, and ready up.
Boss Rush has its own team builder with three saved teams of three Pokemon each.
These teams and their moves are separate from the regular 99-team book and are
included in the combined XML save. Older XML files leave your boss teams intact.
Settings > Closet > Boss Moves adds the custom boss attacks to the singleplayer
move selector, independently of Any Move. The switch starts off and remembers
its setting. Saved boss moves remain in your teams when it is off; battle copies
then fall back to native moves. Online submissions also use native moves,
because the public game service does not implement these custom attacks.
All encounters offer Easy, Normal, Hard, Expert and Champion. Normal preserves
the previous fight balance. Each boss remembers its last difficulty on this browser.
The selection screen shows the resulting HP and attack multipliers; boss bars show
the selected level and actual maximum health, including after Mega Evolution.

Difficulty     Health    Damage    Attack speed    Attack size
Easy           65%       60%       75%             80%
Normal         100%      100%      100%            100%
Hard           130%      120%      115%            110%
Expert         165%      145%      130%            120%
Champion       200%      170%      150%            130%

Health scales from 6,000 for Rayquaza, 4,000 for each Eon boss and 6,500 for Mewtwo. Player damage
is normalized against the game's HP-based formula so higher boss health actually
adds durability. Attack warnings retain a readable minimum. Status protection
still lasts five seconds, and healing percentages and Pokemon body sizes stay the same.

Rayquaza is one of three selectable boss encounters. Sky Pillar is a dedicated rooftop arena with stone
tiles, low parapets, a rear sanctuary ramp, entry stairs and clouds; it is not in the
normal map list. The two freestanding pillars and their collisions have been removed.
Rayquaza is enlarged only for this encounter, with a matching hitbox, 6000 HP on Normal and
a large boss health bar replacing the timer and round label. His size is 20% smaller
than the original Boss Rush release. At half health he Mega Evolves without refilling his HP.
His custom attacks are a straight cross-arena body dash, purple dragon breath,
a large plasma ball, and an airborne crashing ultimate. Mega Rayquaza dashes twice,
breathes a wider green blast, fires four plasma balls in different directions, and
rains meteors during his diving ultimate. Watch the warnings and use the normal
movement and Protect controls.
All attacks have dedicated body animations for windup, execution and recovery.
Attack cycles have shorter pauses and recoveries, quicker follow-ups and faster plasma.
Rayquaza varies attacks based on distance and recent choices instead of a fixed loop.
Dash pursuit/crosscuts, breath sweeps, plasma directions and meteor formations vary;
hit warnings remain visible and repeated dash warnings last at least 240ms.
Energy effects use cached detailed textures, soft glows, plasma surfaces, layered
breath ribbons, meteor trails and shockwaves, with smoothed body animation.
At 25% HP Rayquaza enters Enraged mode after a brief roar: attack areas expand,
dash chains contain four passes, attacks recover faster, and plasma travels faster.
The boss bar changes color and labels this phase ENRAGED. HP does not refill.
Phase-three attacks glow yellow/gold; Reduce Flash softens the glow.
Your phase 1.mp3, phase 2.mp3 and phase 3.mp3 files are included in this add-on.
Boss music starts with the fight, switches at Mega Evolution (50% HP), and switches
again at Enraged mode (25% HP). Each song loops and uses the normal music volume,
mute and pause controls. Victory/loss sounds resume at the result screen.
Transitions keep the old song playing until the next is decoded, then crossfade
over 2.1 seconds. Measured melodic-section maps align the bundled recordings where
confidence is sufficient; the third arrangement differs in tempo and structure.
The music can hold up to three seconds for a nearby matching phrase. When none is
supported by the recordings, it crossfades from the next song's start instead.
Uploaded replacements crossfade from their beginning because their sections may differ.
Settings > Audio > Sound changer has separate Boss Rush slots to replace the songs.
Reset restores the bundled song. Replacement MP3s stay on this device, outside XML.

Mewtwo has a private Psychic Cave arena with a carved ancient doorway, layered rock
walls, weathered stone floor and violet crystals. It is not in the normal map list.
Shoot the real Mewtwo within four seconds during the clone-circle challenge;
the fakes are slightly lighter. Correct hits count during fade-in too, and a real
hit takes priority over fake hits from the same attack/frame. A correct hit clears
pending punishment. Hitting only a fake or running out of time triggers a rapid
Shadow Ball burst: two volleys 95ms apart normally, three 60ms apart in Mega form.
Rotating radial lasers, purple-cracked thrown rocks,
a one-second Aura Sphere charge held behind his body, and fading teleport dodges
form his other attacks. Native movement, Protect and damage handling still apply.
Mewtwo's boss attacks and clone attacks deal neutral damage through type immunities
instead of No Effect. Resistances, weaknesses, Protect and dodge invulnerability still apply.
At half health he becomes Mega Mewtwo X without refilling HP. He summons more clones,
fires faster Shadow Balls and denser radial lasers that rotate about 4.4 times
faster. Six laser clones orbit while firing; Expert and Champion use eight.
Mewtwo also charges and throws rocks while the clone lasers are active.
His Mega teleport lands directly on the player's current position, then Crunch
strikes as he finishes reappearing, with a brief 220ms arrival warning.
Mewtwo Expert and Champion clears award silver and gold Mewtwo profile badges.

Mega X / Mega Y and Auto Evolve
The team builder shows Mega preferences between the preview and movesets. X/Y choices
apply in singleplayer and Direct battles where you are the actual battle host.
Cloud battles and Direct guests keep the native move-based form choice. Your moves stay unchanged.
Auto Evolve appears beneath the selector for every Mega-capable Pokemon and starts off.
Enable it to use the normal Mega action as soon as that Pokemon enters and evolution
is available, including online battles. Native timing and one-Mega-per-battle limits apply.
Both preferences are included in your combined XML save.

Arena graphics
The new lighting is on automatically in battles, the menu exhibition and replays.
A local stage shader lights raised floor detail, darkens crevices and adds soft highlights
with lighting tuned to each arena. Grass has subtle mowing stripes, and cold arenas
have cooler highlights. Firefox uses a Canvas color treatment
when WebGL is unavailable. Pokémon keep their pixel sprites with directional rim light
and floor shadows. Fire, water, electric and psychic attacks have distinct streams and
impact shapes. Moving projectiles have short, soft motion trails along their recent
path. Reduce Flash also suppresses the extra attack bursts, motion blur, trails and beams.
These are original visual effects inspired by Big Kid Nation's Pokémon Arena 2D.

The charcoal, white and crimson panel contains seven control labels
and square checkboxes. An X means enabled; dimmed controls are unavailable
in the current battle. The panel scrolls on small screens while its title
and close button stay visible. All switches start off each game launch.
Unlock them by entering SNEAKYGIO14 in Settings > Data > Save name and clicking Export XML.
Enter the same code again to lock the menu, hide the red R, and turn every menu
switch off. Unlocking again starts with all switches off. The access setting is
remembered on this browser and does not change your save. CLOSET stays separate.
Auto Aim lives in Settings > Controls and works independently of this lock.

CLOSET settings
Enter THECLOSET14 in Settings > Data > Save name and click Export XML to reveal the sixth
settings tab, CLOSET. Repeat with the same code to hide it. CLOSET starts hidden
each time the game loads, while its saved settings stay active.
Auto Protect now lives in CLOSET and starts OFF with this release. Once you
enable it there, it stays enabled when CLOSET is hidden and on later launches.
DASH PROTECT is a separate saved toggle, also off by default. It permits threat-
triggered Protect while dashing, including when ordinary Auto Protect is off.
AUTO STATUS is a separate saved toggle, off by default. It automatically casts an
equipped native self-boost ability when ready, respecting cooldowns and action locks.
Protect remains controlled by the separate Protect options.
Both secret codes preserve your save data and profile stats and do not download a file.

Game settings and background play
Game is the first Settings tab. Connection offers Auto, Force Cloud and Force Direct.
The choice applies when joining or creating a room. Auto keeps native negotiation;
Force Cloud disables peer negotiation; Force Direct accepts only a successful
two-player peer connection and declines Cloud matches. It cannot force the service
to select Direct or make you the battle host.
Switching tabs keeps battles, lobby training and the online connection active.
Held controls release on focus loss. Manual pause and leaving still work.
Firefox may still throttle or suspend a hidden tab.
Keep fainted bodies is off by default in Settings > Game. Enabling it leaves
fainted Pokemon sprites on the battlefield without changing combat or collision.

Bulk card packs
Card Packs offers Buy 10, Buy 25 and Buy Max. Max accounts for rising pack prices
and the remaining collection. Each pack costs the normal number of coins when
opened. The first pack plays its animation; choosing KEEP then opens each next
pack directly at its card choices. Stop Batch or exit to cancel unbought packs;
any already paid pending pack stays saved for later.

If the game patch fails to load, Rocket Menu can reload this tab once to
repair it. It waits for startup first and does not repeatedly reload.
This version uses the game's Canvas renderer as a compatibility workaround
for the reported green battlefield. The original failure was not reproduced
in testing; Canvas rendering was verified with the arena, Pokemon and attacks
visible. No extra graphics setting is needed. Game rules stay the same.

Rocket Menu recognizes the latest November 14 deployment and loads a compatible
official client, checking its fingerprint before applying the menu. A verified
local client cache can keep that client available when its download changes.
New site deployments use compatibility fallback with a dismissible game-update
notification instead of stopping solely because the entry filename changed.
The warning is separate from the locked Rocket button; dismissing it is remembered
for that deployment. Your saves stay on the same site. Major protocol changes,
missing dependent assets or page redesigns can still require an add-on update.

Lobby training
Choose BROWSE MENUS in a waiting lobby to use the main menus with a persistent
lobby bar. Singleplayer and Online stay disabled while you are in the room.
The bar shows player/ready status and lets you ready up or return to the lobby.
Countdown and match start return you to the native online battle flow.
Select TRAIN in a waiting room to practice with your lobby team against
a Hard CPU. When either side loses its last Pokemon, that side's entire
team returns at full health. The top bar shows the room, players and their
ready status. Press Tab to edit your team. Confirm your edits to use them
in practice and in the lobby. Press R to toggle your lobby ready status.
Respawning clears stale knockout overlays when the incoming sprite appears.
Select OPTIONS on the training bar to pick Easy, Normal or Hard, turn off the CPU AI
for a stationary opponent, or choose its three Pokemon. These changes
apply in the current practice fight. Changing maps starts a fresh
practice fight with both teams at full health and keeps your lobby seat.
Once all required players are ready, training closes and the room shows
the normal countdown before the online battle. You can return to the lobby
early with the LOBBY button on the bar.

CPU battle modes
After choosing your team in Vs CPU, select a mode beside Difficulty, then
choose Easy, Normal or Hard to start. Classic keeps the usual team duel.
FFA supports 3 through 12 fighters. Team modes are 5v5, 4v4, 3v3v3,
3v3, 2v2 and 2v2v2v2. All fighters are active at once: you control your
lead Pokemon and CPUs control the rest. Your selected teammates fill allied
slots first; extra slots and opponents use random non-Gmax Pokemon.
Allies cannot damage one another. Knockouts eliminate fighters, and your
team wins by defeating every other team. Compact sprite and health panels
replace the opponent HUD, with small colored health bars on the field and
no large team labels. On short screens, the panels sit below the top HUD.
The camera follows your Pokemon at normal battle zoom and stays inside the
map borders. These modes are for local CPU play.

Teams and roster sorting
The team picker replaces arena buttons with Default, Type, Dex # and
Vanilla. Default keeps the full roster's normal order. Type sorts by primary
type, then Dex number. Vanilla is limited to the game's 36 featured
characters. Search, type filters and recent choices stay inside that list.
Your existing arena choice stays saved.
The offline team selector includes the six original arenas plus Courtyard,
Rock Gym and Temple Court. They use custom pixel-art floors and separately
placed scenery based on the supplied maps. Choose a map below Back,
sorting and Ready. You can also choose these maps in lobby practice under
Options. The three large boulders and the small center stone on the rock
court block movement and projectiles.
The selected map has a highlighted border and the picker remembers your choice.

Save up to 99 three-Pokemon teams. The arrows above your team move through
33 pages, with three team tabs on each page. Existing names, members and
move choices carry over. The combined XML save includes the full team book.
Importing an XML save replaces the book with that file's teams.
While editing moves, the P1/P2/P3 team column is hidden and the move
selector fills the available width. The team column returns when you finish.
Each Pokemon has five shared moveset slots beside its preview. Each slot
has an editable name and shows every saved move on its type-colored tile.
The slots fill the right side of the detail panel. SAVE copies
the displayed moves into a slot; LOAD applies that slot to this Pokemon on
the team you are editing. Other teams stay unchanged. Slots are shared by
the same Pokemon across teams and are included in the XML save.

Data and profile
Data shows GAME VERSION and BUILD for the official site, followed by ROCKET
VERSION and TARGET for Rocket's latest supported site build. Version 1.9.55
targets game v0.9.1 BUILD 1F9FBC0. Future deployments can show a different BUILD
while the fixed TARGET remains visible. Missing metadata shows Unknown.
Settings > Data has one XML export and one XML file import for both Game and
Rocket data. The editable filename defaults to your trainer name. The file
contains collection, story progress, all 99 teams and moveset slots, plus
Rocket profile counters and match history. Import validates both parts before
replacement and asks for one confirmation. Replays remain local to this browser.
Enter SNEAKYGIO14 or THECLOSET14 in Save name and click Export XML to apply a secret
code instead of downloading a save. Ordinary names export a named XML file.

Choose Profile below Card Packs on the main menu to open the full-screen
trainer pages. Use the Profile, History and Stats tabs at the top.
Profile has Edit Name and a grid of stat cards under your trainer name,
with native Pokemon sprites for your favorite and favorite team. It shows your most-used Pokemon, most-used
three-Pokemon team, online win rate and match totals, active playtime, and
story, card and Pokedex completion. Usage and match counters start with this
update; older battles cannot be recovered. Completion uses your actual game
save, so restore Game data to restore those percentages. Menu AI battles do
not count. Outside a real battle, playtime stops after two minutes without
mouse movement. Active battles continue counting while the tab is unfocused;
hidden or unfocused time outside a battle does not count.
Clean Sweeps count online duel wins that defeat all three foes without any
of your Pokemon fainting. Ace counts online wins without taking damage;
healing does not erase damage already taken. These new counters require
the full fight to be observed and are included in XML saves.
Profile and Data panels scroll within the screen; the XML import confirmation
remains reachable on shorter windows.
Profile also shows Current and Highest win streak boxes for consecutive online
wins. Losses and draws end the current streak; CPU and training battles do not
change it. Your own lobby card shows a locally recorded streak from three wins
onward. Streaks save with Rocket data; old codes recover only known outcomes.

On the Stats tab, select Playtime, Win rate, Pick rate or Matches Played to rank your
Pokémon in a horizontal bar chart. Playtime counts active battle time
controlling that Pokémon. Win rate counts wins among recorded results
with that Pokémon on your team, including draws in the denominator.
Pick rate counts games with the Pokémon on your team divided by all
tracked games. Each team member counts once per game.
Matches Played counts a Pokemon once only after it actually enters battle;
unused reserves do not count, and switching back does not add another match.
Temporary Mega forms count toward the originally selected Pokemon. In simultaneous
CPU modes, allied Pokemon that actively fight count too. This counter begins with
1.9.51; older saves cannot reconstruct which reserves entered each match.

The chart includes solo and online battles. Lobby practice and menu
exhibitions do not count. Per-Pokémon playtime starts with version 1.9.27.
Older saves contribute the picks and outcomes they can document. These
career totals travel with your XML save.

Small earned badges appear at the bottom of Profile; unearned badges are hidden.
Equip up to three badges in the slots there. Equipped badges and their selection
are saved with Rocket data and the combined XML save. Online highest winstreak milestones
unlock permanent badges: Poke Ball at 10, Great Ball at 20, Ultra Ball at 50,
Master Ball at 100, and a crown at 250. Known saved highest streaks qualify too.
Each boss encounter has a silver Expert-clear badge and a gold Champion-clear
badge. The Eon badge shows both Latios and Latias. A gold version of the native
Story menu icon unlocks when all story stages are complete, including existing
completed game saves. Earned badges remain earned after a streak ends.
Boss-clear badges begin tracking in 1.9.51 because older clears were not recorded.
Badges and Matches Played are included in Rocket data and the combined XML save.

Match history and replays
History and replay screens use the game's pixel fonts, blue square frames,
and native-style buttons and controls.
Open History in the top navigation. Back or Escape returns from a replay
to the match list. The list shows date and time, lobby,
trainer names, Pokemon, remaining HP and result. Unavailable HP or results
remain unknown. The latest 200 history entries are included in the XML save.
Replays are stored separately on this device and are NEVER included in the XML.
Importing on another device brings history but does not bring its replays.

Replays use the game's animated Pokemon sprites, move effects, status art
and item sprites. Compact arena snapshots at five samples per second plus
timed visual events drive playback without running another battle.
Older recordings still open, with fewer effects where details were not saved.
Use the timeline,
playback speed, zoom, drag-to-pan and player follow controls to inspect the
whole arena. Up to 20 local replays are retained, within an 80 MB total cap;
older recordings are removed as needed while their history can remain.
Clearing site data also removes local recordings. Uploaded MP3s and local
settings stay on this device.
The spectator arena fills the available height, with its timeline docked
at the bottom and both teams' remaining health in the top right. Hide
Nametags, Hide Damage and Hide Status affect the spectator only. These
viewing preferences stay on this device. Recorded switches use the game's
Poke Ball transition, and damage/status text follows the recorded events.

Battle move HUD
In a duel, both active HP bars sit along the bottom, with 24-pixel bars on desktop
and 18-pixel bars on mobile for easier peripheral visibility. The party portraits
stay at the top, with three boxes for your opponent. An empty or unknown
slot keeps its place. Ability buttons are more compact, especially Dash
and Protect, with prominent cooldown numbers.

Below 40% HP, a faint red vignette appears around the battlefield for
your active Pokemon. Each living Pokemon below 30% HP also has a slow
red pulse on its sprite. Both cues clear when HP reaches the threshold.

Damaging moves show their type matchup against the nearest living enemy:
Effective, Super Effective, Not Very Effective or No Effect. These badges
follow target and Pokemon changes. Dash, Protect and status-only moves do
not receive damage-matchup labels. Labels reflect the game's type chart.
Double weaknesses show 2x Super Effective (the native 4x type multiplier).
A separate S.T.A.B box appears underneath when a damaging move matches
one of your current Pokemon's types, independently of the enemy matchup.

Audio
UI SFX controls menu clicks and navigation sounds. Game SFX separately
controls combat sounds and effects. Both follow Master and Mute All.
Existing sound-effect volume carries over as the initial UI SFX volume.

Open Settings, then Audio. Sound Changer uses the game's pixel font,
square blue panels and buttons. Each of the eight music/sound slots has an
MP3 file picker and Reset button. Files stay in this browser on this device;
they are not uploaded or included in a Save Code. Background replacements
loop their full duration and follow the game's music volume, mute and pause.
Lobby - Waiting for Players plays while a room has an open player slot,
including two-player rooms and private three-player brawls. Lobby - Player
Joined plays when a room you host is full, taking priority even while the
Team Editor is open. If a player leaves, Team Editor music resumes while
you are still editing. Otherwise Team Editor plays while you choose
Pokemon or edit moves, then restores the lobby or menu song.
Countdown and battle keep their normal music transitions. Each extra slot
uses your Menu song until you upload an MP3; Reset restores that fallback.
Battle - Victory and Battle - Loss replace the native result sounds.
Each has an independent Loop checkbox, off by default. Checked sounds loop
their full length until you leave the result screen. This also works with
the original sounds. Uploads preserve your loop choice; Reset restores
the original sound and turns Loop off. Loop choices save locally.
The Team Editor slot retains music previously saved for Team Builder.
The copyable host helper keeps the original audio controls and main menu.

Fixed battle slots
Press 1, 2 or 3 (or the matching number-pad key) to select that original
team slot. The three thumbnails stay in order and show orange numbered
badges. Normal switching cooldowns and fainted-member rules still apply.
Plain R continues cycling; Ctrl+R hides or shows the Rocket Menu launcher.

Editable keyboard controls
Open Settings > Controls to change keyboard bindings. Select an action,
then press its new key; Escape cancels. Bindings save on this device and
are not included in XML saves. Browser modifier shortcuts,
including Ctrl+R for the Rocket Menu launcher, remain reserved.

Auto-aim on every device
Settings > Controls > Auto Aim uses the improved targeting on every device.
It aims attacks toward living opponents, with short movement prediction and
range/obstacle checks. Buffered local attacks refresh their aim before casting.
Failed predictions fall back to the opponent's actual position. Turning the
option off keeps manual aiming. The old Rocket Menu Aimbot switch is removed.

Main menu
Online is the first orange button. Open it for Quick Match (Master Ball)
or Find Room. Quick Match tries an open public room using your saved team
and trainer name. If no room is available or joining fails, it creates a
public two-player room. PLAY AGAIN on online results uses the same search.
The orange Singleplayer button has a Great Ball. It opens Quick Match
(Poke Ball), Vs CPU, Story Mode and Arena Run. Both submenus keep the
animated menu arena. Quick Match is orange in each submenu.
Three-player brawls require private rooms: the official server rejects
public three-player creation. A browser extension cannot publish those rooms
to unmodified players or redirect players from a two-player room into one.

The logo sits above a compact left-hand column with even spacing. Profile
and Settings have labeled blue buttons below Card Packs. The Online and
Singleplayer submenus use the same button sizes and alignment.
The menu arena, fighters and effects are mirrored horizontally, keeping
the existing zoom. Playable battles retain their normal orientation.
The background runs a three-against-three Hard AI battle with six Pokemon fighting at once.
Each new menu battle chooses a random lineup and varied, species-legal
movesets. It uses the game's actual move, projectile, ultimate and status
effects. Each defeated fighter respawns as a different Pokemon with a new
species-legal moveset. Replacement artwork loads before the fighter returns.
The view keeps the menu's fixed zoom, so fighters can leave the
visible area. This background does not change your teams, progress or
match results. It stops when you leave the menu.

Full Roster is included
Every supported game load includes Full Roster.
Choose Pokémon in Your Teams or the native battle picker. Quick and Vs CPU
also support Mega forms and a wider CPU roster. Official online rooms keep
the game's permitted species and party rules. Your collection, coins and
rewards keep their normal progress. No separate Full Roster add-on is needed.
Gmax forms are hidden from the picker and excluded from automatic menu,
Quick and CPU lineups. Existing saved teams are preserved.

Choose your moves for solo and Direct battles you host
Turn on Any move in Rocket Menu, then open Your Teams or the online room's team
picker and select a Pokémon's move slot. The native move picker offers
the 104 working moves beyond that species' usual choices. Every move list
is sorted alphabetically by type, then move name, across all pages. Dash
stays first. Each move shows its type alongside its native type color.

With Any move on, every working move is available from each move slot. The
picker places it in a compatible control slot automatically. If it will
use another control, the choice says “Equips on” that control. If a
different equipped move must change, the choice also names that move.
After choosing, the editor shows the move's actual control slot.

You can equip repeated moves and multiple stat buffs. Casting a different
stat buff replaces the active buff using the game's normal behavior.
Protect/Dash and ultimate power rules still determine the final slot
placement. The game's unimplemented moves are excluded.

If a regular move repeats your ultimate's move, an unmodified opponent's
game may show the ultimate's visual effect for that regular cast. The
actual cast role, damage and cooldowns remain correct.

Any move starts off and Firefox remembers your choice. Turning it off uses
a recommended loadout where custom choices would be incompatible; it keeps
your saved custom choices for when you turn it on again. This is a loadout
setting, separate from the seven battle controls below.

Any move applies in solo battles and when your browser runs a two-player
DIRECT battle. The other player can use the ordinary game. The lobby HOST
badge identifies the room creator; the game separately chooses which
browser runs combat. Creating the room does not guarantee Direct authority.

Online room submission uses a normal compatible loadout. If your browser
hosts the Direct battle, the add-on applies your chosen moves to your own
Pokémon. CLOUD battles and battles hosted by another browser use the normal
loadout. Any move is dimmed during these fights, including with a compatible
remote host. Your saved switch preference and custom choices return in
supported battles. You can choose custom moves while setting up a team.

Opening Online
Online > Find Room shows “Loading public rooms…” immediately. Retry starts a new request,
and Back returns to the main menu. If the room list takes eight seconds to
respond, the lobby shows a timeout message. Use Refresh to try again.

Direct connection startup
If the first connection measurements are briefly unstable, Rocket Menu
checks later real measurements within the game's original four-second
attempt. The same connection-quality limits still apply. A failed peer
connection or a CLOUD decision ends the attempt normally.
This does not choose the battle host or turn an existing CLOUD match into
DIRECT. The service still chooses the host, and both peers must qualify.
Live testing confirmed the service accepted a recovered measurement with
an unmodified opponent. That session later fell back to CLOUD; sustained
DIRECT gameplay was not verified by that test.

No cooldowns in a public duel
In Online, choose Create Room > Public > 2 Players. When the service
selects your Firefox browser as the DIRECT battle host, enable No cooldowns
in Rocket Menu. The other player can use the ordinary game. Their own
timers remain normal when only you have the add-on. Unavailable controls
are dimmed; the panel keeps only the controls.
Press the ability again after its cast/recovery animation, or enable
No recovery to skip the recovery period after an attack. Dash and Protect
keep their active durations. Your ultimate charge stays at 100% while
No cooldowns is on, including after using an ultimate or switching Pokémon.
The lobby HOST badge identifies the room creator. A CLOUD battle runs on
the game server; the room creator cannot change its cooldown rules.

Check your controls in battle
Start a CPU battle, open Rocket Menu on the game screen, and turn on 2× speed.
The menu applies changes to the running battle and remembers your choices.
If the menu loads without the game patch, automatic repair can reload the
tab with the verified patch. Full Roster is always included. Any move is a
loadout setting separate from the seven battle controls.
Rapid fire starts off and is remembered by Firefox. Enable it to remove
basic shot cooldowns, then use your normal attack controls. Skill windup
still applies; No recovery separately controls the recovery period.

No recovery and Always super effective start off and are remembered by
Firefox. No recovery skips recovery after attacks while preserving windup
and contact timing. Always super effective makes your damaging moves use
at least the game's 2× type multiplier, preserving natural 4× matchups.
Other damage rules still apply, including defense, critical hits and damage
caps. Healing and fixed-damage status ticks keep their normal behavior.
Both options work in solo battles and when your browser runs a DIRECT
battle. A compatible remote host can also apply them; an older host helper
does not support them. Unsupported switches are dimmed while your saved
preferences remain available for a supported battle.
Rapid fire is also dimmed when an older remote host lacks support for it.

Trainer and room names
Use EDIT NAME only on your Profile screen. These are real game names visible
to unmodified players. The server
only accepts its supported name parts, such as QuietPilot37 or SunnyScout48.
Choose supported parts in the editor, type a valid name, or use Roll.
In a room, Save waits for the server to confirm the name before saving it
for later connections. Outside a room, the name is saved for your next join.
Unsupported text is rejected instead of being stored as a display label.

Set the real room title in Online > Create Room, using a supported name
such as Hasty Grove 63. The game has no supported title-change operation
after creation. Local room labels and shared aliases have been removed;
old alias values are discarded without replacing your real game profile.

IP masking
Direct connections remain enabled. Use your VPN for IP masking. Rocket Menu
does not mask the address or claim that a VPN is connected. The game's
current connection setup has no TURN relay for private Direct transport.

See the opponent's Pokémon
The waiting room displays team names and portraits as soon as a lineup is
available. The normal game sends opponent teams after the room countdown.
This add-on also shows the confirmed teams in the pre-fight intro.

To see your friend's picks before either player presses Ready, your friend
can use a compatible Rocket Menu release or its host helper and choose
Copy invite + my team in the room. Open that link in Firefox. “From invite” means the team
they chose when they copied the link. They can send a new invite if they
change their lineup. In a connected two-player lobby, compatible players
can also choose Share my team to share their current picks directly.
Regular invites leave team details out. No lineup is guessed.

Join your friend's public room
Open https://poke2darena.com/play-online/ and choose Online. Join your
friend's waiting public room or enter its code. Pick your team and both
press Ready. Open Rocket Menu in the arena to see what your connection supports.

• If your browser is the DIRECT battle host, all battle switches and
  your Any move loadout apply to your Pokémon. The other player can use
  the ordinary game.
• If your friend's browser is the DIRECT battle host, their browser needs
  this version or the updated host helper to apply your cooldown, HP,
  speed and Rapid fire settings. No recovery and Always super effective
  also require a host running this version or its updated helper. Your
  own Auto Aim and Auto Protect send local input in either case.
  The game chooses which browser simulates combat. Creating the room
  does not guarantee that a particular browser runs it.
• In CLOUD and three-player battles, the site's server decides damage,
  movement and cooldowns. Auto Aim and Auto Protect send normal local input. The other
  six battle switches are dimmed; your saved settings return for
  supported matches. Any move uses a normal loadout for these battles.

If your friend can use a bookmark but cannot install the add-on
The helper provides compatible battle controls. Extra local input settings,
audio controls, menu battles, Gmax filtering, profile stats, Data panels and
match history with replays require the full add-on.
Open the Firefox toolbar popup and click Copy host helper. Share
the complete text. Before opening Online, your friend can make a bookmark,
paste the entire javascript: address as its URL, and use that bookmark
on the official game's main menu. They should read its prompt and choose
whether to continue. They can then create the public two-player room as
usual. The helper enables the host side of the connection for one game
tab. Reloading or closing the tab ends the helper session.

Your controls
No cooldowns releases ordinary attack, skill, Dash and Protect reuse timers
and keeps your ultimate charged to 100%. Attack windup still applies;
No recovery separately skips recovery after attacks. Turning No cooldowns
off restores normal charging after the next ultimate.
Auto Protect is off by default. Turn it on in Settings > CLOSET to use an available
Protect just before an incoming hit with predicted damage strictly above 12.
Small shots, basic attacks and punches now qualify by damage instead of size.
The estimate uses native stats, typing, known boosts and the maximum random roll;
streams and ultimate zones qualify by their total damage, with each hit's timing
checked separately. Unknown remote boosts can
limit accuracy. Thunder Wave, Hypnosis, Sleep Powder and other harmful status
projectiles also qualify without direct damage when their status can affect you.
Prediction follows movement against arena edges and rocks, ignores already-spent
dash hits, uses the next stream tick, and adjusts online
lead time to measured latency and jitter. Existing dodge invulnerability is
respected; a later impact can trigger Protect just before that immunity ends.
Moving attackers shift predicted shot origins, rings, streams and following
ultimate zones. Remote projectiles and hit schedules account for snapshot age;
shots intercepted by another fighter do not trigger Protect. Recovery can queue
Protect in the native final 150ms when it will be ready before the predicted hit.
Pending casts are confirmed or retried after rejection, and Auto Status waits
while a nearby incoming threat or pending Protect needs the ability input.
Incoming threats also reserve the attack input so held attacks cannot immediately
chain into another cast ahead of Protect. Custom Rayquaza, Latios/Latias and Mewtwo
boss attacks use their own attack geometry and damage for threat prediction.
Protect/Detect must be equipped and ready; normal cooldowns and action locks still apply.
Protect can take the next input when an attack finishes, even while the attack
button stays held.
Dash Protect permits overlap with attacking dashes in solo or locally controlled
Direct battles, retaining the dash and using native Protect costs/cooldowns.
Stock remote authority still controls active move-dashes; ordinary dodge and
Protect are submitted on separate frames there when available.
Protect keeps its normal availability and cooldown. It cannot prevent ongoing
ailment damage; hidden/instant attacks and connection delay can limit prediction.
Auto Aim leads observed enemy movement using each attack's speed and windup.
It favors targets within reach, checks solid-rock obstructions and keeps a steady
target while a suitable shot remains available. Melee, dash and ground-targeted
moves use their own aiming rules. Sudden turns can still evade predicted shots.
God mode protects your
active Pokémon's HP. 2× speed doubles its ground movement, and Rapid fire
removes basic shot cooldowns. Always super effective changes your damaging
moves' type multiplier. These controls also work in solo battles.
This version uses the site's normal networking.

Supported game entry module: index-BBhViti1.js. If the game changes, this
version may need an update. Loading and connection diagnostics are retained
for troubleshooting without adding text to the panel.

Online disconnects and pack cards
Terminal ping/network timeouts in started matches are recorded as No Contest.
They count separately in total matches and do not affect wins, losses, win rate,
achievements or streaks. Confirmed results remain valid; manual quits are forfeits.
A small blue DUPLICATE badge marks any pack choice already owned before opening.
It uses actual card collection ownership, including in quick/bulk opening.

Latios & Latias boss encounter
Choose Singleplayer > Boss Rush > Latios & Latias. Your normal three-Pokemon team
fights two simultaneous allied bosses in a private night city square. On Normal,
each starts with 4,000 HP and an individual boss bar. When either reaches 40% HP, both living
bosses Mega Evolve together without refilling health and attack faster. Win by defeating both; normal player switching
and party fainting rules apply.
When either boss faints, the living partner becomes Enraged once: 25% more damage,
25% faster attacks, and 15% larger attack areas on top of the selected difficulty.
The survivor keeps its remaining HP, gains a warm aura and an ENRAGED boss-bar label,
and continues attacking alone. Both fainting together ends the fight normally.
Both use plasma lasers that join into one stronger beam, and Steel Wing charges.
Latias also uses Ice Beam and heals 8% of her own missing HP plus 4% of living Latios's
missing HP. Latios also uses plasma balls and a 5-second status-immunity field for
every fighter across the arena. Healing and status protection are favored at lower
health. Once both are Mega, plasma lasers always coordinate and sweep;
other attacks remain independent with frequent coordinated opportunities.
Twin Dive sends both bosses airborne: Latios dives first, then Latias marks your
updated position for her own delayed dive. Dragon Cross telegraphs intersecting
charge paths; Mega forms repeat the cross after a fresh warning.
Latios fires Hurricane tornado projectiles using the game's Hurricane ultimate
animation. Latias summons orbiting Psybombs that launch in a shuffled sequence;
some curve toward a locked position rather than endlessly tracking you.
These moves join the existing attacks. Coordinated beams, dives and crosses vary
between casts, with independent attacks in between. Landing areas and charge paths
respect scenery, and airborne bosses cannot be hit until they land.
The map uses varied stone paving, detailed tiled buildings and shopfronts, warm
lantern lighting and richer market stalls. The center stays open, with no fountain.
Scenery collision footprints and the arena's playable boundaries are unchanged.
Latios and Latias share the same displayed body height and collision radius,
including their Mega forms. They navigate around scenery between attacks.
Attacks are larger and faster, with varied choices and fewer repeated patterns.
Animated energy streams join into a much wider, stronger combined beam.
Beam and plasma emission follows the exact Shoot frame's mouth/head landmark for
each of eight directions and all four forms, shared by visuals and collision logic.
Sustained laser and ice firing frames loop throughout the attack, with the mouth
position recalculated on the same simulation clock. Each beam cast keeps a stable
sprite direction; coordinated lasers use one shared junction and outgoing sweep
instead of feeding animated mouth offsets back into their facing direction.
Boss attack damage is 30% higher. Windup/recovery timing, beam sweeps, recent-move
weights and the number of independent moves between coordinated lasers vary.
The supplied latios and latias.mp3 is bundled as their looping theme; Settings >
Audio can replace it or reset to the bundled file.

Eon animation offset credits
The numerical Shoot offsets derive from the matching SpriteCollab source sheets:
https://github.com/PMDCollab/SpriteCollab
Normal Latios/Latias: CHUNSOFT. Mega Latios/Latias: Emmuffin
(https://twitter.com/Ernmuffin), CC BY-NC 4.0:
https://creativecommons.org/licenses/by-nc/4.0/
The offsets are adapted into frame/direction tables. The game continues to load
its existing sprites; this addition bundles no replacement sprite images.
