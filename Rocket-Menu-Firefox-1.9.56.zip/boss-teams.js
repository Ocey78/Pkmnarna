// Three saved Boss Rush teams. This store never replaces the regular team book.
(() => {
  'use strict';
  function createArenaBossTeams(){
    const storageKey='arena.rocket.boss-teams.v1',scope='boss-rush';
    let memory=null,readable=true;
    const copy=value=>structuredClone(value);
    const isBook=book=>book?.scope===scope;
    const fail=message=>{throw Error('Boss teams: '+message);};
    function empty(){return{v:1,scope,active:0,everSaved:false,teams:Array.from({length:3},(_,index)=>({name:'Boss Team '+(index+1),slots:[null,null,null],moves:[null,null,null]})),movePresets:{},megaForms:{},autoMega:{}};}
    function object(value){return !!value&&typeof value==='object'&&!Array.isArray(value);}
    function validMoves(value){return value===null||Array.isArray(value)&&value.length>=4&&value.length<=5&&value.every(id=>typeof id==='string'&&id.length>0&&id.length<=80);}
    function sameMoves(a,b){return a===null&&b===null||Array.isArray(a)&&Array.isArray(b)&&a.length===b.length&&a.every((id,index)=>id===b[index]);}
    function validate(raw){
      if(!object(raw)||raw.v!==1||raw.scope!==scope||!Number.isInteger(raw.active)||raw.active<0||raw.active>2||!Array.isArray(raw.teams)||raw.teams.length!==3)fail('unsupported team data.');
      if(raw.everSaved!==undefined&&typeof raw.everSaved!=='boolean')fail('invalid save state.');
      for(const team of raw.teams){
        if(!object(team)||typeof team.name!=='string'||!team.name.trim()||team.name.length>48||/[\u0000-\u001f\u007f]/.test(team.name)||!Array.isArray(team.slots)||team.slots.length!==3||!Array.isArray(team.moves)||team.moves.length!==3)fail('each team must have three Pokémon slots.');
        const used=new Set();
        for(let index=0;index<3;index++){
          const id=team.slots[index],moves=team.moves[index];
          if(id!==null&&(typeof id!=='string'||!hn.has(id)||used.has(Bn(id))))fail('unknown or duplicate Pokémon.');
          if(id!==null)used.add(Bn(id));
          if(!validMoves(moves)||id===null&&moves!==null)fail('invalid team moves.');
        }
      }
      for(const key of ['movePresets','megaForms','autoMega'])if(raw[key]!==undefined&&!object(raw[key]))fail('invalid '+key+'.');
      if(raw.movePresets)for(const [id,sets] of Object.entries(raw.movePresets)){
        if(!hn.has(id)||!Array.isArray(sets)||sets.length!==5)fail('invalid saved movesets.');
        for(const set of sets)if(!object(set)||typeof set.name!=='string'||set.name.length>24||!validMoves(set.moves))fail('invalid saved moveset.');
      }
      const normalized=arenaTeamBook(raw);
      const result={...normalized,v:1,scope,active:raw.active,teams:normalized.teams.slice(0,3)};
      // Reject damaged move lists instead of silently changing an imported team.
      for(let index=0;index<3;index++)for(let slot=0;slot<3;slot++)if(!sameMoves(raw.teams[index].moves[slot],result.teams[index].moves[slot]))fail('unsupported team moves.');
      if(raw.movePresets)for(const [id,sets] of Object.entries(raw.movePresets))for(let index=0;index<5;index++){
        const expected=sets[index],actual=result.movePresets?.[id]?.[index];
        if(!actual||!sameMoves(expected.moves,actual.moves))fail('unsupported saved moveset.');
      }
      for(const key of ['megaForms','autoMega'])if(raw[key])for(const [id,value] of Object.entries(raw[key]))if(result[key]?.[id]!==value)fail('unsupported Mega preference.');
      return result;
    }
    function normalize(book){
      const normalized=arenaTeamBook(book);
      return{...normalized,v:1,scope,active:Math.max(0,Math.min(2,Number.isInteger(book?.active)?book.active:0)),teams:normalized.teams.slice(0,3)};
    }
    function storage(){const store=globalThis.localStorage;if(!store)fail('browser storage is unavailable.');return store;}
    function read(){
      if(memory)return copy(memory);
      try{const text=storage().getItem(storageKey);readable=true;return text===null?empty():validate(JSON.parse(text));}
      catch{readable=false;return empty();}
    }
    function replaceValidated(book){
      const next=validate(book),store=storage(),text=JSON.stringify(next);
      store.setItem(storageKey,text);if(store.getItem(storageKey)!==text)fail('the saved teams could not be written.');
      memory=null;readable=true;return true;
    }
    function save(book){
      const next=normalize(book);
      try{return replaceValidated(next);}catch{memory=copy(next);readable=false;return false;}
    }
    function reset(){memory=null;readable=true;}
    function wrap(native){
      // Route by the data's explicit scope, not whichever page happens to be
      // visible. Regular reads/imports, including simultaneous lobby work, keep
      // using the native 99-team store and its own memory fallback.
      return{read:(...args)=>native.read(...args),save:book=>isBook(book)?save(book):native.save(book),get saved(){return native.saved;},reset:()=>native.reset()};
    }
    function adopt(ui,book){return ui.rocketBossPick?isBook(book)?normalize(book):read():book;}
    function saved(ui){return isBook(ui?.teamBook)?memory===null&&readable:er.saved;}
    function paint(ui){
      const boss=ui.rocketBossPick===true;
      if(boss)ui.arenaTeamPage=0;
      const panel=ui.pick;if(!panel)return;
      panel.classList.toggle('rocket-boss-team-picker',boss);
      panel.querySelectorAll('.rocket-team-pages').forEach(pager=>{pager.hidden=boss;});
      const info=panel.querySelector('.pick-team-info');
      let heading=info?.querySelector('.rocket-boss-team-title');
      if(info&&!heading){heading=document.createElement('span');heading.className='rocket-boss-team-title';heading.textContent='BOSS RUSH TEAMS';info.prepend(heading);}
      if(heading)heading.hidden=!boss;
      const tabs=panel.querySelector('.saved-team-tabs');if(tabs)tabs.setAttribute('aria-label',boss?'Three saved Boss Rush teams':'Saved teams');
    }
    if(typeof window!=='undefined')window.addEventListener('storage',event=>{if(event.key===null||event.key===storageKey)reset();});
    return Object.freeze({storageKey,isBook,validate,replaceValidated,reset,read,snapshot:read,save,wrap,adopt,paint,saved,
      loadouts:team=>Qn(read(),team)});
  }
  function patch(source){
    const once=(before,after)=>{const parts=source.split(before);if(parts.length!==2)throw Error('Unsupported boss team anchor: '+before.slice(0,85));source=parts.join(after);};
    once('var er=$n(()=>{try{return globalThis.localStorage??null}catch{return null}}),tr=',
      'var er=arenaBossTeams.wrap($n(()=>{try{return globalThis.localStorage??null}catch{return null}})),tr=');
    once('adoptBook(e){this.teamBook=e;','adoptBook(e){e=arenaBossTeams.adopt(this,e);this.teamBook=e;');
    once('paintTeams(){let page=','paintTeams(){arenaBossTeams.paint(this);let page=');
    once('stepTeamPage(step){this.arenaTeamPage=', 'stepTeamPage(step){if(this.rocketBossPick)return;this.arenaTeamPage=');
    once('e&&(e.textContent=er.saved?this.teamBook.everSaved?', 'e&&(e.textContent=arenaBossTeams.saved(this)?this.teamBook.everSaved?');
    once('e.dataset.saved=String(er.saved))}', 'e.dataset.saved=String(arenaBossTeams.saved(this)))}');
    once("note(ui,id,er.saved?'Loaded '+slot.name+'.':'Loaded for this visit only.');", "note(ui,id,arenaBossTeams.saved(ui)?'Loaded '+slot.name+'.':'Loaded for this visit only.');");
    once('function wb(){return`','function wb(){return`<style>.pick .rocket-boss-team-title{font:700 11px/1.4 Silkscreen,monospace;color:var(--ui-text);white-space:nowrap}.pick .rocket-boss-team-title[hidden],.pick .rocket-team-pages[hidden]{display:none!important}.pick.rocket-boss-team-picker .pick-team-info{justify-content:space-between;align-items:center}</style>');
    return 'const arenaBossTeams=('+createArenaBossTeams.toString()+')();globalThis.arenaBossTeams=arenaBossTeams;\n'+source;
  }
  const api=Object.freeze({patch});globalThis.ArenaBossTeamsAdapter=api;
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})();
