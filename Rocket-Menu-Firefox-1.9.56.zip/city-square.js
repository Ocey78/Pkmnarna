// Private night-plaza boss arena; ground, solid scenery and collision share world coordinates.
(() => {
  'use strict';

  function createArenaCitySquare() {
    const id='rocket-city-square',width=2048,height=1280;
    const stage=Object.freeze({id,labelKey:'stages.rocket.citySquare',file:'rocket-private/city-square',backdrop:'#26394f'});
    const key=name=>id+'-'+name;
    const rectangle=(x,y,w,h)=>[{x,y},{x:x+w,y},{x:x+w,y:y+h},{x,y:y+h}];
    const ellipse=(x,y,rx,ry)=>Array.from({length:24},(_,i)=>({x:x+Math.cos(i*Math.PI/12)*rx,y:y+Math.sin(i*Math.PI/12)*ry}));
    const stalls=[
      {x:268,y:365,w:170,h:84,color:'blue'},
      {x:1604,y:386,w:174,h:84,color:'red'},
      {x:285,y:1018,w:166,h:80,color:'red'},
      {x:1600,y:1018,w:174,h:80,color:'blue'}
    ];
    const lamps=[{x:490,y:271},{x:1538,y:271},{x:248,y:650},{x:1790,y:654},{x:550,y:1088},{x:1490,y:1088}];
    const barrels=[{x:296,y:500},{x:335,y:515},{x:1710,y:526},{x:1746,y:513},{x:489,y:1058}];
    const carts=[{x:260,y:737,w:158,h:76},{x:1360,y:1035,w:165,h:65}];
    const combat={left:220,top:240,right:1830,bottom:1110,rocks:[
      ...stalls.map(p=>rectangle(p.x,p.y,p.w,p.h)),
      ...carts.map(p=>rectangle(p.x,p.y,p.w,p.h)),
      ...barrels.map(p=>ellipse(p.x,p.y,21,15)),
      ...lamps.map(p=>ellipse(p.x,p.y,9,7))
    ]};

    function random(seed) {
      return ()=>{seed|=0;seed=seed+0x6D2B79F5|0;let n=Math.imul(seed^seed>>>15,1|seed);
        n=n+Math.imul(n^n>>>7,61|n)^n;return((n^n>>>14)>>>0)/4294967296;};
    }
    function poly(ctx,points,fill,stroke,lineWidth=1) {
      ctx.beginPath();ctx.moveTo(...points[0]);for(const point of points.slice(1))ctx.lineTo(...point);
      ctx.closePath();ctx.fillStyle=fill;ctx.fill();
      if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=lineWidth;ctx.stroke();}
    }
    function line(ctx,points,color,w=1) {
      ctx.beginPath();ctx.moveTo(...points[0]);for(const point of points.slice(1))ctx.lineTo(...point);
      ctx.strokeStyle=color;ctx.lineWidth=w;ctx.stroke();
    }
    function oval(ctx,x,y,rx,ry,color,stroke) {
      ctx.beginPath();ctx.ellipse(x,y,rx,ry,0,0,Math.PI*2);ctx.fillStyle=color;ctx.fill();
      if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=2;ctx.stroke();}
    }
    function brickwork(ctx,x,y,w,h,rng,cool=true,bw=56,bh=28) {
      ctx.save();ctx.beginPath();ctx.rect(x,y,w,h);ctx.clip();
      ctx.fillStyle=cool?'#344456':'#3c343a';ctx.fillRect(x,y,w,h);
      for(let row=0,py=y;py<y+h;py+=bh,row++)for(let px=x-row%2*bw/2;px<x+w;px+=bw) {
        const colors=cool?['#52667e','#5c7086','#657b91']:['#67555a','#735e61','#80686a'];
        ctx.fillStyle=colors[Math.floor(rng()*colors.length)];ctx.fillRect(px+2,py+2,bw-4,bh-4);
        line(ctx,[[px+3,py+bh-4],[px+3,py+3],[px+bw-4,py+3]],cool?'#8596a8':'#a28a7b',2);
        line(ctx,[[px+bw-3,py+3],[px+bw-3,py+bh-3],[px+3,py+bh-3]],'#293849',2);
      }
      ctx.restore();
    }
    function glow(ctx,x,y,rx,ry,strength=.28) {
      // Three snapped light bands keep warm lantern pools in the tile palette.
      for(const [scale,alpha] of [[1,.13],[.67,.18],[.35,.24]]) {
        const points=Array.from({length:12},(_,i)=>[
          Math.round((x+Math.cos(i*Math.PI/6)*rx*scale)/4)*4,
          Math.round((y+Math.sin(i*Math.PI/6)*ry*scale)/4)*4]);
        poly(ctx,points,`rgba(255,196,95,${strength*alpha})`);
      }
    }
    function shadow(ctx,x,y,w,h) {
      if(w<60){oval(ctx,x+w*.6+8,y+h*.65+6,w*.62,h*.55,'#15243b5a');return;}
      poly(ctx,[[x,y+h*.3],[x+w,y+h*.2],[x+w+30,y+h+20],[x+22,y+h+20]],'#17283b4c');
      ctx.fillStyle='#16243838';ctx.fillRect(x+2,y+h-6,w,10);
    }
    function stone(ctx,x,y,w,h,rng,small=false) {
      const colors=small?['#4d606e','#586b77','#506674','#5d6f7b']:['#617784','#687c86','#5c7482','#657983','#6d7e87'];
      const chip=small?2:2+Math.floor(rng()*3)*2;
      poly(ctx,[[x+chip,y+2],[x+w-4,y+2],[x+w-2,y+6],[x+w-2,y+h-4],
        [x+w-chip-2,y+h-2],[x+4,y+h-2],[x+2,y+h-chip-2],[x+2,y+chip]],colors[Math.floor(rng()*colors.length)]);
      // Only parts of weathered edges catch light; no raised button bevel.
      if(rng()<.7)line(ctx,[[x+chip+2,y+3],[x+w*.48,y+3]],small?'#7d8a93':'#8c999e',2);
      if(rng()<.45)line(ctx,[[x+w-3,y+h*.54],[x+w-3,y+h-5],[x+w*.65,y+h-3]],'#475e6c',2);
      if(!small&&rng()<.19) {
        const start=x+Math.floor(w*(.25+rng()*.45)/2)*2;
        line(ctx,[[start,y+2],[start-4,y+h*.3],[start+4,y+h*.46],[start,y+h*.7]],'#4b606b',2);
        line(ctx,[[start+4,y+h*.46],[start+14,y+h*.5]],'#4b606b',2);
      }
      if(!small&&rng()<.3) {
        poly(ctx,[[x+w*.2,y+h*.3],[x+w*.6,y+h*.22],[x+w*.76,y+h*.56],
          [x+w*.4,y+h*.7],[x+w*.18,y+h*.55]],'#adbac212');
      }
      if(w>22&&h>20){
        // Low-contrast mineral clusters belong to each stone, rather than a
        // screen-wide noise filter. Keep broad forms legible under combat VFX.
        for(let i=0,n=Math.min(44,Math.ceil(w*h/(small?230:150)));i<n;i++){
          const px=Math.round((x+6+rng()*(w-14))/2)*2,py=Math.round((y+6+rng()*(h-14))/2)*2;
          ctx.fillStyle=i%3?'#b9c4c51a':'#233e4e28';ctx.fillRect(px,py,2+(i%3)*2,2);
          if(i%4===0){ctx.fillStyle='#bac3bd12';ctx.fillRect(px-2,py+2,6,2);}
        }
        if(!small){
          const py=Math.round((y+h*.65)/2)*2;
          line(ctx,[[x+10,py],[x+w*.3,py-2],[x+w*.48,py-2]],'#b2bec114',2);
          if(rng()<.3){ctx.fillStyle='#3a5260';ctx.fillRect(x+w-8,y+h-4,6,2);ctx.fillStyle='#8b989d';ctx.fillRect(x+w-9,y+h-6,5,2);}
        }
      }
    }
    function border(ctx,x,y,w,h,rng) {
      ctx.fillStyle='#3b5362';ctx.fillRect(x,y,w,h);
      ctx.fillStyle='#82929a';ctx.fillRect(x+2,y+2,w-4,h-4);
      ctx.fillStyle='#4b616e';ctx.fillRect(x+8,y+8,w-16,h-16);
      // An inset civic stone ribbon, rather than a combat-field marking.
      for(let px=x+10;px<x+w-10;px+=40) {
        stone(ctx,px,y+9,40,14,rng,true);stone(ctx,px,y+h-23,40,14,rng,true);
      }
      for(let py=y+24;py<y+h-24;py+=40) {
        stone(ctx,x+9,py,14,40,rng,true);stone(ctx,x+w-23,py,14,40,rng,true);
      }
      for(const [px,py] of [[x+15,y+15],[x+w-15,y+15],[x+15,y+h-15],[x+w-15,y+h-15]]) {
        poly(ctx,[[px,py-9],[px+9,py],[px,py+9],[px-9,py]],'#b3ad91','#536773',2);
        ctx.fillStyle='#687b86';ctx.fillRect(px-3,py-3,6,6);
      }
    }
    function floor(ctx) {
      const rng=random(63923);
      ctx.fillStyle='#425764';ctx.fillRect(0,0,width,height);
      // A smaller cobbled street surrounds a deliberately quieter flagstone
      // square. Changing stone sizes and staggered seams avoid a wallpaper grid.
      for(let row=0,y=0;y<height;y+=28,row++) {
        let x=-(row%2)*19;
        while(x<width){const w=[32,40,48][Math.floor(rng()*3)];stone(ctx,x,y,w,28,rng,true);x+=w;}
      }
      border(ctx,432,282,1184,772,rng);
      ctx.save();ctx.beginPath();ctx.rect(458,308,1132,720);ctx.clip();
      ctx.fillStyle='#4d626d';ctx.fillRect(458,308,1132,720);
      let row=0;
      for(let y=308;y<1028;row++) {
        const h=[52,64,56,72][row%4];let x=458-(row%2)*40;
        while(x<1590) {
          const w=[64,84,108,120][Math.floor(rng()*4)];
          if(w>100&&rng()<.22){stone(ctx,x,y,w,h/2,rng);stone(ctx,x,y+h/2,w,h/2,rng);}
          else stone(ctx,x,y,w,h,rng);
          x+=w;
        }
        y+=h;
      }
      ctx.restore();
      // The south entrance carries a narrow run of large slabs into the plaza.
      for(let y=1054;y<1280;y+=56)for(let x=846;x<1202;x+=89)stone(ctx,x,y,89,56,rng);
      // Raised perimeter curb and gutters are outside the playable rectangle.
      brickwork(ctx,190,212,1667,26,rng,true,65,26);
      brickwork(ctx,190,238,29,894,rng,true,29,56);
      brickwork(ctx,1831,238,29,894,rng,true,29,56);
      brickwork(ctx,190,1111,650,28,rng,true,65,28);
      brickwork(ctx,1210,1111,650,28,rng,true,65,28);
      line(ctx,[[221,240],[221,1110]],'#182b3d55',5);line(ctx,[[1828,240],[1828,1110]],'#182b3d55',5);
      // Low contact shadows anchor the buildings without darkening the battle.
      poly(ctx,[[220,240],[1830,240],[1808,264],[238,264]],'#14253628');
      ctx.fillStyle='#12263820';ctx.fillRect(220,248,18,850);ctx.fillRect(1810,248,20,850);
      for(const p of [...stalls,...carts])shadow(ctx,p.x,p.y,p.w,p.h);
      for(const p of barrels)shadow(ctx,p.x-23,p.y-14,46,28);
      for(const p of lamps){glow(ctx,p.x,p.y-18,158,115,.36);shadow(ctx,p.x-8,p.y-5,16,12);}
      for(const [x,y] of [[698,238],[1320,230],[224,415],[1834,945],[842,1120],[1210,1132]])glow(ctx,x,y,120,90,.20);
      // Drain covers and moss remain unobtrusive edge details.
      for(const [x,y] of [[236,341],[1801,719],[445,1090]]) {
        ctx.fillStyle='#203648';ctx.fillRect(x,y,20,13);
        for(let i=0;i<5;i++)line(ctx,[[x+3+i*4,y+2],[x+3+i*4,y+11]],'#748294');
      }
      for(let i=0;i<64;i++) {
        const side=i%4,x=side===0?223+rng()*20:side===1?1800+rng()*28:240+rng()*1565;
        const y=side<2?250+rng()*840:side===2?242+rng()*14:1090+rng()*18;
        ctx.fillStyle=i%3?'#587a66':'#8a8b70';ctx.fillRect(Math.round(x/4)*4,Math.round(y/4)*4,4+i%2*4,4);
      }
    }

    function clipped(ctx,shape,paint) {
      ctx.save();ctx.beginPath();ctx.moveTo(...shape[0]);for(const p of shape.slice(1))ctx.lineTo(...p);
      ctx.closePath();ctx.clip();paint();ctx.restore();
    }
    function shingles(ctx,w,h,red,rng) {
      const colors=red?['#764f59','#805860','#895e64','#70505c']:['#3e5b76','#47637d','#506d86','#405b73'];
      ctx.fillStyle=red?'#3d3141':'#263c53';ctx.fillRect(0,0,w,h);
      for(let row=0,y=0;y<h;y+=16,row++)for(let x=-(row%2)*16;x<w;x+=32) {
        const color=colors[(row+Math.floor(rng()*2))%colors.length];
        poly(ctx,[[x+1,y],[x+30,y],[x+30,y+10],[x+27,y+15],[x+22,y+18],
          [x+8,y+18],[x+3,y+15],[x+1,y+10]],color);
        line(ctx,[[x+2,y+10],[x+5,y+15],[x+10,y+17],[x+22,y+17],[x+27,y+14],[x+30,y+9]],red?'#493742':'#273d53',2);
        line(ctx,[[x+6,y+3],[x+22,y+3]],red?'#a67c7b80':'#8aa0b080',2);
        if(rng()<.16)line(ctx,[[x+20,y+5],[x+17,y+10],[x+19,y+15]],red?'#5c424e':'#334b62',2);
      }
    }
    function windowArt(ctx,x,y,lit,shutter='#4d6470',w=38,h=44) {
      ctx.fillStyle='#29323f';ctx.fillRect(x-4,y-3,w+8,h+7);
      ctx.fillStyle='#9e9b8c';ctx.fillRect(x-2,y-1,w+4,h+3);
      ctx.fillStyle=lit?'#dcba7d':'#354e68';ctx.fillRect(x+2,y+3,w-4,h-6);
      ctx.fillStyle=lit?'#a8814d':'#293e57';ctx.fillRect(x+2,y+h*.58,w-4,h*.36);
      ctx.fillStyle=lit?'#f6df9e':'#617d93';ctx.fillRect(x+4,y+5,w-8,3);
      line(ctx,[[x+w/2,y+2],[x+w/2,y+h-2]],'#514d47',3);
      line(ctx,[[x+2,y+h*.47],[x+w-2,y+h*.47]],'#514d47',3);
      for(const sx of [x-14,x+w+4]) {
        ctx.fillStyle='#26353f';ctx.fillRect(sx-1,y-1,12,h+2);ctx.fillStyle=shutter;ctx.fillRect(sx,y,10,h);
        for(let sy=y+7;sy<y+h;sy+=8)line(ctx,[[sx+1,sy],[sx+8,sy-1]],'#253d4e',2);
        ctx.fillStyle='#adb09b';ctx.fillRect(sx+2,y+5,2,3);ctx.fillRect(sx+2,y+h-9,2,3);
      }
      ctx.fillStyle='#283540';ctx.fillRect(x-7,y+h+2,w+14,6);ctx.fillStyle='#9a9b8b';ctx.fillRect(x-6,y+h+2,w+12,2);
    }
    function doorArt(ctx,x,y,w,h) {
      poly(ctx,[[x-5,y+h],[x-5,y+12],[x+4,y+2],[x+w-4,y+2],[x+w+5,y+12],[x+w+5,y+h]],'#a29b83','#313c46',2);
      poly(ctx,[[x,y+h],[x,y+14],[x+7,y+7],[x+w-7,y+7],[x+w,y+14],[x+w,y+h]],'#4a403c');
      for(let px=x+6;px<x+w;px+=8)line(ctx,[[px,y+14],[px,y+h-3]],'#78644d',3);
      line(ctx,[[x+2,y+h*.55],[x+w-2,y+h*.55]],'#2c3036',4);
      ctx.fillStyle='#c6a665';ctx.fillRect(x+w-9,y+h*.52,4,4);
      ctx.fillStyle='#263440';ctx.fillRect(x-7,y+h-1,w+14,6);ctx.fillStyle='#9ca39b';ctx.fillRect(x-6,y+h-1,w+12,2);
    }
    function signArt(ctx,x,y,red) {
      line(ctx,[[x,y-18],[x+44,y-18],[x+44,y-10]],'#263544',4);
      line(ctx,[[x+12,y-17],[x+12,y],[x+36,y]],'#a69b7e',2);
      ctx.fillStyle='#2e3138';ctx.fillRect(x+5,y-2,44,29);ctx.fillStyle='#8a7253';ctx.fillRect(x+8,y+1,38,23);
      line(ctx,[[x+9,y+2],[x+44,y+2]],'#c6aa78',2);
      if(red){oval(ctx,x+27,y+13,12,7,'#d3b17d');for(let i=0;i<3;i++)line(ctx,[[x+20+i*6,y+8],[x+17+i*6,y+15]],'#876344',2);}
      else poly(ctx,[[x+14,y+14],[x+21,y+7],[x+35,y+8],[x+39,y+12],[x+45,y+7],[x+45,y+20],[x+39,y+15],[x+24,y+20]],'#a9b7b5');
    }
    function house(ctx,w,h,red,seed) {
      const rng=random(seed),eave=h-90,door=Math.floor(w*.57/2)*2;
      ctx.fillStyle=red?'#8c7c78':'#7b8790';ctx.fillRect(8,eave-8,w-16,h-eave+4);
      brickwork(ctx,8,h-34,w-16,30,rng,true,44,15);
      for(let x=16;x<w-10;x+=92) {
        ctx.fillStyle='#3f3e44';ctx.fillRect(x,eave-3,8,h-eave-2);
        line(ctx,[[x+8,eave+7],[Math.min(x+80,w-14),eave+29]],'#514a48',5);
        line(ctx,[[x+2,eave+3],[x+2,h-8]],'#aaa18c66',2);
      }
      ctx.fillStyle='#403e43';ctx.fillRect(12,eave+29,w-24,6);
      for(let x=42;x<w-55;x+=100)if(Math.abs(x-door)>46)windowArt(ctx,x,eave+15,rng()>.22,red?'#687165':'#4a6572',34,42);
      doorArt(ctx,door,eave+17,34,67);signArt(ctx,w-73,eave+44,red);
      // Curved overlapping shingles on a pitched roof, framed by separate
      // back slope, ridge caps, rafter ends and a shaded timber cornice.
      const front=[[0,eave-8],[29,49],[w-29,35],[w,eave-8]],back=[[29,49],[40,12],[w-40,2],[w-29,35]];
      clipped(ctx,back,()=>{shingles(ctx,w,65,red,rng);ctx.fillStyle='#14293945';ctx.fillRect(0,0,w,65);});
      clipped(ctx,front,()=>{
        shingles(ctx,w,eave,red,rng);
        ctx.fillStyle='#15273a14';ctx.fillRect(0,eave-52,w,44);ctx.fillStyle='#15273a20';ctx.fillRect(0,eave-28,w,20);
      });
      line(ctx,[[0,eave-9],[29,49]],red?'#b18b83':'#879aa7',4);
      line(ctx,[[w-29,35],[w,eave-9]],'#25394d',5);
      for(let x=28;x<w-28;x+=28) {
        const y=49-(x-28)/(w-56)*14;
        poly(ctx,[[x,y+3],[x+3,y-5],[x+24,y-6],[x+28,y+1],[x+24,y+6],[x+3,y+8]],red?'#9b7478':'#71899b','#364a5b',2);
        line(ctx,[[x+5,y-3],[x+22,y-4]],red?'#c49d92':'#b5c0c0',2);
      }
      ctx.fillStyle='#223346';ctx.fillRect(0,eave-8,w,13);ctx.fillStyle=red?'#9b7d73':'#8193a0';ctx.fillRect(0,eave-8,w,3);
      for(let x=12;x<w-8;x+=24){ctx.fillStyle='#b0a58b';ctx.fillRect(x,eave+2,5,7);ctx.fillStyle='#343d46';ctx.fillRect(x+5,eave+3,3,8);}
      // Dormer interrupts the plane; its window and apron share roof lighting.
      const dx=Math.floor(w*.24/2)*2,dy=eave*.48;
      poly(ctx,[[dx-25,dy+42],[dx+31,dy+42],[dx+46,dy+54],[dx-17,dy+54]],'#172c3b55');
      ctx.fillStyle='#897c6d';ctx.fillRect(dx-22,dy+6,45,38);
      windowArt(ctx,dx-12,dy+11,seed%2===1,'#66726e',24,26);
      poly(ctx,[[dx-35,dy+11],[dx,dy-20],[dx+35,dy+11]],red?'#7a515b':'#47627b','#273c50',3);
      line(ctx,[[dx-33,dy+10],[dx,dy-18],[dx+33,dy+10]],red?'#bd9186':'#94a8b3',3);
      const cx=Math.floor(w*.75/2)*2;
      poly(ctx,[[cx,35],[cx+34,35],[cx+53,88],[cx+13,88]],'#13283b48');
      brickwork(ctx,cx,24,34,53,rng,false,18,14);
      ctx.fillStyle='#a29b8f';ctx.fillRect(cx-4,20,42,7);ctx.fillStyle='#273442';ctx.fillRect(cx+3,19,29,4);
      ctx.fillStyle='#b0a89a';ctx.fillRect(cx-4,18,42,3);
    }
    function sideHouse(ctx,w,h,red,seed) {
      const rng=random(seed),eave=216;
      // A side-facing facade follows the street; the long ridge runs north/south.
      ctx.fillStyle=red?'#847573':'#75828a';ctx.fillRect(207,8,53,h-16);
      for(let y=16;y<h-8;y+=84){ctx.fillStyle='#393f47';ctx.fillRect(207,y,53,6);line(ctx,[[211,y+8],[251,y+65]],'#514f4d',5);}
      ctx.fillStyle='#3a4149';ctx.fillRect(251,6,9,h-12);ctx.fillStyle='#a3a18e';ctx.fillRect(251,8,2,h-16);
      for(const y of [37,204])windowArt(ctx,220,y,true,red?'#6b7063':'#4d6571',22,37);
      doorArt(ctx,219,121,28,59);
      const roof=[[5,19],[83,3],[eave,16],[eave,h-14],[82,h-3],[5,h-18]];
      clipped(ctx,roof,()=>{
        ctx.save();ctx.translate(0,h);ctx.rotate(-Math.PI/2);shingles(ctx,h,eave,red,rng);ctx.restore();
        ctx.fillStyle='#16293b40';ctx.fillRect(0,0,78,h);ctx.fillStyle='#192b3e16';ctx.fillRect(190,0,26,h);
      });
      for(let y=10;y<h-10;y+=28) {
        poly(ctx,[[75,y],[83,y-3],[91,y],[92,y+23],[84,y+27],[76,y+23]],red?'#97727a':'#748a9a','#324859',2);
        line(ctx,[[79,y+3],[79,y+21]],red?'#bf9890':'#afbdc1',2);
      }
      line(ctx,[[7,20],[83,5],[215,17]],red?'#aa8980':'#94a4ae',4);
      line(ctx,[[215,17],[215,h-14]],'#263746',8);
      line(ctx,[[213,17],[213,h-14]],red?'#a18478':'#8498a4',2);
      for(let y=23;y<h-13;y+=22){ctx.fillStyle='#9d9987';ctx.fillRect(215,y,7,4);}
      brickwork(ctx,122,44,31,54,rng,false,17,14);ctx.fillStyle='#adab9a';ctx.fillRect(119,41,37,6);ctx.fillStyle='#263b4b';ctx.fillRect(125,41,24,3);
      signArt(ctx,208,282,red);
    }
    function stall(ctx,red) {
      // Canvas 212x164; collision footprint x20..194,y80..164.
      const rng=random(red?711:821);
      for(const x of [23,182]){
        ctx.fillStyle='#2a2b35';ctx.fillRect(x,42,8,118);ctx.fillStyle='#a08861';ctx.fillRect(x+2,48,2,104);
        ctx.fillStyle='#414a50';ctx.fillRect(x-1,90,10,5);ctx.fillRect(x-1,145,10,5);
      }
      ctx.fillStyle='#3c3635';ctx.fillRect(22,102,168,55);
      for(let i=0;i<8;i++){
        const x=23+i*21;ctx.fillStyle=['#755c45','#80664b','#6b5745'][i%3];ctx.fillRect(x,103,19,51);
        line(ctx,[[x+2,105],[x+2,151]],'#b69b6a55',2);
        line(ctx,[[x+13,108],[x+10,121],[x+12,148]],'#403a3750',2);
        ctx.fillStyle='#30333b';ctx.fillRect(x+5,113,2,2);ctx.fillRect(x+5,144,2,2);
      }
      ctx.fillStyle='#473a34';ctx.fillRect(20,147,172,7);ctx.fillStyle='#927657';ctx.fillRect(20,147,172,2);
      poly(ctx,[[19,96],[25,81],[187,81],[196,96]],'#a38b62','#403b36',2);
      ctx.fillStyle='#bfa77d';ctx.fillRect(18,96,178,5);ctx.fillStyle='#67503b';ctx.fillRect(18,101,178,5);
      // Separate produce trays, with clustered fruit, leafy greens and loaves.
      for(let tray=0;tray<3;tray++){
        const x=29+tray*53;poly(ctx,[[x,94],[x+4,79],[x+43,79],[x+47,94]],'#463f36');
        for(let i=0;i<8;i++){
          const px=x+8+(i%4)*9+(i>3?2:0),py=83+Math.floor(i/4)*7;
          if(tray===0){
            oval(ctx,px,py,5,4,red?'#a65c51':'#9eaf62','#39483b');
            ctx.fillStyle=red?'#d58d6c':'#c1c580';ctx.fillRect(px-2,py-2,2,2);line(ctx,[[px,py-4],[px+1,py-6]],'#3c4e35',2);
          }else if(tray===1){
            for(let leaf=0;leaf<3;leaf++)poly(ctx,[[px,py+3],[px-5+leaf*3,py-3],[px+leaf*3-1,py-5],[px+3,py+1]],['#506e50','#6b8a59','#8da76b'][leaf]);
          }else{
            oval(ctx,px,py,5,3,red?'#c5a675':'#a97a49','#62563b');line(ctx,[[px-2,py-2],[px,py]],'#e0c58e',1.5);
          }
        }
        line(ctx,[[x,94],[x+47,94]],'#d1b581',2);
      }
      poly(ctx,[[8,58],[36,12],[176,12],[204,58]],red?'#8d535a':'#4d6b88','#26384a',2);
      for(let i=0;i<10;i++){
        const x=36+i*14,bx=8+i*19.6,color=i%2?(red?'#a76d69':'#66859a'):'#bdb89a';
        poly(ctx,[[x,12],[x+14,12],[bx+19.6,58],[bx,58]],color);
        line(ctx,[[x+12,14],[bx+17,56]],i%2?'#263a4545':'#fff2ce28',3);
        line(ctx,[[x+3,14],[bx+4,56]],'#f5dfb52b',2);
        poly(ctx,[[bx,58],[bx+19.6,58],[bx+18,70],[bx+14,75],[bx+6,75],[bx+2,70]],color,'#2a3b492f',1);
        line(ctx,[[bx+5,72],[bx+14,72]],'#273b4a50',2);
      }
      poly(ctx,[[11,52],[201,52],[204,58],[8,58]],'#23374820');
      line(ctx,[[8,58],[204,58]],'#e1cf9f66',2);line(ctx,[[36,12],[176,12]],'#d8c79e',3);
      for(let i=0;i<12;i++){const x=27+rng()*155;ctx.fillStyle='#c6a87935';ctx.fillRect(Math.round(x/2)*2,129+Math.floor(rng()*9)*2,4,2);}
    }
    function barrel(ctx) {
      oval(ctx,26,46,23,15,'#262d35');
      ctx.fillStyle='#755f4a';ctx.fillRect(5,17,42,29);oval(ctx,26,44,21,12,'#735a45');
      for(let x=10;x<46;x+=8)line(ctx,[[x,18],[x+1,46]],'#3e3838',2);
      oval(ctx,26,18,21,12,'#9c8360','#3d3940');oval(ctx,26,18,16,8,'#756147','#b5a27a66');
      ctx.fillStyle='#35404c';ctx.fillRect(5,25,42,5);ctx.fillRect(5,40,42,5);
      line(ctx,[[7,26],[44,26]],'#9da7aa55');line(ctx,[[7,41],[44,41]],'#9da7aa55');
      for(const x of [13,23,34,43]){ctx.fillStyle='#c1b592';ctx.fillRect(x,27,2,2);ctx.fillRect(x,42,2,2);}
      for(const x of [16,32])line(ctx,[[x,31],[x-2,35],[x,39]],'#ad936341',2);
      line(ctx,[[12,15],[39,15]],'#c7b08166',2);line(ctx,[[10,20],[40,20]],'#504633',2);
    }
    function cart(ctx) {
      const rng=random(1018);
      ctx.fillStyle='#222d3b';ctx.fillRect(12,39,162,8);
      for(const x of [25,153]){oval(ctx,x,54,14,21,'#2c3037','#777565');line(ctx,[[x-10,54],[x+10,54]],'#867b61',2);line(ctx,[[x,38],[x,70]],'#867b61',2);}
      poly(ctx,[[15,18],[154,18],[176,42],[2,42]],'#a08967','#443e3d',2);
      ctx.fillStyle='#715c48';ctx.fillRect(2,42,174,19);
      for(let x=8;x<176;x+=22)line(ctx,[[x,44],[x,59]],'#413d3d');
      line(ctx,[[3,41],[174,41]],'#d0b48a',3);
      for(const [x,y,w,h] of [[37,1,48,31],[94,8,42,27]]){
        ctx.fillStyle='#4c4138';ctx.fillRect(x,y,w,h);ctx.fillStyle='#927651';ctx.fillRect(x+2,y+2,w-4,h-4);
        for(let px=x+9;px<x+w-2;px+=9)line(ctx,[[px,y+2],[px,y+h-2]],'#584734',2);
        line(ctx,[[x+2,y+3],[x+w-3,y+3]],'#c0a675',3);
        line(ctx,[[x+3,y+h-3],[x+w-4,y+4]],'#b59a69',4);
        for(const px of [x+4,x+w-6]){ctx.fillStyle='#343a3b';ctx.fillRect(px,y+4,2,2);ctx.fillRect(px,y+h-6,2,2);}
      }
      line(ctx,[[170,33],[198,20]],'#8a7558',6);
    }
    function lamp(ctx) {
      oval(ctx,25,108,9,6,'#202c37');ctx.fillStyle='#303a46';ctx.fillRect(22,36,6,72);
      line(ctx,[[22,40],[22,104]],'#80909a66',2);ctx.fillStyle='#1c2938';ctx.fillRect(12,14,26,26);
      ctx.fillStyle='#fbe4a2';ctx.fillRect(16,18,18,18);ctx.fillStyle='#d99f53';ctx.fillRect(16,30,18,6);
      line(ctx,[[25,16],[25,38]],'#59472f',2);
      poly(ctx,[[9,14],[25,3],[41,14]],'#617182','#24374b',2);ctx.fillStyle='#202f3d';ctx.fillRect(11,39,28,5);
      glow(ctx,25,27,25,25,.18);
      poly(ctx,[[18,104],[32,104],[36,110],[14,110]],'#303d49','#172c38',2);
      ctx.fillStyle='#80939b';ctx.fillRect(18,104,12,2);ctx.fillStyle='#aab8ae';ctx.fillRect(23,49,2,48);
      for(const y of [43,76,98]){ctx.fillStyle='#263747';ctx.fillRect(20,y,10,4);ctx.fillStyle='#8c9993';ctx.fillRect(21,y,6,1);}
      ctx.fillStyle='#fff2be';ctx.fillRect(18,19,4,12);ctx.fillStyle='#b9753b';ctx.fillRect(28,20,4,16);
      line(ctx,[[13,16],[25,8],[37,16]],'#9caeaf',2);ctx.fillStyle='#a8b9ae';ctx.fillRect(24,0,3,6);
    }
    function texture(scene,name,w,h,paint) {
      if(scene.textures.exists(name))return;
      const canvas=document.createElement('canvas');canvas.width=w;canvas.height=h;
      const pixel=document.createElement('canvas');pixel.width=Math.ceil(w/2);pixel.height=Math.ceil(h/2);
      const low=pixel.getContext('2d'),ctx=canvas.getContext('2d');
      if(!low||!ctx)throw Error('City Square canvas unavailable');
      // Paint on a coherent native-style pixel grid before nearest enlargement;
      // filtering a high-resolution illustration alone would retain hairlines.
      low.imageSmoothingEnabled=false;low.scale(pixel.width/w,pixel.height/h);paint(low);
      ctx.imageSmoothingEnabled=false;ctx.drawImage(pixel,0,0,w,h);
      const result=scene.textures.addCanvas(name,canvas);if(!result)throw Error('City Square texture unavailable');
      result.setFilter(G.Textures.FilterMode.NEAREST);
    }
    async function load(scene,progress) {
      const floorKey=su(id);progress?.track(floorKey);
      try {
        texture(scene,key('house-blue'),440,270,ctx=>house(ctx,440,270,false,765));
        texture(scene,key('house-red'),400,270,ctx=>house(ctx,400,270,true,456));
        texture(scene,key('house-west'),260,330,ctx=>sideHouse(ctx,260,330,false,423));
        texture(scene,key('house-east'),260,330,ctx=>{ctx.translate(260,0);ctx.scale(-1,1);sideHouse(ctx,260,330,true,497);});
        texture(scene,key('stall-blue'),212,164,ctx=>stall(ctx,false));
        texture(scene,key('stall-red'),212,164,ctx=>stall(ctx,true));
        texture(scene,key('barrel'),52,61,barrel);texture(scene,key('cart'),200,78,cart);
        texture(scene,key('lamp'),50,118,lamp);
        texture(scene,floorKey,width,height,floor);progress?.finish(floorKey);return true;
      } catch(error){progress?.resetInflight(floorKey);console.warn('[Rocket Menu] Could not prepare City Square.',error);return false;}
    }
    function place(scene) {
      if(!scene.textures.exists(su(id)))return;
      const ground=scene.add.image(0,0,su(id)).setOrigin(0,0).setDepth(0);
      rocketArenaMaterial.ground(ground,id);
      scene.rocketArenaScenery=true;
      const add=(name,x,y,foot,w,h)=>{
        const sprite=scene.add.image(x,y,key(name)).setOrigin(0,0).setDepth(4+foot/1000000);
        if(w&&h)sprite.setDisplaySize(w,h);
        rocketArenaMaterial.ground(sprite,id,[x/width,y/height,sprite.displayWidth/width,sprite.displayHeight/height]);return sprite;
      };
      for(const [name,x,y] of [['house-blue',-25,-40],['house-red',412,-34],['house-blue',809,-76],['house-red',1240,-34],['house-blue',1624,-40]])
        add(name,x,y,240);
      for(const y of [230,553,876]){add('house-west',-40,y,y+326);add('house-east',1829,y,y+326);}
      for(const p of stalls){const sx=p.w/174,sy=p.h/84;add('stall-'+p.color,p.x-20*sx,p.y-80*sy,p.y+p.h,212*sx,164*sy);}
      for(const p of barrels)add('barrel',p.x-26,p.y-44,p.y+15);
      for(const p of carts){const sx=p.w/174,sy=p.h/57;add('cart',p.x-2*sx,p.y-18*sy,p.y+p.h,200*sx,78*sy);}
      for(const p of lamps)add('lamp',p.x-25,p.y-108,p.y+7);
      scene.events.once('shutdown',()=>{scene.rocketArenaScenery=false;});
    }
    return Object.freeze({id,width,height,stage,combat,load,place});
  }
  function patch(source) {
    const once=(before,after)=>{const parts=source.split(before);if(parts.length!==2)throw Error('Unsupported City Square anchor: '+before);source=parts.join(after);};
    once('function cu(e){','function cu(e){if(e===arenaCitySquare.id)return arenaCitySquare.stage;');
    once('function Pa(e){','function Pa(e){if(e===arenaCitySquare.id)return arenaCitySquare.combat;');
    once('function K(e){','function K(e){if(e===arenaCitySquare.stage.labelKey)return "City Square";');
    once('async function pH(e,t,n){','async function pH(e,t,n){if(t===arenaCitySquare.id){const ready=await arenaCitySquare.load(e,n);hH(e,ai(`vfx/fire/stat_down_tag.png`),`stat-down`);return ready}');
    once('placeGround(e){','placeGround(e){if(e===arenaCitySquare.id){if(!this.groundPlaced&&this.alive&&this.textures.exists(su(e))){this.groundPlaced=true;arenaCitySquare.place(this)}return}');
    return 'const arenaCitySquare=('+createArenaCitySquare.toString()+')();globalThis.arenaCitySquare=arenaCitySquare;\n'+source;
  }
  const api=Object.freeze({patch});globalThis.ArenaCitySquareAdapter=api;
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})();
