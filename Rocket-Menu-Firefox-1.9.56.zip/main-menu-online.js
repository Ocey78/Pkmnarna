(() => {
  'use strict';

  function createArenaMainMenuOnline() {
    const icons = new Map(), pending = new WeakSet(), lists = new WeakMap(), joins = new WeakMap();
    // Indices 0–8 are owned by the native menu (4 opens the room browser).
    const rows = {
      home:[11,12,2,7,8,3], offlineHome:[12,2,7,8,3],
      singleplayer:[0,1,5,6,14,13], online:[10,4,13], bosses:[15,16,17,13]
    };

    function entries(onlineAvailable, section) {
      if (section === 'singleplayer') return rows.singleplayer;
      if (section === 'bosses') return rows.bosses;
      if (section === 'online' && onlineAvailable) return rows.online;
      return onlineAvailable ? rows.home : rows.offlineHome;
    }

    function firstCursor(scene) {
      const visible = entries(scene.onlineMenu, scene.rocketSection);
      return visible.includes(scene.cursor) ? scene.cursor : visible[0];
    }

    function changeSection(scene, next) {
      const previous = scene.rocketSection;
      scene.rocketSection = next;
      scene.pressed = -1;
      scene.cursor = next === 'home' ? (previous === 'online' ? 11 : 12) : next === 'singleplayer' && previous === 'bosses' ? 14 : entries(scene.onlineMenu,next)[0];
      // Repaint only the menu buttons. The exhibition world and its actors
      // remain mounted, with their exact positions and current moves.
      scene.layout();
      scene.root.querySelector('button[data-index="' + scene.cursor + '"]')?.focus({preventScroll:true});
    }

    function pagePlan(width, height, onlineAvailable, section) {
      const home = SX(width,height,onlineAvailable,'home');
      if (section === 'home') return home;
      const page = SX(width,height,onlineAvailable,section);
      page.ring = home.ring;
      page.tag = home.tag;
      return page;
    }

    function icon(kind) {
      if (icons.has(kind)) return icons.get(kind);
      const canvas = document.createElement('canvas');
      canvas.width = canvas.height = 20;
      const ctx = canvas.getContext('2d');
      const pixel = (x,y,w,h,color) => {ctx.fillStyle=color;ctx.fillRect(x,y,w,h);};
      if (kind===8) {
        pixel(7,1,6,1,'#111626');pixel(6,2,8,6,'#111626');pixel(7,8,6,2,'#111626');
        pixel(7,2,6,5,'#f4f5fa');pixel(8,7,4,2,'#d5dce7');
        pixel(6,11,8,1,'#111626');pixel(3,12,14,2,'#111626');pixel(2,14,16,4,'#111626');
        pixel(6,12,8,1,'#f4f5fa');pixel(4,13,12,2,'#f4f5fa');pixel(3,15,14,2,'#d5dce7');
        const value=canvas.toDataURL('image/png');icons.set(kind,value);return value;
      }
      if (kind===13) {
        pixel(8,3,2,14,'#152137');pixel(6,5,2,10,'#152137');pixel(4,7,2,6,'#152137');
        pixel(2,9,2,2,'#152137');pixel(10,7,8,6,'#152137');
        pixel(8,5,1,10,'#d2e7ff');pixel(6,7,2,6,'#edf6ff');pixel(4,9,2,2,'#edf6ff');
        pixel(9,9,7,2,'#edf6ff');
        const value=canvas.toDataURL('image/png');icons.set(kind,value);return value;
      }
      const widths = [0,6,12,14,16,16,18,18,18,18,18,18,18,18,16,16,14,12,6,0];
      const cap = kind===14 || kind===15 ? '#25735a' : kind===16 ? '#458bcf' : kind===17 ? '#9c6bc1' : kind===10 ? '#7944bb' : kind===12 ? '#3678ca' : '#e24a51';
      for (let y=1;y<19;y++) {
        const width=widths[y],x=(20-width)/2;
        pixel(x,y,width,1,'#111626');
        if (width>2) pixel(x+1,y,width-2,1,y<9?cap:'#e3e8ee');
      }
      pixel(2,9,16,2,'#242437');
      pixel(4,12,2,3,'#ffffff');pixel(6,15,7,1,'#ffffff');
      if (kind===17) {
        pixel(5,3,2,3,'#e9d9f5');pixel(13,3,2,3,'#e9d9f5');pixel(7,4,6,2,'#c6a3e3');pixel(9,3,2,1,'#faf0ff');
      } else if (kind===16) {
        pixel(11,3,4,5,'#dd657c');pixel(6,4,3,3,'#b6edff');pixel(12,4,2,3,'#ffd3df');
      } else if (kind===14 || kind===15) {
        pixel(5,3,2,5,'#efcf66');pixel(13,3,2,5,'#efcf66');
        pixel(7,3,6,1,'#efcf66');pixel(5,6,10,2,'#efcf66');
        pixel(9,3,2,3,'#fff1a2');
      } else if (kind===10) {
        pixel(3,5,4,3,'#ec7dac');pixel(13,5,4,3,'#ec7dac');
        pixel(7,4,1,4,'#ffffff');pixel(12,4,1,4,'#ffffff');
        pixel(8,5,1,1,'#ffffff');pixel(11,5,1,1,'#ffffff');pixel(9,6,2,1,'#ffffff');
      } else if (kind===12) {
        pixel(4,5,2,3,'#f2545e');pixel(5,3,2,3,'#ff6b70');
        pixel(14,5,2,3,'#d9404a');pixel(13,3,2,3,'#f2545e');
        pixel(8,3,4,1,'#92c8f4');
      } else pixel(5,4,5,1,'#ffa5a3');
      pixel(7,7,6,6,'#242437');
      pixel(8,8,4,4,'#ffffff');pixel(9,9,2,2,'#d5dce7');
      const value=canvas.toDataURL('image/png');icons.set(kind,value);return value;
    }

    function list(controller, rooms) {
      lists.set(controller, {request:controller.lobbyRequest, rooms});
      return rooms;
    }
    function confirmed(controller) {
      const attempt=joins.get(controller);
      if (attempt) clearTimeout(attempt.timer);
      joins.delete(controller);
    }
    function failed(controller, reason) {
      if (!joins.has(controller)) return false;
      confirmed(controller);
      if (!controller.active || controller.joinedTracked || controller.mode!=='room' ||
          reason==='paused' || reason==='replaced') return false;
      controller.leaveTo('lobby', {arenaQuickOnline:true,arenaQuickCreate:true});
      return true;
    }
    function room(controller, data) {
      if (data.arenaQuickJoin===true && controller.active && !controller.client) {
        joins.set(controller, {timer:setTimeout(()=>failed(controller,'timeout'),12000)});
        controller.lifetime.own(()=>confirmed(controller));
      }
      controller.join(data);
    }
    function takeJoin(data) {
      const value=data?.arenaQuickJoin===true;
      if (value) data.arenaQuickJoin=false;
      return value;
    }
    async function quick(controller, createOnly=false) {
      if (!controller?.active || pending.has(controller)) return;
      pending.add(controller);
      let section, buttons=[], status, request;
      const current=()=>controller.active && controller.mode==='lobby' &&
        controller.lobbyRequest===request && !controller.pausedService;
      try {
        // Render the ordinary lobby first, so errors and Back keep their native
        // behavior. A navigation/refresh while it loads cancels this one-shot.
        const loading=controller.showLobby(); request=controller.lobbyRequest;
        await loading;
        if (!current()) return;
        section=ZD().querySelector('[data-screen="lobby"]');
        if (section) {
          section.setAttribute('aria-busy','true');
          for (const button of section.querySelectorAll('button')) {
            if (button.dataset.action==='back' || button.disabled) continue;
            buttons.push(button);button.disabled=true;
          }
          status=document.createElement('p');
          status.className='hint';status.dataset.quickOnlineStatus='';
          status.setAttribute('role','status');status.textContent='Finding a public room…';
          section.prepend(status);
        }
        const listed=lists.get(controller);
        const candidate=!createOnly && listed?.request===request && listed.rooms.find(entry=>
          entry && typeof entry.code==='string' && Dw(entry.code) &&
          Number.isSafeInteger(entry.players) && entry.players>=0 && entry.players<2 &&
          (entry.visibility===undefined || entry.visibility==='public') &&
          (entry.mode===undefined || entry.mode==='duel') &&
          !['in_battle','fight','countdown','result','started','closed'].includes(entry.state));
        if (candidate) {
          if (status) status.textContent='Joining public room…';
          Ul('online_join_attempt',{join_source:'listed'});
          try {
            const response=await fetch(VC(`/rooms/${candidate.code}/claim`),{
              method:'POST',signal:AbortSignal.any([controller.abort.signal,AbortSignal.timeout(8000)])});
            if (!current()) return;
            if (response.ok) {
              controller.scene.scene.start('room',{
                code:candidate.code,key:null,source:'listed',arenaQuickJoin:true});
              return;
            }
            Ul('online_join_error',{join_source:'listed',error_code:response.status});
            if (response.status===503) {
              await controller.showLobby({error:'Online is paused. Try again later.'});
              return;
            }
          } catch {
            if (!current()) return;
            Ul('online_join_error',{join_source:'listed',error_code:'request_failed'});
          }
        }
        if (!current()) return;
        if (status) status.textContent='Creating public room…';
        // Exactly the normal Create dialog's generated name and wire values.
        await controller.createRoom(xr(),'public','duel');
      } catch {
        if (current())
          await controller.showLobby({error:'Unable to create room. Try again.'});
      } finally {
        pending.delete(controller);
        section?.removeAttribute('aria-busy');
        section?.querySelector('[data-quick-online-status]')?.remove();
        for (const button of buttons) button.disabled=false;
      }
    }
    function takeQuick(data) {
      if (data?.arenaQuickOnline !== true) return false;
      // Phaser retains scene data when a scene is started again without data.
      // Consume this request before any async work, including a cancelled attempt.
      data.arenaQuickOnline = false;
      const createOnly=data.arenaQuickCreate===true;
      data.arenaQuickCreate=false;
      return createOnly?'create':true;
    }
    function again(controller) {
      if (!controller?.active || !controller.result || pending.has(controller)) return;
      pending.add(controller);
      controller.leaveTo('lobby', {arenaQuickOnline:true});
    }
    return {icon,quick,takeQuick,again,list,room,takeJoin,confirmed,failed,entries,firstCursor,changeSection,pagePlan};
  }

  function patch(source) {
    if (source.includes('const arenaMainMenuOnline=')) throw Error('Main menu online actions already applied.');
    const replace=(before,after)=>{
      const parts=source.split(before);
      if(parts.length!==2)throw Error('Unsupported main menu online anchor: '+before.slice(0,70));
      source=parts.join(after);
    };
    replace('function WY(e){return[0,1,5,6,2,7,...e?[4]:[]]}',
      'function WY(e,page){return arenaMainMenuOnline.entries(e,page)}');
    replace('function GY(e){return[...WY(e),3]}', 'function GY(e,page){return WY(e,page)}');
    replace('function qY(e,t,n){let r=GY(n)', 'function qY(e,t,n,page){let r=GY(n,page)');
    replace('function SX(e,t,n=!1){', 'function SX(e,t,n=!1,page="home"){');
    replace('c=r===`pc`&&a>=3,l=n?7:6,u=', 'c=r===`pc`&&a>=3,l=WY(n,page).length,u=');
    replace('f&&t<xX(o,7,d,!0,u)', 'f&&t<xX(o,l,d,!0,u)');
    replace('!i&&t<xX(o,7,d,!1,u)', '!i&&t<xX(o,l,d,!1,u)');
    replace('let b={0:v[0],1:v[1],5:v[2],6:v[3],2:v[4],7:v[5],...n?{4:v[6]}:{}},x=v[l-1]',
      'let b=Object.fromEntries(WY(n,page).map((e,t)=>[e,v[t]])),x=v[l-1]');
    replace('this.cursor=0,this.onlineMenu=VY(),this.sharedHome=',
      'this.onlineMenu=VY(),this.cursor=arenaMainMenuOnline.firstCursor(this),this.sharedHome=');
    replace('constructor(){super(`menu`)}async create(){',
      'rocketSection="home";constructor(){super(`menu`)}async create(){');
    replace('${e.width}x${e.height}|${+!!this.onlineMenu}',
      '${e.width}x${e.height}|${+!!this.onlineMenu}|${this.rocketSection}');
    replace('this.planCache=SX(e.width,e.height,this.onlineMenu)',
      'this.planCache=arenaMainMenuOnline.pagePlan(e.width,e.height,this.onlineMenu,this.rocketSection)');
    replace('let n=e.rowFor[Number(t.dataset.index)];n&&zQ(t,n)',
      'let n=e.rowFor[Number(t.dataset.index)];t.hidden=!n,t.style.display=n?"":"none",n&&zQ(t,n)');
    replace('describe(e,t){', 'describe(e,t){if(e===17)return"MEWTWO AT THE PSYCHIC CAVE";if(e===14)return"CHOOSE A BOSS ENCOUNTER";if(e===15)return"RAYQUAZA AT SKY PILLAR";if(e===16)return"LATIOS AND LATIAS AT THE NIGHT CITY SQUARE";if(e===10)return"JOIN OR CREATE A PUBLIC 2-PLAYER ROOM";if(e===11)return"ONLINE MATCHES";if(e===12)return"SINGLEPLAYER MODES";if(e===13)return"GO BACK";if(e===8)return"PROFILE AND STATISTICS";');
    replace('rowContent(e){', 'rowContent(e){if(e===17)return{label:"MEWTWO",tag:null};if(e===14)return{label:"BOSS RUSH",tag:null};if(e===15)return{label:"RAYQUAZA",tag:null};if(e===16)return{label:"LATIOS & LATIAS",tag:null};if(e===3)return{label:K(`menu.entries.settings`),tag:null};if(e===8)return{label:"PROFILE",tag:null};if(e===10)return{label:"QUICK MATCH",tag:null};if(e===11)return{label:"ONLINE",tag:null};if(e===12)return{label:"SINGLEPLAYER",tag:null};if(e===13)return{label:"BACK",tag:null};');
    replace('case 0:return{label:K(`menu.entries.quick`),tag:null,coins:null,dot:!1,shake:!1}',
      'case 0:return{label:"QUICK MATCH",tag:null,coins:null,dot:!1,shake:!1}');
    replace('case 5:return{label:this.storyEntry.label,tag:null', 'case 5:return{label:"STORY MODE",tag:null');
    replace('case 4:return{label:K(`menu.entries.online`),tag:`LIVE`', 'case 4:return{label:"FIND ROOM",tag:null');
    replace('${this.rowMarkup(0,`is-primary`,``,``)}',
      '${this.rowMarkup(11,`is-primary`,``,`Online`)}\n          ${this.rowMarkup(12,`is-primary`,``,`Singleplayer`)}\n          ${this.rowMarkup(10,`is-primary`,``,`Quick Match`)}\n          ${this.rowMarkup(0,`is-primary`,``,``)}');
    replace('${this.rowMarkup(4,`menu-soon`,`<i class="menu-live menu-badge" hidden></i>`,`Online lobby`)}',
      '${this.rowMarkup(8,``,``,`Profile`)}\n          ${this.rowMarkup(3,``,``,K(`menu.settingsTitle`))}\n          ${this.rowMarkup(4,``,``,`Find Room`)}\n          ${this.rowMarkup(14,``,``,`Boss Rush`)}\n          ${this.rowMarkup(15,``,``,`Rayquaza`)}\n          ${this.rowMarkup(16,``,``,`Latios and Latias`)}\n          ${this.rowMarkup(17,``,``,`Mewtwo`)}\n          ${this.rowMarkup(13,``,``,`Back`)}');
    replace('${e===4&&!this.onlineMenu?` hidden`:``}', '${WY(this.onlineMenu,this.rocketSection).includes(e)?``:` hidden`}');
    replace('<button type="button" class="menu-btn menu-gear" data-index="3" aria-label="${K(`menu.settingsTitle`)}"><span class="menu-face"><canvas class="menu-bar" aria-hidden="true"></canvas><img class="menu-icon" alt="" aria-hidden="true" draggable="false"></span></button>', '');
    replace('i!==4&&e.setAttribute(`aria-label`,`${o.label}. ${this.describe(i,n)}`)',
      'i===3?e.setAttribute(`aria-label`,o.label):i!==4&&e.setAttribute(`aria-label`,`${o.label}. ${this.describe(i,n)}`)');
    replace('n.src=ai(`ui/menu/icons/menu_icon_${jQ[t]}.png`)',
      'n.src=[0,8,10,12,13,14,15,16,17].includes(t)?arenaMainMenuOnline.icon(t):ai(`ui/menu/icons/menu_icon_${jQ[t===11?4:t]}.png`)');
    replace('pZ(n,r,t,i,this.cursor===0,a)', 'pZ(n,r,t,i,[0,10,11,12].includes(this.cursor),a)');
    replace('onKey=e=>{if(DC()||!this.alive||IE())return;', 'onKey=e=>{if(DC()||!this.alive||IE()||document.querySelector("dialog[open]"))return;');
    replace('let n=e.key.toLowerCase();n!==`escape`&&n!==`b`&&',
      'let n=e.key.toLowerCase();if((n==="escape"||n==="b")&&this.rocketSection!=="home"&&!e.repeat){e.preventDefault();this.cursor=13;this.confirm();return}n!==`escape`&&n!==`b`&&');
    replace('qY(this.cursor,n===`arrowup`||n===`w`?-1:1,this.onlineMenu)',
      'qY(this.cursor,n===`arrowup`||n===`w`?-1:1,this.onlineMenu,this.rocketSection)');
    replace('confirm(){if(this.cursor===5&&!this.leaving)',
      'confirm(){if(this.leaving)return;if([11,12,13,14].includes(this.cursor)){jZ();arenaMainMenuOnline.changeSection(this,this.cursor===11?"online":this.cursor===12?"singleplayer":this.cursor===14?"bosses":this.rocketSection==="bosses"?"singleplayer":"home");return}if(this.cursor===15){jZ();arenaBossRush.start(this);return}if(this.cursor===16){jZ();arenaEonBoss.start(this);return}if(this.cursor===17){jZ();arenaMewtwoBoss.start(this);return}if(this.cursor===10&&this.onlineMenu){jZ(),this.leave(`lobby`,{arenaQuickOnline:true});return}if(this.cursor===5&&!this.leaving)');
    replace('if(this.cursor===4&&this.onlineMenu){this.root?.querySelector(`.menu-soon`)?.click();return}',
      'if(this.cursor===4&&this.onlineMenu){jZ();this.leave(`lobby`);return}');
    replace('if(this.cursor===8&&!this.leaving){jZ(),this.openSavePage();return}',
      'if(this.cursor===8&&!this.leaving){jZ(),globalThis.ArenaRocketProfile.open();return}');
    replace('gO(this,e?.missing)', 'gO(this,e?.missing,arenaMainMenuOnline.takeQuick(e))');
    replace('function gO(e,t){', 'function gO(e,t,n=false){');
    replace('hO.showLobby(t?{code:t,error:kw.roomNotFound}:void 0)',
      'n?arenaMainMenuOnline.quick(hO,n==="create"):hO.showLobby(t?{code:t,error:kw.roomNotFound}:void 0)');
    replace('nO(ZD(),n,{create:()=>this.openCreate()',
      'nO(ZD(),arenaMainMenuOnline.list(this,n),{create:()=>this.openCreate()');
    replace('source:e?.source??`invite`})',
      'source:e?.source??`invite`,arenaQuickJoin:arenaMainMenuOnline.takeJoin(e)})');
    replace('hO.scene=e,hO.join(t)', 'hO.scene=e,arenaMainMenuOnline.room(hO,t)');
    replace('end(e,t){if(!this.active)return;',
      'end(e,t){if(arenaMainMenuOnline.failed(this,t))return;if(!this.active)return;');
    replace('e.t===`room`){this.room=e,',
      'e.t===`room`){arenaMainMenuOnline.confirmed(this);this.room=e,');
    replace('leaveTo(e){', 'leaveTo(e,n){');
    replace('mi.menu(),t.scene.start(e)}clearTimers()', 'mi.menu(),t.scene.start(e,n)}clearTimers()');
    replace('<button type="button" class="px-btn" data-action="back-lobby">BACK TO LOBBY</button>',
      '<button type="button" class="px-btn" data-action="rocket-play-again">PLAY AGAIN</button>\n              <button type="button" class="px-btn" data-action="back-lobby">BACK TO LOBBY</button>');
    replace('t===`pause`&&this.pause(),t===`rematch`',
      't==="rocket-play-again"&&arenaMainMenuOnline.again(this),t===`pause`&&this.pause(),t===`rematch`');
    // The profile owns the history entry. Keep its replay API intact.
    replace('e.appendChild(i),arenaMatchHistory.mount(i),i.querySelector(`[data-action="create-open"]`)',
      'e.appendChild(i),i.querySelector(`[data-action="create-open"]`)');
    return 'const arenaMainMenuOnline=('+createArenaMainMenuOnline.toString()+')();\n'+source;
  }
  globalThis.ArenaMainMenuOnlineAdapter=Object.freeze({patch});
  if(typeof module!=='undefined'&&module.exports)module.exports={patch,createArenaMainMenuOnline};
})();
