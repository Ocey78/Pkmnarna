// Private Rayquaza encounter choreography; ordinary worlds never call this runtime.
(() => {
  'use strict';
  function createRocketBossAttacks(){
    const worlds=new WeakMap(),kinds=['dash','breath','plasma','sky'],pace=.66;
    const moves={dash:'dragon-claw',breath:'dragon-pulse',plasma:'hyper-beam',sky:'air-slash',meteor:'dragon-pulse'};
    const clamp=(value,min,max)=>Math.max(min,Math.min(max,value));
    const point=body=>({x:body.x,y:body.y});
    const center=body=>arenaBossRush.center(body);
    // Times use one multiplier; active pulse counts stay stable as cadence rises.
    const tempo=state=>(state.enraged?.62:1)/state.difficulty.speed;
    function random(state){
      let seed=state.rng;seed^=seed<<13;seed^=seed>>>17;seed^=seed<<5;
      state.rng=seed>>>0;return state.rng/4294967296;
    }
    function choose(world,state){
      const distance=Math.hypot(world.player.x-world.opponent.x,world.player.y-world.opponent.y);
      const weights={dash:distance>650?3.1:1.5,breath:distance<500?3:distance>900?.65:1.7,
        plasma:distance>450?2.6:1.35,sky:1.2};
      const previous=state.history[state.history.length-1],older=state.history[state.history.length-2];
      const available=kinds.filter(kind=>kind!==previous);
      // Weighted variety, with a hard age limit so an unlucky roll cannot
      // remove an entire move from the encounter. Never repeat back-to-back.
      const oldest=Math.max(...available.map(kind=>state.turn-state.lastUsed[kind]));
      const choices=oldest>=6?available.filter(kind=>state.turn-state.lastUsed[kind]===oldest):available;
      const weight=kind=>weights[kind]*(kind===older?.45:1)*(1+Math.min(4,state.turn-state.lastUsed[kind])*.18);
      let roll=random(state)*choices.reduce((sum,kind)=>sum+weight(kind),0),chosen=choices[choices.length-1];
      for(const kind of choices){roll-=weight(kind);if(roll<=0){chosen=kind;break;}}
      state.lastUsed[chosen]=state.turn++;state.history.push(chosen);if(state.history.length>2)state.history.shift();
      return chosen;
    }
    function observeTarget(world,state,dt){
      const target=world.player,previous=state.target;
      const dx=target.x-previous.x,dy=target.y-previous.y;
      if(previous.species===target.speciesId&&Math.hypot(dx,dy)<80){
        state.velocity.x=state.velocity.x*.6+dx/Math.max(.001,dt/1000)*.4;
        state.velocity.y=state.velocity.y*.6+dy/Math.max(.001,dt/1000)*.4;
      }else state.velocity.x=state.velocity.y=0;
      state.target={...point(target),species:target.speciesId};
    }
    function aimAt(world,state,lead=0){
      const target=world.player,v=state.velocity,speed=Math.hypot(v.x,v.y);
      const seconds=Math.min(lead,64/Math.max(1,speed));
      return constrained(world,{x:target.x+v.x*seconds,y:target.y+v.y*seconds},target.radius);
    }
    function attack(kind='idle',phase='idle',durationMs=800){
      return {kind,phase,durationMs:durationMs*(phase==='idle'?.4:pace),elapsedMs:0,progress:0,mega:false,enraged:false,actorId:'opponent',facing:0,
        from:{x:0,y:0},to:{x:0,y:0},aim:{x:0,y:0},radius:0,width:0,range:0,halfAngle:0,
        pass:1,maxPasses:1,tempo:1,flyHeight:0,bodyStretch:1,move:moves[kind]||moves.dash,damageFactor:1,ultimate:false};
    }
    function reset(world){
      const boss=world.opponent;
      const state={lastTick:world.tick,clock:0,turn:0,history:[],lastUsed:{dash:-1,breath:-1,plasma:-1,sky:-1},
        rng:((Number(world.seed)||1)^0x71a9c35d)>>>0||1,target:{...point(world.player),species:world.player.speciesId},velocity:{x:0,y:0},
        nextId:1,species:boss?.speciesId,enraged:false,difficulty:world.bossDifficulty||arenaBossDifficulty.get('rayquaza'),
        attack:attack(),projectiles:[],meteors:[],impacts:[],hits:new Set(),nextShot:0,nextTick:0,nextMeteor:0};
      state.attack.from=state.attack.to=point(boss);state.attack.mega=boss.speciesId==='rayquazamega';
      state.attack.tempo=tempo(state);state.attack.durationMs*=tempo(state);
      worlds.set(world,state);return state;
    }
    function init(world){return worlds.get(world)||reset(world);}
    function phase(state,name,duration){
      state.attack.phase=name;state.attack.elapsedMs=0;state.attack.durationMs=duration*(name==='recover'?.45:pace)*tempo(state);state.attack.progress=0;
      if(name==='windup')state.attack.durationMs=Math.max(250,state.attack.durationMs);
    }
    function cancel(world,state,delay=700){
      if(state.attack.flyHeight>0){
        const boss=world.opponent,p=Ia(boss.x,boss.y,boss.radius,world.combat,boss.x,boss.y);
        boss.x=p.x;boss.y=p.y;
      }
      state.attack=attack('idle','idle',delay);state.attack.mega=world.opponent.speciesId==='rayquazamega';
      state.attack.enraged=state.enraged;state.attack.tempo=tempo(state);state.attack.durationMs*=tempo(state);
      state.attack.from=state.attack.to=point(world.opponent);
      state.hits.clear();state.projectiles.length=state.meteors.length=state.impacts.length=0;
    }
    function invulnerable(world){
      const a=worlds.get(world)?.attack;
      return !!(a&&a.kind==='sky'&&['rise','hover','fall'].includes(a.phase)&&a.flyHeight>45);
    }
    function constrained(world,p,radius){return Ia(p.x,p.y,radius,world.combat,p.x,p.y);}
    function blocked(world,from,to,radius){
      return !!(world.combat?.rocks?.length&&typeof arenaReferenceArenas!=='undefined'&&
        arenaReferenceArenas.blocksShot(world.combat.rocks,from.x,from.y,{...to,radius}));
    }
    function impact(state,kind,p,radius,lifeMs=420){
      state.impacts.push({id:state.nextId++,kind,x:p.x,y:p.y,radius,ageMs:0,lifeMs,mega:state.attack.mega,enraged:state.enraged});
      if(state.impacts.length>24)state.impacts.shift();
    }
    function hit(world,state,kind,factor=1,ultimate=false){
      const target=world.player,boss=world.opponent;
      if(world.phase!=='fight'||target.hp<=0||boss.hp<=0||target.iframeMs>0)return false;
      if(target.protectMs>0){
        world.events.push({type:'block',target:target.id,x:target.x,y:target.y});return true;
      }
      const id=moves[kind]||moves.dash;
      const amount=Math.max(0,Math.round(world.damage(boss,target,id,ultimate)*factor*state.difficulty.damage));
      world.landHit(boss,target,id,ultimate,amount);
      return true;
    }
    function idle(world,state,delay=650){
      state.attack=attack('idle','idle',delay*(.86+random(state)*.28));state.attack.mega=world.opponent.speciesId==='rayquazamega';
      state.attack.enraged=state.enraged;state.attack.tempo=tempo(state);state.attack.durationMs*=tempo(state);
      state.attack.from=state.attack.to=point(world.opponent);state.hits.clear();
    }
    function dashAim(world,state,pass){
      const boss=world.opponent,target=world.player,c=world.combat,r=boss.radius+24;
      const left=(c?.left??0)+r,right=(c?.right??Ca)-r;
      const top=(c?.top??0)+r,bottom=(c?.bottom??wa)-r-90;
      const a=state.attack,from=point(boss),aim=aimAt(world,state,a.variant==='cutoff'?.18:0);
      const dx=aim.x-from.x,dy=aim.y-from.y;
      // Choose the far edge, then aim through the player's lane. Every pass
      // traverses the platform instead of ending immediately at the near rim.
      let destination;
      if(a.variant==='crosscut'&&pass%2===0){
        const edge=from.y>(top+bottom)/2?top:bottom,slope=Math.abs(dy)>40?dx/dy:0;
        destination={x:clamp(from.x+(edge-from.y)*slope,left,right),y:edge};
      }else{
        const edge=from.x>(left+right)/2?left:right,slope=Math.abs(dx)>60?dy/dx:0;
        destination={x:edge,y:clamp(from.y+(edge-from.x)*slope,top,bottom)};
      }
      const to=constrained(world,destination,boss.radius);
      a.from=from;a.to=to;a.aim=aim;a.pass=pass;
      a.facing=Math.atan2(to.y-from.y,to.x-from.x);a.radius=(boss.radius+10)*(a.enraged?1.4:1)*state.difficulty.size;a.width=2*a.radius;
      a.range=Math.hypot(to.x-from.x,to.y-from.y);a.damageFactor=1.12;
      boss.facing=a.facing;state.hits.clear();phase(state,'windup',pass>1?360:a.mega?620:820);
    }
    function mouth(world,a){
      const p=center(world.opponent),reach=world.opponent.radius*.65;
      return{x:p.x+Math.cos(a.facing)*reach,y:p.y+Math.sin(a.facing)*reach};
    }
    function begin(world,state){
      const kind=choose(world,state),boss=world.opponent,target=world.player;
      state.attack=attack(kind,'windup',800);const a=state.attack;
      a.mega=boss.speciesId==='rayquazamega';a.from=point(boss);a.to=a.aim=point(target);
      a.enraged=state.enraged;a.tempo=tempo(state);a.maxPasses=a.enraged?4:a.mega?2:1;
      a.facing=Math.atan2(target.y-boss.y,target.x-boss.x);boss.facing=a.facing;
      state.hits.clear();state.nextShot=state.nextTick=state.nextMeteor=0;
      if(kind==='dash'){
        a.variant=['pursuit','cutoff','crosscut'][Math.floor(random(state)*3)];dashAim(world,state,1);return;
      }
      if(kind==='breath'){
        a.range=(a.mega?970:740)*(a.enraged?1.2:1)*state.difficulty.size;a.halfAngle=(a.mega?.29:.18)*(a.enraged?1.25:1);a.width=2*a.range*Math.sin(a.halfAngle);
        a.damageFactor=a.mega?.25:.23;a.hitIntervalMs=200*pace*a.tempo;
        a.aim=center(target);a.facing=Math.atan2(a.aim.y-center(boss).y,a.aim.x-center(boss).x);a.from=mouth(world,a);
        const sweep=random(state)<.55?(random(state)<.5?-.22:.22):0;
        a.variant=sweep?'sweep':'focused';a.sweepFrom=a.facing-sweep/2;a.sweepTo=a.facing+sweep/2;
        a.facing=a.sweepFrom;a.from=mouth(world,a);
        a.to={x:a.from.x+Math.cos(a.facing)*a.range,y:a.from.y+Math.sin(a.facing)*a.range};
        phase(state,'windup',a.mega?900:1050);
      }else if(kind==='plasma'){
        a.variant=random(state)<.5?'cross':'rotated';
        const led=aimAt(world,state,a.variant==='rotated'?.16:0),targetCenter=center(target);
        a.aim={x:targetCenter.x+led.x-target.x,y:targetCenter.y+led.y-target.y};
        a.facing=Math.atan2(a.aim.y-center(boss).y,a.aim.x-center(boss).x);
        const rotation=a.mega&&a.variant==='rotated'?(random(state)<.5?-1:1)*Math.PI/8:0;
        const order=random(state)<.5?[0,1,2,3]:[0,3,2,1];
        a.shotAngles=(a.mega?order:[0]).map(index=>a.facing+rotation+index*Math.PI/2);
        a.facing=a.shotAngles[0];
        a.from=mouth(world,a);a.to={...a.aim};a.radius=44*(a.enraged?1.4:1)*state.difficulty.size;a.damageFactor=1.05;a.shotIntervalMs=170*pace*a.tempo;
        phase(state,'windup',a.mega?700:900);
      }else{
        a.radius=(a.mega?235:185)*(a.enraged?1.4:1)*state.difficulty.size;a.ultimate=true;a.damageFactor=1;a.from=point(boss);
        a.meteorIntervalMs=240*pace*a.tempo;
        a.variant=['ring','line','trail'][Math.floor(random(state)*3)];a.patternAngle=random(state)*Math.PI*2;
        a.to=constrained(world,point(target),boss.radius);phase(state,'windup',a.mega?800:950);
      }
    }
    function emitPlasma(world,state,index){
      const a=state.attack,angle=a.shotAngles?.[index]??a.facing+(a.mega?index*Math.PI/2:0),speed=(a.mega?850:700)*(a.enraged?1.35:1)*state.difficulty.speed;
      const origin=mouth(world,{...a,facing:angle});
      state.projectiles.push({id:state.nextId++,kind:'plasma',x:origin.x,y:origin.y,
        vx:Math.cos(angle)*speed,vy:Math.sin(angle)*speed,radius:a.radius,mega:a.mega,enraged:a.enraged,
        ageMs:0,lifeMs:2600/state.difficulty.speed,move:moves.plasma,damageFactor:1.05,ultimate:false});
    }
    function emitMeteor(world,state){
      const a=state.attack,index=state.nextMeteor,radius=64*(state.enraged?1.4:1)*state.difficulty.size;
      let destination;
      if(a.variant==='line'){
        const offset=(index-2.5)*radius*2.15;
        destination={x:a.aim.x+Math.cos(a.patternAngle)*offset,y:a.aim.y+Math.sin(a.patternAngle)*offset};
      }else if(a.variant==='trail')destination=aimAt(world,state,index%2?.12:0);
      else{
        const angle=a.patternAngle+index*Math.PI/3,offset=radius*2.7;
        destination={x:a.aim.x+Math.cos(angle)*offset,y:a.aim.y+Math.sin(angle)*offset};
      }
      const p=constrained(world,destination,radius);
      state.meteors.push({id:state.nextId++,x:p.x,y:p.y,radius,mega:a.mega,enraged:state.enraged,ageMs:0,warningMs:Math.max(250,1100*pace*tempo(state)),fallMs:350*pace*tempo(state),
        impactMs:360,hit:false,move:moves.meteor,damageFactor:.52,ultimate:false});
    }
    function effects(world,state,dt){
      const target=world.player;
      state.impacts=state.impacts.filter(effect=>(effect.ageMs+=dt)<effect.lifeMs);
      const shots=[];
      for(const shot of state.projectiles){
        shot.ageMs+=dt;if(shot.ageMs>=shot.lifeMs)continue;
        const from=point(shot),to={x:shot.x+shot.vx*dt/1000,y:shot.y+shot.vy*dt/1000};
        if(blocked(world,from,to,shot.radius)){impact(state,'plasma',to,shot.radius);continue;}
        shot.x=to.x;shot.y=to.y;
        if(shot.x<-60||shot.y<-60||shot.x>Ca+60||shot.y>wa+60)continue;
        const contact=oc(from,to,center(target),target.radius+shot.radius);
        if(contact!==null&&hit(world,state,'plasma',shot.damageFactor)){
          impact(state,'plasma',{x:from.x+(to.x-from.x)*contact,y:from.y+(to.y-from.y)*contact},shot.radius);continue;
        }
        shots.push(shot);
      }
      state.projectiles=shots;
      state.meteors=state.meteors.filter(meteor=>{
        meteor.ageMs+=dt;const due=meteor.warningMs+meteor.fallMs;
        if(!meteor.hit&&meteor.ageMs>=due){
          meteor.hit=true;impact(state,'meteor',meteor,meteor.radius,450);
          if(Math.hypot(target.x-meteor.x,target.y-meteor.y)<=meteor.radius+target.radius)
            hit(world,state,'meteor',meteor.damageFactor);
        }
        return meteor.ageMs<due+meteor.impactMs;
      });
    }
    function step(world){
      const state=init(world),boss=world.opponent;
      const ticks=world.tick-state.lastTick;state.lastTick=world.tick;
      if(world.phase!=='fight'||boss.hp<=0){cancel(world,state);return;}
      if(state.species!==boss.speciesId){state.species=boss.speciesId;cancel(world,state,1050);}
      if(ticks<=0)return;
      const dt=Math.min(ticks*q,100);state.clock+=dt;observeTarget(world,state,dt);
      if(boss.ailment==='sleep'||boss.ailment==='freeze'||boss.recoverMs>0){cancel(world,state,450);return;}
      if(!state.enraged&&boss.hp<=boss.maxHp*.25){
        state.enraged=true;cancel(world,state);
        state.attack.phase='enrage';state.attack.durationMs=650;
      }
      effects(world,state,dt);
      const a=state.attack;a.elapsedMs+=dt;a.progress=clamp(a.elapsedMs/Math.max(1,a.durationMs),0,1);
      if(a.kind==='idle'){
        const player=world.player;boss.facing=Math.atan2(player.y-boss.y,player.x-boss.x);
        if(a.progress>=1)begin(world,state);return;
      }
      boss.facing=a.facing;
      if(a.kind==='dash'){
        if(a.phase==='windup'&&a.progress>=1){
          phase(state,'active',clamp(a.range/(a.mega?1750:1450)*1000,250,1150));a.bodyStretch=1.25;
        }else if(a.phase==='active'){
          const from=point(boss),target={x:a.from.x+(a.to.x-a.from.x)*a.progress,y:a.from.y+(a.to.y-a.from.y)*a.progress};
          const next=Ia(target.x,target.y,boss.radius,world.combat,boss.x,boss.y);boss.x=next.x;boss.y=next.y;
          if(!state.hits.has(world.player.id)&&oc(from,next,world.player,a.radius+world.player.radius)!==null&&
              hit(world,state,'dash',a.damageFactor))state.hits.add(world.player.id);
          if(a.progress>=1){a.bodyStretch=1;if(a.pass<a.maxPasses)dashAim(world,state,a.pass+1);else phase(state,'recover',850);}
        }else if(a.phase==='recover'&&a.progress>=1)idle(world,state);
      }else if(a.kind==='breath'){
        if(a.phase==='windup'&&a.progress>=1){phase(state,'active',a.mega?1500:1250);state.nextTick=0;}
        else if(a.phase==='active'){
          a.facing=a.sweepFrom+(a.sweepTo-a.sweepFrom)*a.progress;boss.facing=a.facing;
          a.from=mouth(world,a);a.to={x:a.from.x+Math.cos(a.facing)*a.range,y:a.from.y+Math.sin(a.facing)*a.range};
          if(a.elapsedMs>=state.nextTick){
            state.nextTick+=a.hitIntervalMs;const target={...center(world.player),radius:world.player.radius};
            if(xa(a.from,a.facing,a.range,a.halfAngle,target)&&!blocked(world,a.from,target,4))hit(world,state,'breath',a.damageFactor);
          }
          if(a.progress>=1)phase(state,'recover',850);
        }else if(a.phase==='recover'&&a.progress>=1)idle(world,state);
      }else if(a.kind==='plasma'){
        if(a.phase==='windup'&&a.progress>=1){phase(state,'active',a.mega?720:180);state.nextShot=0;}
        else if(a.phase==='active'){
          const count=a.mega?4:1;
          while(state.nextShot<count&&a.elapsedMs>=state.nextShot*a.shotIntervalMs)emitPlasma(world,state,state.nextShot++);
          if(a.progress>=1)phase(state,'recover',750);
        }else if(a.phase==='recover'&&a.progress>=1)idle(world,state,850);
      }else{
        if(a.phase==='windup'&&a.progress>=1)phase(state,'rise',700);
        else if(a.phase==='rise'){
          a.flyHeight=320*a.progress;
          if(a.progress>=1){phase(state,'hover',a.mega?1500:1100);state.nextMeteor=0;a.aim=point(world.player);}
        }else if(a.phase==='hover'){
          a.flyHeight=320;
          if(a.elapsedMs<a.durationMs-Math.max(250,450*pace*a.tempo))a.to=constrained(world,point(world.player),boss.radius);
          if(a.mega&&state.nextMeteor<6&&a.elapsedMs>=state.nextMeteor*a.meteorIntervalMs){emitMeteor(world,state);state.nextMeteor++;}
          if(a.progress>=1){a.from=point(boss);phase(state,'fall',a.mega?500:600);}
        }else if(a.phase==='fall'){
          a.flyHeight=320*(1-a.progress);const t=a.progress*a.progress;
          boss.x=a.from.x+(a.to.x-a.from.x)*t;boss.y=a.from.y+(a.to.y-a.from.y)*t;
          if(a.progress>=1){
            const p=constrained(world,a.to,boss.radius);boss.x=p.x;boss.y=p.y;a.flyHeight=0;
            impact(state,'crash',p,a.radius,700);
            if(Math.hypot(world.player.x-p.x,world.player.y-p.y)<=a.radius+world.player.radius)hit(world,state,'sky',1,true);
            phase(state,'impact',380);
          }
        }else if(a.phase==='impact'&&a.progress>=1)phase(state,'recover',1050);
        else if(a.phase==='recover'&&a.progress>=1)idle(world,state,900);
      }
    }
    // Read-only collision forecasts shared by the private boss runtimes. The
    // caller supplies player movement and returns null while already guarded.
    function threatProbe(world,horizonMs,predictPlayer){
      const horizon=Math.max(0,Math.min(700,horizonMs)),target=world.player;
      // damage() advances the battle RNG. Forecast its upper roll directly so
      // enabling assistance cannot change attack choices or damage rolls.
      const damage=(actor,id,ultimate=false)=>{
        const move=V(id);if(move.power<=0||move.category==='status')return 0;
        const type=Dc(move),multiplier=world.arenaTypeMultiplier(actor,type,dn(target.speciesId).types);
        if(ultimate)return ao(target.maxHp,multiplier);
        return Kt({maxHp:target.maxHp,power:move.power,attack:Ht(xc(actor,move.category),
          move.category==='physical'&&!!actor.ailment&&ot[actor.ailment]?.physicalScale<1),
          defense:Sc(target,move.category),stab:dn(actor.speciesId).types.includes(type),typeMultiplier:multiplier,
          roll:100,attackMultiplier:fc(actor.buffKind,move.category),defenseMultiplier:pc(target.buffKind,move.category)});
      };
      const disc=(origin,radius,time,bodyCenter=false)=>{
        if(time<0||time>horizon)return false;
        const p=predictPlayer(time,bodyCenter);
        return !!p&&Math.hypot(p.x-origin.x,p.y-origin.y)<=radius+target.radius&&!blocked(world,origin,p,1);
      };
      const beam=(from,to,width,time)=>{
        if(time<0||time>horizon)return false;
        const p=predictPlayer(time,true);
        return !!p&&oc(from,to,p,width/2+target.radius)!==null&&!blocked(world,from,p,1);
      };
      const sweep=(at,radius,start=0,end=horizon,bodyCenter=true)=>{
        start=Math.max(0,start);end=Math.min(horizon,end);if(start>end)return false;
        let from=at(start),previous=predictPlayer(start,bodyCenter);
        for(let time=start;time<end;){
          const next=Math.min(end,time+q),to=at(next),p=predictPlayer(next,bodyCenter);
          if(blocked(world,from,to,radius))return false;
          if(p){const prior=previous||p;
            if(oc({x:from.x-prior.x,y:from.y-prior.y},{x:to.x-p.x,y:to.y-p.y},{x:0,y:0},radius+target.radius)!==null)return true;}
          from=to;previous=p;time=next;
        }
        return false;
      };
      const projectile=(shot,start=0)=>sweep(time=>({x:shot.x+shot.vx*(time-start)/1000,y:shot.y+shot.vy*(time-start)/1000}),
        shot.radius,start,Math.min(horizon,start+Math.max(0,shot.lifeMs-shot.ageMs-q)),true);
      return{horizon,damage,disc,beam,sweep,projectile};
    }
    function autoProtectThreat(world,horizonMs,predictPlayer){
      const state=worlds.get(world),boss=world.opponent;
      if(!state||world.phase!=='fight'||boss.hp<=0||world.player.hp<=0)return false;
      const probe=threatProbe(world,horizonMs,predictPlayer),a=state.attack,left=Math.max(0,a.durationMs-a.elapsedMs);
      const dangerous=(kind,factor=1,total=1,ultimate=false)=>Math.round(probe.damage(boss,moves[kind],ultimate)*factor*state.difficulty.damage)*total>12;
      for(const shot of state.projectiles)if(dangerous('plasma',shot.damageFactor)&&probe.projectile(shot))return true;
      for(const meteor of state.meteors)if(!meteor.hit&&dangerous('meteor',meteor.damageFactor)&&
        probe.disc(meteor,meteor.radius,Math.max(0,meteor.warningMs+meteor.fallMs-meteor.ageMs)))return true;
      if(boss.ailment==='sleep'||boss.ailment==='freeze'||boss.recoverMs>0)return false;
      if(a.kind==='dash'&&['windup','active'].includes(a.phase)&&!state.hits.has(world.player.id)&&dangerous('dash',a.damageFactor)){
        const delay=a.phase==='windup'?left+q:0,duration=a.phase==='windup'?clamp(a.range/(a.mega?1750:1450)*1000,250,1150)*pace*tempo(state):a.durationMs;
        const elapsed=a.phase==='active'?a.elapsedMs:0;
        if(probe.sweep(time=>{const t=clamp((elapsed+time-delay)/duration,0,1);return{x:a.from.x+(a.to.x-a.from.x)*t,y:a.from.y+(a.to.y-a.from.y)*t};},
          a.radius,delay,delay+duration-elapsed,false))return true;
      }
      if(a.kind==='breath'&&['windup','active'].includes(a.phase)){
        const delay=a.phase==='windup'?left+q:0,duration=a.phase==='windup'?(a.mega?1500:1250)*pace*tempo(state):a.durationMs;
        const elapsed=a.phase==='active'?a.elapsedMs:0,first=a.phase==='active'?Math.max(q,state.nextTick-a.elapsedMs):delay;
        if(dangerous('breath',a.damageFactor,Math.max(1,Math.ceil((duration-elapsed)/a.hitIntervalMs))))
          for(let time=first;time<=Math.min(probe.horizon,delay+duration-elapsed);time+=a.hitIntervalMs){
            const p=predictPlayer(time,true);if(!p)continue;
            const facing=a.sweepFrom+(a.sweepTo-a.sweepFrom)*clamp((elapsed+time-delay)/duration,0,1),from=mouth(world,{...a,facing});
            if(xa(from,facing,a.range,a.halfAngle,{...p,radius:world.player.radius})&&!blocked(world,from,p,4))return true;
          }
      }
      if(a.kind==='plasma'&&['windup','active'].includes(a.phase)&&dangerous('plasma',1.05)){
        const delay=a.phase==='windup'?left+q:0,elapsed=a.phase==='active'?a.elapsedMs:0;
        for(let index=a.phase==='active'?state.nextShot:0;index<(a.mega?4:1);index++){
          const time=delay+Math.max(0,index*a.shotIntervalMs-elapsed);if(time>probe.horizon)break;
          const angle=a.shotAngles?.[index]??a.facing+index*Math.PI/2,velocity=(a.mega?850:700)*(a.enraged?1.35:1)*state.difficulty.speed;
          if(probe.projectile({...mouth(world,{...a,facing:angle}),vx:Math.cos(angle)*velocity,vy:Math.sin(angle)*velocity,
            radius:a.radius,ageMs:0,lifeMs:2600/state.difficulty.speed},time))return true;
        }
      }
      if(a.kind==='sky'&&['hover','fall'].includes(a.phase)&&dangerous('sky',1,1,true)){
        const time=left+(a.phase==='hover'?(a.mega?500:600)*pace*tempo(state):0);
        if(probe.disc(a.to,a.radius,time))return true;
      }
      return false;
    }
    function snapshot(world,result){
      const state=worlds.get(world);if(!state)return result;
      const a=state.attack;
      result.rocketBossAttack={...a,from:{...a.from},to:{...a.to},aim:{...a.aim},...(a.shotAngles?{shotAngles:[...a.shotAngles]}:{})};
      result.rocketBossEffects={projectiles:state.projectiles.map(shot=>({...shot})),
        meteors:state.meteors.map(meteor=>{
          const phase=meteor.ageMs<meteor.warningMs?'warning':meteor.ageMs<meteor.warningMs+meteor.fallMs?'fall':'impact';
          const start=phase==='warning'?0:phase==='fall'?meteor.warningMs:meteor.warningMs+meteor.fallMs;
          const duration=phase==='warning'?meteor.warningMs:phase==='fall'?meteor.fallMs:meteor.impactMs;
          return {...meteor,phase,progress:clamp((meteor.ageMs-start)/duration,0,1),remainingMs:Math.max(0,meteor.warningMs+meteor.fallMs-meteor.ageMs)};
        }),impacts:state.impacts.map(effect=>({...effect}))};
      return result;
    }
    return Object.freeze({init,reset,step,snapshot,invulnerable,threatProbe,autoProtectThreat});
  }
  function patch(source){return 'const rocketBossAttacks=('+createRocketBossAttacks.toString()+')();globalThis.rocketBossAttacks=rocketBossAttacks;\n'+source;}
  globalThis.ArenaBossAttacksAdapter=Object.freeze({patch});
  if(typeof module!=='undefined'&&module.exports)module.exports={patch};
})();
