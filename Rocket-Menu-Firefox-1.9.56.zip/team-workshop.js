// Native team-book paging and roster sorting. No battle or protocol changes.
(() => {
  'use strict';
  const SHADOW = 'rocket-menu.team-book.v1';
  const BACKUP = 'rocket-menu.team-book.original.v1';
  const JOURNAL = 'rocket-menu.team-book.import.v1';
  function arenaTeamStorageSnapshot(storage) {
    let pending = null;
    try { pending = JSON.parse(storage.getItem('rocket-menu.team-book.import.v1') ?? 'null'); } catch {}
    if (pending?.v === 1 && (pending.native === null || typeof pending.native === 'string') &&
        (pending.shadow === null || typeof pending.shadow === 'string')) return pending;
    return {v:1, native:storage.getItem(Pn), shadow:storage.getItem('rocket-menu.team-book.v1')};
  }
  function arenaImportTeamBook(storage, text) {
    if (!storage || typeof storage.removeItem !== 'function') return false;
    let prior;
    try {
      const parsed = JSON.parse(text);
      if (!parsed || !Array.isArray(parsed.teams)) return false;
      prior = arenaTeamStorageSnapshot(storage);
    } catch { return false; }
    const journal = 'rocket-menu.team-book.import.v1', shadow = 'rocket-menu.team-book.v1';
    const saved = JSON.stringify(prior);
    try {
      // A journal makes recovery safe even if the browser refuses a rollback
      // write. Readers keep using the previous pair until a commit completes.
      storage.setItem(journal, saved);
      if (storage.getItem(journal) !== saved) throw Error('Team import journal was not saved');
      storage.setItem(shadow, text);
      if (storage.getItem(shadow) !== text) throw Error('Team recovery copy was not saved');
      storage.setItem(Pn, text);
      if (storage.getItem(Pn) !== text) throw Error('Team book was not saved');
      storage.removeItem(journal);
      if (storage.getItem(journal) !== null) throw Error('Team import could not finish');
      return true;
    } catch {
      for (const [key, value] of [[Pn, prior.native], [shadow, prior.shadow]]) {
        try {
          if (storage.getItem(key) === value) continue;
          if (value === null) storage.removeItem(key); else storage.setItem(key, value);
        } catch {}
      }
      try {
        if (storage.getItem(Pn) === prior.native && storage.getItem(shadow) === prior.shadow) storage.removeItem(journal);
      } catch {}
      return false;
    }
  }
  function arenaTeamBook(raw, allowed) {
    const book = Ln();
    if (!raw || !Array.isArray(raw.teams)) return book;
    book.teams = book.teams.map((fallback, index) => {
      const item = raw.teams[index], slots = Hn(Array.isArray(item?.slots) ? item.slots : undefined, allowed);
      return {
        name: typeof item?.name === 'string' && item.name.length ? item.name : fallback.name,
        slots,
        moves: Un(slots, item?.moves)
      };
    });
    book.active = zn(Number(raw.active));
    book.everSaved = raw.everSaved === true || book.teams.some(team => Rn(team.slots).length > 0);
    return book;
  }
  function arenaReadTeamBook(storage, allowed) {
    let text, saved;
    try { saved = arenaTeamStorageSnapshot(storage); text = saved.native; } catch { return Kn(storage, Ln(), allowed); }
    // A removed native key still means a fresh/reset book. The recovery copy is
    // retained on disk, but is not allowed to undo an intentional native reset.
    if (text === null) return Kn(storage, Ln(), allowed);
    let raw = null, prior = null;
    try { raw = JSON.parse(text); } catch {}
    try { prior = JSON.parse(saved.shadow ?? 'null'); } catch {}
    if (!raw || !Array.isArray(raw.teams)) {
      return prior && Array.isArray(prior.teams) ? arenaTeamBook(prior, allowed) : Kn(storage, Ln(), allowed);
    }
    if (raw.teams.length <= 3 && prior && Array.isArray(prior.teams)) {
      // The stock game and earlier releases rewrite only their first three
      // teams. Adopt those edits without discarding the other saved pages.
      raw = {...raw, teams: [...raw.teams, ...prior.teams.slice(raw.teams.length)]};
    }
    return arenaTeamBook(raw, allowed);
  }
  function arenaWriteTeamBook(storage, book) {
    const previous = arenaTeamStorageSnapshot(storage).native;
    if (previous !== null && storage.getItem('rocket-menu.team-book.original.v1') === null) {
      // Write the exact pre-migration bytes before touching the native key.
      // If storage is full, native $n keeps this visit's book in memory.
      storage.setItem('rocket-menu.team-book.original.v1', previous);
    }
    const text = JSON.stringify(arenaTeamBook(book));
    if (!arenaImportTeamBook(storage, text)) throw Error('Could not save the team book');
  }
  function arenaRosterOrder(pool, mode, vanilla, save) {
    const compare = (a, b) => a < b ? -1 : a > b ? 1 : 0;
    if (mode === 'vanilla') {
      // Vanilla is the user's requested 36-character featured roster. Search,
      // types and modded recent history must not expand it to the data catalog.
      const featured = new Set(Jt);
      const ids = new Set(vanilla.filter(item => featured.has(item.id)).map(item => item.id));
      return pool.filter(item => ids.has(item.id) && !ud(item.id, save));
    }
    if (mode !== 'type' && mode !== 'dex') return pool;
    const index = new Map(Zt.map((item, i) => [item.id, i]));
    return [...pool].sort((a, b) => {
      if (mode === 'type') {
        const type = compare(a.types[0] ?? '', b.types[0] ?? '');
        if (type) return type;
      }
      const dex = a.dex - b.dex;
      if (dex) return dex;
      // Keep the native catalogue's base/form order within a national number.
      if (mode === 'dex') return index.get(a.id) - index.get(b.id);
      return compare(a.name, b.name) || compare(a.id, b.id);
    });
  }
  function patch(source) {
    function once(before, after, label) {
      const parts = source.split(before);
      if (parts.length !== 2) throw Error('Unsupported game build: team workshop anchor ' + label);
      source = parts.join(after);
    }
    function between(start, end, replacement, label) {
      const at = source.indexOf(start), to = source.indexOf(end, at + start.length);
      if (at < 0 || to < 0 || source.indexOf(start, at + 1) >= 0 || source.indexOf(end, to + 1) >= 0) {
        throw Error('Unsupported game build: team workshop anchor ' + label);
      }
      source = source.slice(0, at) + replacement + source.slice(to);
    }
    once('var Pn=`poke2d-arena-teams`;', 'var Pn=`poke2d-arena-teams`;' +
      [arenaTeamStorageSnapshot, arenaImportTeamBook, arenaTeamBook, arenaReadTeamBook, arenaWriteTeamBook, arenaRosterOrder].map(fn => fn.toString()).join(';') + ';', 'helpers');
    once('function Ln(e){let t=[];for(let e=0;e<3;e+=1)t.push({name:`Team ${e+1}`,slots:Fn(),moves:In()});return{active:0,teams:t,everSaved:!1}}',
      'function Ln(e){let t=[];for(let e=0;e<99;e+=1)t.push({name:`Team ${e+1}`,slots:Fn(),moves:In()});return{active:0,teams:t,everSaved:!1}}', '99 teams');
    once('function zn(e){return!Number.isInteger(e)||e<0?0:e>=3?2:e}',
      'function zn(e){return!Number.isInteger(e)||e<0?0:Math.min(e,98)}', 'active team');
    between('function Gn(e,t){', 'function Kn(', 'function Gn(e,t){return arenaReadTeamBook(e,t)}', 'read book');
    once('function qn(e,t){e.setItem(Pn,JSON.stringify(t))}', 'function qn(e,t){arenaWriteTeamBook(e,t)}', 'write book');
    once('i.addEventListener(`click`,()=>{jf([_d,...vC]);let t=e.collection;',
      'i.addEventListener(`click`,()=>{jf([_d,...vC]);if(e.extras.teams!==void 0&&!arenaImportTeamBook(E(),e.extras.teams)){g.textContent=`Could not save the imported teams. Your previous teams are kept. Free some browser storage and try again.`;rf(`save_code`,{action:`import_fail`});return}let t=e.collection;', 'checked import before other data');
    once('e.extras.teams!==void 0&&kf(Pn,e.extras.teams),', '', 'native unchecked import');
    once('function E(){try{let e=globalThis.localStorage;return e?{getItem:t=>e.getItem(t),setItem:(t,n)=>e.setItem(t,n)}:null}catch{return null}}',
      'function E(){try{let e=globalThis.localStorage;return e?{getItem:t=>e.getItem(t),setItem:(t,n)=>e.setItem(t,n),removeItem:t=>e.removeItem(t)}:null}catch{return null}}', 'import storage rollback');
    once('for(let n of t)if(n.startsWith(`poke2d`))try{e.removeItem(n)}catch{}',
      'for(let n of t)if(n.startsWith(`poke2d`)||[`rocket-menu.team-book.v1`,`rocket-menu.team-book.original.v1`,`rocket-menu.team-book.import.v1`].includes(n))try{e.removeItem(n)}catch{}', 'explicit reset');
    once('currentPool(){return z_(this.arenaRosterOffline?Zt:rn,{browseAll:true,query:this.pickQuery,typeName:this.pickType,recentIds:W_(Yy(),R_)})}',
      'currentPool(){return arenaRosterOrder(z_(this.arenaRosterOffline?Zt:rn,{browseAll:this.arenaRosterSort!==`vanilla`,query:this.pickQuery,typeName:this.pickType,recentIds:W_(Yy(),R_)}),this.arenaRosterSort,rn,df())}', 'sort pool');
    once('adoptBook(e){this.teamBook=e;', 'adoptBook(e){this.teamBook=e;this.arenaTeamPage=Math.floor(zn(e.active)/3);', 'active page');
    once('paintTeams(){this.pick?.querySelectorAll(`[data-saved-team]`).forEach(e=>{',
      'paintTeams(){let page=Math.max(0,Math.min(32,Number.isInteger(this.arenaTeamPage)?this.arenaTeamPage:Math.floor(this.teamBook.active/3)));this.arenaTeamPage=page;let count=this.pick?.querySelector(`[data-team-page-count]`);if(count){count.textContent=`${page+1}/33`;count.setAttribute(`aria-label`,`Team page ${page+1} of 33`)}this.pick?.querySelectorAll(`[data-team-page-step]`).forEach(e=>{e.disabled=Number(e.dataset.teamPageStep)<0?page===0:page===32});this.pick?.querySelectorAll(`[data-saved-team]`).forEach((e,index)=>{e.dataset.savedTeam=String(page*3+index);let label=e.querySelector(`:scope > span:first-child`);if(label)label.textContent=this.teamBook.teams[page*3+index].name;', 'page tabs');
    once('e.setAttribute(`aria-label`,`Team ${t+1}: ${n.slots.map(e=>e?Jy(e):`Empty`).join(`, `)}`);',
      'e.setAttribute(`aria-label`,`${n.name}, team ${t+1}: ${n.slots.map(e=>e?Jy(e):`Empty`).join(`, `)}`);e.title=n.name;', 'team labels');
    between('paintStages(){', 'chooseStage(e){',
      'paintStages(){this.pick?.querySelectorAll(`[data-roster-sort]`).forEach(e=>{let on=e.dataset.rosterSort===(this.arenaRosterSort??`default`),label=e.dataset.sortLabel;e.classList.toggle(`is-on`,on);e.setAttribute(`aria-pressed`,String(on));e.setAttribute(`aria-label`,label);Iy(e,label,{color:Ey(on?`--ui-on-frame`:`--ui-text`),background:Ey(on?`--ui-frame`:`--ui-panel`),shadow:Ey(`--ui-text-shadow`)})});this.placeFooter()}chooseRosterSort(mode){if(![`default`,`type`,`dex`,`vanilla`].includes(mode))return;this.arenaRosterSort=mode;this.pickPage=0;this.renderPick()}stepTeamPage(step){this.arenaTeamPage=Math.max(0,Math.min(32,(this.arenaTeamPage??Math.floor(this.teamBook.active/3))+step));this.renderPick()}', 'sort paint');
    once('stepStage(e){let t=ou.map(e=>e.id),n=t[(Math.max(0,t.indexOf(fu()))+e+t.length)%t.length]??fu();this.chooseStage(n)}',
      'stepStage(e){let modes=[`default`,`type`,`dex`,`vanilla`];this.chooseRosterSort(modes[(Math.max(0,modes.indexOf(this.arenaRosterSort??`default`))+e+modes.length)%modes.length])}', 'sort keyboard');
    once('this.pick?.querySelectorAll(`[data-stage]`).forEach(e=>{e.addEventListener(`click`,()=>{this.chooseStage(lu(e.dataset.stage))})}),this.pick?.querySelector(`[data-stage-roll]`)?.addEventListener(`click`,()=>{this.chooseStage(mu())})',
      'this.pick?.querySelectorAll(`[data-roster-sort]`).forEach(e=>{e.addEventListener(`click`,()=>this.chooseRosterSort(e.dataset.rosterSort))}),this.pick?.querySelectorAll(`[data-team-page-step]`).forEach(e=>{e.addEventListener(`click`,()=>this.stepTeamPage(Number(e.dataset.teamPageStep)))})', 'sort and page controls');
    once('<div class="pick-team-info"><p class="pick-banner"></p><span class="team-save-status" role="status"></span></div>',
      '<div class="pick-team-info"><div class="rocket-team-pages" role="group" aria-label="Team pages"><button type="button" data-team-page-step="-1" aria-label="Previous team page" title="Previous team page">&#x25C0;</button><span data-team-page-count aria-live="polite">1/33</span><button type="button" data-team-page-step="1" aria-label="Next team page" title="Next team page">&#x25B6;</button></div><span class="team-save-status" role="status"></span></div>', 'page header');
    once('<div class="pick-maps" role="group" aria-label="${K(`stages.label`)}">\n          ${ou.map(e=>`<button type="button" class="pixel-btn" data-stage="${e.id}">${K(e.labelKey)}</button>`).join(``)}\n          <button type="button" class="pixel-btn pick-map-roll" data-stage-roll="1">${K(`stages.random`)}</button>\n        </div>',
      '<div class="pick-maps" role="group" aria-label="Pokémon sorting">${[[`default`,`Default`],[`type`,`Type`],[`dex`,`Dex #`],[`vanilla`,`Vanilla`]].map(([id,label])=>`<button type="button" class="pixel-btn" data-roster-sort="${id}" data-sort-label="${label}" aria-pressed="false">${label}</button>`).join(``)}</div>', 'sort buttons');
    once('function wb(){return`', 'function wb(){return`<style>.pick .rocket-team-pages{display:flex;align-items:center;justify-content:flex-end;gap:4px;height:29px;margin:0 0 2px}.pick .rocket-team-pages button{width:29px;height:29px;flex:none;padding:0;border:2px solid var(--ui-frame-hi);background:var(--ui-panel);color:var(--ui-text);font:inherit;cursor:pointer}.pick .rocket-team-pages button:disabled{opacity:.35;cursor:default}.pick .rocket-team-pages button:focus-visible{outline:2px solid var(--ui-text);outline-offset:2px}.pick [data-team-page-count]{min-width:35px;text-align:center;font-size:12px;line-height:16px}.pick .saved-team-tabs button>span:first-child{overflow:hidden;text-overflow:ellipsis;min-width:0}.pick .saved-team-heads{flex:none}.pick .team-save-status{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}</style>', 'page styling');
    // The native seven-stage row used 110px desktop cells. Four sorting cells
    // have room for 120px, which fits the full pixel-font "Dex number" label.
    // The phone branch still measures each label and fits the available width.
    once('let i=r*110+Math.max(0,r-1)*8,o=80,s=96;', 'let i=r*120+Math.max(0,r-1)*8,o=80,s=96;', 'desktop sort row width');
    once('e.style.width=`110px`,e.style.minWidth=`110px`,e.style.maxWidth=`110px`',
      'e.style.width=`120px`,e.style.minWidth=`120px`,e.style.maxWidth=`120px`', 'desktop sort cell width');
    return source;
  }
  const api = Object.freeze({patch, SHADOW, BACKUP, JOURNAL});
  globalThis.ArenaTeamWorkshopAdapter = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})();
