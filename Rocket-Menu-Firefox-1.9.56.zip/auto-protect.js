// The assist submits an ordinary local ability input through the battle scene.
(() => {
  'use strict';

  function createRocketAutoProtect() {
    const scenes = new WeakMap(), observations=new WeakMap(), dashMarker=Symbol('rocket-dash-protect');

    function observeThreats(scene,state) {
      let history=observations.get(scene);
      if(!history||history.world!==scene.world||state.tick<history.tick){
        history={world:scene.world,tick:state.tick,bodies:new Map(),motion:new Map()};
        observations.set(scene,history);
      }
      if(state.tick===history.tick&&history.bodies.size)return history.motion;
      const dt=(state.tick-history.tick)*q/1000,bodies=new Map(),motion=new Map();
      for(const body of state.fighters){
        const old=history.bodies.get(body.id);let x=0,y=0;
        if(old&&old.entry===body.entry&&old.species===body.speciesId&&dt>0&&dt<=.3&&body.hp>0&&
            body.switchMs<=0&&body.ailment!=='sleep'&&body.ailment!=='freeze'){
          const vx=(body.x-old.x)/dt,vy=(body.y-old.y)/dt,speed=Math.hypot(vx,vy);
          const cap=Math.max(50,(body.walkSpeed||0)*1.35);
          // Require coherent samples; switches, knockback and corrections are
          // not evidence that an attacker will keep walking in that direction.
          if(speed>=5&&speed<=cap&&old.vx*vx+old.vy*vy>0&&
              Math.hypot(vx-old.vx,vy-old.vy)<=Math.max(45,speed*.5)){x=vx;y=vy;}
          bodies.set(body.id,{x:body.x,y:body.y,entry:body.entry,species:body.speciesId,
            vx:speed<=cap?vx:0,vy:speed<=cap?vy:0});
        }else bodies.set(body.id,{x:body.x,y:body.y,entry:body.entry,species:body.speciesId,vx:0,vy:0});
        const prior=history.motion.get(body.id),clock=state.tick*q;
        let buffKind=body.buffKind??null,buffUntil=clock+Math.max(0,body.boostMs||0);
        if(body.buffKind===undefined){
          if(old?.entry===body.entry&&prior?.buffUntil>clock){buffKind=prior.buffKind;buffUntil=prior.buffUntil;}
          if(body.cast==='active'&&body.castMove){
            const move=V(body.castMove);
            if(move.shape==='self'&&['swords','nasty','dragon','bulk','calm'].includes(move.status)){
              buffKind=move.status;buffUntil=clock+Math.max(0,me-Math.max(0,gc-body.castMs));
            }
          }
        }
        motion.set(body.id,{x,y,buffKind,buffUntil});
      }
      history.tick=state.tick;history.bodies=bodies;history.motion=motion;
      return motion;
    }

    function foeAt(state,foe,seconds) {
      const motion=state.rocketThreatMotion?.get(foe.id);
      if(!motion||seconds<=0)return{x:foe.x,y:foe.y};
      return Ia(foe.x+motion.x*seconds,foe.y+motion.y*seconds,foe.radius,state.arena?.combat,foe.x,foe.y);
    }

    function snapshotAge(actor) {return Math.max(0,actor.rocketSnapshotAgeMs||0)/1000;}

    function castEndsThisStep(actor) {
      if(actor.cast==='idle')return true;
      if(!actor.castMove||!Number.isFinite(actor.castMs))return false;
      // Ranged basics don't create a cast. Melee basics can use the ID of a
      // ranged equipped move, so their real lunge phase must be checked first.
      if(actor.castBasic)return actor.castMs<=q&&
        (actor.lungeTick==null||actor.lungeTick>=4);
      const move=V(actor.castMove);
      const zoneCast=actor.cast==='windup'&&(Go(move.id)||so(move.id))&&
        (actor.arenaCastUltimate??Qe(actor.moves.map(entry=>entry.id)).some(slot=>slot.role==='ultimate'&&slot.moveId===move.id));
      if(zoneCast||move.shape==='bolt'||move.shape==='hex')return actor.castMs<=q;
      // These windups become active; they do not free the ability input yet.
      if(actor.cast!=='active')return false;
      if(move.shape==='melee')return (actor.lungeTick??6)>=6&&actor.castMs<=q;
      if(move.shape==='self'||move.shape==='ring'||move.shape==='dash')return actor.castMs<=q;
      if(move.shape==='stream')return actor.castMs<=q||
        Number.isFinite(actor.castTicksLeft)&&Number.isFinite(actor.castTickDebt)&&move.tickMs>0&&
        Math.floor((actor.castTickDebt+q)/move.tickMs)>=actor.castTicksLeft;
      return false;
    }

    function impactTime(shot, center, velocity, radius) {
      const x = shot.x - center.x, y = shot.y - center.y;
      const vx = shot.vx - velocity.x, vy = shot.vy - velocity.y;
      const outside = x * x + y * y - radius * radius;
      if (outside <= 0) return 0;
      const approach = x * vx + y * vy, speedSquared = vx * vx + vy * vy;
      if (approach >= 0 || speedSquared < 1) return Infinity;
      const discriminant = approach * approach - speedSquared * outside;
      return discriminant < 0 ? Infinity : (-approach - Math.sqrt(discriminant)) / speedSquared;
    }

    function hostile(actor, owner) {
      return owner?.id !== actor.id && !(owner && actor.arenaCpuTeam !== undefined && actor.arenaCpuTeam === owner.arenaCpuTeam);
    }

    function statusThreat(move, actor) {
      const ailment = lt(move.status);
      if (!ailment || actor.ailment || actor.statusGraceMs > 0) return false;
      const immune = move.immuneTypes?.length ? move.immuneTypes : ot[ailment]?.immuneTypes || [];
      return !dn(actor.speciesId).types.some(type => immune.includes(type));
    }

    function ultimateMove(owner,move) {
      return !!owner?.moves&&Qe(owner.moves.map(entry=>entry.id)).some(slot=>slot.role==='ultimate'&&slot.moveId===move.id);
    }

    function predictedDamage(state,actor,owner,move,details={}) {
      if(!owner||!(actor.maxHp>0))return 0;
      const attacker=dn(owner.speciesId),defender=dn(actor.speciesId);
      const stat=(body,species,key)=>Number.isFinite(body[key])?body[key]:Ut(species[key]);
      const buff=body=>body.buffKind!==undefined?body.buffKind:state.rocketThreatMotion?.get(body.id)?.buffKind;
      let total=0;
      if(details.basic){
        const fallback=Qe(owner.moves.map(entry=>entry.id))[0]?.basicFallback;
        const basic=Ya({move:fallback?null:move,speciesTypes:attacker.types,
          atk:stat(owner,attacker,'atk'),spa:stat(owner,attacker,'spa')});
        const pct=details.basicPct>0?details.basicPct:basic.pct;
        const type=details.basicType||basic.typeName,category=pct===.032?'physical':'special';
        total=Math.max(1,Math.round(Xa(actor.maxHp,pct,Ba(type,defender.types))*fc(buff(owner),category)*pc(buff(actor),category)));
      }else if(details.ultimate){
        total=ao(actor.maxHp,Ba(Dc(move),defender.types));
      }else if(move.power>0&&move.category!=='status'){
        const physical=move.category==='physical';
        total=Kt({maxHp:actor.maxHp,power:move.power,
          attack:Ht(stat(owner,attacker,physical?'atk':'spa'),physical&&!!owner.ailment&&ot[owner.ailment]?.physicalScale<1),
          defense:stat(actor,defender,physical?'def':'spd'),stab:attacker.types.includes(Dc(move)),
          typeMultiplier:Ba(Dc(move),defender.types),roll:100,
          attackMultiplier:fc(buff(owner),move.category),defenseMultiplier:pc(buff(actor),move.category)});
      }
      // Streams/ultimate zones distribute a total across separate native hits.
      if(details.segments>1)total=co(total,details.segments)[details.segment||0]??0;
      return Math.floor(total*(Number.isFinite(actor.rocketDamageTakenScale)?actor.rocketDamageTakenScale:1));
    }

    function worthProtecting(state,actor,owner,move,details={}) {
      return predictedDamage(state,actor,owner,move,details)>12||
        !details.basic&&move.shape==='hex'&&statusThreat(move,actor);
    }

    function holdOffense(command) {
      // Reserve the next usable input for Protect instead of chaining another
      // held attack while waiting for the impact window or server confirmation.
      return {...command,buttons:{...command.buttons,attacks:command.buttons.attacks.map(()=>false),
        basic:false,heatGate:false,ultGate:false}};
    }

    function pointAt(point, velocity, seconds) {
      if (velocity.at) {
        const feet = velocity.at(seconds);
        return {x:feet.x+point.x-velocity.origin.x,y:feet.y+point.y-velocity.origin.y};
      }
      return {x:point.x + velocity.x * seconds, y:point.y + velocity.y * seconds};
    }

    function movement(state, actor, command, previous, dt) {
      const magnitude = Math.hypot(command.move.x,command.move.y);
      const speed = Math.max(0,Number(actor.walkSpeed)||0);
      const velocity = magnitude >= .2 ? {x:command.move.x/Math.max(1,magnitude)*speed,
        y:command.move.y/Math.max(1,magnitude)*speed} : {x:0,y:0};
      // A dodge follows its existing velocity, not a newly pressed direction.
      const sample = previous && previous.entry === actor.entry && dt > 0 && dt <= .2;
      const observed = sample ? {x:(actor.x-previous.x)/dt,y:(actor.y-previous.y)/dt} : null;
      const dodge = Number.isFinite(actor.dodgeVx) && Number.isFinite(actor.dodgeVy)
        ? {x:actor.dodgeVx,y:actor.dodgeVy}
        : observed && Math.hypot(observed.x,observed.y) <= 600 ? observed : {x:0,y:0};
      const dash=actor.cast==='active'&&actor.castMove&&V(actor.castMove).shape==='dash'?V(actor.castMove):null;
      const points = [{x:actor.x,y:actor.y}], step = q/1000;
      velocity.origin = actor;
      velocity.at = seconds => {
        const frame = Math.max(0,seconds)/step, end = Math.ceil(frame);
        while (points.length <= end) {
          const prior = points[points.length-1], time = (points.length-1)*q;
          const motion = actor.iframeMs-time > q ? dodge : dash && time<actor.castMs
            ? {x:Math.cos(actor.castFacing)*dash.dashSpeed,y:Math.sin(actor.castFacing)*dash.dashSpeed} : velocity;
          points.push(Ia(prior.x+motion.x*step,prior.y+motion.y*step,actor.radius,state.arena?.combat,prior.x,prior.y));
        }
        const index = Math.floor(frame), a = points[index], b = points[Math.min(index+1,points.length-1)], blend = frame-index;
        return {x:a.x+(b.x-a.x)*blend,y:a.y+(b.y-a.y)*blend};
      };
      return velocity;
    }

    function vulnerable(actor, seconds) {
      // Native immunity ticks down before collisions in the next simulation step.
      const time=Math.max(q,seconds*1000);
      const ready=actor.rocketProtectReadyMs||0;
      return actor.iframeMs <= time && ready+(ready>0?q:0)<=time &&
        (actor.rocketGuardRemainingMs||0)<=time;
    }

    function obstructed(state, from, to, radius) {
      const rocks = state.arena?.combat?.rocks;
      return !!(rocks?.length && typeof arenaReferenceArenas !== 'undefined' &&
        arenaReferenceArenas.blocksShot(rocks, from.x, from.y, {...to,radius}));
    }

    function projectileThreat(state, actor, shot, center, velocity, horizon, delay = 0) {
      // Damage/status eligibility is checked before geometry, regardless of size.
      if (![shot.x,shot.y,shot.vx,shot.vy,shot.radius].every(Number.isFinite) || shot.radius<0 || delay > horizon) return false;
      const age=shot.rocketPredicted?0:snapshotAge(actor);
      if(age){
        const advanced={...shot,x:shot.x+shot.vx*age,y:shot.y+shot.vy*age};
        if(Number.isFinite(shot.ttl))advanced.ttl=Math.max(0,shot.ttl-age*1000);
        if(obstructed(state,shot,advanced,shot.radius))return false;
        shot=advanced;
      }
      // Piecewise motion stops or slides at arena edges/rocks. A single straight
      // extrapolation falsely assumed the player could walk through a wall.
      const step = q/1000, radius = Math.max(1,actor.radius)+shot.radius;
      for (let time=0;time<horizon-delay;time+=step) {
        const span=Math.min(step,horizon-delay-time), target=pointAt(center,velocity,time+delay);
        const next=pointAt(center,velocity,time+delay+span);
        const from={x:shot.x+shot.vx*time,y:shot.y+shot.vy*time,vx:shot.vx,vy:shot.vy};
        const seconds=impactTime(from,target,{x:(next.x-target.x)/span,y:(next.y-target.y)/span},radius);
        if (seconds<0||seconds>span) continue;
        const travel=time+seconds, arrival=delay+travel;
        if (Number.isFinite(shot.ttl)&&Math.max(1,Math.ceil(travel/step))*q>=shot.ttl) return false;
        if (!vulnerable(actor,arrival)) continue;
        if(obstructed(state,shot,{x:shot.x+shot.vx*travel,y:shot.y+shot.vy*travel},shot.radius))return false;
        // Native bolts are consumed by their first target. Don't spend Protect
        // on a shot another combatant will intercept before it reaches us.
        const owner=state.fighters.find(body=>body.id===shot.owner);
        for(const body of state.fighters){
          if(body.id===actor.id||body.id===shot.owner||body.hp<=0||body.switchMs>0||!hostile(body,owner))continue;
          if(shot.move&&V(shot.move).shape==='hex'){
            const move=V(shot.move),ailment=lt(move.status),immune=move.immuneTypes?.length?move.immuneTypes:ot[ailment]?.immuneTypes||[];
            if(dn(body.speciesId).types.some(type=>immune.includes(type)))continue;
          }
          const feet=foeAt(state,body,snapshotAge(actor)+delay),position=rc(body.speciesId,feet.x,feet.y);
          const later=foeAt(state,body,snapshotAge(actor)+delay+travel),end=rc(body.speciesId,later.x,later.y);
          const hit=impactTime(shot,position,travel>0?{x:(end.x-position.x)/travel,y:(end.y-position.y)/travel}:{x:0,y:0},body.radius+shot.radius);
          if(hit>=0&&hit<travel&&body.iframeMs<=Math.max(q,(snapshotAge(actor)+delay+hit)*1000))return false;
        }
        return true;
      }
      return false;
    }

    function meleeThreat(state, actor, foe, move, velocity, horizon) {
      const basic = foe.castBasic === true, range = basic ? 100 : move.range;
      if (!(range > 0)) return false;
      const windup = foe.cast === 'windup', count = basic ? 4 : 6;
      if(!windup&&Number.isInteger(foe.castTargetEntry)&&foe.castTargetEntry!==actor.entry&&
          !foe.castTargetEntries?.includes(actor.entry))return false;
      let tick = windup ? 0 : foe.lungeTick;
      // An active melee animation can remain after its one damage check has passed.
      if (!Number.isInteger(tick) || tick >= count) return false;
      let seconds = windup ? Math.max(0,foe.castMs) / 1000 : 0;
      let from = windup ? foeAt(state,foe,seconds) : {x:foe.x,y:foe.y};
      const facing = foe.castFacing, dx = Math.cos(facing), dy = Math.sin(facing);
      for (;tick < count;) {
        seconds += q / 1000;
        if (seconds > horizon) return false;
        tick++;
        const distance = basic ? Za(tick) : ac(tick);
        const endpoint = Ia(from.x + dx * distance,from.y + dy * distance,foe.radius,state.arena?.combat);
        if (state.arena?.combat?.rocks?.length && typeof arenaReferenceArenas !== 'undefined') {
          const safe = arenaReferenceArenas.constrain(endpoint.x,endpoint.y,foe.radius,state.arena.combat.rocks,from.x,from.y);
          endpoint.x = safe.x; endpoint.y = safe.y;
        }
        const target = pointAt(actor,velocity,seconds);
        const contact = oc(from,endpoint,target,foe.radius + actor.radius + 4);
        const blocked = Math.hypot(endpoint.x-from.x,endpoint.y-from.y) < distance - .01;
        if (contact !== null) {
          endpoint.x = from.x + (endpoint.x-from.x)*contact;
          endpoint.y = from.y + (endpoint.y-from.y)*contact;
        }
        if (contact !== null || blocked || tick === count) {
          const source = basic ? rc(foe.speciesId,endpoint.x,endpoint.y) : endpoint;
          const body = basic ? rc(actor.speciesId,target.x,target.y) : target;
          const x = body.x-source.x, y = body.y-source.y;
          return vulnerable(actor,seconds) && Math.hypot(x,y) <= range + actor.radius && sc(x,y,facing,actor.radius);
        }
        from = endpoint;
      }
      return false;
    }

    function castThreat(state, actor, foe, velocity, center, horizon) {
      if (!hostile(actor,foe) || foe.hp <= 0 || foe.switchMs > 0 ||
          !['windup','active'].includes(foe.cast) || !foe.castMove || !Number.isFinite(foe.castFacing)) return false;
      const move = V(foe.castMove);
      const ultimate=!foe.castBasic&&(foe.arenaCastUltimate??ultimateMove(foe,move));
      const damageDetails={basic:foe.castBasic,ultimate,basicType:foe.castBasicType,basicPct:foe.castBasicPct};
      if(!worthProtecting(state,actor,foe,move,damageDetails))return false;
      const age=snapshotAge(actor),windup=foe.cast==='windup';
      const rawDelay=windup?Math.max(0,foe.castMs)/1000:0,delay=Math.max(0,rawDelay-age);
      if (delay > horizon) return false;
      // Zone ultimates have their own announced hit schedule. Their underlying
      // move's projectile/melee shape does not describe the ultimate's danger.
      if((Go(move.id)||so(move.id))&&ultimate){
        if(!windup)return false;
        const follows=!!Go(move.id),config=follows?Wo:so(move.id);
        if(!follows&&(!Number.isFinite(foe.castGroundX)||!Number.isFinite(foe.castGroundY)))return false;
        for(const tick of config.hitTicks){
          const seconds=rawDelay+(config.warnTicks+tick)*q/1000-age;
          if(seconds<0)continue;if(seconds>horizon)break;
          const target=pointAt(actor,velocity,seconds),origin=follows?foeAt(state,foe,age+seconds):{x:foe.castGroundX,y:foe.castGroundY};
          if(vulnerable(actor,seconds)&&Math.hypot(target.x-origin.x,target.y-origin.y)<=config.r)return true;
        }
        return false;
      }
      if (foe.castBasic || move.shape === 'melee') {
        // Keep native lunge progress: extrapolating a whole lunge past its
        // collision can invent a second hit after the first one is already spent.
        return meleeThreat(state,actor,foe,move,velocity,horizon);
      }
      if (move.shape === 'bolt' || move.shape === 'hex') {
        if (!windup) return false;
        const feet=foeAt(state,foe,rawDelay),origin=rc(foe.speciesId,feet.x,feet.y),reach=foe.radius+move.radius+2;
        const dx = Math.cos(foe.castFacing), dy = Math.sin(foe.castFacing);
        const flown=Math.max(0,age-rawDelay),spawn={x:origin.x+dx*reach,y:origin.y+dy*reach};
        const shot={x:spawn.x+dx*move.speed*flown,y:spawn.y+dy*move.speed*flown,
          vx:dx*move.speed,vy:dy*move.speed,radius:move.radius,ttl:move.ttlMs-flown*1000,
          move:move.id,owner:foe.id,rocketPredicted:true};
        return !obstructed(state,spawn,shot,move.radius)&&projectileThreat(state,actor,shot,center,velocity,horizon,delay);
      }
      if (move.shape === 'dash') {
        if (!windup && (foe.dashHitTargets?.includes(actor.id) || (state.fighters.length<=2 && foe.dashHit))) return false;
        const remaining = windup ? move.dashMs / 1000 : Math.max(0,foe.castMs) / 1000;
        const vx=Math.cos(foe.castFacing)*move.dashSpeed,vy=Math.sin(foe.castFacing)*move.dashSpeed;
        let from=windup?foeAt(state,foe,rawDelay):{x:foe.x,y:foe.y};
        for(let time=0;time<Math.min(horizon-delay,remaining);time+=q/1000){
          const span=Math.min(q/1000,horizon-delay-time,remaining-time);
          const endpoint=Ia(from.x+vx*span,from.y+vy*span,foe.radius,state.arena?.combat,from.x,from.y);
          const target=pointAt(actor,velocity,delay+time),next=pointAt(actor,velocity,delay+time+span);
          const contact=oc({x:from.x-target.x,y:from.y-target.y},{x:endpoint.x-next.x,y:endpoint.y-next.y},{x:0,y:0},foe.radius+actor.radius+6);
          if(contact!==null&&vulnerable(actor,delay+time+span*contact))return true;
          from=endpoint;
        }
        return false;
      }
      if (move.shape === 'ring') {
        if (!windup) return false; // Native rings strike once, as windup ends.
        if(rawDelay<age-q/1000)return false;
        const target = pointAt(actor,velocity,delay);
        const origin=foeAt(state,foe,rawDelay);
        return vulnerable(actor,delay) && Math.hypot(target.x-origin.x,target.y-origin.y) <= move.range;
      }
      if (move.shape === 'stream' || move.shape === 'beam') {
        const interval = Math.max(q,move.tickMs || q) / 1000;
        const elapsed = Math.max(0,(move.activeMs || 0)-foe.castMs) / 1000;
        let index = windup ? 0 : Number.isInteger(foe.castTicksLeft) ? move.ticks-foe.castTicksLeft : Math.floor(elapsed / interval)+1;
        let seconds = (windup ? rawDelay : Number.isFinite(foe.castTickDebt) ? Math.max(0,interval-foe.castTickDebt/1000) : index*interval-elapsed)-age;
        const end = (windup ? rawDelay + Math.max(0,move.activeMs) / 1000 : Math.max(0,foe.castMs) / 1000)-age;
        for (;index < move.ticks && seconds <= Math.min(horizon,end + q/1000);index++,seconds+=interval) {
          if(seconds<0)continue;
          const target = pointAt(actor,velocity,Math.max(0,seconds));
          const origin=foeAt(state,foe,age+seconds);
          if (vulnerable(actor,seconds) && xa(origin,foe.castFacing,move.range,move.halfAngle,{...target,radius:actor.radius})) return true;
        }
      }
      return false;
    }

    function zoneThreat(state, actor, zone, velocity, horizon) {
      const owner = state.fighters.find(foe=>foe.id === zone.owner);
      if (zone.owner === actor.id || !hostile(actor,owner) || !Array.isArray(zone.hitTicks)) return false;
      // The 12-damage threshold applies to the attack, not each small tick.
      if(!worthProtecting(state,actor,owner,V(zone.move),{ultimate:true}))return false;
      const follows=!!(Go(zone.move)&&owner),age=snapshotAge(actor);
      for (const tick of zone.hitTicks) {
        const frames = zone.warnTicks + tick - zone.age;
        if (frames <= 0) continue;
        const seconds = frames*q/1000-age;
        if(seconds<0)continue;
        if (seconds > horizon) break;
        const point = pointAt(actor,velocity,seconds);
        const origin=follows?foeAt(state,owner,age+seconds):zone;
        // Native zones check the feet against their radius, without body padding.
        if (vulnerable(actor,seconds) && Math.hypot(point.x-origin.x,point.y-origin.y) <= zone.r) return true;
      }
      return false;
    }

    function timing(scene,memory,wallNow) {
      if (!scene.net || scene.net.direct?.step) return {lead:(2*q+5)/1000,retry:2*q,age:0,stale:false};
      const net=scene.net;
      const number=(value,fallback)=>Number.isFinite(value)&&value>=0?value:fallback;
      if(!memory.timing || wallNow-memory.timingAt>=250){
        const stats=net.summary?.()||{};
        const rtt=number(net.pingYou,100), input=1000/Math.max(10,number(stats.inputHz,60));
        const snapshot=1000/Math.max(10,number(stats.snapshotHz,30));
        const jitter=Math.min(50,Math.max(0,number(stats.snapGapP95Ms,snapshot)-snapshot));
        // Ack latency already includes the RTT, so these are alternative estimates.
        const delivery=Math.max(rtt/2+input,number(stats.ackP95Ms,0)/2);
        memory.timingAt=wallNow;
        memory.timing={lead:Math.min(.3,Math.max(.05,(delivery+q+jitter)/1000)),transit:Math.min(150,rtt/2),
          retry:Math.max(90,Math.min(500,rtt+snapshot+2*q))};
      }
      const received=net.quality?.lastSnapshot, clock=net.now?.()??wallNow;
      const age=Number.isFinite(received)?Math.max(0,clock-received):0;
      // Remote shots/casts stay at their server snapshot coordinates. Include
      // inbound transit; only the client's own position is locally predicted.
      return {...memory.timing,age:Math.min(.3,(age+memory.timing.transit)/1000),stale:age>450};
    }

    function rocketAutoProtect(scene, state, command) {
      const previousMemory=scenes.get(scene);
      if(previousMemory)previousMemory.reserveUntil=0;
      if (!command || !state || state.phase !== 'fight' ||
          document.hidden || !scene.controls?.acceptsPress() || arenaKeybinds.blocked() ||
          scene.net?.spectating() || state.hitStopFrames > 0) return command;
      let actor = state.fighters[0];
      if (!actor || actor.hp <= 0 || command.switchSlot !== null || command.buttons.mega) return command;
      const dashing=command.buttons.dodge || actor.iframeMs>0 ||
        actor.cast==='active' && actor.castMove && V(actor.castMove).shape==='dash';
      const dashProtect=dashing&&rocketCloset.getDashProtect();
      if ((!rocketCloset.getAutoProtect()&&!dashProtect) || dashing&&!dashProtect) return command;
      const now = state.tick * q;
      if (!Number.isFinite(now)) return command;
      let memory = scenes.get(scene);
      if (!memory || memory.world !== scene.world || memory.entry !== actor.entry ||
          memory.species !== actor.speciesId || memory.match!==scene.net?.matchId || now < memory.clock) {
        memory = {world:scene.world, entry:actor.entry, species:actor.speciesId,
          match:scene.net?.matchId,clock:now,retryAt:0,protectedUntil:0,pending:null,
          sample:{x:actor.x,y:actor.y,entry:actor.entry,time:now}};
        scenes.set(scene, memory);
      }
      if (now>memory.clock) {
        memory.previous=memory.sample;
        memory.sample={x:actor.x,y:actor.y,entry:actor.entry,time:now};
      }
      memory.clock = now;
      const wallNow=performance.now(),net=scene.net;
      if (net && (!net.acceptsInput() || !net.enabled || !net.connected || net.frozenMs!==null)) {
        memory.retryAt=0;memory.pending=null;
        return command;
      }
      const schedule=timing(scene,memory,wallNow),localAuthority=!net||!!net.direct?.step;
      if(schedule.stale){memory.pending=null;memory.retryAt=0;return command;}
      state={...state,rocketThreatMotion:observeThreats(scene,state)};
      // The public snapshot exposes Protect's active cast but omits its guard timer.
      // Reconstruct the remaining native guard duration after a confirmed cast.
      if (actor.cast === 'active' && actor.castMove && V(actor.castMove).status === 'protect') {
        memory.protectedUntil = Math.max(memory.protectedUntil,
          now + Math.max(0, de - Math.max(0, gc - actor.castMs)));
      }
      if(memory.pending){
        const pending=memory.pending, move=actor.moves[pending.slot];
        const spent=move?.id===pending.move && (pending.ultimate
          ? actor.ultCharge<pending.charge : move.cooldownMs>pending.cooldown+q);
        if(actor.protectMs>0||now<memory.protectedUntil||spent){
          if(spent)memory.protectedUntil=Math.max(memory.protectedUntil,
            now+Math.max(0,de-Math.max(0,now-pending.tick-pending.readyMs)));
          memory.pending=null;memory.retryAt=0;
        }else{
          const answered=now-pending.tick>=pending.readyMs+q&&wallNow>=pending.executeAfter&&
            (localAuthority||Number.isFinite(net.ack)&&net.ack>=pending.seq&&
              Number.isFinite(net.quality?.lastSnapshot)&&net.quality.lastSnapshot>=pending.executeAfter);
          if(wallNow<pending.expires&&!answered){memory.reserveUntil=wallNow+2*q;return holdOffense(command);}
          // A fresh acknowledged frame without a cast is a rejection, not protection.
          memory.pending=null;memory.retryAt=0;
        }
      }
      const guardMs=Math.max(0,Math.max(actor.protectMs||0,memory.protectedUntil-now)-schedule.age*1000);
      if (wallNow < memory.retryAt || guardMs>Math.max(q,schedule.lead*1000)) return command;

      const plan = Qe(actor.moves.map(move => move.id));
      // Stock authority gives a new dodge precedence over attacks. Leave the
      // player's dodge intact, then submit Protect on a later input frame.
      if(!localAuthority&&dashProtect&&command.buttons.dodge&&plan[2]?.dash&&
          actor.dodgeCooldownMs<=q&&actor.iframeMs<=q&&actor.recoverMs<=q)return command;
      // Timers are decremented before the simulator consumes this command.
      const readyMs=Math.max(0,actor.recoverMs-q);
      const ready={...actor,recoverMs:0,switchMs:Math.max(0,actor.switchMs-q),
        moves:actor.moves.map(move=>({...move,cooldownMs:Math.max(0,move.cooldownMs-q-readyMs)}))};
      // Find the defensive slot while casting so its approach window can reserve
      // offense. Execution still waits for the native cast-ending transition.
      const castReady=castEndsThisStep(actor)||localAuthority&&dashProtect&&
        actor.castMove&&V(actor.castMove).shape==='dash';
      ready.cast='idle';
      const reserveMs=Math.max(340,Math.min(650,schedule.lead*1000+readyMs));
      // A nearly-ready Protect also needs an open action slot when its cooldown
      // ends. This lookahead is only for reservation, never for casting early.
      const reservable={...ready,moves:ready.moves.map(move=>({...move,cooldownMs:Math.max(0,move.cooldownMs-reserveMs)}))};
      const protect = plan.filter(slot => {
        if (slot.dash || slot.basicFallback || slot.role === 'basic' || !slot.moveId ||
            !Number.isInteger(slot.loadoutIndex) || rl(reservable, slot) !== null) return false;
        const move = V(slot.moveId);
        return move.status === 'protect' && move.shape === 'self';
      }).sort((a,b)=>(a.role==='ultimate'?0:ready.moves[a.loadoutIndex].cooldownMs)-
        (b.role==='ultimate'?0:ready.moves[b.loadoutIndex].cooldownMs))[0];
      if (!protect) return command;

      // Native recovery queues inputs only in its final 150ms. Check cooldowns
      // and charge separately: the native buffering shortcut skips those checks.
      const protectReadyMs=Math.max(readyMs,protect.role==='ultimate'?0:actor.moves[protect.loadoutIndex].cooldownMs-q);
      actor={...actor,rocketProtectReadyMs:protectReadyMs,rocketGuardRemainingMs:guardMs,rocketSnapshotAgeMs:schedule.age*1000};
      const center = rc(actor.speciesId, actor.x, actor.y);
      const velocity=movement(state,actor,command,memory.previous,(now-(memory.previous?.time??now))/1000);
      const threatsWithin=horizon=>{
        let examined=0;
        for(const shot of state.projectiles||[]){
          if(shot.owner===actor.id||!shot.move)continue;
          if(++examined>160)break;
          const owner=state.fighters.find(fighter=>fighter.id===shot.owner);
          const move=V(shot.move),details={basic:shot.basic,ultimate:!shot.basic&&(shot.ult??ultimateMove(owner,move)),basicType:shot.basicType,basicPct:shot.basicPct};
          if(hostile(actor,owner)&&worthProtecting(state,actor,owner,move,details)&&
              projectileThreat(state,actor,shot,center,velocity,horizon))return true;
        }
        return (state.zones||[]).some(zone=>zoneThreat(state,actor,zone,velocity,horizon))||
          state.fighters.some(foe=>castThreat(state,actor,foe,velocity,center,horizon))||
          !!scene.world.rocketAutoProtectThreat?.(horizon*1000,(ms,useCenter=false)=>
            vulnerable(actor,ms/1000)?pointAt(useCenter?center:actor,velocity,ms/1000):null);
      };
      const horizon=Math.min(.65,schedule.lead+readyMs/1000);
      if(!threatsWithin(Math.max(horizon,.34)))return command;
      memory.reserveUntil=wallNow+2*q;
      if(!castReady||rl(ready,protect)!==null||readyMs>150||!threatsWithin(horizon))return holdOffense(command);

      // A brief retry guard prevents repeated packets before the next authoritative
      // snapshot confirms the cast. The simulator still decides whether it succeeds.
      memory.retryAt = wallNow + schedule.retry;
      memory.pending={slot:protect.loadoutIndex,move:protect.moveId,ultimate:protect.role==='ultimate',
        cooldown:actor.moves[protect.loadoutIndex].cooldownMs,charge:actor.ultCharge,tick:now,readyMs,
        seq:Number.isFinite(net?.seq)?net.seq+1:0,
        executeAfter:wallNow+readyMs+(localAuthority?q:schedule.lead*1000),
        expires:wallNow+readyMs+schedule.retry+2*q};
      const attacks = command.buttons.attacks.map(() => false);
      attacks[protect.loadoutIndex] = true;
      return {...command,[dashMarker]:dashProtect, buttons:{...command.buttons, attacks, basic:false,
        dodge:dashProtect&&command.buttons.dodge, heatGate:false, ultGate:protect.role === 'ultimate'}};
    }
    rocketAutoProtect.reserved=scene=>(scenes.get(scene)?.reserveUntil||0)>performance.now();
    rocketAutoProtect.markLocalDash=command=>{
      if(rocketCloset.getDashProtect())command[dashMarker]=true;
      return command;
    };
    rocketAutoProtect.overlap=(world,actor,command,recovering,dodged,foe,extra,extra2)=>{
      if(!command[dashMarker]||!rocketCloset.getDashProtect()||recovering||actor.hp<=0||actor.protectMs>0||
          actor.ailment==='sleep'||actor.ailment==='freeze')return;
      const dash=actor.cast?.phase==='active'&&actor.cast.shape==='dash'?actor.cast:null;
      if(!dodged&&!dash)return;
      const slot=Qe(actor.loadout).find(slot=>!slot.dash&&!slot.basicFallback&&slot.role!=='basic'&&
        Number.isInteger(slot.loadoutIndex)&&command.buttons.attacks[slot.loadoutIndex]&&slot.moveId&&
        V(slot.moveId).shape==='self'&&V(slot.moveId).status==='protect');
      if(!slot)return;
      const attacks=command.buttons.attacks.map((_,index)=>index===slot.loadoutIndex);
      const protectCommand={...command,buttons:{...command.buttons,attacks,basic:false,dodge:false,mega:false}};
      const facing=actor.facing;
      if(dash)actor.cast=null;
      try{world.tryAttack(actor,protectCommand,foe,extra,extra2);}
      finally{if(dash){actor.cast=dash;actor.facing=facing;}}
    };
    return rocketAutoProtect;
  }

  function patch(source) {
    function once(before,after){
      const parts=source.split(before);
      if(parts.length!==2)throw Error('Unsupported Auto Protect detail: '+before);
      source=parts.join(after);
    }
    // Extra local snapshot detail improves prediction without changing the
    // network protocol. Older remote snapshots keep the existing fallbacks.
    once('castBasic:e.cast?.basic===!0,',
      'castBasic:e.cast?.basic===!0,castBasicType:e.cast?.basicType,castBasicPct:e.cast?.basicPct,buffKind:e.buffKind,boostMs:e.boostMs,rocketDamageTakenScale:this.bossAdvantage?(e.id===`player`?this.bossAdvantage.opponent:this.bossAdvantage.player):1,protectMs:e.protectMs,statusGraceMs:e.statusGraceMs,dodgeVx:e.dodgeVx,dodgeVy:e.dodgeVy,castTicksLeft:e.cast?.ticksLeft,castTickDebt:e.cast?.tickDebt,castTargetEntry:e.cast?.targetEntry,castTargetEntries:e.cast?.targetEntries,castGroundX:e.cast?.groundX,castGroundY:e.cast?.groundY,dashHit:e.cast?.hit,dashHitTargets:e.cast?.hitTargets,');
    once('radius:e.radius,basic:e.basic})),party:', 'radius:e.radius,basic:e.basic,basicType:e.basicType,basicPct:e.basicPct,ult:e.ult,ttl:e.ttl})),party:');
    once('let u=!s&&this.tryDodge(e,l),d=Tc(e.cast)',
      'let u=!s&&this.tryDodge(e,l),d=(rocketAutoProtect.overlap(this,e,l,s,u,n,r,i),Tc(e.cast))');
    // Direct authority re-tags only its own local seat after normal decoding.
    once('t.pending=null,t.ack=t.seq,n}',
      't.pending=null,t.ack=t.seq,e===this.start.direct.host&&rocketAutoProtect.markLocalDash(n),n}');
    const step = 'let e=this.net?this.netPresented??c:c,t=this.world.step(s);';
    const parts = source.split(step);
    if (parts.length !== 2) throw Error('Unsupported battle input for Auto Protect.');
    return 'const rocketAutoProtect=(' + createRocketAutoProtect.toString() + ')();\n' +
      parts.join('s=rocketAutoProtect(this,c,s);' + step);
  }

  globalThis.ArenaAutoProtectAdapter = Object.freeze({patch});
})();
