(() => {
  'use strict';

  function createArenaLobby() {
    const pending = new WeakMap();

    function showLoading(controller) {
      const section = document.createElement('section');
      section.className = 'screen';
      section.dataset.screen = 'lobby-loading';
      section.innerHTML = '<div class="row"><h1>ONLINE</h1>' +
        '<button class="px-btn" type="button" data-action="refresh">RETRY</button>' +
        '<button class="px-btn" type="button" data-action="back">BACK</button></div>' +
        '<p class="hint" role="status">Loading public rooms…</p>';
      section.querySelector('[data-action="refresh"]').onclick = () => controller.refreshLobby();
      section.querySelector('[data-action="back"]').onclick = () => controller.leaveTo('menu');
      ZD().replaceChildren(section);
    }

    function parseRooms(list) {
      if (!Array.isArray(list)) return {rooms: [], ok: false, error: 'Could not read the public room list. Choose Refresh to try again.'};
      const rooms = [];
      for (const room of list) {
        if (!room || typeof room.code !== 'string' || !Dw(room.code) ||
            typeof room.roomName !== 'string' || typeof room.hostName !== 'string' ||
            !Number.isSafeInteger(room.players) || room.players < 0) continue;
        // Ping values are interpolated as numbers by the game's room renderer.
        rooms.push({...room, hostPingMs: Number.isFinite(room.hostPingMs) ? room.hostPingMs : null,
          estMs: Number.isFinite(room.estMs) ? room.estMs : null});
      }
      if (rooms.length === list.length) return {rooms, ok: true};
      return {rooms, ok: rooms.length > 0, error: rooms.length ?
        'Some public rooms could not be displayed. Choose Refresh to try again.' :
        'Could not read the public rooms. Choose Refresh to try again.'};
    }

    async function load(controller) {
      pending.get(controller)?.abort();
      const attempt = new AbortController();
      pending.set(controller, attempt);
      const deadline = AbortSignal.timeout(8000);
      const signal = AbortSignal.any([attempt.signal, controller.abort.signal, deadline]);
      showLoading(controller);
      let status = 0, paused;
      try {
        const response = await fetch(VC('/lobby'), {cache: 'no-store', signal});
        status = response.status;
        paused = status === 503;
        const body = await response.json();
        if (!response.ok) {
          const error = typeof body?.error === 'string' && body.error || 'Unable to load rooms. Choose Refresh to try again.';
          return {status, paused, rooms: [], ok: false, error};
        }
        return {...parseRooms(body?.rooms), status, paused};
      } catch {
        const error = deadline.aborted ? 'The room list timed out. Choose Refresh to try again.' :
          'Unable to load rooms. Choose Refresh to try again.';
        return {status, paused, rooms: [], ok: false, error};
      } finally {
        if (pending.get(controller) === attempt) pending.delete(controller);
      }
    }
    return {load};
  }

  function patch(source) {
    // Keep the native renderer, room buttons and analytics. Replace only the
    // request and its result guard in the supported game build.
    const original = 'async refreshLobby(e){let t=++this.lobbyRequest,n=[],r=e?.error,i=0,a=!1;try{let e=await fetch(VC(`/lobby`),{cache:`no-store`,signal:this.abort.signal});i=e.status;let t=await e.json();e.ok||(r=t.error??`Unable to load rooms. Try again.`),this.pausedService=e.status===503,e.ok&&(n=t.rooms??[],a=!0)}catch{r=`Unable to load rooms. Try again.`}this.active&&this.mode===`lobby`&&t===this.lobbyRequest&&(';
    function replace(before, after) {
      const parts = source.split(before);
      if (parts.length !== 2) throw Error('Unsupported game build. Could not update the public room list.');
      source = parts.join(after);
    }
    const replacement = 'async refreshLobby(e){let t=++this.lobbyRequest,result=await arenaLobby.load(this);' +
      'if(!this.active||this.mode!=="lobby"||this.lobbyRequest!==t)return;' +
      'if(result.paused!==undefined)this.pausedService=result.paused;' +
      'let n=result.rooms,r=result.error??e?.error,i=result.status,a=result.ok;(';
    replace(original, replacement);
    replace('{...e,error:r,paused:this.pausedService}', '{...e,error:r,paused:this.pausedService,roomListRead:a}');
    const empty = '<p class="empty">${kw.emptyLobby}</p>';
    replace('o||`' + empty + '`', 'o||(r?.roomListRead===false?"":`' + empty + '`)');
    return 'const arenaLobby=(' + createArenaLobby.toString() + ')();\n' + source;
  }
  globalThis.ArenaLobbyAdapter = Object.freeze({patch});
})();
