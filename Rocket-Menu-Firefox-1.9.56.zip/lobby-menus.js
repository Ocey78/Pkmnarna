// Browse the existing menus without replacing the live waiting-room controller.
(() => {
  'use strict';

  function createRocketLobbyMenus() {
    let current = null;
    const blockedRows = new Set([0,1,4,5,6,10,11,12,14,15,16]);

    function waiting(controller) {
      return !!controller?.active && controller === hO && controller.mode === 'room' && !controller.battle &&
        ['open','lobby'].includes(controller.room?.state) &&
        controller.room.seats?.[Fc(controller.you)]?.present === true && controller.client?.ws?.readyState === 1;
    }
    function allReady(room) {
      const count = room?.mode === 'ffa3' ? 3 : 2;
      return Array.from({length:count},(_,index)=>room?.seats?.[index])
        .every(seat=>seat?.present && seat.ready && !seat.editing);
    }
    function locked() {
      return !!current || (typeof hO !== 'undefined' && !!hO?.active && hO.mode === 'room' && !hO.battle);
    }
    function style() {
      if (document.getElementById('rocket-lobby-menus-style')) return;
      const node = document.createElement('style');
      node.id = 'rocket-lobby-menus-style';
      node.textContent = `
        #online-root [data-screen="room"] .room-actions{display:grid;grid-template-columns:repeat(3,minmax(0,1fr)) minmax(120px,1fr);gap:8px;align-items:stretch}
        #online-root .room-actions>.px-btn{width:100%;min-width:0;margin:0;box-sizing:border-box;min-height:40px}
        #online-root .room-actions>[data-action="change-team"]{grid-column:1;grid-row:1}
        #online-root .room-actions>[data-action="train"]{grid-column:2;grid-row:1}
        #online-root .room-actions>[data-rocket-browse-menus]{grid-column:3;grid-row:1}
        #online-root .room-actions>[data-action="ready"]{grid-column:4;grid-row:1}
        #online-root .room-actions>[data-action="invite"]{grid-column:4;grid-row:2}
        #online-root .room-actions>.ready-prompt{grid-column:1 / 4;grid-row:2;align-self:center}
        @media(max-width:540px){#online-root [data-screen="room"] .room-actions{grid-template-columns:repeat(3,minmax(0,1fr))}#online-root .room-actions>[data-action="ready"]{grid-column:1 / 4;grid-row:2}#online-root .room-actions>[data-action="invite"]{grid-column:1 / 4;grid-row:3}#online-root .room-actions>.ready-prompt{grid-row:4}#online-root .room-actions>.px-btn{font-size:10px;padding:6px 3px}}
        .rocket-lobby-menus .menu-root{top:var(--rocket-lobby-bar-height,40px)!important}
        .rocket-lobby-menus .collection,.rocket-lobby-menus #settings{top:var(--rocket-lobby-bar-height,40px)!important;height:calc(100% - var(--rocket-lobby-bar-height,40px))!important}
        .rocket-lobby-menus .menu-btn[data-rocket-room-disabled]{filter:grayscale(1) brightness(.5);cursor:default}
        .rocket-lobby-menus #rocket-training-bar{z-index:150}
        .rocket-lobby-menu-dialog{padding-top:var(--rocket-lobby-bar-height,40px)!important}
        .rocket-lobby-menu-dialog #rocket-training-bar{position:absolute;z-index:150}
      `;
      document.head.append(node);
    }
    function canEdit(session) {
      return current === session && waiting(session.controller) && !allReady(session.controller.room) &&
        !session.editing && !document.querySelector('dialog[open]') &&
        !document.documentElement.classList.contains('settings-open') && !DC();
    }
    function editStart(session) {
      if (!canEdit(session)) return false;
      session.editing = true;
      if (session.menu?.root) session.menu.root.style.visibility = 'hidden';
      session.controller.scene.game.canvas.style.visibility = '';
      return true;
    }
    function editEnd(session) {
      if (current !== session) return;
      session.editing = false;
      if (session.menu?.root) session.menu.root.style.visibility = '';
      session.menu?.layout();
      arenaTrainingUi.update(session.controller);
    }
    function overlay(dialog) {
      const session = current;
      if (!session?.bar) return;
      session.dialog?.classList.remove('rocket-lobby-menu-dialog');
      session.dialog = dialog || null;
      const host = dialog || session.surface;
      dialog?.classList.add('rocket-lobby-menu-dialog');
      if (session.bar.parentNode !== host) host.append(session.bar);
    }
    function menuMounted(scene) {
      const session = current;
      if (!session || scene !== session.menu) return;
      paintMenu(scene);
      arenaAudioWorkshop.roomMusic(session.controller);
    }
    function paintMenu(scene) {
      if (current?.menu !== scene || !scene.root) return;
      for (const node of scene.root.querySelectorAll('button[data-index]')) {
        if (!blockedRows.has(Number(node.dataset.index))) continue;
        node.disabled = true;
        node.dataset.rocketRoomDisabled = '';
        node.setAttribute('aria-disabled','true');
        node.title = 'Return to the lobby and leave this room before starting another game.';
      }
    }
    function begin(controller) {
      if (current || !waiting(controller) || allReady(controller.room) || arenaTrainingLobby.active(controller)) return false;
      style();
      const manager = controller.scene.game.scene, surface = document.getElementById('rotator') || document.body;
      const session = {controller,manager,surface,origin:controller.scene,menu:manager.keys.menu,
        code:controller.code,seat:controller.you,editing:false,timer:0,bar:null,dialog:null};
      if (!session.menu) return false;
      current = session;
      surface.classList.add('rocket-lobby-menus');
      arenaTrainingUi.open(controller, {
        browsing:true, back:()=>close(controller,true), canEdit:()=>canEdit(session),
        editStart:()=>editStart(session), editEnd:()=>editEnd(session)
      });
      session.bar = document.getElementById('rocket-training-bar');
      session.bar.setAttribute('aria-label','Online lobby');
      session.bar.querySelector('[aria-label="Training options"]')?.remove();
      const back = session.bar.querySelector('.actions button:last-child');
      if (back) back.textContent = 'RETURN TO LOBBY';
      const team = session.bar.querySelector('.actions button:first-child');
      if (team) { team.textContent = 'TEAM'; team.removeAttribute('aria-keyshortcuts'); }
      session.resize = new ResizeObserver(() => {
        if (current !== session) return;
        document.documentElement.style.setProperty('--rocket-lobby-bar-height',session.bar.offsetHeight+'px');
        session.menu?.layout();
      });
      session.resize.observe(session.bar);
      document.documentElement.style.setProperty('--rocket-lobby-bar-height',session.bar.offsetHeight+'px');
      session.disposed = () => close(controller,false);
      session.origin.events.once('shutdown',session.disposed);
      session.origin.events.once('destroy',session.disposed);
      function launch() {
        session.timer = 0;
        if (current !== session) return;
        if (!waiting(controller) || allReady(controller.room)) { close(controller,true); return; }
        if (manager.isProcessing || !manager.isBooted) { session.timer = setTimeout(launch,16); return; }
        session.menu.rocketSection = 'home'; session.menu.cursor = 2;
        // SceneManager.start adds the menu alongside room. ScenePlugin.start
        // would shut down the room and must not be used here.
        manager.start('menu'); manager.bringToTop('menu');
      }
      session.timer = setTimeout(launch,0);
      return true;
    }
    function close(controller, repaint, stoppingMenu = false) {
      const session = current;
      if (session?.controller !== controller) return;
      current = null;
      clearTimeout(session.timer);
      session.resize?.disconnect();
      session.origin.events.off('shutdown',session.disposed);
      session.origin.events.off('destroy',session.disposed);
      document.getElementById('arena-name-editor')?.close();
      globalThis.ArenaRocketProfile?.close?.();
      // Native collection disposal preserves a paid pack's pending card choices.
      jC(); BE();
      arenaTrainingUi.close(controller,{allowNativeCancel:!!repaint && waiting(controller)});
      session.dialog?.classList.remove('rocket-lobby-menu-dialog');
      session.surface.classList.remove('rocket-lobby-menus');
      document.documentElement.style.removeProperty('--rocket-lobby-bar-height');
      if (session.menu.root) session.menu.root.style.display = 'none';
      if (!stoppingMenu) session.manager.stop('menu');
      if (session.origin.sys.isActive()) session.manager.bringToTop(session.origin.sys.settings.key);
      const canvas = controller.scene.game.canvas;
      canvas.style.visibility = ''; canvas.dataset.mode = 'room'; canvas.dataset.phase = 'room';
      if (repaint && controller.active && controller.mode === 'room') {
        controller.paintRoom(); arenaAudioWorkshop.roomMusic(controller);
      }
    }
    function layoutRoom() {
      style();
      const room=ZD().querySelector('[data-screen="room"]'),actions=room?.querySelector('.room-actions');
      if(!actions)return;
      room.querySelector('.room-invite [data-action="copy"]')?.remove();
      const invite=room.querySelector('[data-action="invite"]');
      if(invite && invite.parentNode!==actions)actions.append(invite);
      const train=actions.querySelector('[data-action="train"]'),browse=actions.querySelector('[data-rocket-browse-menus]');
      if(train&&browse)train.after(browse);
    }
    function roomPainted(controller) {
      layoutRoom();
      if (current?.controller === controller) { arenaTrainingUi.update(controller); return; }
      if (!waiting(controller) || allReady(controller.room) || arenaTrainingLobby.active(controller)) return;
      const host = ZD().querySelector('[data-screen="room"] .room-actions');
      if (!host || host.querySelector('[data-rocket-browse-menus]')) return;
      const button = document.createElement('button');
      button.type = 'button'; button.className = 'px-btn'; button.textContent = 'BROWSE MENUS';
      button.dataset.rocketBrowseMenus = '';
      button.addEventListener('click',()=>begin(controller));
      host.append(button);layoutRoom();
    }
    function beforePacket(controller, packet) {
      if (current?.controller !== controller) return;
      if (packet.t === 'room') {
        if (!['open','lobby'].includes(packet.state) || packet.code !== current.code || packet.you !== current.seat ||
            !packet.seats?.[Fc(packet.you)]?.present || allReady(packet)) close(controller,false);
      } else if (['countdown','start','resume','dissolved','kicked','error'].includes(packet.t)) close(controller,false);
    }
    function editMenu(scene) {
      if (current?.menu !== scene) return false;
      arenaTrainingUi.editCurrent(current.controller);
      return true;
    }
    function blocksKey(scene, event) {
      return current?.menu === scene && (current.editing ||
        event.target instanceof Element && !!event.target.closest('#rocket-training-bar'));
    }
    return {begin,close,roomPainted,beforePacket,menuMounted,paintMenu,overlay,editMenu,blocksKey,locked,
      active:()=>!!current, blocksRow:index=>locked()&&blockedRows.has(index),
      height:scene=>current?.menu===scene ? current.bar?.offsetHeight||0 : 0,
      menuStopped:scene=>{if(current?.menu===scene)close(current.controller,true,true);}};
  }

  function patch(source) {
    function replace(before, after, label) {
      const parts = source.split(before);
      if (parts.length !== 2) throw Error('Unsupported game build for lobby menus: ' + label + '.');
      source = parts.join(after);
    }
    replace('arenaTrainingLobby.roomPainted(this);rocketLobbyStreak.paint(this)',
      'arenaTrainingLobby.roomPainted(this);rocketLobbyStreak.paint(this);rocketLobbyMenus.roomPainted(this)', 'lobby button/status');
    replace('arenaTrainingLobby.beforePacket(this,e);',
      'rocketLobbyMenus.beforePacket(this,e);arenaTrainingLobby.beforePacket(this,e);', 'match transition');
    replace('arenaTrainingLobby.closed(this,e===`drop`);',
      'rocketLobbyMenus.close(this,e===`drop`);arenaTrainingLobby.closed(this,e===`drop`);', 'connection closure');
    replace('arenaTrainingLobby.closed(this,false),this.networkSetup',
      'rocketLobbyMenus.close(this,false),arenaTrainingLobby.closed(this,false),this.networkSetup', 'controller disposal');
    replace('function begin(controller = hO) {\n      if (!canBegin(controller)) return false;',
      'function begin(controller = hO) {\n      if (rocketLobbyMenus.active() || !canBegin(controller)) return false;', 'training exclusivity');
    replace('return {room,open,update,close,nativeReady};',
      'return {room,open,update,close,nativeReady,editCurrent:controller=>{if(current?.controller===controller)edit(current)}};', 'native live editor');
    replace("        consumed.add(key);\n        if (!event.repeat) {",
      "        if (session.actions.browsing && key === 'tab') return;\n        consumed.add(key);\n        if (!event.repeat) {", 'normal Tab navigation');
    replace('confirm(){if(this.leaving)return;if([11,12,13,14].includes(this.cursor))',
      'confirm(){if(this.leaving||rocketLobbyMenus.blocksRow(this.cursor))return;if([11,12,13,14].includes(this.cursor))', 'menu action guard');
    replace('openTeams(){this.leave(`pick`,{source:`team`})}',
      'openTeams(){if(rocketLobbyMenus.editMenu(this))return;this.leave(`pick`,{source:`team`})}', 'team button');
    replace('leave(e,t){this.leaving||(this.leaving=!0,this.time.delayedCall(60,()=>{this.alive&&this.scene.start(e,t)}))}',
      'leave(e,t){if(rocketLobbyMenus.locked())return;this.leaving||(this.leaving=!0,this.time.delayedCall(60,()=>{this.alive&&this.scene.start(e,t)}))}', 'programmatic menu exits');
    replace('function changeSection(scene, next) {\n      const previous',
      'function changeSection(scene, next) {\n      if (next !== "home" && rocketLobbyMenus.locked()) return;\n      const previous', 'submenus');
    replace('async function quick(controller, createOnly=false) {\n      if (!controller?.active',
      'async function quick(controller, createOnly=false) {\n      if (rocketLobbyMenus.locked()) return;\n      if (!controller?.active', 'quick matchmaking');
    replace('function Lb(){let e=Ib(),t=Mb();',
      'function Lb(){if(rocketLobbyMenus.locked())return!1;let e=Ib(),t=Mb();', 'collection encounter');
    replace('function gO(e,t,n=false){yO(),',
      'function gO(e,t,n=false){if(rocketLobbyMenus.active())return;yO(),', 'room-browser reentry');
    replace('onKey=e=>{if(DC()||!this.alive||IE()||document.querySelector("dialog[open]"))return;',
      'onKey=e=>{if(rocketLobbyMenus.blocksKey(this,e)||DC()||!this.alive||IE()||document.querySelector("dialog[open]"))return;', 'menu key guard');
    replace('this.root=e;let t=e.querySelectorAll(`.menu-arrow`);',
      'this.root=e;rocketLobbyMenus.menuMounted(this);let t=e.querySelectorAll(`.menu-arrow`);', 'menu mount');
    replace('this.cameras.main.roundPixels=!0,arenaFriendBridge.link.clear(),this.game.canvas.dataset.mode=`menu`',
      'this.cameras.main.roundPixels=!0,rocketLobbyMenus.active()||arenaFriendBridge.link.clear(),this.game.canvas.dataset.mode=`menu`', 'preserve room link');
    replace('paintDom(){let e=this.root;e&&(e.querySelectorAll(`.menu-abs .menu-btn`)',
      'paintDom(){rocketLobbyMenus.paintMenu(this);let e=this.root;e&&(e.querySelectorAll(`.menu-abs .menu-btn`)', 'disabled menu rows');
    replace('this.events.once(G.Scenes.Events.SHUTDOWN,()=>{_Q(!1),this.collectionUnsub',
      'this.events.once(G.Scenes.Events.SHUTDOWN,()=>{rocketLobbyMenus.menuStopped(this);_Q(!1),this.collectionUnsub', 'menu disposal');
    replace('n=e.offsetHeight||e.clientHeight||Math.round(this.scale.gameSize.height);return{width:Math.max(1,Math.round(t)),height:Math.max(1,Math.round(n))}}onFonts=',
      'n=e.offsetHeight||e.clientHeight||Math.round(this.scale.gameSize.height);n-=rocketLobbyMenus.height(this);return{width:Math.max(1,Math.round(t)),height:Math.max(1,Math.round(n))}}onFonts=', 'menu bar space');
    replace('const api={open:openProfile,summary,career,',
      'const api={open:openProfile,close:closeProfile,summary,career,', 'profile cleanup');
    replace('document.body.append(dialog);dialog.showModal();select(initial);',
      'document.body.append(dialog);dialog.showModal();select(initial);rocketLobbyMenus.overlay(dialog);', 'profile lobby bar');
    replace('function closeProfile(){\n      if(!profileView)return;',
      'function closeProfile(){\n      if(!profileView)return;rocketLobbyMenus.overlay(null);', 'profile bar return');
    return 'const rocketLobbyMenus=(' + createRocketLobbyMenus.toString() + ')();\n' + source;
  }

  const api = Object.freeze({patch});
  globalThis.ArenaLobbyMenusAdapter = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})();
