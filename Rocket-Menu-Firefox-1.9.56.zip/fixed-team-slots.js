(() => {
  'use strict';

  function patch(original) {
    let source = original;
    function replace(before, after) {
      const parts = source.split(before);
      if (parts.length !== 2) throw Error('Unsupported game build. Could not update fixed team shortcuts.');
      source = parts.join(after);
    }

    // Native party arrays and switch packets already retain the original
    // zero-based team index. Only the number-key conversion was off by one.
    replace('function eh(e){switch(e){case`Digit1`:case`Numpad1`:return 1;case`Digit2`:case`Numpad2`:return 2;case`Digit3`:case`Numpad3`:return 3;default:return null}}',
      'function eh(e){switch(e){case`Digit1`:case`Numpad1`:return 0;case`Digit2`:case`Numpad2`:return 1;case`Digit3`:case`Numpad3`:return 2;default:return null}}');

    // Let the Rocket Menu's Ctrl+R listener and browser shortcuts handle their
    // modifier combinations. Plain R keeps the native next-living-member cycle.
    replace('this.scene.input.mouse?.disableContextMenu();let i=e=>{if(typeof Element',
      'this.scene.input.mouse?.disableContextMenu();let i=e=>{if(e.ctrlKey||e.metaKey||e.altKey)return;if(typeof Element');

    // All three own-team cards stay in their original positions. Native
    // renderParty continues to update their active/fainted/Mega state in place.
    replace('r.dataset.slot=String(n),r.innerHTML=`<img alt="" />',
      'r.dataset.slot=String(n),r.style.order=String(n),n<3&&r.setAttribute(`aria-keyshortcuts`,String(n+1)),r.innerHTML=`${n<3?`<span class="party-r" data-team-hotkey aria-hidden="true" style="background:#F87818">${n+1}</span>`:``}<img alt="" />');
    replace('<span class="party-r">R</span>', '');
    replace('let a=this.root?.querySelector(`.party-r`),o=i===null?null:t.querySelector(`button[data-slot="${i}"]`);a&&(o?(o.appendChild(a),a.hidden=!1):a.hidden=!0)', '');
    return source;
  }

  const api = Object.freeze({patch});
  globalThis.ArenaFixedTeamSlotsAdapter = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})();
