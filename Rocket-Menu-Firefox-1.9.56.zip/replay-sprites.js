// Replays reuse the native actor loader and animation painter, without a world.
(() => {
  'use strict';
  function createArenaReplayBalls(scene, canvas) {
    // Keep the native frame tables, red recall beam and ball/flash sheets, but
    // never attach another DOM overlay or use its live clock/audio callbacks.
    const balls=Object.create(Oj.prototype),layer=document.createElement('canvas');
    Object.assign(balls,{scene,debug:null,canvas:layer,ctx:layer.getContext('2d',{alpha:true}),
      ballImage:jj(Tj('vfx/pokeball/pokeball_sheet_1x.png')),flashImage:jj(Tj('vfx/pokeball/flash_sheet_1x.png')),
      active:new Map(),destroyed:false,now:0,camera:null});
    balls.frameOf=entry=>entry.freeze===null?mj(Math.max(0,balls.now-entry.startedAt),entry.kind):entry.freeze;
    balls.playThrough=()=>{};
    balls.advance=()=>{for(const [id,entry] of balls.active)if(balls.now-entry.startedAt>=lj(entry.kind))balls.active.delete(id);};
    balls.note=(events,actors,before,state)=>{
      for(const event of events)if(event.type==='switch'){
        const old=before?.fighters.find(f=>f.id===event.actor),next=state?.fighters.find(f=>f.id===event.actor);
        balls.active.set(event.actor,{kind:event.cause==='faint'?'faint':'swap',startedAt:balls.now,freeze:null,
          oldSpecies:old?.speciesId||actors.get(event.actor)?.speciesId||null,newSpecies:event.speciesId||next?.speciesId,
          played:new Set(),shown:-1});
      }
    };
    balls.fit=()=>{if(layer.width!==canvas.width||layer.height!==canvas.height){layer.width=canvas.width;layer.height=canvas.height;}};
    balls.setView=matrix=>{
      const {a,b,c,d,e,f}=matrix,det=a*d-b*c;
      balls.camera={width:canvas.width,height:canvas.height,matrixCombined:{matrix:[a,b,c,d,e,f]},
        getWorldPoint:(x,y)=>({x:(d*(x-e)-c*(y-f))/det,y:(a*(y-f)-b*(x-e))/det})};
    };
    balls.draw=(ctx,actors,fighters)=>{
      if(balls.destroyed||!balls.camera)return;
      balls.paint(balls.camera,actors,fighters);
      ctx.save();try{ctx.setTransform(1,0,0,1,0,0);ctx.imageSmoothingEnabled=false;ctx.drawImage(layer,0,0);}finally{ctx.restore();}
    };
    return balls;
  }
  function createArenaReplaySprites(scene, actors, balls=null) {
    const pending=new Map(),cache=new Map(),hurts=new Map();
    const shadows=scene.add.graphics().setDepth(3);
    let disposed=false,latest=null,clock=0;
    const key=(id,species)=>id+':'+species;
    function mount(id,species){
      if(!species)return;
      const idKey=key(id,species);if(cache.has(idKey)||pending.has(idKey))return;
      const token={species};pending.set(idKey,token);
      uk(scene,id,species).then(actor=>{
        if(disposed||pending.get(idKey)!==token){actor.sprite.destroy();return;}
        pending.delete(idKey);actor.sprite.setVisible(false);cache.set(idKey,actor);
        if(latest)paint(latest,clock);
      }).catch(()=>{if(pending.get(idKey)===token)pending.delete(idKey);});
    }
    function paint(state,now){
      const tick=now/q;
      const hidden=new Set(state.fighters.filter(f=>balls?.hidesGroundShadow(f.id)).map(f=>f.id));
      Wk(shadows,state,hidden);
      for(const actor of cache.values())actor.sprite.setVisible(false);
      actors.clear();
      for(const fighter of state.fighters){
        const entry=balls?.active.get(fighter.id),pose=balls?.poseFor(fighter.id);
        const species=pose?.sprite?.who==='old'?entry.oldSpecies:entry?.newSpecies||fighter.speciesId;
        const actor=cache.get(key(fighter.id,species));if(!actor)continue;
        actors.set(fighter.id,actor);
        if(actor.replayEntry!==fighter.entry){actor.replayEntry=fighter.entry;actor.poseTick=tick;actor.lastX=NaN;actor.lastY=NaN;}
        const hurt=tick-(hurts.get(fighter.id)??-Infinity)<12;
        const look=balls?.camera?balls.lookFor(fighter.id,fighter,balls.camera):null;
        pk(actor,fighter,tick,hurt,true,false,false,look);
        if(pose&&!balls?.camera)actor.sprite.setVisible(false);
        // Keep native move effects above fighters while sorting overlapping actors.
        actor.sprite.setDepth(4+Math.max(0,fighter.y)/1e6);
      }
    }
    function update(state,now,events=[]){
      if(disposed||!state?.fighters)return;
      latest=state;clock=now;
      for(const event of events)if(event.type==='hit'&&event.amount>0&&event.target)hurts.set(event.target,Number.isFinite(event.arenaReplayTick)?event.arenaReplayTick:state.tick);
      for(const fighter of state.fighters){
        mount(fighter.id,fighter.speciesId);
        const entry=balls?.active.get(fighter.id);
        if(entry){mount(fighter.id,entry.oldSpecies);mount(fighter.id,entry.newSpecies);}
      }
      paint(state,now);
    }
    function dispose(){if(disposed)return;disposed=true;pending.clear();for(const actor of cache.values())actor.sprite.destroy();cache.clear();actors.clear();hurts.clear();shadows.destroy();latest=null;}
    return{update,dispose,paint(){if(latest)paint(latest,clock);}};
  }
  function patch(source){
    if(source.includes('function createArenaReplaySprites('))throw Error('Replay sprites already applied.');
    return createArenaReplayBalls.toString()+'\n'+createArenaReplaySprites.toString()+'\n'+source;
  }
  const api=Object.freeze({patch,createArenaReplaySprites,createArenaReplayBalls});globalThis.ArenaReplaySpritesAdapter=api;
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})();
