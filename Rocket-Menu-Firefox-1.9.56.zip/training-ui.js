(() => {
  'use strict';

  function createArenaTrainingUi() {
    let current = null;
    const consumed = new Set();

    function element(tag, className, text) {
      const node = document.createElement(tag);
      if (className) node.className = className;
      if (text) node.textContent = text;
      return node;
    }

    function installStyle() {
      if (document.getElementById('rocket-training-style')) return;
      const style = element('style');
      style.id = 'rocket-training-style';
      style.textContent = `
        #online-root.rocket-is-training .screen[data-screen="room"]{display:none}
        #rocket-training-bar{box-sizing:border-box;position:absolute;z-index:120;inset:0 0 auto;
          display:flex;align-items:center;gap:4px 12px;padding:4px 7px;
          border-bottom:2px solid var(--ui-outline,#080918);background:var(--ui-panel,#242940);
          color:var(--ui-text,#fff);font:clamp(10px,1.4vw,14px)/1.25 Silkscreen,monospace}
        #rocket-training-bar[hidden]{display:none}
        #rocket-training-bar .room-label{display:grid;gap:2px;min-width:0;max-width:24%}
        #rocket-training-bar .room-label>*{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
        #rocket-training-bar .room-code{color:var(--ui-frame-hi,#bac4ed);font-size:.85em}
        #rocket-training-bar .seats{display:flex;flex:1;flex-wrap:wrap;gap:2px 10px;min-width:0}
        #rocket-training-bar .seat{max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
        #rocket-training-bar .seat[data-ready="true"]{color:#a1edb3}
        #rocket-training-bar .actions{display:flex;flex-wrap:wrap;justify-content:flex-end;gap:3px}
        #rocket-training-bar button{box-sizing:border-box;padding:4px 7px;border:2px solid var(--ui-outline,#080918);
          box-shadow:inset 1px 1px var(--ui-frame-hi,#bac4ed);border-radius:0;background:var(--ui-panel-shade,#30334e);
          color:var(--ui-text,#fff);font:inherit;cursor:pointer}
        #rocket-training-bar button:focus-visible{outline:2px solid #ffda82;outline-offset:1px}
        #rocket-training-bar button:disabled{opacity:.58;cursor:default}
        .rocket-training-surface #overlay .hud>.cluster,.rocket-training-surface #overlay .hud>.timer,
        .rocket-training-surface #overlay .hud>.pause,.rocket-training-surface #overlay .hud>.party,
        .rocket-training-surface #overlay .hud>.mega-btn{translate:0 var(--rocket-training-bar-height,0px)}
        .rocket-training-surface #overlay.is-page>.pick{top:var(--rocket-training-bar-height,0px);
          height:calc(100% - var(--rocket-training-bar-height,0px))}
        .rocket-training-options{position:absolute;z-index:119;inset:var(--rocket-training-bar-height,0px) 0 0;
          box-sizing:border-box;display:grid;place-items:center;padding:8px;background:rgba(8,12,26,.58)}
        .rocket-training-options form{box-sizing:border-box;margin:0;display:grid;gap:12px;width:min(100%,510px);
          max-height:100%;overflow:auto;overscroll-behavior:contain;padding:14px 16px;
          border:3px solid var(--ui-frame-hi,#8895c1);outline:2px solid var(--ui-outline,#080918);
          background:var(--ui-panel,#242940);box-shadow:4px 4px 0 var(--ui-outline,#080918);
          color:var(--ui-text,#fff);font:clamp(11px,1.5vw,15px)/1.3 Silkscreen,monospace;scrollbar-width:thin}
        .rocket-training-options h2,.rocket-training-options p{margin:0;font:inherit}
        .rocket-training-options h2{font-size:1.25em}
        .rocket-training-options .training-option-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px}
        .rocket-training-options label{display:grid;align-content:end;gap:4px;min-width:0}
        .rocket-training-options label.training-ai{display:flex;gap:8px;align-items:center}
        .rocket-training-options input,.rocket-training-options select,.rocket-training-options button{
          box-sizing:border-box;min-width:0;padding:5px 7px;border:2px solid var(--ui-outline,#080918);
          border-radius:0;background:var(--ui-panel-shade,#30334e);color:inherit;font:inherit;
          box-shadow:inset 1px 1px var(--ui-frame-hi,#8895c1)}
        .rocket-training-options label input:not([type=checkbox]),.rocket-training-options select{width:100%}
        .rocket-training-options input[type=checkbox]{width:18px;height:18px;margin:0;accent-color:#f87818}
        .rocket-training-options fieldset{display:grid;gap:6px;min-width:0;margin:0;padding:7px 10px 10px;
          border:2px solid var(--ui-frame-hi,#8895c1)}
        .rocket-training-options .training-slot{grid-template-columns:1.5em minmax(0,1fr);align-items:center}
        .rocket-training-options .training-option-actions{display:flex;justify-content:flex-end;gap:8px}
        .rocket-training-options button{cursor:pointer}.rocket-training-options button[type=submit]{border-color:var(--ui-cursor,#f87818)}
        .rocket-training-options :focus-visible{outline:2px solid var(--ui-cursor,#f87818);outline-offset:1px}
        .rocket-training-options [role=alert]{color:#ffb3a3}.rocket-training-options [role=alert]:empty{display:none}
        @media(max-height:430px){.rocket-training-options form{gap:6px;padding:8px 12px}
          .rocket-training-options fieldset{grid-template-columns:repeat(3,minmax(0,1fr));gap:6px}
          .rocket-training-options .training-slot{grid-template-columns:auto;gap:2px}}
        @media(max-width:650px){#rocket-training-bar{gap:2px 6px;padding:2px 4px;font-size:10px}
          #rocket-training-bar .seats{gap:1px 5px}#rocket-training-bar button{padding:3px}}
      `;
      document.head.append(style);
    }

    function waiting(controller) {
      return !!controller?.active && controller.mode === 'room' &&
        ['open','lobby'].includes(controller.room?.state);
    }

    function room(controller, {start}) {
      if (!waiting(controller) || current?.controller === controller) return;
      const actions = document.querySelector('#online-root [data-screen="room"] .room-actions');
      if (!actions || actions.querySelector('[data-action="train"]')) return;
      const button = element('button','px-btn','TRAIN');
      button.type = 'button';
      button.dataset.action = 'train';
      button.title = 'Practice against a Hard CPU while waiting';
      button.addEventListener('click', () => {
        if (!current && waiting(controller)) start();
      });
      actions.append(button);
    }

    function nativeReady(controller) {
      controller.client?.send({t:'ready', on:!controller.room?.seats[Fc(controller.you)]?.ready});
    }

    function allowReady(session) {
      const c = session.controller, own = c.room?.seats[Fc(c.you)];
      return waiting(c) && c.client?.ws?.readyState === 1 && own?.present && !own.editing &&
        c.team?.length === 3 && !session.editor && !session.readyPending;
    }

    function toggleReady(session) {
      if (current !== session || !allowReady(session)) return;
      const c = session.controller;
      session.readyPending = {before:!!c.room.seats[Fc(c.you)].ready};
      // The room frame confirms the change. Allow another deliberate try if no reply arrives.
      session.readyTimer = window.setTimeout(() => {
        if (current === session) { session.readyPending = null; update(c); }
      }, 1800);
      nativeReady(c);
      update(c);
    }

    function allowEditor(session) {
      const c = session.controller;
      return waiting(c) && c.client?.ws?.readyState === 1 && c.room?.seats[Fc(c.you)]?.present &&
        !session.editor && !session.options && session.actions.canEdit();
    }

    function edit(session) {
      if (current !== session || !allowEditor(session)) return;
      const c = session.controller;
      session.editor = {};
      update(c);
      try {
        if (!session.actions.editStart()) {
          session.editor = null;
          update(c);
          return;
        }
        c.changeTeam();
        const originalLeave = Z.onLeavePick, originalSave = Z.onReady;
        const editor = session.editor;
        function complete(callback, args) {
          if (current !== session || session.editor !== editor) return;
          try { return callback?.(...args); }
          finally {
            if (current === session && session.editor === editor) {
              if (Z.onReady === editor.save) Z.onReady = null;
              if (Z.onLeavePick === editor.leave) Z.onLeavePick = null;
              session.editor = null;
              session.actions.editEnd();
              update(c);
            }
          }
        }
        editor.originalLeave = originalLeave;
        editor.leave = (...args) => complete(originalLeave,args);
        editor.save = (...args) => complete(originalSave,args);
        Z.onLeavePick = editor.leave;
        Z.onReady = editor.save;
      } catch (error) {
        if (current === session) {
          if (ZD().classList.contains('is-under')) {
            c.client?.send({t:'editing',on:false});
            Z.hidePick();
            ZD().classList.remove('is-under');
          }
          session.editor = null;
          session.actions.editEnd();
          update(c);
        }
        throw error;
      }
    }

    function button(label, shortcut, click) {
      const node = element('button','',label);
      node.type = 'button';
      if (shortcut) node.setAttribute('aria-keyshortcuts',shortcut);
      node.addEventListener('click',click);
      return node;
    }

    function trainingOptions(session) {
      if (current !== session || !allowEditor(session)) return;
      const initial = session.actions.openOptions();
      if (!initial) return;
      const layer = element('div','rocket-training-options');
      const form = element('form');
      form.setAttribute('role','dialog');
      form.setAttribute('aria-labelledby','rocket-training-options-title');
      const heading = element('h2','','TRAINING OPTIONS');
      heading.id = 'rocket-training-options-title';
      const grid = element('div','training-option-grid');
      const ai = element('input');
      ai.type = 'checkbox';
      ai.checked = initial.ai;
      const aiLabel = element('label','training-ai');
      aiLabel.append(ai,'CPU AI');

      function select(caption, choices, value) {
        const label = element('label','',caption), control = element('select');
        for (const [id,name] of choices) control.add(new Option(name,id));
        control.value = value;
        label.append(control);
        return {label,control};
      }
      const difficulty = select('Difficulty',[['easy','Easy'],['normal','Normal'],['hard','Hard']],initial.difficulty);
      grid.append(aiLabel,difficulty.label);
      const team = element('fieldset');
      team.append(element('legend','','CPU TEAM'));
      const choices = element('datalist');
      choices.id = 'rocket-training-species';
      const byText = new Map(), byId = new Map();
      const roster = Zt.filter(species=>!arenaGmaxSpecies(species));
      const names = new Set(), duplicates = new Set();
      for (const species of roster) {
        if (names.has(species.name)) duplicates.add(species.name);
        names.add(species.name);
      }
      for (const species of roster) {
        const label = duplicates.has(species.name) ? species.name+' ('+species.id+')' : species.name;
        const option = element('option');
        option.value = label;
        choices.append(option);
        byText.set(label.toLowerCase(),species.id);
        byText.set(species.id.toLowerCase(),species.id);
        byId.set(species.id,label);
      }
      const slots = initial.opponentPartyIds.map((id,index)=>{
        const input = element('input'), label = element('label','training-slot');
        input.type = 'text';
        input.required = true;
        input.spellcheck = false;
        input.autocomplete = 'off';
        input.setAttribute('list',choices.id);
        input.setAttribute('aria-label','CPU Pokémon '+(index+1));
        input.value = byId.get(id) || '';
        label.append(String(index+1),input);
        team.append(label);
        return input;
      });
      const map = select('Map',ou.map(stage=>[stage.id,K(stage.labelKey)]),initial.stageId);
      const restart = element('p','','Changing the map restarts practice.');
      restart.hidden = true;
      map.control.addEventListener('change',()=>{ restart.hidden = map.control.value === initial.stageId; });
      const error = element('p');
      error.setAttribute('role','alert');
      function dismiss() {
        layer.remove();
        if (current !== session) return;
        session.options = null;
        update(session.controller);
        if (!session.optionsButton.disabled) session.optionsButton.focus();
      }
      function cancel() {
        if (current !== session || session.options !== layer) return;
        session.actions.closeOptions();
        dismiss();
      }
      const actions = element('div','training-option-actions');
      const cancelButton = button('CANCEL',null,cancel), apply = element('button','','APPLY');
      apply.type = 'submit';
      actions.append(cancelButton,apply);
      form.append(heading,grid,team,choices,map.label,restart,error,actions);
      layer.append(form);
      form.addEventListener('input',()=>{ error.textContent = ''; });
      form.addEventListener('submit',event=>{
        event.preventDefault();
        if (current !== session || session.options !== layer) return;
        const ids = slots.map(input=>byText.get(input.value.trim().toLowerCase()));
        const invalid = ids.findIndex((id,i)=>!id || ids.indexOf(id) !== i);
        if (invalid >= 0) {
          error.textContent = ids[invalid] ? 'Choose three different Pokémon.' : 'Choose a Pokémon from the roster.';
          slots[invalid].focus();
          return;
        }
        try {
          session.actions.applyOptions({ai:ai.checked,difficulty:difficulty.control.value,
            opponentPartyIds:ids,stageId:map.control.value});
          dismiss();
        } catch (reason) {
          error.textContent = reason?.message || 'Could not apply training options.';
        }
      });
      form.addEventListener('keydown',event=>{
        if (event.key === 'Escape') {
          event.preventDefault();
          cancel();
        } else if (event.key === 'Tab' && !event.ctrlKey && !event.altKey && !event.metaKey) {
          if (event.shiftKey && event.target === ai) { event.preventDefault(); apply.focus(); }
          if (!event.shiftKey && event.target === apply) { event.preventDefault(); ai.focus(); }
        }
        event.stopPropagation();
      });
      for (const name of ['pointerdown','pointerup','mousedown','mouseup','touchstart','touchend','click','keyup']) {
        layer.addEventListener(name,event=>event.stopPropagation());
      }
      session.options = layer;
      session.surface.append(layer);
      update(session.controller);
      ai.focus();
    }

    function open(controller, actions) {
      if (current?.controller === controller) { update(controller); return; }
      if (current) close(current.controller);
      installStyle();
      const surface = document.getElementById('rotator') || document.body;
      const online = ZD(), bar = element('section'), title = element('strong'), code = element('span','room-code');
      bar.id = 'rocket-training-bar';
      bar.setAttribute('aria-label','Training lobby');
      const label = element('div','room-label'), seats = element('div','seats'), controls = element('div','actions');
      seats.setAttribute('role','status');
      label.append(title,code);
      const session = {controller,actions,surface,online,bar,title,code,seats,nodes:new Map(),present:new Map(),editor:null,readyPending:null};
      session.edit = button('TEAM [TAB]','Tab',()=>edit(session));
      session.ready = button('READY [R]','R',()=>toggleReady(session));
      session.optionsButton = button('OPTIONS',null,()=>trainingOptions(session));
      session.optionsButton.setAttribute('aria-haspopup','dialog');
      session.optionsButton.setAttribute('aria-label','Training options');
      const back = button('LOBBY',null,()=>{ if (current === session) actions.back(); });
      controls.append(session.edit,session.optionsButton,session.ready,back);
      bar.append(label,seats,controls);
      for (const name of ['pointerdown','pointerup','mousedown','mouseup','touchstart','touchend','click']) {
        bar.addEventListener(name,event=>event.stopPropagation());
      }
      current = session;
      online.classList.add('rocket-is-training');
      surface.classList.add('rocket-training-surface');
      surface.append(bar);
      function sizeBar() {
        if (current === session && !bar.hidden)
          surface.style.setProperty('--rocket-training-bar-height',bar.offsetHeight+'px');
      }
      session.resize = new ResizeObserver(sizeBar);
      session.resize.observe(bar);
      update(controller);
      sizeBar();
    }

    function setText(node, text) {
      if (node.textContent !== text) node.textContent = text;
    }

    function update(controller) {
      const session = current, room = controller.room;
      if (session?.controller !== controller || !room) return;
      const own = room.seats[Fc(controller.you)], ids = room.mode === 'ffa3' ? ['A','B','C'] : ['A','B'];
      const title = room.name || 'Training lobby';
      setText(session.title,title);
      session.title.title = title;
      setText(session.code, 'ROOM ' + (room.code || controller.code || ''));
      for (const id of ids) {
        const seat = room.seats[Fc(id)], self = id === controller.you;
        let node = session.nodes.get(id);
        if (!node) {
          node = element('span','seat');
          node.dataset.seat = id;
          session.nodes.set(id,node);
          session.seats.append(node);
        }
        const present = !!seat?.present, was = session.present.get(id);
        if (!self && was === false && present) node.dataset.joined = 'true';
        if (!present) delete node.dataset.joined;
        session.present.set(id,present);
        const name = (self ? 'You' : seat?.name) || ('Player '+id);
        const status = !present ? 'Open' : seat.editing ? 'Editing' : seat.ready ? 'Ready' :
          node.dataset.joined ? 'Joined' : 'Waiting';
        const caption = present ? name + ' · ' + status : 'Seat '+id+' · '+status;
        setText(node,caption);
        node.title = caption;
        node.dataset.ready = String(!!seat?.ready);
      }
      if (session.readyPending && !!own?.ready !== session.readyPending.before) {
        clearTimeout(session.readyTimer);
        session.readyPending = null;
      }
      session.edit.disabled = !allowEditor(session);
      session.optionsButton.disabled = session.edit.disabled;
      session.optionsButton.setAttribute('aria-expanded', String(!!session.options));
      session.ready.disabled = !allowReady(session);
      setText(session.ready,own?.ready ? 'UNREADY [R]' : 'READY [R]');
      session.ready.setAttribute('aria-pressed',String(!!own?.ready));
    }

    function close(controller, {allowNativeCancel = false} = {}) {
      const session = current;
      if (session?.controller !== controller) return;
      current = null;
      clearTimeout(session.readyTimer);
      session.resize.disconnect();
      session.options?.remove();
      session.bar.remove();
      session.online.classList.remove('rocket-is-training');
      session.surface.classList.remove('rocket-training-surface');
      session.surface.style.removeProperty('--rocket-training-bar-height');
      const editor = session.editor;
      if (editor && Z.onLeavePick === editor.leave) {
        if (Z.onReady === editor.save) Z.onReady = null;
        Z.onLeavePick = null;
        if (allowNativeCancel && waiting(controller) && controller.client?.ws?.readyState === 1) editor.originalLeave?.();
        else {
          Z.hidePick();
          session.online.classList.remove('is-under');
        }
      }
    }

    function onKey(event) {
      const key = event.key.toLowerCase();
      if (event.type === 'keyup') {
        if (!consumed.delete(key)) return;
      } else {
        const session = current;
        if (!session || session.editor || session.options || !['tab','r'].includes(key) ||
            event.shiftKey || event.altKey || event.ctrlKey || event.metaKey || event.isComposing ||
            document.documentElement.classList.contains('settings-open') ||
            event.composedPath().some(node=>node instanceof Element && node.closest(
              'input,textarea,select,[contenteditable="true"],[role="dialog"],#panel')))
          return;
        consumed.add(key);
        if (!event.repeat) {
          if (key === 'tab') edit(session);
          else toggleReady(session);
        }
      }
      event.preventDefault();
      event.stopImmediatePropagation();
    }
    // Installed before native battle controls so R never also switches a Pokémon.
    window.addEventListener('keydown',onKey,true);
    window.addEventListener('keyup',onKey,true);
    window.addEventListener('blur',()=>consumed.clear());
    return {room,open,update,close,nativeReady};
  }

  function patch(source) {
    const original = 'ready:()=>this.client?.send({t:`ready`,on:!this.room?.seats[Fc(this.you)]?.ready})';
    const parts = source.split(original);
    if (parts.length !== 2) throw Error('Unsupported game build. Could not attach the training Ready control.');
    return 'const arenaTrainingUi=(' + createArenaTrainingUi.toString() + ')();\n' +
      parts.join('ready:()=>arenaTrainingUi.nativeReady(this)');
  }
  const api = Object.freeze({patch});
  globalThis.ArenaTrainingUiAdapter = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})();
