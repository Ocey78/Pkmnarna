// World-space boss presentation, drawn after the ordinary arena sprites.
(() => {
  'use strict';
  function createRocketBossVfx() {
    const scenes = new WeakMap();
    const purple = {dark:0x32154d,edge:0x8753c9,light:0xca91ff,core:0xffe9ff,accent:0x77deff};
    const green = {dark:0x124b36,edge:0x21ae75,light:0x81ffb0,core:0xf6ffd4,accent:0xf4e76e};
    const gold = {dark:0x6b4109,edge:0xe9ac16,light:0xffe34a,core:0xffffd9,accent:0xfff594};
    const palette = effect => effect.enraged ? gold : effect.mega ? green : purple;
    const clamp = value => Math.max(0,Math.min(1,value || 0));
    const pixel = value => Math.round(value / 2) * 2;
    let textureSerial=0;

    function texture(record,kind,p,frame=0) {
      const theme=p===gold?'gold':p===green?'green':'purple',id=kind+':'+theme+':'+frame;
      if(record.textures.has(id))return record.textures.get(id);
      const size=kind==='breath'?[512,192]:kind==='trail'?[256,96]:kind==='segment'?[64,64]:[256,256];
      const key='rocket-boss-fx-'+record.textureId+'-'+id.replace(/:/g,'-');
      const canvas=record.scene.textures.createCanvas(key,size[0],size[1]),ctx=canvas.getContext();
      const [w,h]=size,cx=w/2,cy=h/2,r=Math.min(w,h)*.44;
      const css=color=>'#'+color.toString(16).padStart(6,'0');
      const rgba=(color,alpha)=>'rgba('+[(color>>16)&255,(color>>8)&255,color&255,alpha].join(',')+')';
      let seed=3197+frame*911;
      const random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
      ctx.clearRect(0,0,w,h);ctx.imageSmoothingEnabled=true;
      if(kind==='glow'){
        const g=ctx.createRadialGradient(cx,cy,0,cx,cy,w*.5);
        g.addColorStop(0,rgba(p.core,.75));g.addColorStop(.27,rgba(p.light,.4));
        g.addColorStop(.6,rgba(p.edge,.12));g.addColorStop(1,rgba(p.edge,0));
        ctx.fillStyle=g;ctx.fillRect(0,0,w,h);
      }else if(kind==='trail'){
        const g=ctx.createLinearGradient(0,0,w,0);
        g.addColorStop(0,rgba(p.edge,0));g.addColorStop(.4,rgba(p.edge,.15));
        g.addColorStop(.82,rgba(p.light,.75));g.addColorStop(1,rgba(p.core,.95));
        ctx.fillStyle=g;ctx.beginPath();ctx.moveTo(0,cy);ctx.bezierCurveTo(w*.4,cy*.8,w*.7,0,w,cy*.4);
        ctx.quadraticCurveTo(w*1.07,cy,w,cy*1.6);ctx.bezierCurveTo(w*.7,h,w*.4,cy*1.2,0,cy);ctx.fill();
        for(let i=0;i<9;i++){
          const y=cy+(i-4)*5;ctx.strokeStyle=rgba(i%2?p.light:p.core,.35);ctx.lineWidth=i%3?1.5:3;
          ctx.beginPath();ctx.moveTo(w*(.15+random()*.3),cy);ctx.bezierCurveTo(w*.5,y,w*.8,y,w,y);ctx.stroke();
        }
      }else if(kind==='breath'){
        ctx.save();ctx.beginPath();ctx.moveTo(0,cy);ctx.lineTo(w,4);ctx.lineTo(w,h-4);ctx.closePath();ctx.clip();
        const g=ctx.createLinearGradient(0,0,w,0);
        g.addColorStop(0,rgba(p.core,.9));g.addColorStop(.12,rgba(p.light,.85));g.addColorStop(.5,rgba(p.edge,.6));
        g.addColorStop(.88,rgba(p.edge,.35));g.addColorStop(1,rgba(p.dark,0));ctx.fillStyle=g;ctx.fillRect(0,0,w,h);
        for(let lane=-9;lane<=9;lane++){
          ctx.strokeStyle=rgba(lane%3?p.light:p.core,lane%3?.38:.7);ctx.lineWidth=lane%3?4:7;
          ctx.beginPath();ctx.moveTo(0,cy);
          for(let x=8;x<=w;x+=8){
            const spread=(x/w)*h*.46,y=cy+lane/10*spread+Math.sin(x*.037-lane*.8+frame*Math.PI/2)*spread*.13;
            ctx.lineTo(x,y);
          }
          ctx.stroke();
        }
        for(let i=0;i<180;i++){
          const x=random()*w,y=cy+(random()*2-1)*(x/w)*h*.49;
          ctx.fillStyle=rgba(i%4?p.light:p.core,.15+random()*.5);
          ctx.fillRect(x,y,2+random()*12,1+random()*3);
        }
        ctx.restore();
      }else if(kind==='shock'){
        const g=ctx.createRadialGradient(cx,cy,r*.65,cx,cy,r*1.1);
        g.addColorStop(0,rgba(p.edge,0));g.addColorStop(.5,rgba(p.edge,.18));g.addColorStop(.7,rgba(p.light,.85));
        g.addColorStop(.78,rgba(p.core,.95));g.addColorStop(.88,rgba(p.light,.4));g.addColorStop(1,rgba(p.edge,0));
        ctx.fillStyle=g;ctx.fillRect(0,0,w,h);
        for(let i=0;i<32;i++){
          const a=i*Math.PI/16,len=r*(.65+random()*.36);
          ctx.strokeStyle=rgba(p.core,.35+random()*.4);ctx.lineWidth=1+random()*2;
          ctx.beginPath();ctx.moveTo(cx+Math.cos(a)*len,cy+Math.sin(a)*len);
          ctx.lineTo(cx+Math.cos(a+.03)*r*1.08,cy+Math.sin(a+.03)*r*1.08);ctx.stroke();
        }
      }else if(kind==='segment'){
        ctx.save();ctx.beginPath();ctx.ellipse(cx,cy,w*.44,h*.41,0,0,Math.PI*2);ctx.clip();
        const g=ctx.createLinearGradient(0,0,0,h);g.addColorStop(0,'#69ba70');g.addColorStop(.4,'#278b58');g.addColorStop(1,'#083d37');
        ctx.fillStyle=g;ctx.fillRect(0,0,w,h);
        for(let y=5;y<h;y+=9)for(let x=-5;x<w;x+=10){
          const ox=x+(y%18?5:0);ctx.strokeStyle='rgba(6,45,35,.35)';ctx.lineWidth=1;
          ctx.beginPath();ctx.moveTo(ox,y);ctx.lineTo(ox+5,y+4);ctx.lineTo(ox+10,y);ctx.stroke();
        }
        ctx.fillStyle='rgba(178,229,128,.25)';ctx.fillRect(8,12,48,5);ctx.restore();
        ctx.strokeStyle='#0b3d35';ctx.lineWidth=3;ctx.beginPath();ctx.ellipse(cx,cy,w*.44,h*.41,0,0,Math.PI*2);ctx.stroke();
      }else{
        const meteor=kind==='meteor';ctx.save();ctx.beginPath();ctx.arc(cx,cy,r,0,Math.PI*2);ctx.clip();
        const g=ctx.createRadialGradient(cx-r*.3,cy-r*.3,r*.03,cx,cy,r);
        g.addColorStop(0,css(meteor?0xeab987:p.core));g.addColorStop(.23,css(meteor?0x986e4c:p.light));
        g.addColorStop(.68,css(meteor?0x4f4144:p.edge));g.addColorStop(1,css(meteor?0x241e2b:p.dark));
        ctx.fillStyle=g;ctx.fillRect(0,0,w,h);
        for(let i=0;i<120;i++){
          const x=random()*w,y=random()*h,s=2+random()*(meteor?14:7);
          ctx.fillStyle=rgba(i%2?p.dark:p.core,meteor?.12:.045);ctx.fillRect(x,y,s,s*.65);
        }
        for(let i=0;i<(meteor?9:15);i++){
          const a=random()*Math.PI*2,points=meteor?5:16;ctx.beginPath();
          for(let j=0;j<points;j++){
            const b=a+j*(meteor?.14:.18),d=meteor?r*(.2+j*.19):r*(.45+Math.sin(j*.9+i)*.35);
            const x=cx+Math.cos(b)*d,y=cy+Math.sin(b)*d;j?ctx.lineTo(x,y):ctx.moveTo(x,y);
          }
          ctx.strokeStyle=rgba(p.light,meteor?.8:.55);ctx.lineWidth=meteor?3:2;ctx.stroke();
          if(i%3===0){ctx.strokeStyle=rgba(p.core,.85);ctx.lineWidth=1;ctx.stroke();}
        }
        ctx.restore();ctx.strokeStyle=rgba(p.light,.8);ctx.lineWidth=3;ctx.beginPath();ctx.arc(cx,cy,r,0,Math.PI*2);ctx.stroke();
        const shine=ctx.createRadialGradient(cx-r*.28,cy-r*.3,0,cx-r*.28,cy-r*.3,r*.33);
        shine.addColorStop(0,rgba(p.core,meteor?.3:.85));shine.addColorStop(1,rgba(p.core,0));ctx.fillStyle=shine;ctx.fillRect(0,0,w,h);
      }
      canvas.refresh();record.textures.set(id,key);return key;
    }
    function image(record,kind,p,x,y,w,h,rotation=0,alpha=1,depth=5.8,originX=.5,frame=0) {
      const key=texture(record,kind,p,frame),index=record.used++;
      let sprite=record.images[index];
      if(!sprite){sprite=record.scene.add.image(0,0,key);record.images.push(sprite);}
      if(sprite.texture.key!==key)sprite.setTexture(key);
      sprite.setPosition(x,y).setOrigin(originX,.5).setDisplaySize(Math.max(1,w),Math.max(1,h))
        .setRotation(rotation).setAlpha(Math.max(0,Math.min(1,alpha))).setDepth(depth).setVisible(true);
      return sprite;
    }

    function polygon(g,points,color,alpha=1,stroke=0,width=2) {
      if (!points.length) return;
      g.beginPath();g.moveTo(pixel(points[0].x),pixel(points[0].y));
      for (let i=1;i<points.length;i++) g.lineTo(pixel(points[i].x),pixel(points[i].y));
      g.closePath();
      if (alpha>0) {g.fillStyle(color,alpha);g.fillPath();}
      if (stroke) {g.lineStyle(width,stroke,Math.min(1,alpha+.45));g.strokePath();}
    }
    function disc(g,x,y,r,color,alpha=1,stroke=0,width=2) {
      const points=[];
      for(let i=0;i<16;i++){const a=i*Math.PI/8;points.push({x:x+Math.cos(a)*r,y:y+Math.sin(a)*r});}
      polygon(g,points,color,alpha,stroke,width);
    }
    function goldenGlow(g,x,y,r,reduced) {
      if(!reduced)disc(g,x,y,r*1.16,gold.edge,.055);
      disc(g,x,y,r*1.07,gold.light,reduced?.035:.08);
    }
    function line(g,points,color,width,alpha=1) {
      if(points.length<2)return;
      g.lineStyle(width,color,alpha);g.beginPath();g.moveTo(pixel(points[0].x),pixel(points[0].y));
      for(let i=1;i<points.length;i++)g.lineTo(pixel(points[i].x),pixel(points[i].y));
      g.strokePath();
    }
    function ray(origin,angle,distance,side=0) {
      return {x:origin.x+Math.cos(angle)*distance-Math.sin(angle)*side,
        y:origin.y+Math.sin(angle)*distance+Math.cos(angle)*side};
    }
    function spark(g,x,y,size,color,alpha=1) {
      g.fillStyle(color,alpha);g.fillRect(pixel(x-size),pixel(y-2),size*2,4);
      g.fillRect(pixel(x-2),pixel(y-size),4,size*2);
    }
    function reticle(g,x,y,r,progress,color,time,reduced) {
      disc(g,x,y,r,0x111726,.17,color,3);
      const phase=reduced?0:Math.sin(time/170)*.04;
      disc(g,x,y,r*Math.max(.06,1-clamp(progress)),color,.035+phase*.2,color,2);
      const gap=Math.min(22,r*.24),size=Math.min(18,r*.2);
      for(let i=0;i<4;i++){
        const a=i*Math.PI/2,p=ray({x,y},a,r);
        line(g,[ray(p,a,-size),p,ray(p,a+Math.PI/2,gap)],color,4,.9);
      }
      spark(g,x,y,7,color,.9);
      for(let i=0;i<12;i++)if(i/12<=progress){
        const p=ray({x,y},-Math.PI/2+i*Math.PI/6,r-9);
        g.fillStyle(color,.9);g.fillRect(pixel(p.x-2),pixel(p.y-2),4,4);
      }
    }
    function corridor(g,from,to,width,progress,palette) {
      const angle=Math.atan2(to.y-from.y,to.x-from.x),length=Math.hypot(to.x-from.x,to.y-from.y),half=width/2;
      polygon(g,[ray(from,angle,0,-half),ray(from,angle,length,-half),ray(from,angle,length,half),ray(from,angle,0,half)],palette.edge,.13,palette.light,3);
      for(let d=32;d<length;d+=84){
        const p=ray(from,angle,d),size=10;
        line(g,[ray(p,angle,-size,-size),ray(p,angle,0),ray(p,angle,-size,size)],palette.core,3,.45+progress*.4);
      }
      line(g,[from,to],palette.core,2,.32);
    }
    function cone(g,from,angle,range,halfAngle,color,alpha,stroke=0) {
      const points=[from];
      for(let i=0;i<=12;i++)points.push(ray(from,angle-halfAngle+halfAngle*2*i/12,range));
      polygon(g,points,color,alpha,stroke,2);
    }
    function breath(record,attack,time,reduced) {
      const {ground,front}=record,p=palette(attack),from=attack.from;
      const angle=attack.facing,range=attack.range,half=attack.halfAngle;
      if(attack.phase==='windup'){
        const start=Number.isFinite(attack.sweepFrom)?attack.sweepFrom:angle,end=Number.isFinite(attack.sweepTo)?attack.sweepTo:angle;
        cone(ground,from,(start+end)/2,range,half+Math.abs(end-start)/2,p.edge,.13,p.light);
        const radius=10+clamp(attack.progress)*20;
        image(record,'glow',p,from.x,from.y,radius*4,radius*4,0,reduced?.25:.6,5.7);
        image(record,'orb',p,from.x,from.y,radius*2,radius*2,time/1800,.85,5.9);
        for(let i=0;i<5;i++){
          const a=angle+i*Math.PI*2/5+time/340,v=ray(from,a,radius+12);
          line(front,[v,ray(from,a,radius*.45)],p.light,3,.7);
        }
        return;
      }
      if(attack.phase!=='active')return;
      cone(ground,from,angle,range,half,p.edge,.13,p.light);
      const animation=reduced?0:attack.elapsedMs/110,frame=Math.floor(animation)%4,blend=animation%1;
      // This textured triangle stays inside the exact radial cone telegraph.
      const length=range*Math.cos(half),width=2*range*Math.sin(half);
      image(record,'breath',p,from.x,from.y,length,width,angle,.95*(1-blend),5.4,0,frame);
      if(blend>0)image(record,'breath',p,from.x,from.y,length,width,angle,.95*blend,5.41,0,(frame+1)%4);
      image(record,'glow',p,from.x,from.y,110,110,0,reduced?.2:.6,5.6);
      for(let i=0;i<12;i++){
        const f=((i*73+time*(reduced?0:.52))%997)/997,distance=range*f;
        const side=Math.sin(i*18.1)*Math.tan(half)*distance*.9,pos=ray(from,angle,distance,side);
        front.fillStyle(i%3?p.light:p.core,.6);front.fillRect(pixel(pos.x),pixel(pos.y),i%4?4:8,4);
      }
      disc(front,from.x,from.y,12,p.core,.85);
    }
    function orb(record,shot,time,reduced) {
      const g=record.front;
      const p=palette(shot),r=shot.radius,angle=Math.atan2(shot.vy,shot.vx);
      const speed=Math.hypot(shot.vx,shot.vy),trail=Math.min(r*7,Math.max(r*3.8,speed*.16));
      if(speed>1)image(record,'trail',p,shot.x,shot.y,trail,r*1.6,angle,reduced?.25:.65,5.65,1);
      image(record,'glow',p,shot.x,shot.y,r*3.4,r*3.4,0,reduced?.2:.65,5.7);
      image(record,'orb',p,shot.x,shot.y,r*2/.88,r*2/.88,reduced?0:time/1800,.98,5.9);
      const phase=reduced?0:time/95;
      for(let i=0;i<3;i++){
        const a=i*Math.PI/3+phase*.14,points=[];
        for(let j=0;j<4;j++)points.push(ray(shot,a+j*.23,r*(.65+j*.13)+(j%2?4:-2)));
        line(g,points,i%2?p.light:p.accent,2,.9);
      }
      spark(g,shot.x+r*.4,shot.y-r*.4,5,p.core,.9);
    }
    function restore(record) {
      const owned=record?.owned;record&&(record.owned=null);
      if(!owned?.sprite?.scene)return;
      const {sprite,x,y,scaleX,scaleY,rotation,alpha,originX,originY}=owned;
      sprite.setPosition(x,y).setScale(scaleX,scaleY).setRotation(rotation)
        .setOrigin(originX,originY).setAlpha(alpha);
      // Visibility belongs to native faint/switch rendering, never this cache.
    }
    function beforeDraw(scene) {restore(scenes.get(scene));}
    function bodyFrame(actor,pose,angle,progress,loop=false) {
      if(actor.still)return;
      const animation=actor.clips?.[pose]||actor.clips?.idle;
      if(!animation)return;
      const clip=animation.clip,row=clip.rows>1?Math.min(clip.rows-1,mp(angle)):0;
      const phase=loop?((progress%1)+1)%1:clamp(progress);
      const column=Math.min(clip.frames-1,Math.floor(phase*clip.frames));
      actor.sprite.setTexture(animation.key,row*clip.frames+column);
      const anchor=XO(actor.speciesId,pose,row,column,clip.anchor);
      if(anchor)actor.sprite.setOrigin(anchor[0]/clip.frameWidth,anchor[1]/clip.frameHeight);
    }
    function animateBody(record,scene,fighter,attack,effects,time,reduced) {
      const actor=scene.actors?.get(fighter.id),sprite=actor?.sprite;
      if(!sprite?.scene||actor.speciesId!==fighter.speciesId||(attack.kind==='idle'&&attack.phase!=='enrage')){
        record.motion=null;return;
      }
      const base={sprite,x:sprite.x,y:sprite.y,scaleX:sprite.scaleX,scaleY:sprite.scaleY,
        rotation:sprite.rotation,alpha:sprite.alpha,originX:sprite.originX,originY:sprite.originY};
      record.owned=base;
      const progress=clamp(attack.progress),unit=Math.max(.4,fighter.radius/36),strength=reduced?.35:1;
      let sx=1,sy=1,lean=0,forward=0,lift=0,angle=attack.facing,pose='idle',frame=progress;
      if(attack.phase==='enrage'){
        const roar=Math.sin(progress*Math.PI),tension=Math.sin(clamp(progress/.38)*Math.PI/2);
        pose='shoot';frame=progress;sx=1+.1*roar;sy=1+.12*roar;
        lift=14*unit*roar;forward=-9*unit*roar;lean=-.13*tension*(1-progress);
      }else if(attack.kind==='dash'){
        if(attack.phase==='windup'){
          pose='shoot';frame=progress*.42;sx=1-progress*.13;sy=1+progress*.1;
          forward=-12*unit*progress;lean=-.12*progress;
        }else if(attack.phase==='active'){
          pose='shoot';frame=.42+progress*.58;sx=1.11;sy=.91;
          forward=6*unit;lean=(reduced?0:Math.sin(time/80)*.025);
        }else if(attack.phase==='recover'){
          pose=progress<.25?'hurt':'idle';frame=progress<.25?progress*4:progress;
          const settle=(1-progress)*Math.cos(progress*Math.PI*2);
          sx=1-settle*.07;sy=1+settle*.06;forward=-7*unit*settle;
        }
      }else if(attack.kind==='breath'){
        if(attack.phase==='windup'){
          pose='shoot';frame=progress*.48;sx=1+progress*.07;sy=1-progress*.06;
          lift=8*unit*progress;forward=-8*unit*progress;lean=-.08*progress;
        }else if(attack.phase==='active'){
          const beat=Math.max(1,attack.hitIntervalMs||200),pulse=Math.sin(Math.PI*clamp((attack.elapsedMs%beat)/(beat*.75)));
          pose='shoot';frame=.48+(attack.elapsedMs%beat)/beat*.5;
          sx=1+.035*pulse;sy=1-.025*pulse;forward=(-5-7*pulse)*unit;lift=5*unit;
          lean=-.055-.025*pulse;
        }else if(attack.phase==='recover'){
          pose='shoot';frame=.82+progress*.18;forward=-5*unit*(1-progress);lift=4*unit*(1-progress);
        }
      }else if(attack.kind==='plasma'){
        if(attack.phase==='windup'){
          pose='shoot';frame=progress*.4;sy=1+progress*.1;sx=1-progress*.07;
          lift=12*unit*progress;forward=-10*unit*progress;lean=-.12*progress;
        }else if(attack.phase==='active'){
          const interval=Math.max(1,attack.shotIntervalMs||170),recoilMs=interval*.94;
          const index=attack.mega?Math.min(3,Math.floor(attack.elapsedMs/interval)):0,age=attack.elapsedMs-index*interval;
          const fresh=(effects?.projectiles||[]).filter(shot=>shot.ageMs<=interval+q&&shot.ageMs<=attack.elapsedMs+q).sort((a,b)=>a.ageMs-b.ageMs)[0];
          angle=fresh?Math.atan2(fresh.vy,fresh.vx):(attack.shotAngles?.[index]??attack.facing+index*Math.PI/2);
          const kick=Math.sin(Math.PI*clamp(age/recoilMs))*Math.exp(-age/(interval*1.12));
          pose='shoot';frame=.35+clamp(age/recoilMs)*.65;forward=-25*unit*kick;lift=7*unit*kick;
          sx=1-kick*.11;sy=1+kick*.09;lean=-.19*kick;
        }else if(attack.phase==='recover'){
          pose='shoot';frame=.8+progress*.2;lift=4*unit*(1-progress);
        }
      }else if(attack.kind==='sky'){
        if(attack.phase==='windup'){
          pose='shoot';frame=progress*.45;sx=1-progress*.13;sy=1+progress*.12;
          lift=11*unit*progress;lean=-.13*progress;
        }else if(attack.phase==='rise'){
          pose='walk';frame=progress*2;angle=-Math.PI/2;
          sx=1-progress*.08;sy=1+progress*.08;
        }else if(attack.phase==='hover'){
          pose='idle';frame=time/600;angle=attack.facing;
        }else if(attack.phase==='fall'){
          angle=Math.atan2(attack.to.y-(attack.from.y-320),attack.to.x-attack.from.x);
          pose='shoot';frame=.4+progress*.6;sx=1-progress*.08;sy=1+progress*.14;
        }else if(attack.phase==='impact'){
          const spring=Math.exp(-progress*3)*Math.cos(progress*Math.PI*2);
          pose='hurt';frame=progress;sx=1+.2*spring;sy=1-.24*spring;lift=-9*unit*(1-progress);
          lean=.1*spring;
        }else if(attack.phase==='recover'){
          pose=progress<.3?'hurt':'idle';frame=progress<.3?progress/.3:progress;
          const sag=1-progress;sx=1+.04*sag;sy=1-.05*sag;lift=-4*unit*sag;
        }
      }
      bodyFrame(actor,pose,angle,frame,attack.phase==='hover'||attack.phase==='rise');
      const sign=Math.cos(angle)>=0?1:-1;
      const target={sx:1+(sx-1)*strength,sy:1+(sy-1)*strength,roll:lean*sign*strength,
        x:Math.cos(angle)*forward*strength,y:Math.sin(angle)*forward*strength-lift*strength};
      let motion=record.motion;
      if(!motion||motion.entry!==fighter.entry||motion.species!==fighter.speciesId||time<motion.time||time-motion.time>250){
        motion=record.motion={...target,entry:fighter.entry,species:fighter.speciesId,time};
      }else{
        const response=attack.phase==='impact'?22:attack.kind==='plasma'&&attack.phase==='active'?28:45;
        const mix=1-Math.exp(-Math.max(0,time-motion.time)/response);
        for(const key of ['sx','sy','roll','x','y'])motion[key]+=(target[key]-motion[key])*mix;
        motion.time=time;
      }
      sprite.setScale(base.scaleX*motion.sx,base.scaleY*motion.sy)
        .setRotation(base.rotation+motion.roll).setPosition(base.x+motion.x,base.y+motion.y);
      record.bodyAngle=angle;
      if(attack.mega&&!['rise','hover','fall'].includes(attack.phase)){
        const center={x:sprite.x,y:sprite.y-sprite.displayHeight*.34},radius=fighter.radius;
        for(const side of [-1,1]){
          const points=[];
          for(let i=0;i<9;i++){
            const sway=reduced?0:Math.sin(time/190+i*.72+side)*radius*.12;
            points.push(ray(center,angle,-i*radius*.26,side*(radius*.34+i*radius*.035)+sway));
          }
          line(record.body,points,0x72592b,6,.9);line(record.body,points,0xffdb69,3,.95);
        }
      }
    }
    function enrage(record,scene,fighter,attack,time,reduced) {
      if(!attack.enraged&&attack.phase!=='enrage')return;
      if(attack.kind==='sky'&&['rise','hover','fall'].includes(attack.phase))return;
      const sprite=scene.actors?.get(fighter.id)?.sprite;
      if(!sprite?.scene||!sprite.visible)return;
      const cue=attack.phase==='enrage',progress=clamp(attack.progress);
      const radius=Math.max(12,fighter.radius),center={x:sprite.x,y:sprite.y-sprite.displayHeight*.34};
      const strength=cue?Math.sin(progress*Math.PI):.24,spin=reduced?0:time/620;
      if(attack.kind==='dash'&&attack.phase==='active'){
        const threatRadius=Math.max(radius,attack.width/2);
        goldenGlow(record.ground,fighter.x,fighter.y,threatRadius,reduced);
        disc(record.ground,fighter.x,fighter.y,threatRadius,gold.edge,.075,gold.light,2);
        for(const side of [-1,1]){
          const edge=ray(fighter,attack.facing,0,side*threatRadius);
          line(record.front,[ray(edge,attack.facing,-radius*1.5),edge],gold.core,3,.7);
        }
      }
      // Golden arcs announce phase three without a full-screen flash.
      for(let side=0;side<3;side++){
        const points=[];
        for(let i=0;i<9;i++){
          const angle=spin+side*Math.PI*2/3+i*.13;
          const r=radius*(1.03+strength*.4)+(i%2?radius*.05:0);
          points.push(ray(center,angle,r));
        }
        line(record.body,points,gold.edge,7,cue?.7:.35);
        line(record.body,points,side===1?gold.core:gold.light,3,cue?.88:.52);
      }
      if(cue){
        const expansion=radius*(.65+progress*1.9),alpha=(1-progress)*(reduced?.35:.7);
        line(record.ground,Array.from({length:25},(_,i)=>ray(fighter,i*Math.PI/12,expansion)),0xe6d069,3,alpha);
        for(let i=0;i<8;i++){
          const angle=i*Math.PI/4,point=ray(center,angle,radius*(.8+progress));
          const end=ray(point,angle,radius*(.15+strength*.3));
          line(record.front,[point,end],i%2?gold.light:gold.core,3,alpha);
        }
      }
      if(!reduced)for(let i=0;i<6;i++){
        const phase=((time/660+i/6)%1),angle=i*2.399;
        const point=ray(center,angle,radius*.8);
        point.y-=phase*radius*.9;
        record.front.fillStyle(i%2?gold.light:gold.core,(1-phase)*(cue?.8:.42));
        record.front.fillRect(pixel(point.x),pixel(point.y),4,4);
      }
    }
    function serpent(record,scene,fighter,attack,time,reduced) {
      const actor=scene.actors?.get(fighter.id),sprite=actor?.sprite;
      if(!sprite?.scene)return;
      const angle=attack.facing;
      const width=Math.max(8,fighter.radius*.42),length=width*7*(attack.bodyStretch||1);
      const extension=attack.kind==='sky'?.12*(1-clamp(attack.progress)):
        attack.phase==='windup'?Math.pow(clamp(attack.progress),2)*.5:1;
      const head={x:sprite.x,y:sprite.y-sprite.displayHeight*.32};
      // The native sheet stays visible at the head. Banded segments extend its
      // serpentine body along the dash where the sheet has no straight pose.
      for(let i=11;i>=1;i--){
        const t=i/12,w=width*(1-t*.65),wave=reduced?0:Math.sin(time/80-i*.6)*4*t;
        const straight=ray(head,angle,-length*t,wave),turn=angle+Math.PI+t*Math.PI*2.2;
        const coil=ray(ray(head,angle,-width*1.5),turn,width*(.6+t*1.4));
        const center={x:coil.x+(straight.x-coil.x)*extension,y:coil.y+(straight.y-coil.y)*extension};
        if(attack.enraged){
          goldenGlow(record.body,center.x,center.y,w,reduced);
          disc(record.body,center.x,center.y,w*1.05,gold.edge,.15,gold.light,3);
        }
        image(record,'segment',green,center.x,center.y,w*2/.88,w*2/.82,angle,1,3.95);
        if(i%3===0){
          const a=ray(center,angle,0,-w*.76),b=ray(center,angle,0,w*.76);
          line(record.body,[a,b],0xf0d456,4,.95);
        }
        if(i===3||i===7){
          for(const side of [-1,1])polygon(record.body,[ray(center,angle,8,w*side*.55),ray(center,angle,-12,w*side*1.8),ray(center,angle,-16,w*side*.65)],0xb73b43,1,0xf1c45a,2);
        }
      }
      if(attack.mega)for(const side of [-1,1]){
        const ribbon=[];
        for(let i=0;i<=12;i++)ribbon.push(ray(head,angle,-length*i/12,side*(width*.8+Math.sin(i*.75-time/240)*width*.35)));
        line(record.body,ribbon,0x625526,7,.9);line(record.body,ribbon,0xffdc65,3,.95);
      }
      for(let i=0;attack.phase==='active'&&i<4;i++){
        const side=(i%2?1:-1)*(width+9+i*3),start=ray(head,angle,-length*(i*.15),side);
        line(record.front,[start,ray(start,angle,-38-i*12)],attack.enraged?(i%2?gold.core:gold.light):(i%2?0xf1de75:0xaaffd1),3,.65);
      }
    }
    function flight(record,scene,fighter,attack,time,reduced) {
      const actor=scene.actors?.get(fighter.id),sprite=actor?.sprite;
      if(!sprite?.scene)return;
      const landing=attack.to,r=attack.radius;
      reticle(record.ground,landing.x,landing.y,r,attack.phase==='fall'?clamp(attack.progress):.1,palette(attack).light,time,reduced);
      const height=Math.max(0,attack.flyHeight);
      disc(record.ground,fighter.x,fighter.y,Math.max(12,fighter.radius*(1-height/500)),0x10172a,.35);
      if(!record.air)record.air=scene.add.sprite(0,0,sprite.texture.key,sprite.frame.name).setDepth(6.1);
      const air=record.air,alpha=attack.phase==='hover'?.18:Math.max(.2,1-height/440);
      const progress=clamp(attack.progress),center={x:sprite.x+(.5-sprite.originX)*sprite.displayWidth,
        y:sprite.y+(.5-sprite.originY)*sprite.displayHeight-height};
      const spin=attack.phase==='rise'?(reduced?Math.sin(progress*Math.PI)*.1:progress*Math.PI*1.5):
        attack.phase==='hover'?(reduced?0:Math.sin(time/240)*.08):-Math.cos(record.bodyAngle??attack.facing)*.16;
      const sweep=attack.phase==='rise'&&!reduced?Math.sin(progress*Math.PI*2)*fighter.radius*.25:0;
      air.setTexture(sprite.texture.key,sprite.frame.name).setOrigin(.5,.5)
        .setPosition(center.x+sweep,center.y).setScale(sprite.scaleX*(1-height/900),sprite.scaleY*(1-height/900))
        .setRotation(sprite.rotation+spin)
        .setAlpha(alpha).setVisible(sprite.visible);
      sprite.setVisible(false);
      const color=palette(attack).light;
      if(attack.mega)for(const side of [-1,1]){
        const points=[],radius=fighter.radius*(1-height/900);
        for(let i=0;i<12;i++){
          const a=spin+i*.32+side*Math.PI;
          points.push({x:air.x+Math.cos(a)*(radius+i*radius*.06),y:air.y+Math.sin(a)*radius*.6+i*4});
        }
        line(record.front,points,0x6d592b,6,alpha);line(record.front,points,0xffdf70,3,alpha);
      }
      if(attack.phase==='rise')for(let i=0;i<5;i++){
        const x=air.x+(i-2)*fighter.radius*.38,offset=reduced?i*9:(time*.4+i*29)%95;
        line(record.front,[{x,y:air.y+offset+20},{x,y:air.y+offset+52}],color,3,.38);
      }
      if(attack.phase==='fall'){
        const top={x:landing.x,y:landing.y-height};
        line(record.front,[{x:top.x-9,y:top.y-110},landing],color,18,.15);
        line(record.front,[{x:top.x+9,y:top.y-70},landing],0xfff4cf,5,.6);
        for(let i=0;i<6;i++){
          const x=landing.x+(i-2.5)*13,offset=(time*.5+i*37)%130;
          line(record.front,[{x,y:landing.y-height-offset},{x,y:landing.y-height-offset-36}],color,3,.65);
        }
      }
    }
    function impact(record,effect,reduced) {
      const g=record.front;
      const progress=clamp(effect.ageMs/Math.max(1,effect.lifeMs)),p=palette(effect);
      const radius=effect.radius*(.3+.7*progress),alpha=(1-progress)*.85;
      image(record,'glow',p,effect.x,effect.y,radius*2.7,radius*2.7,0,alpha*(reduced?.1:.32),5.5);
      image(record,'shock',p,effect.x,effect.y,radius*2/.95,radius*2/.95,0,alpha,5.8);
      const seed=Array.from(String(effect.id||'')).reduce((value,char)=>(value*31+char.charCodeAt(0))%997,0);
      for(let i=0;i<12;i++){
        const a=i*Math.PI/6+seed*.17,point=ray(effect,a,radius*(.65+(i%3)*.12));
        const size=Math.max(2,10*(1-progress));
        polygon(g,[{x:point.x,y:point.y-size},{x:point.x+size,y:point.y},{x:point.x,y:point.y+size},{x:point.x-size,y:point.y}],i%3?p.light:p.accent,alpha);
      }
    }
    function meteor(record,meteor,time,reduced) {
      const p=meteor.enraged?gold:green,progress=clamp(meteor.progress);
      if(meteor.phase==='warning'||meteor.phase==='fall')reticle(record.ground,meteor.x,meteor.y,meteor.radius,progress,p.accent,time,reduced);
      if(meteor.phase!=='fall')return;
      const height=(1-progress)*270,head={x:meteor.x-height*.35,y:meteor.y-height};
      const size=Math.max(9,meteor.radius*.36),angle=Math.atan2(1,.35);
      image(record,'trail',p,head.x,head.y,size*7,size*2.3,angle,reduced?.3:.8,5.7,1);
      image(record,'glow',p,head.x,head.y,size*4,size*4,0,reduced?.15:.45,5.75);
      image(record,'meteor',p,head.x,head.y,size*2/.88,size*2/.88,reduced?0:progress*1.2,1,5.9);
      spark(record.front,head.x-5,head.y-9,5,p.core,.9);
    }
    function clear(scene) {
      const record=scenes.get(scene);if(!record)return;
      restore(record);
      for(const key of ['ground','body','front','air'])record[key]?.destroy();
      for(const sprite of record.images)sprite.destroy();
      for(const key of record.textures.values())if(scene.textures.exists(key))scene.textures.remove(key);
      scene.events?.off('shutdown',record.dispose);scene.events?.off('destroy',record.dispose);
      scenes.delete(scene);
    }
    function draw(scene,state) {
      const attack=state?.rocketBossAttack,effects=state?.rocketBossEffects;
      if(!attack||scene.net||state.phase!=='fight'){clear(scene);return;}
      let record=scenes.get(scene);
      if(record&&record.world!==scene.world){clear(scene);record=null;}
      if(!record){
        record={scene,world:scene.world,textureId:++textureSerial,textures:new Map(),images:[],used:0,
          ground:scene.add.graphics().setDepth(3.12),body:scene.add.graphics().setDepth(3.96),front:scene.add.graphics().setDepth(6),air:null};
        record.dispose=()=>clear(scene);scenes.set(scene,record);
        scene.events.once('shutdown',record.dispose);scene.events.once('destroy',record.dispose);
      }
      // Native draw has already restored the current sprite pose and visibility.
      record.air?.setVisible(false);
      record.used=0;
      record.ground.clear();record.body.clear();record.front.clear();
      const fighter=state.fighters?.find(actor=>actor.id===attack.actorId),time=(state.tick||0)*q;
      const reduced=ei().display.reduceFlash||Wq(),p=palette(attack);
      if(fighter?.hp>0){
        animateBody(record,scene,fighter,attack,effects,time,reduced);
        enrage(record,scene,fighter,attack,time,reduced);
        if(attack.kind==='dash'){
          if(attack.phase==='windup')corridor(record.ground,attack.from,attack.to,attack.width,clamp(attack.progress),p);
          if(attack.phase==='windup'||attack.phase==='active')serpent(record,scene,fighter,attack,time,reduced);
        } else if(attack.kind==='breath')breath(record,attack,time,reduced);
        else if(attack.kind==='plasma'&&attack.phase==='windup'){
          const radius=Math.max(6,attack.radius*(.25+clamp(attack.progress)*.75));
          orb(record,{x:attack.from.x,y:attack.from.y,vx:0,vy:0,radius,mega:attack.mega,enraged:attack.enraged},time,reduced);
          for(const angle of attack.shotAngles||[attack.facing]){
            const start=ray(attack.from,angle,radius+8),end=ray(attack.from,angle,radius+42);
            line(record.ground,[start,end],p.light,3,.65);
          }
        } else if(attack.kind==='sky'){
          if(['rise','hover','fall'].includes(attack.phase))flight(record,scene,fighter,attack,time,reduced);
          else if(attack.phase==='windup'){
            serpent(record,scene,fighter,attack,time,reduced);
            reticle(record.ground,attack.to.x,attack.to.y,attack.radius,clamp(attack.progress),p.light,time,reduced);
          }
        }
      }
      for(const shot of effects?.projectiles||[])orb(record,shot,time,reduced);
      for(const falling of effects?.meteors||[])meteor(record,falling,time,reduced);
      for(const burst of effects?.impacts||[])impact(record,burst,reduced);
      for(let i=record.used;i<record.images.length;i++)record.images[i].setVisible(false);
    }
    return Object.freeze({beforeDraw,draw,clear});
  }
  function patch(source) {
    return 'const rocketBossVfx=('+createRocketBossVfx.toString()+')();globalThis.rocketBossVfx=rocketBossVfx;\n'+source;
  }
  const api=Object.freeze({patch});
  globalThis.ArenaBossVfxAdapter=api;
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})();
