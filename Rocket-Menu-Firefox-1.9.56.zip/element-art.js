// Original combat accents. The same painter is embedded in the game and replay.
(() => {
  'use strict';

  function rocketDrawArenaFx(ctx, cue) {
    if (!ctx || !cue || !Number.isFinite(cue.x) || !Number.isFinite(cue.y)) return;
    const size = Number(cue.size);
    const isLine = cue.kind === 'line';
    const rawProgress = Number(cue.progress) || 0;
    const progress = isLine ? rawProgress - Math.floor(rawProgress) : Math.max(0, Math.min(1, rawProgress));
    if (!(size > 0) || (!isLine && progress >= 1)) return;
    if (isLine && !(Number.isFinite(cue.length) && cue.length > 0)) return;

    // Keep the swatches with the serialized function so all renderers share them.
    const swatches = rocketDrawArenaFx.swatches ||= {
      normal:   ['#9b7663', '#f8d8aa', '#fff5df'],
      fire:     ['#d13735', '#ff9433', '#fff0a5'],
      water:    ['#1476bf', '#40c9ea', '#d9ffff'],
      electric: ['#dd851c', '#ffe24a', '#fffddd'],
      grass:    ['#257353', '#7ed26d', '#e1f7a2'],
      ice:      ['#398ec2', '#86e6f0', '#f0ffff'],
      fighting: ['#bf4636', '#ff9162', '#ffe2ab'],
      poison:   ['#71379a', '#c569da', '#f3c5ff'],
      ground:   ['#906241', '#e6ac62', '#ffe1a2'],
      flying:   ['#6385c5', '#acdaf1', '#fcffff'],
      psychic:  ['#9a36a7', '#fa83ec', '#fff1ff'],
      bug:      ['#617728', '#c1d452', '#eff7a1'],
      rock:     ['#65554f', '#b69b7e', '#eed9ac'],
      ghost:    ['#493077', '#9c76e6', '#e3c9ff'],
      dragon:   ['#5135a7', '#a181fa', '#f1d5ff'],
      dark:     ['#393647', '#857a9c', '#d6c5dd'],
      steel:    ['#53677d', '#a9c0cc', '#f4f9ff'],
      fairy:    ['#bc528a', '#ffa4d0', '#fff2fa']
    };
    const key = String(cue.type || 'normal').toLowerCase();
    const type = Object.hasOwn(swatches, key) ? key : 'normal';
    const [shade, color, light] = swatches[type];
    if (cue.kind === 'motion') {
      const points = cue.points, now = Number(cue.now);
      const exposure = Math.max(35, Math.min(65, Number(cue.exposureMs) || 64));
      if (!Array.isArray(points) || points.length < 2 || !Number.isFinite(now)) return;
      // One small brush per element supplies the soft edges. Its horizontal
      // extent fits each observed segment, including the current projectile tip.
      const stamps = rocketDrawArenaFx.motionStamps ||= new Map();
      if (!stamps.has(type)) {
        const canvas = typeof OffscreenCanvas === 'function' ? new OffscreenCanvas(64, 32) :
          ctx.canvas?.ownerDocument?.createElement('canvas');
        if (canvas) { canvas.width = 64; canvas.height = 32; }
        const brush = canvas?.getContext('2d');
        if (brush) {
          const along = brush.createLinearGradient(0, 0, 64, 0);
          along.addColorStop(0, color + '68');
          along.addColorStop(.55, color + 'c4');
          along.addColorStop(1, light + 'e0');
          brush.fillStyle = along;
          brush.fillRect(0, 0, 64, 32);
          const across = brush.createLinearGradient(0, 0, 0, 32);
          across.addColorStop(0, '#ffffff00');
          across.addColorStop(.25, '#ffffff38');
          across.addColorStop(.43, '#ffffffd0');
          across.addColorStop(.5, '#ffffffff');
          across.addColorStop(.57, '#ffffffd0');
          across.addColorStop(.75, '#ffffff38');
          across.addColorStop(1, '#ffffff00');
          brush.globalCompositeOperation = 'destination-in';
          brush.fillStyle = across;
          brush.fillRect(0, 0, 64, 32);
        }
        stamps.set(type, brush ? canvas : null);
      }
      const stamp = stamps.get(type);
      if (!stamp) return;
      ctx.save();
      try {
        ctx.imageSmoothingEnabled = true;
        const alpha = ctx.globalAlpha;
        for (let i = Math.max(1, points.length - 4); i < points.length; i++) {
          const a = points[i - 1], b = points[i], elapsed = b.t - a.t;
          if (!(elapsed > 0) || b.t <= now - exposure || a.t >= now) continue;
          const from = Math.max(0, (now - exposure - a.t) / elapsed);
          const to = Math.min(1, (now - a.t) / elapsed);
          if (from >= to) continue;
          const dx = b.x - a.x, dy = b.y - a.y, distance = Math.hypot(dx, dy);
          if (!(distance > .15) || !Number.isFinite(distance)) continue;
          const age = now - (a.t + elapsed * (from + to) * .5);
          const freshness = Math.max(0, 1 - age / exposure);
          const width = size * (.62 + .38 * freshness);
          ctx.save();
          try {
            ctx.translate(a.x + dx * from, a.y + dy * from);
            ctx.rotate(Math.atan2(dy, dx));
            ctx.globalAlpha = alpha * .46 * freshness ** 1.65 * Math.min(1, distance / elapsed * 1.4);
            ctx.drawImage(stamp, 0, -width, distance * (to - from), width * 2);
          } finally {
            ctx.restore();
          }
        }
      } finally {
        ctx.restore();
      }
      return;
    }
    const luminous = type === 'fire' || type === 'electric' || type === 'psychic' ||
      type === 'dragon' || type === 'fairy' || type === 'ghost' || type === 'ice';
    const seed = Number(cue.seed) || 0;
    const phase = (seed % 997) * 2.39996;
    const tau = Math.PI * 2;
    const angle = Number.isFinite(cue.angle) ? cue.angle : 0;
    const style = String(cue.style || '').toLowerCase();
    const slash = style === 'melee' || style === 'slash' || style === 'dash';
    const area = ['zone', 'area', 'burst', 'ring', 'self'].includes(style);

    function paint(fill) {
      ctx.fillStyle = fill;
      ctx.fill();
    }
    function line(stroke, width) {
      ctx.strokeStyle = stroke;
      ctx.lineWidth = width;
      ctx.stroke();
    }
    function disk(x, y, radius, fill) {
      ctx.beginPath();
      ctx.arc(x, y, radius, 0, tau);
      paint(fill);
    }
    function bloom(x, y, rx, ry, strength) {
      if (!luminous || strength <= 0 || rx <= 0 || ry <= 0) return;
      // A soft, element-colored falloff made once and scaled to each cue. Use
      // ordinary alpha compositing so simultaneous bright attacks keep detail.
      const stamps = rocketDrawArenaFx.bloomStamps ||= new Map();
      if (!stamps.has(type)) {
        const stamp = typeof OffscreenCanvas === 'function' ? new OffscreenCanvas(64, 64) :
          ctx.canvas?.ownerDocument?.createElement('canvas');
        if (stamp) stamp.width = stamp.height = 64;
        const brush = stamp?.getContext('2d');
        if (brush) {
          const halo = brush.createRadialGradient(32, 32, 0, 32, 32, 32);
          halo.addColorStop(0, light);
          halo.addColorStop(.21, color + 'd9');
          halo.addColorStop(.51, color + '62');
          halo.addColorStop(.78, color + '19');
          halo.addColorStop(1, color + '00');
          brush.fillStyle = halo;
          brush.fillRect(0, 0, 64, 64);
        }
        stamps.set(type, brush ? stamp : null);
      }
      const stamp = stamps.get(type);
      if (!stamp) return;
      const alpha = ctx.globalAlpha;
      ctx.globalAlpha = alpha * strength;
      ctx.drawImage(stamp, x - rx, y - ry, rx * 2, ry * 2);
      ctx.globalAlpha = alpha;
    }
    function glint(x, y, length, width) {
      ctx.beginPath();
      ctx.moveTo(x + length, y);
      ctx.lineTo(x + length * .15, y + width * .22);
      ctx.lineTo(x, y + width);
      ctx.lineTo(x - length * .15, y + width * .22);
      ctx.lineTo(x - length, y);
      ctx.lineTo(x - length * .15, y - width * .22);
      ctx.lineTo(x, y - width);
      ctx.lineTo(x + length * .15, y - width * .22);
      ctx.closePath();
      paint(light);
    }
    function crescent(length, height, fill) {
      ctx.beginPath();
      ctx.moveTo(-length, height * .22);
      ctx.quadraticCurveTo(0, -height * 1.55, length * .97, 0);
      ctx.quadraticCurveTo(length * .32, -height * .72, -length, height * .22);
      paint(fill);
    }
    function flame(length, width, fill, bend) {
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.bezierCurveTo(-length * .12, -width, -length * .32, -width, -length * .52, -width * .68);
      ctx.quadraticCurveTo(-length * .47, -width * .33, -length * .40, -width * .20);
      ctx.quadraticCurveTo(-length * .77, -width * .82, -length, bend);
      ctx.quadraticCurveTo(-length * .74, -width * .06, -length * .64, width * .60);
      ctx.quadraticCurveTo(-length * .37, width * 1.16, -length * .06, width * .32);
      ctx.closePath();
      paint(fill);
    }
    function lance(length, width, fill, bend) {
      ctx.beginPath();
      ctx.moveTo(.035, 0);
      ctx.quadraticCurveTo(-length * .07, -width * 1.2, -length * .55, bend - width * .55);
      ctx.lineTo(-length, bend);
      ctx.quadraticCurveTo(-length * .60, bend + width * .38, -length * .19, width * .83);
      ctx.quadraticCurveTo(-length * .04, width, .035, 0);
      paint(fill);
    }
    function flameJet(length, width, fill, bend) {
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.bezierCurveTo(0, -width, -length * .15, -width * 1.6, -length * .27, -width * .80);
      ctx.bezierCurveTo(-length * .29, -width * 1.53, -length * .49, -width * 1.40, -length * .56, -width * .61);
      ctx.bezierCurveTo(-length * .64, -width * 1.05, -length * .82, -width, -length, bend);
      ctx.bezierCurveTo(-length * .81, bend + width * .24, -length * .76, width * 1.26, -length * .57, width * .58);
      ctx.bezierCurveTo(-length * .45, width * 1.60, -length * .28, width * 1.16, -length * .25, width * .82);
      ctx.bezierCurveTo(-length * .13, width * 1.30, -length * .03, width * .72, 0, 0);
      paint(fill);
    }
    function bolt(length, width, bend) {
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(-length * .28, bend - width * .8);
      ctx.lineTo(-length * .42, bend + width * .43);
      ctx.lineTo(-length * .62, bend - width * .44);
      ctx.lineTo(-length, bend);
      line(shade, width * .6);
      line(color, width * .38);
      line(light, width * .12);
      ctx.beginPath();
      ctx.moveTo(-length * .42, bend + width * .43);
      ctx.lineTo(-length * .51, bend + width * 1.22);
      ctx.lineTo(-length * .73, bend + width * 1.65);
      line(color, width * .18);
    }
    function shard(length, width, mineral) {
      // Cleaved planes let the debris read as rock, metal or ice at sprite scale.
      ctx.beginPath();
      ctx.moveTo(0, -width * .36);
      ctx.lineTo(-length * .22, -width);
      ctx.lineTo(-length * .76, -width * .72);
      ctx.lineTo(-length, mineral ? width * .27 : 0);
      ctx.lineTo(-length * .54, width);
      ctx.lineTo(-length * .1, width * .65);
      ctx.closePath();
      paint(shade);
      ctx.beginPath();
      ctx.moveTo(0, -width * .36);
      ctx.lineTo(-length * .22, -width);
      ctx.lineTo(-length * .76, -width * .72);
      ctx.lineTo(-length * .58, width * .04);
      ctx.closePath();
      paint(color);
      ctx.beginPath();
      ctx.moveTo(-length * .22, -width);
      ctx.lineTo(-length * .76, -width * .72);
      line(light, width * .13);
    }
    function mark(length, width, offset) {
      const bend = width * Math.sin(phase + offset + progress * 4) * .65;
      switch (type) {
        case 'fire':
          if (cue.kind === 'trail') {
            flameJet(length, width, shade, bend);
            flameJet(length * .95, width * .80, color, bend);
            flameJet(length * .72, width * .37, light, 0);
          } else {
            flame(length, width, shade, bend);
            flame(length * .84, width * .70, color, bend * .62);
            flame(length * .49, width * .35, light, 0);
          }
          break;
        case 'electric':
          bolt(length, width, bend);
          if (cue.kind === 'trail') {
            disk(0, 0, width * .46, color);
            disk(0, 0, width * .27, light);
          }
          break;
        case 'water':
          lance(length, width, shade, bend);
          lance(length * .91, width * .68, color, bend);
          lance(length * .66, width * .26, light, bend * .63);
          disk(-length * .61, bend - width * .89, width * .26, light);
          disk(-length * .84, bend + width * .80, width * .18, color);
          break;
        case 'rock': case 'ground': case 'steel': case 'ice':
          shard(length * (type === 'rock' || type === 'ground' ? .54 : .85),
            width * (type === 'rock' || type === 'ground' ? 1.02 : .67), type !== 'ice');
          if (type === 'ground') disk(-length * .77, bend, width * .33, color);
          break;
        case 'grass': case 'bug':
          ctx.beginPath();
          ctx.moveTo(0, 0);
          ctx.quadraticCurveTo(-length * .21, -width * 1.45, -length * .85, bend);
          ctx.quadraticCurveTo(-length * .41, width * 1.37, 0, 0);
          paint(color);
          ctx.beginPath();
          ctx.moveTo(-length * .06, 0);
          ctx.quadraticCurveTo(-length * .35, width * .12, -length * .73, bend);
          line(type === 'bug' ? light : shade, width * .18);
          break;
        case 'poison':
          disk(-width * .69, 0, width * .82, shade);
          disk(-width * .65, -width * .15, width * .67, color);
          disk(-width * .50, -width * .40, width * .16, light);
          disk(-length * .78, bend, width * .33, shade);
          break;
        case 'ghost': case 'dark':
          flame(length * .89, width * .69, shade, bend + width);
          crescent(length * .45, width, color);
          break;
        case 'psychic': case 'dragon':
          lance(length, width, shade, bend);
          lance(length * .89, width * .69, color, bend);
          lance(length * .72, width * .31, light, bend * .77);
          if (type === 'psychic') {
            ctx.beginPath();
            ctx.ellipse(-length * .26, 0, width * .28, width * 1.28, -.20, 0, tau);
            if (cue.kind === 'trail') {
              ctx.moveTo(-length * .62 + width * .20, bend);
              ctx.ellipse(-length * .62, bend, width * .20, width * .81, -.20, 0, tau);
            }
            line(light, width * .14);
          }
          break;
        case 'fairy':
          glint(-length * .24, 0, length * .28, width * 1.05);
          disk(-length * .72, bend - width * .6, width * .16, color);
          break;
        case 'flying':
          crescent(length * .65, width, color);
          crescent(length * .46, width * .73, light);
          break;
        default:
          lance(length * .81, width, color, 0);
          lance(length * .51, width * .39, light, 0);
      }
    }

    // Normalized local space: muzzle at zero, the visible end at +span, one
    // unit is the beam's half-width. Periodic movement wraps during held casts.
    function drawLine(span) {
      const time = progress * tau;
      const steps = Math.max(8, Math.min(28, Math.ceil(span * 1.4)));
      const electric = type === 'electric';
      bloom(span * .50, 0, span * .50, electric ? 1.12 : 2.15, .26);
      bloom(span, 0, electric ? .90 : 1.33, electric ? .90 : 1.33, .20);
      if (electric) {
        const branches = Math.max(3, Math.min(13, Math.round(span / 1.5)));
        const jointY = i => i === 0 || i === branches ? 0 :
          (i % 2 ? 1 : -1) * (.26 + .22 * Math.sin(i * 4.23 + phase + time));
        ctx.beginPath();
        ctx.moveTo(0, 0);
        for (let i = 1; i <= branches; i++) ctx.lineTo(span * i / branches, jointY(i));
        line(shade, .32);
        line(color, .19);
        line(light, .065);
        ctx.beginPath();
        for (let i = 2; i < branches; i += 3) {
          const start = span * i / branches, end = Math.min(span - start, 2.4);
          const y = jointY(i), side = y < 0 ? -1 : 1;
          ctx.moveTo(start, y);
          ctx.lineTo(start + end * .42, y + side * .47);
          ctx.lineTo(start + end * .65, y + side * .36);
          ctx.lineTo(start + end, y + side * .84);
        }
        line(color, .10);
        disk(span, 0, .29, color);
        disk(span, 0, .16, light);
        return;
      }

      const fire = type === 'fire', water = type === 'water';
      const waveCount = Math.max(2, Math.min(7, span / 3.6));
      function center(t) {
        const envelope = Math.sin(Math.PI * t);
        return (fire ? .13 : water ? .09 : .035) * envelope * Math.sin(t * waveCount * 4 + phase - time);
      }
      function radius(t) {
        if (fire) return (.27 + .66 * t) * (.86 + .14 * Math.sin(t * waveCount * tau - time + phase));
        if (water) return (.40 + .41 * t) * (.95 + .05 * Math.sin(t * waveCount * tau - time));
        return .61 + .06 * Math.sin(time - t * tau + phase);
      }
      function ribbon(fill, width, offset) {
        ctx.beginPath();
        for (let i = 0; i <= steps; i++) {
          const t = i / steps, y = center(t) + radius(t) * (offset - width);
          if (!i) ctx.moveTo(0, y); else ctx.lineTo(span * t, y);
        }
        for (let i = steps; i >= 0; i--) {
          const t = i / steps;
          ctx.lineTo(span * t, center(t) + radius(t) * (offset + width));
        }
        ctx.closePath();
        paint(fill);
      }
      // Clip the moving details to the native path even at point-blank range.
      ctx.save();
      ctx.beginPath();
      ctx.rect(0, -1.6, span, 3.2);
      ctx.clip();
      const opacity = ctx.globalAlpha;
      ctx.globalAlpha = opacity * .24;
      ribbon(color, 1.48, 0);
      ctx.globalAlpha = opacity;
      ribbon(shade, 1.0, 0);
      ribbon(color, .78, -.035);
      ribbon(light, fire ? .31 : water ? .22 : .35, -.02);

      const count = Math.max(2, Math.min(11, Math.ceil(span / (fire ? 1.85 : 2.7))));
      for (let i = 0; i < count; i++) {
        const u = (i + progress) / count;
        const x = span * u, y = center(u), r = radius(u);
        const side = i % 2 ? -1 : 1;
        if (fire) {
          const reach = Math.min(span / count, 2.4) * .62;
          ctx.beginPath();
          ctx.moveTo(x - reach, y + r * side * .55);
          ctx.bezierCurveTo(x - reach * .68, y + r * side * 1.17, x, y + r * side * 1.47, x + reach * .32, y + r * side * .69);
          ctx.quadraticCurveTo(x - reach * .12, y + r * side * .84, x - reach, y + r * side * .55);
          paint(color);
          ctx.beginPath();
          ctx.moveTo(x - reach * .76, y + r * side * .14);
          ctx.quadraticCurveTo(x - reach * .08, y + r * side * .91, x + reach * .25, y + r * side * .16);
          ctx.quadraticCurveTo(x - reach * .14, y + r * side * .47, x - reach * .76, y + r * side * .14);
          paint(light);
        } else if (water || type === 'flying' || type === 'ice') {
          const reach = Math.min(span / count, 3.4) * .88;
          ctx.beginPath();
          ctx.moveTo(x - reach, y + r * side * .58);
          ctx.quadraticCurveTo(x - reach * .35, y + r * side * .90, x, y + r * side * .39);
          line(light, r * .12);
          if (water) disk(x - reach * .13, y + r * side * .90, r * .095, light);
        } else if (type === 'psychic' || type === 'dragon' || type === 'fairy' || type === 'ghost') {
          ctx.beginPath();
          ctx.ellipse(x, y, .25, r * 1.48, -.17, 0, tau);
          line(color, .15);
          ctx.beginPath();
          ctx.ellipse(x, y, .25, r * 1.48, -.17, -.5, 1.75);
          line(light, .055);
        }
      }
      ctx.restore();
    }

    ctx.save();
    ctx.translate(cue.x, cue.y);
    ctx.rotate(angle);
    ctx.scale(size, size);
    ctx.lineJoin = 'round';
    ctx.lineCap = 'round';
    const opacity = ctx.globalAlpha;
    const fade = 1 - progress * progress;
    if (isLine) {
      drawLine(cue.length / size);
    } else if (cue.kind === 'trail') {
      ctx.globalAlpha = opacity * fade * .88;
      const length = (style === 'beam' ? 1.78 : 1.12) * (1 - .19 * progress);
      bloom(-.05, 0, .51, .41, .29);
      mark(length, .145 * (1 - .36 * progress), 0);
    } else if (cue.kind === 'cast') {
      ctx.globalAlpha = opacity * fade * .80;
      if (slash) {
        ctx.rotate(-1.10 + progress * 1.85);
        ctx.translate(.45, 0);
        ctx.rotate(Math.PI * .5);
        crescent(.61 + progress * .24, .34, shade);
        crescent(.60 + progress * .23, .24, color);
      } else {
        // Twin open arcs leave the casting sprite and the aiming direction clear.
        const radius = .38 + .35 * progress;
        for (let i = 0; i < 2; i++) {
          const start = i * Math.PI + .27 + progress * .55;
          ctx.beginPath();
          ctx.arc(0, 0, radius, start, start + (area ? 2.52 : 1.42));
          line(color, .048 * (1 - progress * .55));
        }
        ctx.translate(.39 + .32 * progress, 0);
        mark(.46, .11, .3);
      }
    } else if (cue.kind === 'hit') {
      const outward = 1 - (1 - progress) * (1 - progress);
      const count = area ? 7 : 5;
      if (size >= 33 && progress < .72) {
        const radius = .41 + outward * .29;
        bloom(0, 0, radius, radius, .31 * (1 - progress / .72));
      }
      if (type === 'fire' && progress > .18) {
        ctx.globalAlpha = opacity * Math.sin((progress - .18) * Math.PI / .82) * .22;
        for (let i = 0; i < 3; i++) {
          const spread = (i - 1) * (.13 + outward * .17);
          disk(spread, -.14 - outward * (.24 + .10 * Math.cos(i + phase)), .10 + .07 * outward, '#776b76');
        }
      }
      ctx.globalAlpha = opacity * fade * .92;
      for (let i = 0; i < count; i++) {
        const offset = Math.sin(i * 11.7 + phase);
        const direction = i * tau / count + phase + offset * .22;
        const reach = (.20 + outward * .76) * (.87 + .13 * offset);
        ctx.save();
        ctx.rotate(direction);
        ctx.translate(reach, 0);
        mark((.21 + outward * .18) * (1 + offset * .2), (.073 + .022 * offset) * (1 - progress * .34), i);
        ctx.restore();
      }
      if (progress < .56) {
        ctx.globalAlpha = opacity * (1 - progress / .56) * .80;
        glint(0, 0, slash ? .34 : .22, .16);
      }
    }
    ctx.restore();
  }

  globalThis.rocketDrawArenaFx = rocketDrawArenaFx;
})();
