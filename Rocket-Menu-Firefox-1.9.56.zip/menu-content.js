// Seeded native-legal loadouts belonging only to the menu exhibition world.
(() => {
  'use strict';
  function arenaMenuMoves(species,seed) {
    return arenaAnyMoveOnline(()=>{
      const random=lo(seed), defaults=un(species), current=defaults.slice();
      // Native sets contain four moves plus Dash, or five including Protect.
      // Protect is legal for every catalog entry and gives every role a move.
      if(current.length===4)current.push('protect');
      if(!Tn(species,current))throw Error('Invalid native menu loadout.');
      for(let round=0;round<2;round++){
        const slots=[0,1,3,4];
        for(let i=slots.length-1;i>0;i--){const j=Math.floor(random()*(i+1));[slots[i],slots[j]]=[slots[j],slots[i]];}
        for(const slot of slots){
          const choices=An(species,current,slot);
          if(!choices.length)continue;
          // Prefer some same-type moves without turning every set into the
          // same recommendation. The original species pool is always used.
          const typed=choices.filter(id=>dn(species).types.includes(V(id).typeName));
          const pool=typed.length&&random()<.65?typed:choices;
          const move=pool[Math.floor(random()*pool.length)], next=On(current,slot,move);
          if(!next||!Tn(species,next)||Qe(next)[slot].moveId!==move)throw Error('Invalid menu move assignment.');
          current.splice(0,current.length,...next);
        }
      }
      // Random replacements can occasionally circle back to the recommendation.
      // Ensure the exhibition actually uses a different move when one is legal.
      if(current.every(id=>id==='protect'||defaults.includes(id))){
        for(const slot of [1,3,4,0]){
          const choices=An(species,current,slot).filter(id=>!defaults.includes(id));
          if(!choices.length)continue;
          const next=On(current,slot,choices[Math.floor(random()*choices.length)]);
          if(!next||!Tn(species,next))throw Error('Invalid alternate menu loadout.');
          current.splice(0,current.length,...next);break;
        }
      }
      return current;
    });
  }
  function arenaMenuRespawnStart(scene,session) {
    const replacements={pending:new Map(),ready:new Map(),reserved:new Set(),retry:new Map(),running:0};
    session.menuReplacements=replacements;
    session.world.menuReplacement=(fighter,index)=>{
      const next=replacements.ready.get(fighter.id);
      if(!next)return null;
      const actor=scene.actors[index];
      actor.id=next.species;actor.art=next.art.art;actor.pose='idle';actor.poseTick=session.world.tick;
      actor.lastX=NaN;actor.lastY=NaN;actor.entry=0;actor.drawn='';
      actor.view.dataset.species=next.species;
      next.art.view.remove();next.art.shadow.remove();
      replacements.ready.delete(fighter.id);replacements.reserved.delete(next.species);
      scene.game.canvas.dataset.menuBattleRoster=scene.actors.map(item=>item.id).join(',');
      return next;
    };
    arenaMenuPrepareRespawns(scene,session);
  }
  function arenaMenuPruneImages(scene,session) {
    if(!arenaMenuCurrent(scene,session)||session.menuReplacements?.running)return;
    const retained=new Set();
    for(const actor of [...scene.actors,...[...session.menuReplacements.ready.values()].map(item=>item.art)])
      for(const art of Object.values(actor.art))retained.add(art.source);
    for(const image of session.images)if(!retained.has(image)){image.close?.();session.images.delete(image);}
    for(const [url,image]of session.menuImageValues||[])if(!retained.has(image)){
      session.menuImageValues.delete(url);session.imageLoads.delete(url);
    }
  }
  function arenaMenuPrepareRespawns(scene,session) {
    const queue=session.menuReplacements;
    if(!queue||!arenaMenuCurrent(scene,session))return;
    for(const [index,fighter]of session.world.fighters().entries()){
      if(queue.running>=2)break;
      if(queue.ready.has(fighter.id)||queue.pending.has(fighter.id)||(queue.retry.get(fighter.id)||0)>session.world.tick)continue;
      const next=session.world.chooseMenuReplacement(fighter,queue.reserved);
      queue.reserved.add(next.species);queue.pending.set(fighter.id,next);queue.running++;
      (async()=>{
        let art=null;
        try {
          art=await arenaMenuLoadActor(scene,session,next.species,index);
          if(!art)throw Error('Replacement artwork unavailable.');
          if(!arenaMenuCurrent(scene,session))return;
          if(session.nativeVfx&&!session.nativeVfx.disposed){
            const missing=await Promise.all([Rz(cH(scene),next.loadout),qV(cH(scene),next.loadout)]);
            if(missing.some(keys=>keys.length))throw Error('Replacement move artwork unavailable.');
          }
          if(!arenaMenuCurrent(scene,session))return;
          queue.ready.set(fighter.id,{...next,art});art=null;queue.retry.delete(fighter.id);
        } catch {
          if(arenaMenuCurrent(scene,session))queue.retry.set(fighter.id,session.world.tick+180);
        } finally {
          art?.view.remove();art?.shadow.remove();queue.pending.delete(fighter.id);queue.running--;
          if(!queue.ready.has(fighter.id))queue.reserved.delete(next.species);
          if(arenaMenuCurrent(scene,session)){arenaMenuPruneImages(scene,session);arenaMenuPrepareRespawns(scene,session);}
        }
      })();
    }
  }
  function patch(original) {
    let source=original;
    function replace(before,after){const parts=source.split(before);if(parts.length!==2)throw Error('Unsupported menu content anchor: '+before.slice(0,80));source=parts.join(after);}
    if(source.includes('function arenaMenuMoves('))throw Error('Menu content already applied.');
    if(!source.includes('function arenaGmaxSpecies('))throw Error('Menu content requires the Gmax filter.');
    replace('function arenaMenuWorldType() {',[arenaMenuMoves,arenaMenuRespawnStart,arenaMenuPruneImages,arenaMenuPrepareRespawns].map(fn=>fn.toString()).join('\n')+'\nfunction arenaMenuWorldType() {');
    replace("if (ids.length !== 6 || new Set(ids).size !== 6) throw Error('Menu battle needs six distinct species.');",
      "if (ids.length !== 6 || new Set(ids).size !== 6 || ids.some(id=>arenaGmaxSpecies(dn(id)))) throw Error('Menu battle needs six eligible distinct species.');");
    replace('this.menuMembers = new Map();',
      'this.menuMembers = new Map();\n        this.menuRandom=lo((seed^0xa5f1523d)>>>0);\n        this.menuLoadouts = new Map(ids.map((species,index)=>[species,arenaMenuMoves(species,(seed^Math.imul(index+1,2246822519))>>>0)]));');
    replace('this.menuMembers.set(id, this.membersFrom([species], null));',
      'this.menuMembers.set(id, this.membersFrom([species], [fighter.loadout]));');
    replace('memberLoadout(id, species) { return un(species.id).slice(); }',
      `memberLoadout(id, species) { return (this.menuLoadouts?.get(species.id)??un(species.id)).slice(); }
      chooseMenuReplacement(actor,reserved=[]) {
        const excluded=new Set([...this.fighters().map(f=>f.speciesId),...reserved,actor.speciesId]);
        const pool=rn.filter(species=>!arenaGmaxSpecies(species)&&!excluded.has(species.id));
        if(!pool.length)throw Error('No different menu species available.');
        const species=pool[Math.floor(this.menuRandom()*pool.length)].id;
        return{species,loadout:arenaMenuMoves(species,Math.floor(this.menuRandom()*0x100000000)>>>0)};
      }`);
    replace('const point=this.spawnPoint(index), team=actor.menuTeam;\n          Object.assign(actor,this.makeFighter(actor.id,dn(actor.speciesId),point.x,point.y,index<3?0:Math.PI));',
      `const next=this.menuReplacement?this.menuReplacement(actor,index):this.chooseMenuReplacement(actor);
          if(!next)return;
          this.menuLoadouts.delete(actor.speciesId);this.menuLoadouts.set(next.species,next.loadout);
          const point=this.spawnPoint(index), team=actor.menuTeam;
          Object.assign(actor,this.makeFighter(actor.id,dn(next.species),point.x,point.y,index<3?0:Math.PI));`);
    replace('this.menuMembers.set(actor.id,this.membersFrom([actor.speciesId],null));',
      'this.menuMembers.set(actor.id,this.membersFrom([actor.speciesId],[actor.loadout]));\n          this.party=this.partyOf(this.player.id);this.foeParty=this.partyOf(this.opponent.id);this.thirdParty=this.partyOf(this.third.id);');
    replace('const random=lo(seed), ids=rn.map(species=>species.id);',
      'const random=lo(seed), ids=rn.filter(species=>!arenaGmaxSpecies(species)).map(species=>species.id);');
    replace('async function arenaMenuLoadActor(scene, session, id, index) {',
      'async function arenaMenuLoadActor(scene, session, id, index) {\n    if(arenaGmaxSpecies(dn(id)))return null;');
    replace('session.state=session.world.getState();scene.actors=actors;',
      'session.state=session.world.getState();scene.actors=actors;arenaMenuRespawnStart(scene,session);');
    replace('scene.game.canvas.dataset.menuBattleTick=String(session.world.tick);',
      'scene.game.canvas.dataset.menuBattleTick=String(session.world.tick);arenaMenuPrepareRespawns(scene,session);');
    replace('session.images.add(image);',
      '(session.menuImageValues??=new Map()).set(url,image);session.images.add(image);');
    replace('session.images.clear();session.imageLoads.clear();session.flashes=[];session.effects?.remove();',
      'session.images.clear();session.imageLoads.clear();session.menuImageValues?.clear();session.menuReplacements?.ready.clear();session.menuReplacements?.reserved.clear();if(session.world)session.world.menuReplacement=null;session.flashes=[];session.effects?.remove();');
    return source;
  }
  const api=Object.freeze({patch});
  globalThis.ArenaMenuContentAdapter=api;
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})();
