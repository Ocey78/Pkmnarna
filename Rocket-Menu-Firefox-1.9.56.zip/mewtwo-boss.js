// Private Mewtwo encounter: native party selection, scene lifecycle and boss HUD.
(() => {
  'use strict';
  function createArenaMewtwoBoss(){
    const source='rocket-mewtwo-boss',stage='rocket-psychic-cave',hp=6500,radius=30;
    const visualScale=species=>Qs.M*1.4/Qs[ec(species)];
    function register(scene){if(!scene.scene.manager.keys[source])scene.scene.manager.add(source,arenaMewtwoBossSceneType(),false);}
    function start(scene){arenaBossDifficulty.choose(scene,'mewtwo',()=>{register(scene);scene.scene.start('pick',{source});});}
    function launch(scene,team){
      if(scene.started||!Array.isArray(team)||team.length!==3)return;
      register(scene);scene.started=true;TT.ui('confirm');
      scene.scene.start(source,{source,stageId:stage,difficulty:'hard',seed:Rk(team[0]),
        playerSpeciesId:team[0],partyIds:team.slice(),partyLoadouts:arenaBossTeams.loadouts(team),
        opponentSpeciesId:'mewtwo',opponentPartyIds:['mewtwo']});
    }
    function hud(scene,state){
      const boss=state.fighters.find(actor=>actor.id==='opponent');if(!boss||!Z.hud)return;
      let view=scene.rocketMewtwoHud;
      if(!view){
        if(!document.getElementById('rocket-mewtwo-hud-style')){
          const style=document.createElement('style');style.id='rocket-mewtwo-hud-style';
          style.textContent=`
            .hud.rocket-mewtwo-boss .timer,.hud.rocket-mewtwo-boss .cluster.foe,.hud.rocket-mewtwo-boss .rocket-foe-party,
            .hud.rocket-mewtwo-boss .rocket-active-health[data-side="opponent"],.hud.rocket-mewtwo-boss .ffa-hud{display:none!important}
            .hud.rocket-mewtwo-boss .cluster.player,.hud.rocket-mewtwo-boss>.party{translate:0 var(--rocket-mewtwo-offset,84px)}
            .rocket-mewtwo-health{position:absolute;box-sizing:border-box;left:50%;top:8px;transform:translateX(-50%);
              width:min(760px,calc(100% - 112px));padding:8px 12px;border:3px solid var(--ui-frame-hi,#61799e);
              background:var(--ui-panel,#192c4c);box-shadow:0 0 0 2px #071326;color:var(--ui-text,#fff);
              font:700 13px/1.4 Silkscreen,monospace;pointer-events:none;z-index:4}
            .rocket-mewtwo-health[hidden]{display:none}.rocket-mewtwo-heading{display:flex;align-items:center;gap:8px;margin-bottom:5px}
            .rocket-mewtwo-heading img{width:28px;height:28px;object-fit:contain;image-rendering:pixelated}
            .rocket-mewtwo-name{flex:1;color:#d8b7ff}.rocket-mewtwo-value{font-size:11px;white-space:nowrap}
            .rocket-mewtwo-track{height:26px;border:2px solid #071326;background:#071326;overflow:hidden}
            .rocket-mewtwo-fill{height:100%;background:linear-gradient(#e6ccff 0 27%,#ae78e3 27% 74%,#6d42aa 74%);transform-origin:left}
            .rocket-mewtwo-level{font-size:9px;color:var(--ui-text-dim,#a5bbd7);margin-top:3px}
            .rocket-mewtwo-health.is-mega{border-color:#b69bea}.rocket-mewtwo-health.is-mega .rocket-mewtwo-name{color:#ffb5e3}
            .rocket-mewtwo-health.is-mega .rocket-mewtwo-fill{background:linear-gradient(#ffe0ef 0 27%,#d974bd 27% 74%,#89449f 74%)}
            @media(max-width:600px),(max-height:440px){.rocket-mewtwo-health{padding:5px 7px;font-size:10px}.rocket-mewtwo-value{font-size:9px}.rocket-mewtwo-heading img{width:20px;height:20px}.rocket-mewtwo-track{height:22px}}
          `;document.head.append(style);
        }
        const root=document.createElement('section');root.className='rocket-mewtwo-health';
        root.setAttribute('role','progressbar');root.setAttribute('aria-valuemin','0');
        const heading=document.createElement('div');heading.className='rocket-mewtwo-heading';
        const portrait=document.createElement('img');portrait.alt='';
        const name=document.createElement('span');name.className='rocket-mewtwo-name';
        const value=document.createElement('span');value.className='rocket-mewtwo-value';heading.append(portrait,name,value);
        const track=document.createElement('div');track.className='rocket-mewtwo-track';
        const fill=document.createElement('div');fill.className='rocket-mewtwo-fill';track.append(fill);
        const level=document.createElement('div');level.className='rocket-mewtwo-level';root.append(heading,track,level);
        const host=Z.hud;host.classList.add('rocket-mewtwo-boss');host.append(root);
        view=scene.rocketMewtwoHud={root,portrait,name,value,fill,level,host,key:'',layoutAt:0};
        scene.events.once('shutdown',()=>{root.remove();host.classList.remove('rocket-mewtwo-boss');host.style.removeProperty('--rocket-mewtwo-offset');scene.rocketMewtwoHud=null;});
      }
      view.root.hidden=state.phase!=='fight';
      const health=Math.max(0,Math.ceil(boss.hp)),maximum=boss.maxHp,mega=boss.speciesId==='mewtwomegax';
      const difficulty=scene.world.bossDifficulty||arenaBossDifficulty.get('mewtwo'),key=[health,maximum,mega,difficulty.id].join(':');
      if(view.key!==key){
        view.key=key;view.portrait.src=yp({id:boss.speciesId});view.name.textContent=mega?'MEGA MEWTWO X':'MEWTWO';
        view.value.textContent=health.toLocaleString()+' / '+maximum.toLocaleString();view.level.textContent=difficulty.label.toUpperCase();
        view.fill.style.transform='scaleX('+Math.max(0,Math.min(1,boss.hp/maximum))+')';view.root.classList.toggle('is-mega',mega);
        view.root.setAttribute('aria-valuemax',String(maximum));view.root.setAttribute('aria-valuenow',String(health));
        view.root.setAttribute('aria-label',view.name.textContent+' boss health');
      }
      if(!view.root.hidden&&performance.now()>=view.layoutAt){
        view.layoutAt=performance.now()+250;const width=view.host.clientWidth;let left=12,right=width-12;
        for(const node of view.host.querySelectorAll('.party,.cluster.player'))if(node.offsetWidth&&node.offsetHeight)left=Math.max(left,node.offsetLeft+node.offsetWidth+12);
        const pause=view.host.querySelector('.pause');if(pause?.offsetWidth)right=Math.min(right,pause.offsetLeft-10);
        const beside=right-left>=340;
        view.root.style.left=(beside?(left+right)/2:width/2)+'px';
        view.root.style.width=(beside?Math.min(760,right-left):Math.max(180,width-(pause?.offsetWidth?112:24)))+'px';
        view.host.style.setProperty('--rocket-mewtwo-offset',beside?'0px':(view.root.offsetHeight+10)+'px');
      }
    }
    return Object.freeze({source,stage,hp,radius,visualScale,start,launch,hud});
  }
  function arenaMewtwoBossSceneType(){
    return class RocketMewtwoScene extends RY {
      constructor(){super('rocket-mewtwo-boss');this.rocketMewtwoBoss=true;}
      init(data){
        super.init({...data,net:null,source:'cpu',difficulty:'hard',cpuSwitch:false,arenaCpuMode:null,
          stageId:arenaMewtwoBoss.stage,story:null,run:null,encounter:null});
        this.battleSource=arenaMewtwoBoss.source;this.aiEnabled=true;this.assist=null;this.rocketBossBadgeGranted=false;
        this.debugKo=this.debugUlt=false;this.debugFaint=this.debugBall=null;this.debugSwitchSlot=null;
      }
      async create(){
        const epoch=this.loadEpoch;await super.create();
        if(!this.alive||!this.ready||epoch!==this.loadEpoch)return;
        Z.onRepick=()=>{Lq();Z.hideResult();this.scene.start('pick',{source:arenaMewtwoBoss.source});};
        this.events.once('shutdown',()=>rocketMewtwoVfx.clear(this));
        arenaMewtwoBoss.hud(this,this.world.getState());
      }
      draw(state){
        this.rocketMewtwoIllusion=state.rocketMewtwoBoss?.attack.kind==='illusion';
        rocketMewtwoVfx.beforeDraw(this);super.draw(state);rocketMewtwoVfx.draw(this,state);arenaMewtwoBoss.hud(this,state);
      }
      publishAnchors(state){
        if(!this.rocketMewtwoIllusion)return super.publishAnchors(state);
        k_([...this.shown.entries()].filter(([id])=>id!=='opponent').map(([id,point])=>{
          const species=state.fighters.find(actor=>actor.id===id)?.speciesId||'',anchor=this.stackAnchor(species,point.x,point.y);
          return{id,x:anchor.x,y:anchor.y,frozen:point.freezeMs>0};
        }));
      }
      stackAnchor(species,x,y){
        const boss=this.world?.opponent,player=this.world?.player;
        if(boss?.speciesId===species&&(species!==player?.speciesId||Math.hypot(x-boss.x,y-boss.y)<Math.hypot(x-player.x,y-player.y)))
          return this.hudPoint(x,y-Qs[ec(species)]*arenaMewtwoBoss.visualScale(species));
        return super.stackAnchor(species,x,y);
      }
      settleMatch(phase){
        Fl(phase,0);Z.setResultCoins(null,false);Z.setResultStars(null);
        if(phase!=='victory'){this.rocketBossBadgeGranted=false;return;}
        const level=this.world?.bossDifficulty?.id,profile=globalThis.ArenaRocketProfile;
        if(!this.rocketBossBadgeGranted&&['expert','champion'].includes(level)&&profile?.awardBadge){
          this.rocketBossBadgeGranted=true;
          try{profile.awardBadge('mewtwo-'+level);}catch(error){console.warn('[rocket-profile] Boss badge could not be recorded',error);}
        }
      }
      noteCollection(){} lightRow(){} noteOwnRow(){}
    };
  }
  function patch(source){
    const once=(before,after)=>{const chunks=source.split(before);if(chunks.length!==2)throw Error('Unsupported Mewtwo boss anchor: '+before.slice(0,90));source=chunks.join(after);};
    once('launch(e,t){if(this.source===arenaEonBoss.source)',
      'launch(e,t){if(this.source===arenaMewtwoBoss.source){arenaMewtwoBoss.launch(this,e);return}if(this.source===arenaEonBoss.source)');
    once('this.rocketBossPick=t===arenaBossRush.source||t===arenaEonBoss.source;',
      'this.rocketBossPick=t===arenaBossRush.source||t===arenaEonBoss.source||t===arenaMewtwoBoss.source;');
    once('let e=t===arenaEonBoss.source?',
      'let e=t===arenaMewtwoBoss.source?`BOSS RUSH - MEWTWO / PSYCHIC CAVE`:t===arenaEonBoss.source?');
    once('this.world=new (this.rocketEonBoss?',
      'this.world=new (this.rocketMewtwoBoss?arenaMewtwoBossWorldType():this.rocketEonBoss?');
    once('hudObstacles(){let e=[','hudObstacles(){let e=[`.rocket-mewtwo-health`,');
    once('Wk(this.worldGraphics,n,t)',
      'this.rocketMewtwoBoss&&e.phase===`fight`&&t.add(`opponent`),Wk(this.worldGraphics,n,t)');
    once('visible:!!t?.sprite.visible&&!this.balls?.poseFor(e.id)',
      'visible:!!t?.sprite.visible&&!this.balls?.poseFor(e.id)&&!(this.rocketMewtwoIllusion&&e.id===`opponent`)');
    // The guessing mechanic must not expose the real actor through target lock.
    once('if (!ei().controls.autoAim) return result;',
      'if(state?.rocketMewtwoBoss?.attack.kind===`illusion`)return {...result,buttons:{...command.buttons,snapAim:false}};if (!ei().controls.autoAim) return result;');
    return 'const arenaMewtwoBoss=('+createArenaMewtwoBoss.toString()+')();globalThis.arenaMewtwoBoss=arenaMewtwoBoss;\n'+arenaMewtwoBossSceneType.toString()+'\n'+source;
  }
  globalThis.ArenaMewtwoBossAdapter=Object.freeze({patch});
  if(typeof module!=='undefined'&&module.exports)module.exports={patch};
})();
