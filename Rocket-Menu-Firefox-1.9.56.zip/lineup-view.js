// Runs in the verified game's module. Rows are rendered exclusively from known
// Pokémon IDs. Sharing and invite ownership/lifecycle belong to their bridges.
(() => {
  'use strict';

  function createTrainerTeamMemory(storage, validTeam) {
    const key='arena.rocket.opponent-teams.v1';
    let records=new Map();
    const identity=player=>{
      // Never use a name, room seat, connection secret, or transport ID as identity.
      for(const field of ['trainerId','clientId','playerId']){
        const id=player?.[field];
        if(typeof id==='string' && /^[a-zA-Z0-9_-]{8,128}$/.test(id))return field+':'+id;
      }
      return null;
    };
    try {
      const rows=JSON.parse(storage?.getItem(key)||'[]');
      if(Array.isArray(rows))for(const row of rows.slice(-1000)){
        if(Array.isArray(row)&&typeof row[0]==='string'&&validTeam(row[1]))records.set(row[0],row[1]);
      }
    } catch {}
    function remember(player,team){
      const id=identity(player);if(!id||!validTeam(team))return;
      if(JSON.stringify(records.get(id))===JSON.stringify(team))return;
      records.delete(id);records.set(id,team.slice());
      while(records.size>1000)records.delete(records.keys().next().value);
      try{storage?.setItem(key,JSON.stringify([...records]));}catch{}
    }
    function recall(player){const team=records.get(identity(player));return team&&validTeam(team)?team.slice():null;}
    return {remember,recall};
  }

  function createArenaLineupView() {
    let preview = null;
    let storage=null;try{storage=localStorage;}catch{}
    const memory=createTrainerTeamMemory(storage,team=>!!ids(team));

    function style() {
      if (document.getElementById('arena-lineup-style')) return;
      const sheet = document.createElement('style');
      sheet.id = 'arena-lineup-style';
      sheet.textContent = [
        '#online-root .arena-lineup, #arena-loading-lineups .arena-lineup {display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:3px;align-items:start;width:100%;min-width:0}',
        '#online-root .arena-lineup-host {display:block;min-width:0}',
        '#online-root .arena-lineup .mon, #arena-loading-lineups .mon {box-sizing:border-box;display:flex;flex-flow:column;align-items:center;justify-content:flex-start;text-align:center;width:auto;min-width:0;height:auto;min-height:0;padding:2px;background:transparent;border:0}',
        '#online-root .arena-lineup img, #arena-loading-lineups img {display:block;width:clamp(24px,4.5vw,48px);height:clamp(24px,4vw,42px);max-width:100%;object-fit:contain;image-rendering:pixelated}',
        '#online-root .arena-lineup-name, #arena-loading-lineups .arena-lineup-name {display:block;max-width:100%;white-space:normal;overflow-wrap:anywhere;font:600 clamp(9px,1.25vw,13px)/1.1 system-ui,sans-serif;color:inherit}',
        '#online-root .arena-lineup-note {display:block;margin:3px 0;text-align:center;font:500 clamp(10px,1.3vw,13px)/1.15 system-ui,sans-serif;color:inherit}',
        '#online-root .arena-lineup-source {font-size:10px;opacity:.85}',
        '#online-root .arena-lineup-share {display:block;margin:5px auto 0;padding:4px 8px;font:600 11px/1.15 system-ui,sans-serif;cursor:pointer}',
        '#online-root [data-screen="vs"] .arena-lineup img {width:clamp(32px,6vw,80px);height:clamp(30px,5.5vw,70px)}',
        '#online-root [data-screen="vs"] .arena-lineup-name {font-size:clamp(10px,1.6vw,17px)}',
        '#arena-loading-lineups {pointer-events:none;position:absolute;z-index:45;left:50%;top:max(6px,env(safe-area-inset-top));transform:translateX(-50%);display:flex;gap:8px;justify-content:center;padding:5px 9px;max-width:92%;width:max-content;color:#eef4f0;background:#172530ec;border:1px solid #658079;border-radius:6px}',
        '#arena-loading-lineups[hidden]{display:none}#arena-loading-lineups>div {width:clamp(108px,23vw,235px);min-width:0;text-align:center}',
        '#arena-loading-lineups strong {display:block;font:700 10px/1.2 system-ui,sans-serif;margin-bottom:2px}#arena-loading-lineups img{width:28px;height:24px}',
        '@media(max-height:460px){#online-root .arena-lineup img{width:28px;height:23px}#arena-loading-lineups img{width:18px;height:16px}#arena-loading-lineups{padding:3px 6px}}'
      ].join('\n');
      document.head.append(sheet);
    }

    function ids(value, allowPartial = false) {
      if (!Array.isArray(value) || value.length > 3 || (!allowPartial && value.length !== 3)) return null;
      const list = [];
      for (const entry of value) {
        if (allowPartial && entry == null) continue;
        const id = typeof entry === 'string' ? entry : entry?.speciesId ?? entry?.id;
        if (typeof id !== 'string' || !Qt.has(id) || list.includes(id)) return null;
        list.push(id);
      }
      return list.length ? list : null;
    }

    function disclosed(room, seat, player) {
      for (const source of [room.teams?.[seat], player.team, player.species, player.partyIds]) {
        const team = ids(source) ?? ids(source?.species) ?? ids(source?.ids);
        if (team) return team;
      }
      return null;
    }

    function roomData(controller, room, mine, seat) {
      const player = room.seats?.[Fc(seat)];
      if (!player?.present) return {message:'Seat open'};
      if (seat === room.you) return {team:ids(mine,true),message:'Choose your team'};

      const official = disclosed(room,seat,player);
      if (official && !player.editing) return {team:official};
      if (controller?.active && controller.room?.code === room.code) {
        const live = ids(arenaLobbyShare.forSeat(controller,seat));
        if (live) return {team:live,source:'Shared by player'};
        const snapshot = ids(arenaLineupInvite.forSeat(controller,seat));
        if (snapshot) return {team:snapshot,source:'From invite'};
      }
      const identity=controller?arenaLobbyShare.identity(controller,seat):null;
      const previous=memory.recall(identity?{clientId:identity}:player);
      if(previous)return {team:previous,previous:true};
      return {message:player.editing?'Choosing a team':'Team not revealed'};
    }

    function note(text, extra) {
      const el = document.createElement('span');
      el.className = 'arena-lineup-note' + (extra ? ' ' + extra : '');
      el.textContent = text;
      return el;
    }

    function portraits(team) {
      const row = document.createElement('div');
      row.className = 'team arena-lineup';
      for (const id of team) {
        const name = dn(id).name, cell = document.createElement('span');
        cell.className = 'mon arena-lineup-cell'; cell.title = name; cell.dataset.species = id;
        const image = document.createElement('img');
        image.alt = name; image.decoding = 'async';
        image.addEventListener('error',()=>{image.style.visibility='hidden';},{once:true});
        image.src = yp({id});
        const label = document.createElement('span');
        label.className = 'arena-lineup-name'; label.textContent = name;
        cell.append(image,label); row.append(cell);
      }
      return row;
    }

    function fill(container, data) {
      if (!container) return;
      const key = JSON.stringify([data.team ?? null,data.source ?? null,data.message ?? null]);
      if (container.dataset.arenaLineupKey === key) return;
      const pieces = data.team ? [portraits(data.team)] : [note(data.message ?? 'Team not revealed')];
      if (data.source) pieces.push(note(data.source,'arena-lineup-source'));
      container.classList.add('arena-lineup-host');
      container.replaceChildren(...pieces);
      container.dataset.arenaLineupKey = key;
    }

    function shareControl(section, room, controller) {
      let button = section.querySelector('[data-action="arena-share-lineup"]');
      const mine = section.querySelector('[data-team="you"]')?.parentElement;
      const sharing = controller && arenaLobbyShare.shared(controller);
      const available = controller && arenaLobbyShare.available(controller);
      if (!mine || !controller?.active || room.mode === 'ffa3' || (!sharing && !available)) {
        button?.remove(); return;
      }
      if (!button) {
        button = document.createElement('button');
        button.type = 'button'; button.className = 'px-btn arena-lineup-share';
        button.dataset.action = 'arena-share-lineup';
        button.addEventListener('click', () => {
          if (hO !== controller || !controller.active) return;
          arenaLobbyShare.set(controller,!arenaLobbyShare.shared(controller));
          refresh();
        });
        mine.append(button);
      }
      button.textContent = sharing ? 'Stop sharing' : 'Share my team';
      button.setAttribute('aria-pressed',String(!!sharing));
      button.title = arenaLobbyShare.compatible(controller)
        ? 'Share your current team with the other player in this room.'
        : 'The other player needs the lineup add-on to see your team.';
    }

    function renderRoom(section, room, mine, controller) {
      if (!section || !room || !['A','B','C'].includes(room.you)) return;
      style();
      for (const seat of room.mode === 'ffa3' ? ['A','B','C'] : ['A','B']) {
        const key = room.you === seat ? 'you' : room.mode === 'ffa3' ? seat : 'foe';
        const data=roomData(controller,room,mine,seat);
        fill(section.querySelector('[data-team="'+key+'"]'),data);
        const status=section.querySelector('[data-seat="'+key+'"] .seat-state');
        status?.querySelector('.rocket-previous-team')?.remove();
        if(data.previous && status){
          const label=document.createElement('span');label.className='rocket-previous-team';label.textContent='PREVIOUS TEAM';
          label.title='Last team seen in battle. Their current team may be different.';
          label.style.cssText='margin-left:auto;font-size:10px';status.append(label);
        }
      }
      shareControl(section,room,controller);
    }

    function refresh() {
      const section = document.querySelector('#online-root [data-screen="room"]');
      const controller = hO;
      if (!controller?.active || !section || section.dataset.arenaRoom !== controller.room?.code) return;
      renderRoom(section,controller.room,controller.team,controller);
    }
    document.addEventListener('arena-lineup-change',refresh);

    function mount(section, room, mine, controller) {
      section.dataset.arenaRoom = room.code;
      if (controller) arenaLineupInvite.update(controller);
      renderRoom(section,room,mine,controller);
      if (controller) arenaLineupInvite.mount(controller,section);
    }

    function stopPreview() {
      if (!preview) return;
      cancelAnimationFrame(preview.frame);
      preview.node.remove(); preview = null;
    }

    function start(controller, match) {
      stopPreview(); style();
      const client = controller.battle, teams = match.teams, you = controller.you;
      if (!client || !teams || !['A','B','C'].includes(you) || controller.result) return;
      const seats = [you,...(teams.C ? ['A','B','C'] : ['A','B']).filter(seat=>seat!==you)];
      const lineups = seats.map(seat=>ids(teams[seat]));
      if (lineups.some(team=>!team)) return;
      const vs = document.querySelector('#online-root [data-screen="vs"]');
      for (let i=0; vs && i<seats.length; i++) {
        const key = i===0 ? 'you' : teams.C ? seats[i] : 'foe';
        const nativeRow = vs.querySelector('[data-team="'+key+'"] > .team');
        if (nativeRow) nativeRow.replaceWith(portraits(lineups[i]));
      }

      // The stock versus screen is brief. Keep the confirmed teams available
      // while the arena loads without pausing the countdown or intercepting input.
      if (client.acceptsInput() || client.getState()?.tick > 0) return;
      const node = document.createElement('aside');
      node.id = 'arena-loading-lineups'; node.hidden = true;
      node.setAttribute('aria-label','Match lineups');
      for (let i=0; i<seats.length; i++) {
        const group = document.createElement('div'), label = document.createElement('strong');
        group.dataset.seat = seats[i]; label.textContent = i===0 ? 'Your team' : teams.C ? 'Player '+seats[i] : 'Opponent';
        group.append(label,portraits(lineups[i]));node.append(group);
      }
      (document.getElementById('rotator') ?? document.body).append(node);
      preview = {node,frame:0};
      function update() {
        if (!controller.active || controller.result || controller.battle !== client || client.stopped ||
            client.acceptsInput() || client.getState()?.tick > 0 || !['vs','fight'].includes(controller.mode)) {
          stopPreview();return;
        }
        node.hidden = !!(vs?.isConnected && vs.getClientRects().length);
        preview.frame = requestAnimationFrame(update);
      }
      update();
    }
    function rememberMatch(controller,match){
      for(const seat of ['A','B','C']){
        if(seat===controller.you||!match.teams?.[seat])continue;
        const id=arenaLobbyShare.identity(controller,seat);
        memory.remember(id?{clientId:id}:controller.room?.seats?.[Fc(seat)],ids(match.teams[seat]));
      }
    }
    return {mount,start,rememberMatch};
  }

  function patch(original) {
    let source = original;
    function replace(anchor,replacement) {
      const index = source.indexOf(anchor);
      if (index < 0 || source.indexOf(anchor,index+anchor.length)!==-1) throw Error('Unsupported game build. Missing or ambiguous lineup-view anchor.');
      source = source.slice(0,index) + replacement + source.slice(index+anchor.length);
    }
    replace('function iO(e,t,n,r,i,a){','const createTrainerTeamMemory='+createTrainerTeamMemory.toString()+';\nconst arenaLineupView=('+createArenaLineupView.toString()+')();\nfunction iO(e,t,n,r,i,a){');
    replace('e.appendChild(s),s.inert=!!e.querySelector(`[data-room-invite-dialog]`)',
      'e.appendChild(s),arenaLineupView.mount(s,t,n,hO),s.inert=!!e.querySelector(`[data-room-invite-dialog]`)');
    replace('t||cO(ZD(),e.teams,this.you,`FIGHT`);let o=this.lifetime.guard',
      't||cO(ZD(),e.teams,this.you,`FIGHT`);arenaLineupView.start(this,e);let o=this.lifetime.guard');
    replace('arenaLineupInvite.clear(this);arenaLobbyShare.close(this);', 'arenaLineupView.rememberMatch(this,e);arenaLineupInvite.clear(this);arenaLobbyShare.close(this);');
    replace('typeof navigator.share==`function`?i.share():oO(e,r,t.code)', 'oO(e,r,t.code)');
    replace('${tT(t,n).map(e=>`<a class="px-btn share-btn" data-share="${e.id}" href="${mO(e.href)}" target="_blank" rel="noopener noreferrer">${e.label}</a>`).join(``)}', '<button type="button" class="px-btn" data-action="copy-invite-link">COPY LINK</button>');
    replace('r.querySelector(`[data-action="close-invite"]`)?.addEventListener(`click`,i)', 'r.querySelector(`[data-action="copy-invite-link"]`)?.addEventListener(`click`,async()=>{try{await navigator.clipboard.writeText(t);fO(e,`Link copied`)}catch{window.prompt(`Copy link:`,t)}}),r.querySelector(`[data-action="close-invite"]`)?.addEventListener(`click`,i)');
    return source;
  }

  const api = Object.freeze({patch});
  globalThis.ArenaLineupViewAdapter = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})();
