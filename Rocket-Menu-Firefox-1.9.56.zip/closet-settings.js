// Session-only tab visibility; its preferences remain local to this device.
(() => {
  'use strict';
  function createRocketCloset(){
    const key='arena.rocket.closet.autoprotect.v1',dashKey='arena.rocket.closet.dashprotect.v1',statusKey='arena.rocket.closet.autostatus.v1',bossKey='arena.rocket.closet.bossmoves.v1';
    let shown=false,autoProtect=false,dashProtect=false,autoStatus=false,bossMoves=false;
    try{autoProtect=localStorage.getItem(key)==='on';}catch{}
    try{dashProtect=localStorage.getItem(dashKey)==='on';}catch{}
    try{autoStatus=localStorage.getItem(statusKey)==='on';}catch{}
    try{bossMoves=localStorage.getItem(bossKey)==='on';}catch{}
    function refresh(){
      if(!pE)return;
      if(!shown&&hE==='closet'){hE='data';gE=0;}
      WE();
      if(hE==='data')lE?.querySelector('[data-rocket-data-action="export-xml"]')?.focus({preventScroll:true});
    }
    function setAutoProtect(value){
      autoProtect=value===true;
      try{localStorage.setItem(key,autoProtect?'on':'off');}catch{}
    }
    function setDashProtect(value){
      dashProtect=value===true;
      try{localStorage.setItem(dashKey,dashProtect?'on':'off');}catch{}
    }
    function setAutoStatus(value){
      autoStatus=value===true;
      try{localStorage.setItem(statusKey,autoStatus?'on':'off');}catch{}
    }
    function setBossMoves(value){
      bossMoves=value===true;
      try{localStorage.setItem(bossKey,bossMoves?'on':'off');}catch{}
      if(typeof document!=='undefined')document.dispatchEvent(new Event('arena-boss-moves-settings'));
    }
    function toggle(code){
      if(code!=='THECLOSET14')return null;
      shown=!shown;
      // Let Data finish its import feedback before rebuilding native rows.
      queueMicrotask(refresh);
      return shown?'CLOSET shown':'CLOSET hidden';
    }
    function choose(value,kind='closetAutoProtect'){
      const restoreFocus=document.activeElement?.closest?.('#settings [data-kind="'+kind+'"]');
      if(kind==='closetBossMoves')setBossMoves(value);else if(kind==='closetAutoStatus')setAutoStatus(value);else if(kind==='closetDashProtect')setDashProtect(value);else setAutoProtect(value);
      NE();WE();
      if(restoreFocus)lE?.querySelector('[data-kind="'+kind+'"] [data-value="'+(value?'on':'off')+'"]')?.focus({preventScroll:true});
    }
    function settingsKey(event){
      if(!pE||(event.key!=='Enter'&&event.key!==' '))return false;
      const button=event.target?.closest?.('#settings [data-kind="closetAutoProtect"] [data-value],#settings [data-kind="closetDashProtect"] [data-value],#settings [data-kind="closetAutoStatus"] [data-value],#settings [data-kind="closetBossMoves"] [data-value]');
      if(!button)return false;
      event.preventDefault();event.stopPropagation();
      if(!event.repeat)choose(button.dataset.value==='on',button.closest('[data-kind]').dataset.kind);
      return true;
    }
    window.addEventListener('storage',event=>{
      if(event.key!==key&&event.key!==dashKey&&event.key!==statusKey&&event.key!==bossKey&&event.key!==null)return;
      if(event.key===key||event.key===null)autoProtect=event.key!==null&&event.newValue==='on';
      if(event.key===dashKey||event.key===null)dashProtect=event.key!==null&&event.newValue==='on';
      if(event.key===statusKey||event.key===null)autoStatus=event.key!==null&&event.newValue==='on';
      if(event.key===bossKey||event.key===null){bossMoves=event.key!==null&&event.newValue==='on';document.dispatchEvent(new Event('arena-boss-moves-settings'));}
      if(pE&&hE==='closet')WE();
    });
    return Object.freeze({isVisible:()=>shown,toggle,getAutoProtect:()=>autoProtect,setAutoProtect,getDashProtect:()=>dashProtect,setDashProtect,getAutoStatus:()=>autoStatus,setAutoStatus,getBossMoves:()=>bossMoves,setBossMoves,choose,settingsKey});
  }
  function patch(source){
    function once(before,after){
      const parts=source.split(before);
      if(parts.length!==2)throw Error('Unsupported Closet settings anchor: '+before);
      source=parts.join(after);
    }
    once('iE={game:`GAME`,', 'iE={closet:`CLOSET`,game:`GAME`,');
    once('function aE(e,t,n){', 'function aE(e,t,n){if(e===`closet`)return rocketCloset.isVisible()?[`closetAutoProtect`,`closetDashProtect`,`closetAutoStatus`,`closetBossMoves`]:[];');
    once('function FE(){return[`game`,...oE(AE(),EE,_E??void 0).filter(group=>group!==`profile`&&group!==`game`)]}',
      'function FE(){return[`game`,...oE(AE(),EE,_E??void 0).filter(group=>group!==`profile`&&group!==`game`&&group!==`closet`),...(rocketCloset.isVisible()?[`closet`]:[])]}');
    once('function gD(e){switch(e){', 'function gD(e){switch(e){case`closetBossMoves`:return`BOSS MOVES`;case`closetAutoStatus`:return`AUTO STATUS`;case`closetDashProtect`:return`DASH PROTECT`;case`closetAutoProtect`:return`AUTO PROTECT`;');
    once('function _D(e,t){', 'function _D(e,t){if(e===`closetBossMoves`)return yD(rocketCloset.getBossMoves());if(e===`closetAutoStatus`)return yD(rocketCloset.getAutoStatus());if(e===`closetDashProtect`)return yD(rocketCloset.getDashProtect());if(e===`closetAutoProtect`)return yD(rocketCloset.getAutoProtect());');
    once('function ND(e){let t=PE()[gE];', 'function ND(e){let t=PE()[gE];if(t?.kind===`closetBossMoves`){rocketCloset.choose(e===`on`,t.kind);return;}if(t?.kind===`closetAutoStatus`){rocketCloset.choose(e===`on`,t.kind);return;}if(t?.kind===`closetDashProtect`){rocketCloset.choose(e===`on`,t.kind);return;}if(t?.kind===`closetAutoProtect`){rocketCloset.choose(e===`on`);return;}');
    once('function DD(e){let t=PE()[gE];', 'function DD(e){let t=PE()[gE];if(t?.kind===`closetBossMoves`){rocketCloset.choose(!rocketCloset.getBossMoves(),t.kind);return;}if(t?.kind===`closetAutoStatus`){rocketCloset.choose(!rocketCloset.getAutoStatus(),t.kind);return;}if(t?.kind===`closetDashProtect`){rocketCloset.choose(!rocketCloset.getDashProtect(),t.kind);return;}if(t?.kind===`closetAutoProtect`){rocketCloset.choose(!rocketCloset.getAutoProtect());return;}');
    once('function KD(){let e=PE()[gE];', 'function KD(){let e=PE()[gE];if(e?.kind===`closetBossMoves`){rocketCloset.choose(!rocketCloset.getBossMoves(),e.kind);return;}if(e?.kind===`closetAutoStatus`){rocketCloset.choose(!rocketCloset.getAutoStatus(),e.kind);return;}if(e?.kind===`closetDashProtect`){rocketCloset.choose(!rocketCloset.getDashProtect(),e.kind);return;}if(e?.kind===`closetAutoProtect`){rocketCloset.choose(!rocketCloset.getAutoProtect());return;}');
    once('function GD(e){', 'function GD(e){if(rocketCloset.settingsKey(e))return;');
    once('function BD(){', 'function BD(){rocketCloset.setAutoProtect(false);rocketCloset.setDashProtect(false);rocketCloset.setAutoStatus(false);rocketCloset.setBossMoves(false);');
    return 'const rocketCloset=('+createRocketCloset.toString()+')();globalThis.rocketCloset=rocketCloset;\n'+source;
  }
  const api=Object.freeze({patch});
  globalThis.ArenaClosetSettingsAdapter=api;
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})();
