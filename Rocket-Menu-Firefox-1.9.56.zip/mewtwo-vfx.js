// Native Mewtwo actors with layered psychic effects tied to the simulation's hit geometry.
(() => {
  'use strict';
  function createRocketMewtwoVfx(){
    const scenes=new WeakMap();let serial=0;
    const palette={shadow:{key:'shadow',dark:0x17112b,edge:0x672ba7,light:0xc898f5,core:0xf1dcff},aura:{key:'aura',dark:0x102b66,edge:0x227ad0,light:0x83dfff,core:0xf2ffff},psychic:{key:'psychic',dark:0x332047,edge:0x9c55db,light:0xe5b7ff,core:0xffedff}};
    const clamp=v=>Math.max(0,Math.min(1,Number(v)||0)),css=n=>'#'+n.toString(16).padStart(6,'0');
    const rgba=(n,a)=>'rgba('+[(n>>16)&255,(n>>8)&255,n&255,a].join(',')+')';
    const point=(p,a,d,side=0)=>({x:p.x+Math.cos(a)*d-Math.sin(a)*side,y:p.y+Math.sin(a)*d+Math.cos(a)*side});
    function texture(r,kind,p){
      const id=kind+':'+p.key;if(r.textures.has(id))return r.textures.get(id);
      const key='rocket-mewtwo-fx-'+r.id+'-'+id.replace(':','-'),canvas=r.scene.textures.createCanvas(key,192,192),c=canvas.getContext();c.clearRect(0,0,192,192);
      if(kind==='glow'){
        const g=c.createRadialGradient(96,96,0,96,96,96);g.addColorStop(0,rgba(p.light,.65));g.addColorStop(.35,rgba(p.edge,.3));g.addColorStop(1,rgba(p.edge,0));c.fillStyle=g;c.fillRect(0,0,192,192);
      }else if(kind==='ring'){
        const g=c.createRadialGradient(96,96,57,96,96,90);g.addColorStop(0,rgba(p.edge,0));g.addColorStop(.5,rgba(p.light,.7));g.addColorStop(.6,rgba(p.core,.9));g.addColorStop(1,rgba(p.edge,0));c.fillStyle=g;c.fillRect(0,0,192,192);
      }else if(kind==='crescent'){
        c.beginPath();c.arc(96,96,78,-1.35,1.35);c.quadraticCurveTo(94,96,96+Math.cos(-1.35)*78,96+Math.sin(-1.35)*78);
        const g=c.createLinearGradient(76,0,175,0);g.addColorStop(0,rgba(p.edge,0));g.addColorStop(.65,rgba(p.light,.6));g.addColorStop(1,rgba(p.core,.95));c.fillStyle=g;c.fill();
      }else if(kind==='rock'){
        const points=[[40,37],[93,20],[151,42],[177,93],[154,155],[101,175],[44,149],[18,93]];
        c.beginPath();c.moveTo(...points[0]);for(const p of points.slice(1))c.lineTo(...p);c.closePath();const g=c.createLinearGradient(30,20,158,173);g.addColorStop(0,'#b1a9b7');g.addColorStop(.45,'#625771');g.addColorStop(1,'#282035');c.fillStyle=g;c.fill();c.lineWidth=5;c.strokeStyle='#241e31';c.stroke();
        for(const [a,b,d] of [[[40,37],[93,20],[75,83]],[[93,20],[151,42],[118,84]],[[18,93],[75,83],[44,149]],[[75,83],[118,84],[101,175]],[[118,84],[177,93],[154,155]]]){c.beginPath();c.moveTo(...a);c.lineTo(...b);c.lineTo(...d);c.closePath();c.fillStyle=rgba(p.light,.08);c.fill();c.lineWidth=2;c.strokeStyle='#2d233d';c.stroke();}
        // Cracks are part of the rock texture, with a dark lip and bright psychic core.
        for(const path of [[[93,23],[92,58],[77,78],[102,103],[90,139],[101,171]],[[77,78],[45,70],[23,93]],[[102,103],[132,86],[170,93]],[[132,86],[128,58],[150,44]]]){c.beginPath();c.moveTo(...path[0]);for(const p of path.slice(1))c.lineTo(...p);c.lineWidth=11;c.strokeStyle='#492366';c.stroke();c.lineWidth=5;c.strokeStyle='#b36bf0';c.stroke();c.lineWidth=2;c.strokeStyle='#f6d8ff';c.stroke();}
      }else{
        c.save();c.beginPath();c.arc(96,96,73,0,Math.PI*2);c.clip();const g=c.createRadialGradient(75,67,4,96,96,80);g.addColorStop(0,css(p.core));g.addColorStop(.25,css(p.light));g.addColorStop(.65,css(p.edge));g.addColorStop(1,css(p.dark));c.fillStyle=g;c.fillRect(0,0,192,192);
        for(let i=0;i<4;i++){c.strokeStyle=rgba(i%2?p.light:p.core,.24);c.lineWidth=6-i;c.beginPath();c.ellipse(96,96,62-i*6,22+i*7,i*.8,0,Math.PI*2);c.stroke();}
        c.restore();c.strokeStyle=rgba(p.light,.7);c.lineWidth=3;c.beginPath();c.arc(96,96,73,0,Math.PI*2);c.stroke();
      }
      canvas.refresh();r.textures.set(id,key);return key;
    }
    function image(r,kind,p,x,y,w,h,a=0,alpha=1,depth=5.8){
      const key=texture(r,kind,p),index=r.used++;let sprite=r.images[index];if(!sprite){sprite=r.scene.add.image(0,0,key);r.images.push(sprite);}
      sprite.setTexture(key).setPosition(x,y).setOrigin(.5,.5).setDisplaySize(Math.max(1,w),Math.max(1,h)).setRotation(a).setAlpha(clamp(alpha)).setDepth(depth).setVisible(true).setFlipX(false).setFlipY(false).clearTint().setTintMode(G.TintModes.MULTIPLY).setBlendMode('NORMAL');return sprite;
    }
    function line(g,points,color,width,alpha=1){if(points.length<2)return;g.lineStyle(width,color,alpha);g.beginPath();g.moveTo(points[0].x,points[0].y);for(let i=1;i<points.length;i++)g.lineTo(points[i].x,points[i].y);g.strokePath();}
    function ribbon(g,from,to,width,color,alpha,time=0,wave=0){
      const length=Math.hypot(to.x-from.x,to.y-from.y);if(length<1||width<=0)return;const angle=Math.atan2(to.y-from.y,to.x-from.x),steps=Math.max(12,Math.min(64,Math.ceil(length/22))),cap=Math.min(length*.25,Math.max(16,width*.65));
      g.fillStyle(color,alpha);g.beginPath();for(let side=1;side>=-1;side-=2)for(let i=0;i<=steps;i++){
        const f=side===1?i/steps:1-i/steps,d=f*length,end=Math.min(1,d/cap,(length-d)/cap),round=Math.sqrt(Math.max(0,1-(1-end)*(1-end)));
        const offset=Math.sin(d*.035-time)*wave*Math.sin(f*Math.PI)+side*width*.5*round*(.93+.07*Math.sin(d*.047-time));const p=point(from,angle,d,offset);if(side===1&&i===0)g.moveTo(p.x,p.y);else g.lineTo(p.x,p.y);
      }g.closePath();g.fillPath();
    }
    function circle(g,p,radius,color,alpha=.5,width=2){g.lineStyle(width,color,alpha);g.strokeCircle(p.x,p.y,Math.max(1,radius));}
    function saveSprite(r,s){r.owned.push({s,x:s.x,y:s.y,sx:s.scaleX,sy:s.scaleY,rotation:s.rotation,ox:s.originX,oy:s.originY,alpha:s.alpha,depth:s.depth,key:s.texture.key,frame:s.frame.name,tint:hk(s)});}
    function restore(r){if(!r)return;for(const b of r.owned)if(b.s?.scene){b.s.setTexture(b.key,b.frame).setPosition(b.x,b.y).setScale(b.sx,b.sy).setRotation(b.rotation).setOrigin(b.ox,b.oy).setAlpha(b.alpha).setDepth(b.depth);gk(b.s,b.tint);}r.owned.length=0;}
    function beforeDraw(scene){restore(scenes.get(scene));}
    function pose(actor,kind,angle,time){
      const animation=actor.clips?.[kind]||actor.clips?.idle;if(!animation||actor.still)return null;
      const clip=animation.clip,row=clip.rows>1?Math.min(clip.rows-1,mp(angle)):0,column=Math.floor(Math.max(0,time)/95)%Math.max(1,clip.frames),anchor=XO(actor.speciesId,kind,row,column,clip.anchor)||clip.anchor;
      return{key:animation.key,index:row*clip.frames+column,ox:anchor[0]/clip.frameWidth,oy:anchor[1]/clip.frameHeight};
    }
    function body(r,fighter,boss,time,reduced){
      const actor=r.scene.actors?.get(fighter.id),s=actor?.sprite,a=boss.attack?.rock||boss.attack||{};if(!s?.scene||actor.speciesId!==fighter.speciesId||r.scene.megaFx?.holdsOld(fighter.id))return;
      saveSprite(r,s);const age=a.elapsedMs||0,p=clamp(a.progress),angle=Number.isFinite(a.facing)?a.facing:fighter.facing||0;
      const casting=['radial','aura','rock','turrets'].includes(a.kind),charging=['windup','charge','warning'].includes(a.phase);
      const type=casting?(charging?'charge':'shoot'):a.kind==='crunch'||a.kind==='illusion'&&a.phase==='retaliate'?'shoot':a.kind==='teleport'?'charge':'idle';
      if(a.kind!=='idle'){const frame=pose(actor,type,angle,a.kind==='illusion'?(boss.clones?.[0]?.ageMs??age):age);if(frame)s.setTexture(frame.key,frame.index).setOrigin(frame.ox,frame.oy);}
      // The charge body leans away from the target while the orb grows behind it.
      if(a.kind==='aura'&&charging){const lean=(reduced?.02:.06)*Math.sin(p*Math.PI);s.setRotation(Math.cos(angle)>=0?-lean:lean);s.setPosition(s.x-Math.cos(angle)*p*4,s.y-Math.sin(angle)*p*4);}
      if(a.kind==='rock'&&charging)s.setPosition(s.x,s.y-(reduced?1:3)*Math.sin(p*Math.PI));
      if(a.kind==='crunch'&&a.phase==='active'){const pulse=Math.sin(p*Math.PI);s.setPosition(s.x+Math.cos(angle)*pulse*7,s.y+Math.sin(angle)*pulse*7);}
      s.setAlpha(clamp(fighter.rocketMewtwoAlpha??a.alpha??1)*s.alpha);
      if(a.kind==='teleport'&&s.alpha<.9){
        const size=fighter.radius*2.3,at={x:fighter.x,y:fighter.y-fighter.radius*.45};image(r,'ring',palette.psychic,at.x,at.y,size*(1+.4*p),size*.6,0,(1-s.alpha)*(reduced?.15:.4),3.2);
        image(r,'glow',palette.psychic,at.x,at.y-25,size*1.1,size*2,0,(1-s.alpha)*(reduced?.08:.2),5.4);
      }
    }
    function clones(r,state,boss,time,reduced){
      const actor=r.scene.actors?.get('opponent'),native=actor?.sprite;if(!native?.scene)return;
      for(const clone of boss.clones||[]){
        const animation=pose(actor,clone.kind==='turret'||boss.attack?.phase==='retaliate'?'shoot':'idle',clone.facing||0,clone.ageMs||0);
        const key=animation?.key||native.texture.key,index=animation?.index??native.frame.name,ox=animation?.ox??native.originX,oy=animation?.oy??native.originY;
        const alpha=clamp(clone.alpha??1),depth=4+(clone.y||0)/1000000;
        const radius=clone.radius||30;r.ground.fillStyle(1313802,.28*alpha);r.ground.fillEllipse(clone.x,clone.y+radius*.2,radius*2.4,radius*.7);
        for(let layer=0;layer<2;layer++){
          const slot=r.used++;let s=r.images[slot];if(!s){s=r.scene.add.image(0,0,key,index);r.images.push(s);}
          s.setTexture(key,index).setPosition(Math.round(clone.x),Math.round(clone.y)).setOrigin(ox,oy).setScale(native.scaleX,native.scaleY).setRotation(0).setAlpha(alpha*(layer?.13:1)).setDepth(depth+layer*.000001).setVisible(true).setFlipX(false).setFlipY(false).setBlendMode('NORMAL').clearTint().setTintMode(G.TintModes.MULTIPLY);
          if(layer)s.setTintFill(0xf3e9ff);else gk(s,hk(native));
        }
        if(clone.kind==='turret'){
          const at={x:clone.x,y:clone.y-25};image(r,'glow',palette.psychic,at.x,at.y,75,92,0,alpha*(reduced?.035:.08),3.1);
        }
      }
      if(boss.attack?.kind==='illusion')for(const tag of r.scene.ffaLabels||[])tag.setVisible(false);
    }
    function gather(r,at,radius,p,progress,time,reduced){
      const size=radius*(.2+.8*clamp(progress)),spin=reduced?0:time/260;
      image(r,'glow',p,at.x,at.y,size*3.2,size*3.2,0,reduced?.12:.32,5.55);
      image(r,'orb',p,at.x,at.y,size*2,size*2,-spin*.6,.96,5.8);
      image(r,'crescent',p,at.x,at.y,size*2.4,size*1.7,spin,.8,5.9);
      image(r,'crescent',p,at.x,at.y,size*2.1,size*2.4,-spin*.8+2,.6,5.9);
      for(let i=0;i<(reduced?2:7);i++){const f=(progress*1.5+i/7)%1,a=i*2.399+spin*.2,end=point(at,a,radius*(1.7-f*1.45)),start=point(at,a,radius*(1.9-f*1.45));line(r.front,[start,end],p.light,2,Math.sin(f*Math.PI)*.7);}
    }
    function beam(r,b,time,reduced){
      if(!b.from||!b.to)return;const p=palette.psychic,width=Math.max(3,b.width||12),angle=Math.atan2(b.to.y-b.from.y,b.to.x-b.from.x),length=Math.hypot(b.to.x-b.from.x,b.to.y-b.from.y);
      if(b.phase==='warning'){
        ribbon(r.ground,b.from,b.to,width,p.edge,.08);line(r.ground,[b.from,b.to],p.light,1,.55);
        for(let d=50;d<length;d+=145){const at=point(b.from,angle,d);line(r.ground,[point(at,angle,-6,-4),at,point(at,angle,-6,4)],p.light,2,.45);}
        image(r,'ring',p,b.from.x,b.from.y,width*1.4,width*1.4,0,.45,5.3);return;
      }
      const phase=time/(reduced?900:90),pulse=reduced?1:.96+.04*Math.sin(time/77);
      ribbon(r.front,b.from,b.to,width*1.35,p.edge,reduced?.08:.15,phase,width*.015);
      ribbon(r.front,b.from,b.to,width*pulse,p.edge,.86,phase,width*.025);
      ribbon(r.front,b.from,b.to,width*.59,p.light,.95,phase+1,width*.025);
      ribbon(r.front,b.from,b.to,width*.22,p.core,.96,phase+2,width*.012);
      image(r,'glow',p,b.from.x,b.from.y,width*2.8,width*2.8,0,reduced?.15:.32,5.85);
      image(r,'crescent',p,b.from.x,b.from.y,width*1.9,width*1.4,time/150,.8,5.95);
      const count=Math.max(2,Math.floor(length/165));for(let i=0;i<count;i++){const t=((time/550+i/count)%1),at=point(b.from,angle,length*t),off=point(at,angle,Math.min(26,length*.1),Math.sin(t*8+phase)*width*.13);line(r.front,[at,off],p.core,Math.max(1,width*.045),Math.sin(t*Math.PI)*.6);}
    }
    function projectile(r,shot,time,reduced){
      const p=shot.kind==='aura'?palette.aura:shot.kind==='rock'?palette.psychic:palette.shadow,angle=Math.atan2(shot.vy||0,shot.vx||1),radius=Math.max(3,shot.radius||16),at={x:shot.x,y:shot.y};
      const age=shot.ageMs||0,tail=Math.min(radius*(shot.kind==='rock'?2.2:3.7),Math.hypot(shot.vx||0,shot.vy||0)*age/1000);
      for(let i=3;i>0;i--){const rear=point(at,angle,-tail*i/3);image(r,shot.kind==='rock'?'glow':'orb',p,rear.x,rear.y,radius*(1.6-i*.3),radius*(1.6-i*.3),0,(reduced?.045:.09)*(4-i),5.55);}
      if(shot.kind==='rock'){
        image(r,'glow',p,at.x,at.y,radius*3,radius*3,0,reduced?.12:.28,5.6);
        image(r,'rock',p,at.x,at.y,radius*2.4,radius*2.4,age/(reduced?1300:430),1,5.8);
        image(r,'crescent',p,at.x,at.y,radius*3.1,radius*2.2,-age/220,.65,5.9);
      }else{
        image(r,'glow',p,at.x,at.y,radius*3.1,radius*3.1,0,reduced?.15:.3,5.6);
        image(r,'orb',p,at.x,at.y,radius*2.4,radius*2.4,age/700,.98,5.8);
        image(r,'crescent',p,at.x,at.y,radius*2.9,radius*2.2,age/130+angle,.85,5.9);
        image(r,'crescent',p,at.x,at.y,radius*2.3,radius*3.1,-age/170,.62,5.91);
      }
      if(!reduced)for(let i=0;i<3;i++){const f=(age/220+i/3)%1,a=angle+Math.PI+(i-1)*.22,start=point(at,a,radius*(1.1+f*1.5)),end=point(start,a,radius*.3);line(r.front,[start,end],p.light,2,(1-f)*.6);}
    }
    function impact(r,event,reduced){
      const p=event.kind==='aura'?palette.aura:palette.psychic,progress=clamp((event.ageMs||0)/(event.lifeMs||450)),alpha=1-progress,radius=Math.max(6,event.radius||30)*(0.3+progress);
      image(r,'ring',p,event.x,event.y,radius*2,radius*2,0,alpha*(reduced?.3:.65),5.8);
      image(r,'glow',p,event.x,event.y,radius*2,radius*2,0,alpha*(reduced?.06:.18),5.65);
      for(let i=0;i<(reduced?3:8);i++){const a=i*Math.PI/4+event.x*.01,start=point(event,a,radius*.6),end=point(event,a,radius);line(r.front,[start,end],i%2?p.light:p.core,Math.max(1,3*alpha),alpha*.75);}
      if(event.kind==='crunch')for(const side of [-1,1]){
        const g=r.front,y=event.y+side*radius*(.2+progress*.3);for(let i=0;i<5;i++){const x=event.x+(i-2)*radius*.3;g.fillStyle(p.core,alpha*.8);g.fillTriangle(x-4,y,x+4,y,x,y-side*radius*.27);}
      }
    }
    function paint(r,state,boss,time,reduced){
      const fighter=state.fighters?.find(f=>f.id==='opponent'),a=boss.attack||{},p=palette.psychic,progress=clamp(a.progress);
      if(fighter?.hp>0){
        body(r,fighter,boss,time,reduced);
        const alpha=clamp(fighter.rocketMewtwoAlpha??a.alpha??1),radius=fighter.radius||30;
        r.ground.fillStyle(1313802,.28*alpha);r.ground.fillEllipse(fighter.x,fighter.y+radius*.2,radius*2.4,radius*.7);
        const charging=['windup','charge','warning'].includes(a.phase),center={x:fighter.x,y:fighter.y-fighter.radius*.7};
        if(a.kind==='aura'&&charging){const at=a.origin||point(center,a.facing||0,-42,14);gather(r,at,a.radius||30,palette.aura,progress,time,reduced);}
        const rock=a.kind==='rock'?a:a.rock;
        if(rock?.phase==='windup'){const at=rock.origin||point(center,rock.facing||0,35),growth=clamp(rock.progress);image(r,'rock',p,at.x,at.y,50+growth*18,50+growth*18,growth*.3,.55+growth*.45,5.8);image(r,'glow',p,at.x,at.y,95,95,0,reduced?.1:.24,5.6);circle(r.ground,{x:at.x,y:at.y+32},34,p.light,.3);}
        if(a.kind==='mega'||a.phase==='mega'){image(r,'ring',p,center.x,center.y,100+progress*190,100+progress*190,0,Math.sin(progress*Math.PI)*(reduced?.2:.55),5.4);image(r,'glow',p,center.x,center.y,180,200,0,reduced?.06:.18,5.5);}
        if(a.kind==='crunch'&&charging||a.kind==='teleport'&&a.crunch&&a.phase==='fadein'){const target=a.target||point(center,a.facing||0,65),radius=a.radius||50;circle(r.ground,target,radius,p.light,.65,2);line(r.ground,[center,target],p.light,2,.65);for(let i=0;i<4;i++){const angle=i*Math.PI/2+Math.PI/4;line(r.ground,[point(target,angle,radius+5),point(target,angle,radius-8)],p.core,2,.8);}}
      }
      clones(r,state,boss,time,reduced);
      for(const b of boss.beams||[])beam(r,b,time,reduced);
      for(const s of boss.projectiles||[])projectile(r,s,time,reduced);
      for(const e of boss.impacts||[])impact(r,e,reduced);
    }
    function clear(scene){const r=scenes.get(scene);if(!r)return;restore(r);for(const sprite of r.images)sprite.destroy();r.ground.destroy();r.front.destroy();for(const key of r.textures.values())if(scene.textures.exists(key))scene.textures.remove(key);scene.events?.off('shutdown',r.dispose);scene.events?.off('destroy',r.dispose);scenes.delete(scene);}
    function draw(scene,state){
      const boss=state?.rocketMewtwoBoss;if(!boss||scene.net||state.phase!=='fight'){clear(scene);return;}let r=scenes.get(scene);if(r&&r.world!==scene.world){clear(scene);r=null;}
      if(!r){r={scene,world:scene.world,id:++serial,textures:new Map(),images:[],used:0,owned:[],ground:scene.add.graphics().setDepth(3.15),front:scene.add.graphics().setDepth(6)};r.dispose=()=>clear(scene);scenes.set(scene,r);scene.events.once('shutdown',r.dispose);scene.events.once('destroy',r.dispose);}
      r.used=0;r.ground.clear();r.front.clear();paint(r,state,boss,(state.tick||0)*q,ei().display.reduceFlash||Wq());for(let i=r.used;i<r.images.length;i++)r.images[i].setVisible(false);
    }
    return Object.freeze({beforeDraw,draw,clear});
  }
  function patch(source){return 'const rocketMewtwoVfx=('+createRocketMewtwoVfx.toString()+')();globalThis.rocketMewtwoVfx=rocketMewtwoVfx;\n'+source;}
  const api=Object.freeze({patch});globalThis.ArenaMewtwoVfxAdapter=api;if(typeof module!=='undefined'&&module.exports)module.exports=api;
})();
