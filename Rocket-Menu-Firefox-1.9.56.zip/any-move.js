// Species eligibility only. Native role assignment, duplicate checks and move
// effects remain original. Wire copies follow the official server's rules;
// the separate authoritative-host adapter applies supported custom loadouts.
(() => {
  'use strict';

  function patch(original) {
    let source = original;
    function replace(anchor, replacement) {
      const at = source.indexOf(anchor);
      if (at < 0 || source.indexOf(anchor, at + anchor.length) !== -1) {
        throw new Error('Unsupported game build. Missing or ambiguous any-move anchor: ' + anchor.slice(0, 80));
      }
      source = source.slice(0, at) + replacement + source.slice(at + anchor.length);
    }

    replace('function Sn(e){return xn(e).ids}',
      'var arenaAnyMoveIds,arenaAnyMoveOnlineDepth=0;function arenaAnyMoveOnline(run){arenaAnyMoveOnlineDepth++;try{return run()}finally{arenaAnyMoveOnlineDepth--}}function arenaAnyMoveEnabled(){return !arenaAnyMoveOnlineDepth&&typeof arenaModEnabled===`function`&&arenaModEnabled(`anymove`)===true}function arenaAnyMovePool(){return arenaAnyMoveIds??=Object.freeze([...new Set(Ne().map(Me))].filter(_t))}function Sn(e){return arenaAnyMoveEnabled()&&hn.has(e)?arenaAnyMovePool():xn(e).ids}');
    replace('function wn(e,t){return xn(e).strips.has(yn(t))}',
      'function wn(e,t){return arenaAnyMoveEnabled()&&hn.has(e)&&arenaAnyMovePool().includes(t)||xn(e).strips.has(yn(t))}');

    // Stored extended loadouts remain valid data even with the switch off.
    // This optional argument is used only by the saved team-book reader/writer;
    // battle and editor normalization continue to use the live option.
    replace('function Tn(e,t){if(!hn.has(e)',
      'function Tn(e,t,arenaStored=false){if(!hn.has(e)');
    replace('for(let n of t)if(!wn(e,n))return!1;',
      'for(let n of t)if(!wn(e,n)&&!(arenaStored&&arenaAnyMovePool().includes(n)))return!1;');
    replace('function Mn(e,t){if(Tn(e,t))return t.slice();if(!Array.isArray(t)||t.some(e=>typeof e!=`string`||!Pe(e)))return null;let n=t.slice(0,5).findIndex(Ge);if(n<0||V(t[n]).power<=0)return null;let r=t.filter((e,t)=>t!==n);return Tn(e,r)?r:null}',
      'function Mn(e,t,arenaStored=false){if(Tn(e,t,arenaStored))return t.slice();if(!Array.isArray(t)||t.some(e=>typeof e!=`string`||!Pe(e)))return null;let n=t.slice(0,5).findIndex(Ge);if(n<0||V(t[n]).power<=0)return null;let r=t.filter((e,t)=>t!==n);return Tn(e,r,arenaStored)?r:null}');
    replace('i&&Array.isArray(a)&&(n[t]=Mn(i,a))',
      'i&&Array.isArray(a)&&(n[t]=Mn(i,a,true))');

    // Only the launch/submission copy falls back while disabled. Saving another
    // team or changing the active team never overwrites the retained choices.
    replace('function Qn(e,t){let n=Jn(e);return t.map(e=>{let t=n.slots.indexOf(e);if(t<0)return null;let r=n.moves[t];return r?[...r]:null})}',
      'function Qn(e,t){let n=Jn(e);return t.map(e=>{let t=n.slots.indexOf(e);if(t<0)return null;let r=n.moves[t];return r?Mn(e,r):null})}');

    // The real service rejects cross-species loadouts. Normalize only outgoing
    // wire copies. The controller keeps the desired set for its own Direct
    // authority, and saved books and the shared editor retain those choices.
    replace('function TO(e){return[0,1,2].map(t=>{let n=e[t];return n?[...n]:null})}',
      'function TO(e,species){return arenaAnyMoveOnline(()=>[0,1,2].map(t=>{let n=e[t],id=species?.[t];return n&&hn.has(id)?Mn(id,n):null}))}');
    replace('moves:TO(this.moves)', 'moves:TO(this.moves,this.team)');

    // Refresh an already-open native editor when either the site menu or
    // extension popup changes the option. There is no mid-fight loadout swap.
    replace('function Sn(e){',
      'if(typeof document!==`undefined`){let arenaAnyMoveLast;document.addEventListener(`arena-mod-settings`,()=>{let enabled=arenaAnyMoveEnabled();if(enabled===arenaAnyMoveLast)return;arenaAnyMoveLast=enabled;if(typeof Z!==`undefined`&&Z?.movePick&&Z.pick?.isConnected)Z.paintDetail()})}function Sn(e){');
    return source;
  }

  const api = Object.freeze({patch});
  globalThis.ArenaAnyMoveAdapter = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})();
