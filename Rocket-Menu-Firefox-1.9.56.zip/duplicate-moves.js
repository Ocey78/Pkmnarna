// Apply after Any move. Each equipped copy keeps its own native loadout index;
// the network validator still rejects duplicates in the outgoing wire copy.
(() => {
  'use strict';
  function arenaPlanMove(species,loadout,requestedSlot,moveId) {
    if(!arenaAnyMoveEnabled()||!hn.has(species)||!mn.includes(requestedSlot)||!arenaAnyMovePool().includes(moveId))return null;
    const current=Nn(species,loadout),roles=Qe(current),selected=roles[requestedSlot];
    if(selected?.moveId===moveId)return {moves:current.slice(),slot:requestedSlot,loadoutIndex:selected.loadoutIndex,reassigned:false,replacedSlot:requestedSlot,replacedMoveId:moveId};
    function attempt(index,append=false) {
      const moves=current.slice();if(append)moves.push(moveId);else moves[index]=moveId;
      if(!Tn(species,moves))return null;
      const slot=Qe(moves).findIndex(role=>role.loadoutIndex===index&&role.moveId===moveId);
      return slot<0?null:{moves,slot,loadoutIndex:index,reassigned:slot!==requestedSlot,
        replacedSlot:append?null:roles.findIndex(role=>role.loadoutIndex===index),replacedMoveId:append?null:current[index]};
    }
    // First replace precisely the clicked copy. Native role assignment may
    // move its key, but every other equipped entry remains unchanged.
    if(selected?.loadoutIndex!==null&&selected?.loadoutIndex!==undefined){
      const result=attempt(selected.loadoutIndex);if(result)return result;
    }
    // Protect needs a real utility slot. Four-move sets have room to add it.
    if(current.length===4&&We(moveId)){const result=attempt(current.length,true);if(result)return result;}
    // When the clicked copy is indispensable (for example the only qualifying
    // ultimate), replace one compatible skill instead. Never reset a whole set.
    for(const role of [1,3,0,4,2]){
      const index=roles[role]?.loadoutIndex;
      if(index===null||index===undefined||index===selected?.loadoutIndex)continue;
      const result=attempt(index);if(result)return result;
    }
    return null;
  }
  function patch(original) {
    let source=original;
    function replace(anchor,replacement) {
      const at=source.indexOf(anchor);
      if(at<0||source.indexOf(anchor,at+anchor.length)!==-1)
        throw new Error('Unsupported game build. Missing or ambiguous duplicate-move anchor: '+anchor.slice(0,80));
      source=source.slice(0,at)+replacement+source.slice(at+anchor.length);
    }
    // Cn itself remains untouched: the native server-compatible validation path
    // runs with Any move suppressed and must keep its original uniqueness rule.
    replace('if(!Cn(t))return!1;for(let n of t)',
      'if(!Cn(t)&&!arenaStored&&!arenaAnyMoveEnabled())return!1;for(let n of t)');
    replace('let n=0;for(let e of t)vn(e)&&(n+=1);if(n>1)return!1;',
      'let n=0;for(let e of t)vn(e)&&(n+=1);if(n>1&&!arenaStored&&!arenaAnyMoveEnabled())return!1;');

    // Move IDs cease to identify a slot when a loadout contains copies. Always
    // edit by Qe's original loadoutIndex, including the native UI commit path.
    replace('function On(e,t,n){let r=Qe(e);if(t===2){let t=r[2].moveId;return t?Dn(e,t,n):[...e,n]}let i=r[t].moveId;return i?Dn(e,i,n):null}',
      arenaPlanMove.toString()+'\nfunction arenaReplaceMoveSlot(e,t,n){let r=Qe(e)[t]?.loadoutIndex;if(r===null||r===undefined)return t===2&&n!==null?[...e,n]:null;let i=e.slice();return n===null?i.splice(r,1):i[r]=n,i}function On(e,t,n){return arenaReplaceMoveSlot(e,t,n)}');
    replace('function An(e,t,n){if(!mn.includes(n))return[];let r=En(e,t),i=[];',
      'function An(e,t,n){if(!mn.includes(n))return[];let r=En(e,t),i=[];if(arenaAnyMoveEnabled())return Sn(e).filter(id=>id!==Qe(r)[n]?.moveId&&arenaPlanMove(e,r,n,id)!==null).sort((a,b)=>kn(dn(e).types,a,b));');
    replace('function jn(e,t){let n=En(e,t),r=Qe(n)[2].moveId;return r?Tn(e,n.filter(e=>!bt(e,r))):Tn(e,n)}',
      'function jn(e,t){let n=En(e,t),r=Qe(n)[2].moveId;return r?Tn(e,arenaReplaceMoveSlot(n,2,null)):Tn(e,n)}');
    replace('function Lv(e,t,n,r,i){if(r===null)return n!==2||!jn(i,e)?null:t?e.filter(e=>!bt(e,t)):e.slice();if(n===2&&!t)return[...e,r];if(!t)return null;let a=e.findIndex(e=>bt(e,t));if(a<0)return null;let o=e.slice();return o[a]=r,o}',
      'function Lv(e,t,n,r,i){if(r===null)return n!==2||!jn(i,e)?null:t?arenaReplaceMoveSlot(e,n,null):e.slice();return arenaReplaceMoveSlot(e,n,r)}');
    replace('function Iv(e,t,n,r){let i=Nn(e,t)',
      'function Iv(e,t,n,r){if(arenaAnyMoveEnabled()&&r!==null){let planned=arenaPlanMove(e,t,n,r);if(!planned)return{ok:!1};let defaults=un(e),moves=planned.moves;return{ok:!0,moves:moves.length===defaults.length&&moves.every((id,index)=>bt(id,defaults[index]??``))?null:moves,slot:planned.slot}}let i=Nn(e,t)');

    // Same-ID regular/ultimate copies need explicit display metadata. These
    // optional fields survive ordinary native Direct snapshots. Stock guests
    // accept them but retain their own older effect-classification heuristic.
    replace('this.events.push({type:`cast`,actor:e.id,move:t.id,x:e.x,y:e.y})',
      'this.events.push({type:`cast`,actor:e.id,move:t.id,x:e.x,y:e.y,arenaUltimate:i===true})');
    replace('this.events.push({type:`cast`,actor:e.id,move:a,x:e.x,y:e.y,basic:!0})',
      'this.events.push({type:`cast`,actor:e.id,move:a,x:e.x,y:e.y,basic:!0,arenaUltimate:false})');
    replace('castBasic:e.cast?.basic===!0,basicCooldownMs:',
      'castBasic:e.cast?.basic===!0,arenaCastUltimate:e.cast?.ult===true,basicCooldownMs:');
    replace('d=c&&l&&', 'd=c&&l&&(typeof a.arenaUltimate===`boolean`?a.arenaUltimate:');
    replace('===a.move,f=FU(', '===a.move),f=FU(');
    replace('if(this.enforcedUltimateGate)for(let e of t.fighters){if(e.hp<=0',
      'if(this.enforcedUltimateGate)for(let e of t.fighters){if(e.arenaCastUltimate===false||e.hp<=0');
    replace('function XA(e){return!e.castMove||!so(e.castMove)?!1:Qe(e.moves.map(e=>e.id))[4]?.moveId===e.castMove}',
      'function XA(e){return!e.castMove||!so(e.castMove)?!1:typeof e.arenaCastUltimate===`boolean`?e.arenaCastUltimate&&!e.castBasic:Qe(e.moves.map(e=>e.id))[4]?.moveId===e.castMove}');
    const guidance='a.ultCharge>=100&&o.ultCharge<a.ultCharge&&l.some(e=>e.type===`cast`&&!e.basic)';
    const unlimitedGuidance='a.ultCharge>=100&&l.some(e=>e.type===`cast`&&!e.basic&&(o.ultCharge<a.ultCharge||arenaModEnabled("cooldowns")&&e.move===Qe(a.moves.map(move=>move.id))[4]?.moveId))';
    const previous=source.includes(unlimitedGuidance)?unlimitedGuidance:guidance;
    replace(previous,
      '(l.some(e=>e.type===`cast`&&!e.basic&&e.arenaUltimate===true)||!l.some(e=>typeof e.arenaUltimate===`boolean`)&&('+previous+'))');
    return source;
  }
  const api=Object.freeze({patch});
  globalThis.ArenaDuplicateMovesAdapter=api;
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})();
