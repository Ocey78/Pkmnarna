// Native Bw owns the local player's input in every online battle. Its render
// state is already in viewer order, including at seats B and C in a brawl.
(() => {
  'use strict';

  function aimOnlineCommand(command, sending) {
    if (!command || !arenaModEnabled('aim')) return command;
    const buttons = command.buttons;
    if (!buttons.basic && !buttons.attacks.some(Boolean)) return command;

    const [actor, ...opponents] = this.render.fighters;
    if (!actor || actor.hp <= 0) return command;
    const slots = Qe(actor.moves.map(move => move.id));
    let mode = buttons.basic && slots[0].basicFallback ? 'basic' : null;

    // The native simulator checks pressed loadout indices highest first. The
    // basic button uses its own aiming rule even if its assigned move is a dash.
    for (let i = actor.moves.length - 1; i >= 0; i--) {
      if (!buttons.attacks[i]) continue;
      const slot = tt(slots,i);
      if (!slot) continue;
      const move = actor.moves[i];
      const ultimate = slot.role === 'ultimate';
      if (ultimate ? actor.ultCharge < 100 : move.cooldownMs > 0) continue;
      if (slot.role === 'basic') mode = 'basic';
      else {
        const definition = V(move.id);
        if (definition.shape === 'self' || (ultimate && Go(move.id))) return command;
        mode = ultimate && so(move.id) ? 'ground' : definition.shape;
      }
      break;
    }
    if (!mode) return command;

    const origin = rc(actor.speciesId,actor.x,actor.y);
    let closest = null, distanceSquared = Infinity, aim;
    for (const foe of opponents) {
      if (!foe || foe.hp <= 0) continue;
      const target = rc(foe.speciesId,foe.x,foe.y);
      const dx = target.x-origin.x, dy = target.y-origin.y;
      const distance = dx*dx + dy*dy;
      if (distance < distanceSquared) {
        closest = foe;
        distanceSquared = distance;
        aim = {x:dx,y:dy};
      }
    }
    if (!closest) return command;
    if (mode === 'ground') aim = {x:closest.x-actor.x,y:closest.y-actor.y};
    const result = {...command,aim,buttons:{...buttons,snapAim:true}};

    // Dash *attacks* take their direction from the encoded movement vector.
    // Only change that vector on the actual attack packet. Never steer a dodge
    // or change normal movement prediction just because auto-aim is enabled.
    if (sending && mode === 'dash' && !buttons.dodge && distanceSquared > 0) {
      const distance = Math.sqrt(distanceSquared);
      result.move = {x:aim.x/distance,y:aim.y/distance};
    }
    return result;
  }

  function patch(original) {
    let source = original;
    function replace(anchor,replacement) {
      const index = source.indexOf(anchor);
      if (index < 0 || source.indexOf(anchor,index+anchor.length) !== -1) {
        throw new Error('Unsupported game build. Missing or ambiguous online aim anchor: '+anchor.slice(0,70));
      }
      source = source.slice(0,index) + replacement + source.slice(index+anchor.length);
    }
    const method = aimOnlineCommand.toString().replace(/^function /,'');
    replace('prepareInput(e,t){let n=this.lastCommand',method+'\nprepareInput(e,t){let n=this.lastCommand');
    replace('this.cancelled=!1;let n=Js(e);this.seq+=1',
      'this.cancelled=!1;let n=this.aimOnlineCommand(Js(e),false);this.seq+=1');
    replace('this.sendInput(yw(this.held,this.seq,this.matchId),t)',
      'this.sendInput(yw(this.aimOnlineCommand(this.held,true),this.seq,this.matchId),t)');
    return source;
  }

  const api = Object.freeze({patch});
  globalThis.ArenaOnlineAimAdapter = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})();
