// Applies after the solo menu in the fingerprinted game build. Eligibility and
// each seat's settings belong to the matched room controller, not the renderer.
(() => {
  'use strict';

  function patch(original) {
    let source = original;
    function replace(anchor, replacement) {
      const at = source.indexOf(anchor);
      if (at === -1 || source.indexOf(anchor, at + anchor.length) !== -1) {
        throw new Error('Unsupported game build. Missing or ambiguous private combat anchor: ' + anchor.slice(0, 75));
      }
      source = source.slice(0, at) + replacement + source.slice(at + anchor.length);
    }

    // Cw exists only on the peer chosen to simulate a direct duel. Its resolver
    // captures this room and match so the handshake can revoke or reject it.
    replace('this.client?.send(this.directResult)}),this.authority.pingMs=this.peer.rttMs',
      'this.client?.send(this.directResult)},(seat,key)=>arenaFriendOption(this,e,seat,key),this.you),this.authority.pingMs=this.peer.rttMs');
    replace('constructor(e,t,n){if(this.start=e,this.emit=t,this.result=n,!e.direct',
      'constructor(e,t,n,friendOption,localSeat){if(this.start=e,this.emit=t,this.result=n,!e.direct');
    replace('matchLimitMs:e.direct.limitMs})}setState(e,t){',
      'matchLimitMs:e.direct.limitMs});if(typeof friendOption==="function")this.world.arenaFriendOption=friendOption;' +
      'if((localSeat==="A"||localSeat==="B")&&localSeat===e.direct.host)this.world.arenaHostCooldownSeat=localSeat}setState(e,t){');

    // Cw always represents seat A with world.player and seat B with
    // world.opponent, including when the native host is seat B. Guest prediction
    // already uses the per-fighter walkSpeed published in the native snapshot.
    replace('return this.arenaSoloMods === true && actor === this.player && arenaModEnabled(key);', [
      'if (this.arenaSoloMods === true) return actor === this.player && arenaModEnabled(key);',
      'const seat = actor === this.player ? "A" : actor === this.opponent ? "B" : null;',
      // A Direct host owns its simulation and reads its own timing and speed
      // options directly. Other seats/options use the matched session.
      'if (seat && seat === this.arenaHostCooldownSeat && ["cooldowns","speed","rapidfire","norecovery","supereffective"].includes(key)) return arenaModEnabled(key);',
      'if (!this.arenaFriendOption) return false;',
      'return seat !== null && this.arenaFriendOption(seat, key) === true;'
    ].join('\n'));
    replace('return this.arenaSoloMods&&fighter===this.player&&arenaModEnabled("cooldowns")',
      'return this.localOption(fighter,"cooldowns")');
    replace('if(e==="player"&&t===this.activeOf(e)&&n<this.player.hp&&this.localOption(this.player,"god"))return;',
      'if((e==="player"||e==="opponent")&&t===this.activeOf(e)){const active=this.fighterOf(e);if(n<active.hp&&this.localOption(active,"god"))return;}');
    return source;
  }

  const api = Object.freeze({patch});
  globalThis.ArenaPrivateCombatAdapter = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})();
