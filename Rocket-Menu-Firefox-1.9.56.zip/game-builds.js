// Both Firefox launch paths use the same list of official game releases.
const rocketGameBuilds = Object.freeze({
  clientPath: '/play-online/assets/index-BBhViti1.js',
  clientHash: '06f753660f6405ce447fa04f9a53de87cf1a4e28108fed70bf7cee989ac905c7',
  cacheKey: 'arena.compatible-engine.v1',
  targetVersion: 'v0.9.1',
  targetBuild: '1F9FBC0',
  releases: Object.freeze({
    '/play-online/assets/index-BBhViti1.js': Object.freeze({version:'v0.9.1',build:'F4E96BF'}),
    '/play-online/assets/index-Jt3qNLiM.js': Object.freeze({version:'v0.9.1',build:'D8F0173'}),
    '/play-online/assets/index-C0mgwU-3.js': Object.freeze({version:'v0.9.1',build:'1F9FBC0'})
  }),
  readMetadata(source) {
    const match = typeof source === 'string' && source.match(/return\s*[`"'](v\d+\.\d+\.\d+(?:[-+][A-Za-z0-9.-]+)?)\s*·\s*BUILD\s+([A-Fa-f0-9]{7,40})[`"']/);
    return match ? {version:match[1],build:match[2].toUpperCase()} : {version:'Unknown',build:'Unknown'};
  },
  fullRosterHash: 'ce960e56e53735f92e21cd00a274a89a21dc33afb20e845b10d6be9f05ab7c30',
  deployments: Object.freeze({
    '/play-online/assets/index-CA79LLfk.js': '4a0d10e3dc73571c5e4aeb7a54fd5557889200de1e61ff788b9e512e7826ee5a',
    '/play-online/assets/index-jekZq7aZ.js': '0ee89037d7f6adffe12f2b59bce051310ad7eeaf83de0ffc34ed908fd258bc8c',
    '/play-online/assets/index-Jt3qNLiM.js': '77eb739f0483ee40be22798da4ceb02fdb7e8326b3ddef4be7341a2fe4c0521c',
    '/play-online/assets/index-C0mgwU-3.js': 'a14a515b66628cf0b05ff7608e409dd83887cb276d38f8d619c055f1f0853ce2'
  })
});
