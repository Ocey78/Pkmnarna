// Split interface sounds from battle sounds while retaining the native mixer/UI.
(() => {
  'use strict';

  function createUiAudio(readSettings) {
    const buses = new Map(), media = new Set();
    function scalar(settings, ui = true) {
      const audio = settings.audio;
      const unit = value => Number.isFinite(value) ? Math.min(10, Math.max(0, value)) / 10 : 0;
      return audio.muteAll ? 0 : unit(audio.master) * unit(ui ? audio.uiSfx ?? audio.sfx : audio.sfx);
    }
    function set(settings) {
      for (const [context, entry] of buses) {
        if (context.state === 'closed') { buses.delete(context); continue; }
        entry.gain.gain.setTargetAtTime(scalar(settings) * entry.factor, context.currentTime, .02);
      }
      for (const entry of media) entry.audio.volume = Math.min(1, entry.base * scalar(settings, entry.ui));
    }
    function bus(context, factor = .5, target = context.destination) {
      let entry = buses.get(context);
      if (!entry) {
        const gain = context.createGain();
        gain.gain.value = scalar(readSettings()) * factor;
        gain.connect(target);
        entry = { gain, factor };
        buses.set(context, entry);
      }
      return entry.gain;
    }
    function track(audio, base, ui) {
      const entry = { audio, base, ui };
      audio.volume = Math.min(1, base * scalar(readSettings(), ui));
      media.add(entry);
      const done = () => media.delete(entry);
      for (const event of ['ended', 'error', 'pause', 'abort', 'emptied']) audio.addEventListener(event, done, { once: true });
      return audio;
    }
    return Object.freeze({ scalar, set, bus, media: track, enabled: () => scalar(readSettings()) > 0 });
  }

  function patch(source) {
    function replace(before, after, count = 1) {
      const parts = source.split(before);
      if (parts.length !== count + 1) throw Error('Unsupported game build. Could not split interface and game sound effects.');
      source = parts.join(after);
    }

    // Preserve existing native preferences and migrate UI volume from old SFX.
    replace('audio:{master:8,sfx:8,music:5,muteAll:!1}', 'audio:{master:8,sfx:8,uiSfx:8,music:5,muteAll:!1}');
    replace('sfx:Ar(a?.sfx,0,10,n.audio.sfx),music:', 'sfx:Ar(a?.sfx,0,10,n.audio.sfx),uiSfx:Ar(a?.uiSfx,0,10,Ar(a?.sfx,0,10,n.audio.sfx)),music:');
    replace('t===`off`&&(i.audio.sfx=0),i}function Br(', 't===`off`&&(i.audio.sfx=0),i.audio.uiSfx=i.audio.sfx,i}function Br(');
    replace('function Qr(e){S(Fr(e),e.audio.muteAll)}', 'function Qr(e){S(Fr(e),e.audio.muteAll),arenaUiAudio.set(e)}');

    // UI synth voices share the native compressor, but bypass the battle gain.
    replace('r.connect(a),a.connect(n.destination);', 'r.connect(a),arenaUiAudio.bus(n,.5,a),a.connect(n.destination);');
    replace('l.connect(r),g(e),i({t:u()+.005,tono:o,out:c})', 'l.connect(t.ui?arenaUiAudio.bus(n):r),g(e),i({t:u()+.005,tono:o,out:c})');
    replace('ui(e){this.play(vT(e),Ca/2)}', 'ui(e){arenaPlayUiSfx(vT(e))}');

    // Main-menu/difficulty tones had their own direct-to-speaker context.
    // Its factor keeps the original loudness at the native 8/8 defaults.
    replace('o.connect(i.destination),a.start(t),a.stop(t+n+.02)', 'o.connect(arenaUiAudio.bus(i,1/.64)),a.start(t),a.stop(t+n+.02)');
    replace('function AZ(){if(!Bv())return;', 'function AZ(){if(!arenaUiAudio.enabled())return;');
    replace('function jZ(){if(!Bv())return;', 'function jZ(){if(!arenaUiAudio.enabled())return;');

    // Pack presentation is interface audio. Shared effect names are not remapped.
    replace('blip(e,t={}){this.silent||A(e,t)}', 'blip(e,t={}){this.silent||arenaPlayUiSfx(e,t)}');
    const packStart = 'sounds(e,t,n){', packEnd = 'activeGold(e,t){';
    if (source.split(packStart).length !== 2 || source.split(packEnd).length !== 2) throw Error('Unsupported pack audio.');
    const start = source.indexOf(packStart), end = source.indexOf(packEnd, start);
    const pack = source.slice(start, end);
    if ((pack.match(/\bA\(/g) || []).length !== 7) throw Error('Unsupported pack sound effects.');
    source = source.slice(0, start) + pack.replace(/\bA\(/g, 'arenaPlayUiSfx(') + source.slice(end);

    // Only explicit UI previews use UI volume; shared battle cries keep Game SFX.
    const originalCryLevel = 'let t=ei();if(t.audio.muteAll||t.audio.sfx<=0||t.audio.master<=0)return;let n=t.audio.master/10*(t.audio.sfx/10),r=Cp(e)';
    replace('cry(e){if(this.silent)return;' + originalCryLevel, 'cry(e){if(this.silent)return;let t=ei(),arenaCryLevel=arenaUiAudio.scalar(t);if(arenaCryLevel<=0)return;let n=arenaCryLevel,r=Cp(e)');
    replace('function RJ(e){' + originalCryLevel, 'function RJ(e){let t=ei(),arenaCryLevel=arenaUiAudio.scalar(t);if(arenaCryLevel<=0)return;let n=arenaCryLevel,r=Cp(e)');
    replace('playCry(e){' + originalCryLevel, 'playCry(e,arenaUi=!1){let t=ei(),arenaCryLevel=arenaUiAudio.scalar(t,arenaUi);if(arenaCryLevel<=0)return;let n=arenaCryLevel,r=Cp(e)');
    replace('a.volume=Math.min(1,.7*n),a.addEventListener(`error`,', 'arenaUiAudio.media(a,.7,!0),a.addEventListener(`error`,', 2);
    replace('a.volume=Math.min(1,.45*n),e+1<r.length', 'arenaUiAudio.media(a,.45,arenaUi),e+1<r.length');
    replace('this.playCry(r.id)', 'this.playCry(r.id,!0)');
    replace('t&&this.playCry(t),this.onReady', 't&&this.playCry(t,!0),this.onReady');
    replace('this.playCry(this.detailId)', 'this.playCry(this.detailId,!0)');
    replace('this.playCry(r),this.saveParty()', 'this.playCry(r,!0),this.saveParty()');

    // Extend the existing native pixel sliders, including keyboard and mute state.
    replace('let e=[`master`,`sfx`];return n.music', 'let e=[`master`,`sfx`,`uiSfx`];return n.music');
    replace('case`sfx`:return`SFX`;', 'case`sfx`:return`GAME SFX`;case`uiSfx`:return`UI SFX`;');
    replace('e===`master`||e===`sfx`||e===`music`', 'e===`master`||e===`sfx`||e===`uiSfx`||e===`music`', 2);
    replace('t.kind===`master`||t.kind===`sfx`||t.kind===`music`', 't.kind===`master`||t.kind===`sfx`||t.kind===`uiSfx`||t.kind===`music`');

    return `const arenaUiAudio=(${createUiAudio.toString()})(()=>ei());\nfunction arenaPlayUiSfx(effect,options={}){A(effect,{...options,ui:!0})}\n` + source;
  }

  globalThis.ArenaUiAudioAdapter = Object.freeze({ patch });
  if (typeof module !== 'undefined' && module.exports) module.exports = Object.freeze({ patch, createUiAudio });
})();
