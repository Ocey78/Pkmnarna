// Boss catalog choices stay local; ordinary online loadout copies contain native moves only.
(() => {
  'use strict';
  function createArenaBossMovePicker(){
    function catalog(){arenaBossMoves.register();return arenaBossMoves;}
    function enabled(){return !arenaAnyMoveOnlineDepth&&catalog().enabled();}
    function isMove(id){return catalog().isMove(id);}
    function allowed(id){return enabled()&&isMove(id);}
    function ids(){return catalog().entries().map(entry=>entry.id);}
    function nativeMoves(moves){return Array.isArray(moves)?moves.map(id=>isMove(id)?Me(catalog().baseMove(id)):id):moves;}
    function candidates(ui,items){const allow=ui.arenaRosterOffline===true&&enabled();return items.filter(item=>!item.id||!isMove(item.id)||allow);}
    if(typeof document!=='undefined')document.addEventListener('arena-boss-moves-settings',()=>{
      if(typeof Z!=='undefined'&&Z?.pick?.isConnected){Z.candidatePage=0;Z.paintDetail();}
    });
    return Object.freeze({catalog,enabled,isMove,allowed,ids,nativeMoves,candidates});
  }
  function patch(source){
    const once=(before,after)=>{const parts=source.split(before);if(parts.length!==2)throw Error('Unsupported Boss Moves picker anchor: '+before.slice(0,100));source=parts.join(after);};
    once('function arenaAnyMovePool(){return arenaAnyMoveIds??=Object.freeze([...new Set(Ne().map(Me))].filter(_t))}',
      'function arenaAnyMovePool(){return arenaAnyMoveIds??=Object.freeze([...new Set(Ne().map(Me))].filter(id=>_t(id)&&!arenaBossMovePicker.isMove(id)))}');
    once('function Sn(e){return arenaAnyMoveEnabled()&&hn.has(e)?arenaAnyMovePool():xn(e).ids}',
      'function Sn(e){let ids=arenaAnyMoveEnabled()&&hn.has(e)?arenaAnyMovePool():xn(e).ids;return hn.has(e)&&arenaBossMovePicker.enabled()?[...ids,...arenaBossMovePicker.ids()]:ids}');
    once('function wn(e,t){return arenaAnyMoveEnabled()&&hn.has(e)&&arenaAnyMovePool().includes(t)||xn(e).strips.has(yn(t))}',
      'function wn(e,t){if(arenaBossMovePicker.isMove(t))return hn.has(e)&&arenaBossMovePicker.allowed(t);return arenaAnyMoveEnabled()&&hn.has(e)&&arenaAnyMovePool().includes(t)||xn(e).strips.has(yn(t))}');
    once('function Tn(e,t,arenaStored=false){', 'function Tn(e,t,arenaStored=false){arenaBossMovePicker.catalog();');
    once('!(arenaStored&&arenaAnyMovePool().includes(n))', '!(arenaStored&&(arenaAnyMovePool().includes(n)||arenaBossMovePicker.isMove(n)))');
    once('if(!arenaAnyMoveEnabled()||!hn.has(species)||!mn.includes(requestedSlot)||!arenaAnyMovePool().includes(moveId))return null;',
      'if((!arenaAnyMoveEnabled()&&!arenaBossMovePicker.enabled())||!hn.has(species)||!mn.includes(requestedSlot)||(!arenaAnyMovePool().includes(moveId)&&!arenaBossMovePicker.allowed(moveId)))return null;');
    once('if(arenaAnyMoveEnabled())return Sn(e).filter(id=>', 'if(arenaAnyMoveEnabled()||arenaBossMovePicker.enabled())return Sn(e).filter(id=>');
    once('function Iv(e,t,n,r){if(arenaAnyMoveEnabled()&&r!==null)',
      'function Iv(e,t,n,r){if((arenaAnyMoveEnabled()||arenaBossMovePicker.enabled())&&r!==null)');
    once('function Mn(e,t,arenaStored=false){if(Tn(e,t,arenaStored))',
      'function Mn(e,t,arenaStored=false){if(!arenaStored&&!arenaBossMovePicker.enabled())t=arenaBossMovePicker.nativeMoves(t);if(Tn(e,t,arenaStored))');
    once('b.sort((e,t)=>arenaMoveSortCompare(e,t,V));',
      'b=arenaBossMovePicker.candidates(this,b);b.sort((e,t)=>arenaMoveSortCompare(e,t,V));');
    once('function TO(e,species){return arenaAnyMoveOnline(()=>[0,1,2].map(t=>{let n=e[t],id=species?.[t];return n&&hn.has(id)?Mn(id,n):null}))}',
      'function TO(e,species){return arenaAnyMoveOnline(()=>[0,1,2].map(t=>{let n=arenaBossMovePicker.nativeMoves(e[t]),id=species?.[t];return n&&hn.has(id)?Mn(id,n):null}))}');
    // The custom Direct loadout path must be sanitized as well as the server wire path.
    once('if (Array.isArray(selected) && Tn(species, selected, true)) return selected.slice();',
      'if (Array.isArray(selected)) { const native = arenaBossMovePicker.nativeMoves(selected); if (Tn(species, native, true)) return native.slice(); }');
    return 'const arenaBossMovePicker=('+createArenaBossMovePicker.toString()+')();globalThis.arenaBossMovePicker=arenaBossMovePicker;\n'+source;
  }
  const api=Object.freeze({patch});globalThis.ArenaBossMovePickerAdapter=api;if(typeof module!=='undefined'&&module.exports)module.exports=api;
})();
