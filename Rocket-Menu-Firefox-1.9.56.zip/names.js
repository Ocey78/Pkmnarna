// Edit only real game names. The service's room frames confirm renames.
(() => {
  'use strict';
  function createArenaNames() {
    let editor = null, committingClient = null;
    const trainerHint = 'Use the game\'s supported name parts, such as QuietPilot37, or Trainer1234.';
    const roomHint = 'Use a supported room name, such as Hasty Grove 63. Set it before creating the room.';
    try { localStorage.removeItem('arena.mod.display-name.v1'); } catch {}
    try { sessionStorage.removeItem('arena.mod.room-labels.v1'); } catch {}
    function gameRoomName(value) {
      if (typeof value !== 'string') return false;
      const parts = value.split(' ');
      return parts.length === 3 && pr.includes(parts[0]) && hr.includes(parts[1]) && /^\d{2}$/.test(parts[2]);
    }
    function controller() { return typeof hO === 'undefined' ? null : hO; }
    function ownName(room) { return room?.seats?.[Fc(room.you)]?.name; }
    function persisted(value) {
      try { return JSON.parse(localStorage.getItem('poke2d.settings') || 'null')?.profile?.name === value; }
      catch { return false; }
    }
    function commit(value, client) {
      committingClient = client || null;
      try { AD(value); } finally { committingClient = null; }
      return persisted(value);
    }
    function profileChanged(c, value) {
      if (c.client && c.client !== committingClient) c.client.send({t:'rename', name:value});
    }
    function roomConfirmed(c, room) {
      if (!c.active || c.code !== room.code || !c.client?.options) return;
      const name = ownName(room);
      if (br(name)) c.client.options.name = name;
    }
    async function saveTrainer(raw) {
      const value = typeof raw === 'string' ? raw.trim() : '';
      if (!br(value)) throw Error(trainerHint);
      const c = controller();
      if (!c?.active || !c.client) {
        const previous = ei().profile.name;
        if (!commit(value)) {
          commit(previous);
          throw Error('Firefox could not save this name. Your previous name is unchanged.');
        }
        return {confirmed:false, persisted:true};
      }
      const client = c.client, code = c.code, seat = c.you;
      if (c.mode !== 'room' || c.linkDown || !c.room || client.ws?.readyState !== 1 ||
          !['open','lobby'].includes(c.room.state)) throw Error('Return to a connected waiting room to change your name.');
      if (ownName(c.room) === value) {
        roomConfirmed(c, c.room);
        return {confirmed:true, persisted:commit(value, client)};
      }
      await new Promise((resolve, reject) => {
        let finished = false, timer, watcher, unmessage = () => {}, unclose = () => {};
        const sameRoom = () => controller() === c && c.active && c.client === client && c.code === code && c.you === seat;
        function finish(error) {
          if (finished) return;
          finished = true; window.clearTimeout(timer); window.clearInterval(watcher); unmessage(); unclose();
          error ? reject(Error(error)) : resolve();
        }
        unmessage = client.onMessage(message => {
          if (['error','kicked','dissolved'].includes(message.t)) return finish(message.msg || message.reason || 'The server did not confirm the name change.');
          if (!sameRoom()) return finish('The room changed before the name was confirmed.');
          if (message.t === 'room' && message.code === code && message.you === seat && ownName(message) === value) {
            client.options.name = value;
            finish();
          }
        });
        unclose = client.onClose(() => finish('The connection closed before the name was confirmed.'));
        watcher = window.setInterval(() => { if (!sameRoom()) finish('The room changed before the name was confirmed.'); }, 100);
        timer = window.setTimeout(() => finish('The server did not confirm this name. Your saved name is unchanged.'), 8000);
        try { client.send({t:'rename', name:value}); }
        catch { finish('Unable to send the name change. Your saved name is unchanged.'); }
      });
      if (controller() !== c || !c.active || c.client !== client || c.code !== code || c.you !== seat)
        throw Error('The room changed before the name could be saved.');
      return {confirmed:true, persisted:commit(value, client)};
    }
    function el(tag, text) {
      const node = document.createElement(tag);
      if (text !== undefined) node.textContent = text;
      return node;
    }
    function style() {
      if (document.getElementById('arena-name-style')) return;
      const sheet = el('style'); sheet.id = 'arena-name-style';
      sheet.textContent = [
        '#arena-name-editor{color-scheme:dark;box-sizing:border-box;margin:auto;max-width:calc(100vw - 30px);width:390px;border:1px solid #dc244b;border-radius:8px;background:#17171d;color:#f4f1f3;padding:18px;font:14px/1.45 system-ui,sans-serif;z-index:2147483646}',
        '#arena-name-editor::backdrop{background:#09090ec9}#arena-name-editor form{display:grid;gap:10px}#arena-name-editor h2{font:700 19px/1.2 system-ui,sans-serif;margin:0}#arena-name-editor p{margin:0;color:#d4cbd0;font-size:12px}',
        '#arena-name-editor input,#arena-name-editor select{font:15px/1.35 system-ui,sans-serif;color:#f4f1f3;background:#101016;border:1px solid #70636a;border-radius:4px;padding:7px;width:100%;box-sizing:border-box}',
        '#arena-name-editor button{font:600 13px system-ui,sans-serif;border:1px solid #79636d;background:#29232b;color:#f4f1f3;border-radius:4px;cursor:pointer;padding:7px 10px}#arena-name-editor [type=submit]{background:#bd183a;border-color:#ee345c}#arena-name-editor button:disabled{opacity:.5;cursor:default}',
        '#arena-name-editor .arena-name-actions{display:flex;flex-wrap:wrap;gap:7px}#arena-name-editor label{font-weight:650}#arena-name-editor [role=alert]{color:#ff9eb3}',
        '#arena-name-editor .arena-name-parts{display:grid;grid-template-columns:1fr 1fr 72px;gap:6px;margin-top:8px}#arena-name-editor summary{cursor:pointer;font-size:12px}',
        '.arena-room-name-help{display:block;margin:5px 0;color:inherit;font:12px/1.35 system-ui,sans-serif}'
      ].join('\n');
      document.head.appendChild(sheet);
    }
    function nameParts(input, update) {
      const details = el('details'), summary = el('summary', 'Choose supported name parts'), row = el('div');
      row.className = 'arena-name-parts';
      const first = el('select'), second = el('select'), number = el('input');
      first.setAttribute('aria-label','First name part'); second.setAttribute('aria-label','Second name part'); number.setAttribute('aria-label','Two-digit number');
      for (const text of pr) { const option = el('option', text); option.value = text; first.append(option); }
      for (const text of mr) { const option = el('option', text); option.value = text; second.append(option); }
      first.value = pr.find(part => input.value.startsWith(part)) || pr[0];
      second.value = mr.find(part => input.value === first.value + part + input.value.slice(-2)) || mr[0];
      number.type = 'number'; number.min = '0'; number.max = '99'; number.step = '1'; number.value = input.value.slice(-2).match(/^\d{2}$/)?.[0] || '00';
      const use = () => { const n = Number(number.value); if (number.value !== '' && Number.isInteger(n) && n >= 0 && n < 100) { input.value = first.value + second.value + String(n).padStart(2,'0'); update(); } };
      for (const node of [first,second,number]) node.addEventListener('change',use);
      row.append(first,second,number); details.append(summary,row); return details;
    }
    function editTrainer(settings) {
      if (editor?.open) return;
      editor?.remove(); style();
      const c = controller(), inRoom = c?.active && c.room;
      const d = el('dialog'); d.id = 'arena-name-editor'; d.setAttribute('aria-labelledby','arena-name-heading');
      const form = el('form'), heading = el('h2','Trainer name'), label = el('label','Name'), input = el('input');
      heading.id = 'arena-name-heading'; label.htmlFor = input.id = 'arena-name-value';
      input.type = 'text'; input.maxLength = 16; input.autocomplete = 'off'; input.value = inRoom ? ownName(c.room) : ei().profile.name;
      const hint = el('p'), result = el('p'); hint.id = 'arena-name-hint'; result.id = 'arena-name-result'; result.setAttribute('role','status');
      input.setAttribute('aria-describedby', hint.id + ' ' + result.id);
      const buttons = el('div'); buttons.className = 'arena-name-actions';
      const save = el('button','Save'), cancel = el('button','Cancel'), roll = el('button','Roll');
      save.type = 'submit'; save.dataset.saveName = ''; cancel.type = roll.type = 'button';
      let busy = false;
      function update() { const valid = br(input.value.trim()); save.disabled = busy || !valid; hint.textContent = valid ? (inRoom ? 'The server must confirm this change before it is saved.' : 'This real game name will be used the next time you connect.') : trainerHint; result.textContent = ''; result.setAttribute('role','status'); }
      function pending(value) { busy = value; for (const node of form.querySelectorAll('input,select,button')) node.disabled = value; save.disabled = value || !br(input.value.trim()); }
      roll.addEventListener('click', () => { input.value = yr(); update(); input.select(); });
      input.addEventListener('input', update);
      cancel.addEventListener('click', () => d.close());
      d.addEventListener('cancel', event => { if (busy) event.preventDefault(); });
      d.addEventListener('close', () => { if (editor === d) editor = null; d.remove(); });
      form.addEventListener('submit', async event => {
        event.preventDefault(); if (busy) return;
        pending(true); result.textContent = inRoom ? 'Waiting for the server…' : 'Saving…';
        try {
          const saved = await saveTrainer(input.value);
          if (settings && pE) { TE = ei().profile.name; NE(); WE(); }
          if (!saved.persisted) { pending(false); result.setAttribute('role','alert'); result.textContent = 'Changed for this room, but Firefox could not save it for later.'; cancel.textContent = 'Close'; return; }
          d.close();
        } catch (error) { pending(false); result.setAttribute('role','alert'); result.textContent = error.message; }
      });
      for (const kind of ['keydown','keyup','pointerdown','pointerup','click']) d.addEventListener(kind,event=>event.stopPropagation());
      buttons.append(save,cancel,roll); form.append(heading,label,input,hint,nameParts(input,update),result,buttons); d.append(form); document.body.append(d); editor=d;
      update(); d.showModal(); input.focus(); input.select();
    }
    function createField(input) {
      if (!input) return;
      style(); const hint = el('small',roomHint); hint.className = 'arena-room-name-help'; hint.id = 'arena-room-name-help';
      input.setAttribute('aria-describedby',hint.id); input.parentElement.after(hint);
      const update = () => input.setCustomValidity(gameRoomName(input.value.trim()) ? '' : roomHint);
      input.addEventListener('input',update);
      input.closest('form')?.querySelector('[data-action="roll-room"]')?.addEventListener('click',()=>queueMicrotask(update));
      update();
    }
    function submitCreate(send, input, visibility, mode) {
      const name = input?.value?.trim() || '';
      if (!gameRoomName(name)) { input?.setCustomValidity(roomHint); input?.reportValidity(); return; }
      input.setCustomValidity(''); return send(name,visibility,mode);
    }
    return {saveTrainer, profileChanged, roomConfirmed, gameRoomName, editTrainer, createField, submitCreate, editing:()=>!!editor?.open};
  }
  function patch(source) {
    function replace(before, after) { const parts = source.split(before); if(parts.length !== 2) throw Error('Unsupported real-name control anchor: '+before.slice(0,70)); source = parts.join(after); }
    replace('function _r(e,t){return e[Math.floor(t()*e.length)%e.length]}', 'const arenaNames=('+createArenaNames.toString()+')();\nfunction _r(e,t){return e[Math.floor(t()*e.length)%e.length]}');
    // The standalone Profile owns the sole trainer-name editing entry point.
    // Keep the native read-only name display without a Settings action.
    replace('<button type="button" class="px edit" data-act="roll" aria-label="Random trainer name">ROLL</button>', '');
    replace('if(r===`roll`){jD();return}', 'if(r===`roll`){return}');
    replace('e.kind===`name`?jD():e.kind===`reset`', 'e.kind===`name`?void 0:e.kind===`reset`');
    replace('function GD(e){if(!pE&&!mE)', 'function GD(e){if(arenaNames.editing())return;if(!pE&&!mE)');
    replace('${n?`<button type="button" class="px-btn" data-action="roll-name" aria-label="Random trainer name">ROLL</button>`:``}', '');
    replace('e.profile.name!==i&&(i=e.profile.name,this.client?.send({t:`rename`,name:i}))', 'e.profile.name!==i&&(i=e.profile.name,arenaNames.profileChanged(this,i))');
    replace('this.roomReceivedAt=performance.now(),this.you=e.you,', 'this.roomReceivedAt=performance.now(),this.you=e.you,arenaNames.roomConfirmed(this,e),');
    replace('<input data-field="room-name" readonly tabindex="-1"', '<input data-field="room-name" type="text" maxlength="32" required autocomplete="off"');
    replace('let s=i.querySelector(`[data-field="room-name"]`);i.querySelector', 'let s=i.querySelector(`[data-field="room-name"]`);arenaNames.createField(s);i.querySelector');
    replace('Promise.resolve(n(s?.value??``,a,o))', 'Promise.resolve(arenaNames.submitCreate(n,s,a,o))');
    return source;
  }
  const api = Object.freeze({patch}); globalThis.ArenaNamesAdapter = api;
  if(typeof module !== 'undefined' && module.exports) module.exports = {patch, createArenaNames};
})();
