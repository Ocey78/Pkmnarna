// Main-menu DOM layout only: preserve the native field/camera plan and artwork.
(() => {
  'use strict';

  function metrics(width, height, plan, logo, tag) {
    const margin = width < 700 ? 12 : 24;
    const compact = height < 460;
    const headerClearance = compact ? 54 : 68;
    const bottom = compact ? 12 : 24;
    // The existing Rocket launcher occupies the outer 46px; keep a 12px gap.
    const rightGutter = 58;
    const columnWidth = Math.min(width - margin - rightGutter, width * (width < 520 ? .85 : .49),
      Math.max(320, Math.min(520, height * .55)));
    const logoScale = Math.min(1, plan.column.w * .88 / Math.max(1, logo.width), (compact ? 60 : 120) / Math.max(1, logo.height));
    const showTag = height >= 540;
    const tagScale = showTag ? Math.min(1, plan.column.w * .9 / Math.max(1, tag.width), 26 / Math.max(1, tag.height)) : 0;
    const gap = compact ? 10 : 18;
    const headerHeight = logo.height * logoScale + (showTag ? 6 + tag.height * tagScale : 0) + gap;
    // Size every page against the six-row home menu. A shorter submenu keeps
    // its first button in place and keeps the same spacing as the home menu.
    const rowCount = Math.max(6, plan.rows.length);
    const regularHeight = plan.rows[1]?.h ?? plan.rows[0].h;
    const reservedRows = plan.rows.reduce((sum,row) => sum + row.h, 0) + (rowCount - plan.rows.length) * regularHeight;
    const rowGap = regularHeight * (compact ? .18 : .25);
    const groupHeight = headerHeight + reservedRows + (rowCount - 1) * rowGap;
    const availableHeight = height - headerClearance - bottom;
    const scale = Math.max(.1, Math.min(columnWidth / plan.column.w, availableHeight / groupHeight));
    const top = headerClearance + Math.round(Math.max(0, availableHeight - groupHeight * scale) / 2);
    const actualWidth = plan.column.w * scale;
    const columnLeft = margin;
    const stackTop = top + headerHeight * scale;
    let rowY = plan.column.y;
    const rowOffsets = plan.rows.map(row => {
      const offset = rowY - row.y;
      rowY += row.h + rowGap;
      return offset;
    });
    return {
      margin, top, scale, showTag, rightGutter, rowOffsets,
      stackTop,
      stackBottom: stackTop + (rowY - plan.column.y - rowGap) * scale,
      stackLeft: columnLeft,
      stackWidth: actualWidth,
      translateX: columnLeft - plan.column.x * scale,
      translateY: top + headerHeight * scale - plan.column.y * scale,
      logoScale: logoScale * scale,
      logoX: columnLeft + (actualWidth - logo.width * logoScale * scale) / 2,
      logoY: top,
      logoBottom: top + logo.height * logoScale * scale,
      tagScale: tagScale * scale,
      tagX: columnLeft + (actualWidth - tag.width * tagScale * scale) / 2,
      tagY: top + (logo.height * logoScale + 6) * scale
    };
  }

  function place(root, plan, paintLogo, paintPixelText) {
    if (!root || !plan?.column) return;
    const width = root.clientWidth, height = root.clientHeight;
    if (!width || !height) return;
    const title = root.querySelector('.menu-title'), subtitle = root.querySelector('.menu-sub');
    const absolute = root.querySelector('.menu-abs');
    if (!title || !subtitle || !absolute) return;
    let stack = absolute.querySelector('.rocket-menu-stack');
    if (!stack) {
      stack = root.ownerDocument.createElement('div');
      stack.className = 'rocket-menu-stack';
      Object.assign(stack.style, { position: 'absolute', inset: '0', transformOrigin: '0 0', pointerEvents: 'none' });
      for (const selector of ['.menu-column', '.menu-fight', '.menu-desc', '.menu-arrow.is-left', '.menu-arrow.is-right']) {
        const node = absolute.querySelector(selector);
        if (node) stack.appendChild(node);
      }
      absolute.appendChild(stack);
    }
    const wordScale = Math.max(2, Math.ceil(plan.column.w / 48));
    const logoPlan = { ...plan, tag: { ...plan.tag, text: 'ROCKET EDITION' }, ring: { ...plan.ring, wordScale: [wordScale, Math.round(wordScale * 1.24)], wordMaxW: Math.floor(plan.column.w * .9) } };
    paintLogo(root, logoPlan);
    const tagCanvas = subtitle.querySelector('canvas.pixel-text');
    if (tagCanvas && tagCanvas.dataset.rocketTint !== '1') {
      const context = tagCanvas.getContext('2d');
      if (context) {
        const prefix = paintPixelText('ROCKET ', { font: 'Press Start 2P', px: 8, weight: 400, color: '#EF3340', scale: Number.parseFloat(subtitle.style.borderWidth) || 1 });
        context.imageSmoothingEnabled = false;
        context.drawImage(prefix, 0, 0);
        tagCanvas.dataset.rocketTint = '1';
      }
    }
    Object.assign(subtitle.style, { background: '#21151E', borderColor: '#CC2F45', boxShadow: '0 1px 0 #F2EDF4' });
    const canvas = title.querySelector('canvas.pixel-text');
    if (!canvas) return;
    const layout = arenaMenuLayoutMetrics(width, height, plan, { width: canvas.width, height: canvas.height }, { width: subtitle.offsetWidth, height: subtitle.offsetHeight });
    stack.style.transform = `translate(${layout.translateX}px,${layout.translateY}px) scale(${layout.scale})`;
    const description = root.querySelector('.menu-desc');
    if (description) { description.hidden = true; description.style.display = 'none'; }
    let selectedOffset = 0;
    for (const button of root.querySelectorAll('.menu-fight .menu-btn')) {
      const row = plan.rowFor[Number(button.dataset.index)];
      const offset = layout.rowOffsets[plan.rows.indexOf(row)] || 0;
      button.style.translate = `0 ${offset}px`;
      if (button.classList.contains('is-on')) selectedOffset = offset;
    }
    for (const arrow of root.querySelectorAll('.menu-arrow')) arrow.style.translate = `0 ${selectedOffset}px`;
    // Mirror the scenery as whole layers; the UI and playable arena stay upright.
    for (const layer of root.querySelectorAll(':scope > .menu-field,:scope > .menu-vignette,:scope > .menu-cast')) {
      Object.assign(layer.style, { transform: 'scaleX(-1)', transformOrigin: '50% 50%' });
      // Native cast children are absolutely positioned, leaving their parent
      // at zero size. Give it viewport bounds before reflecting their positions.
      if (layer.classList.contains('menu-cast')) Object.assign(layer.style, { width: '100%', height: '100%' });
    }
    Object.assign(title.style, { left: `${layout.logoX}px`, top: `${layout.logoY}px`, transformOrigin: '0 0', transform: `scale(${layout.logoScale})` });
    Object.assign(subtitle.style, { left: `${layout.tagX}px`, top: `${layout.tagY}px`, transformOrigin: '0 0', transform: `scale(${layout.tagScale || 1})`, visibility: layout.showTag ? '' : 'hidden' });
    for (const node of root.querySelectorAll('.menu-disclaimer,.menu-site')) {
      node.style.transformOrigin = '0 0';
      node.style.transform = width < 700 || height < 460 ? 'scale(.75)' : '';
    }
    root.dataset.rocketMenuLayout = 'left-logo';
  }

  function sharedSurface(active, view) {
    try {
      const frame = view.frameElement;
      if (!frame || frame.getAttribute('data-home-menu') !== 'shared-v1' || view.parent.location.origin !== view.location.origin) return;
      const container = frame.closest('[data-game-window]');
      if (!container || container.ownerDocument !== view.parent.document) return;
      if (!active) { frame.removeAttribute('data-rocket-menu-active'); return; }
      const parentDocument = container.ownerDocument;
      if (!parentDocument.getElementById('rocket-home-menu-scene-style')) {
        const style = parentDocument.createElement('style');
        style.id = 'rocket-home-menu-scene-style';
        // Removing the iframe immediately restores the original homepage artwork.
        const activeMenu = '[data-game-window].is-playing:has(>iframe[data-rocket-menu-active="1"])';
        style.textContent = `${activeMenu} .hero-scene{visibility:hidden!important}${activeMenu} :is(.hero-bg,.hero-vignette){transform:scaleX(-1);transform-origin:50% 50%}`;
        parentDocument.head.appendChild(style);
      }
      if (!view.document.getElementById('rocket-home-menu-logo-style')) {
        const style = view.document.createElement('style');
        style.id = 'rocket-home-menu-logo-style';
        // The parent grass image retains its framing and zoom while mirrored.
        style.textContent = '.home-menu-surface .menu-root[data-rocket-menu-layout="left-logo"] :is(.menu-title,.menu-sub,.menu-cast){display:block!important}';
        view.document.head.appendChild(style);
      }
      frame.setAttribute('data-rocket-menu-active', '1');
      if (!frame.__rocketMenuPagehideAttached) {
        frame.__rocketMenuPagehideAttached = true;
        view.addEventListener('pagehide', () => frame.removeAttribute('data-rocket-menu-active'));
      }
    } catch { /* Cross-origin or already-detached frames retain the native homepage. */ }
  }

  function patch(source) {
    const replace = (before, after) => {
      const parts = source.split(before);
      if (parts.length !== 2) throw Error('Unsupported game build. Could not arrange the main menu.');
      source = parts.join(after);
    };
    // Paint the native logo once, using the header's sizing rather than the field center.
    replace('function RQ(e,t){LQ(e,t);', 'function RQ(e,t){');
    replace('this.placeArrows(e,t)}paintPacksRow()', 'this.placeArrows(e,t),arenaMenuPlaceLayout(e,t,LQ,rE)}paintPacksRow()');
    replace('function _Q(e,t=window){if(!gQ(t))return;', 'function _Q(e,t=window){if(!gQ(t))return;arenaMenuSharedSurface(e,t);');
    return `const arenaMenuLayoutMetrics=(${metrics.toString()});\nconst arenaMenuPlaceLayout=(${place.toString()});\nconst arenaMenuSharedSurface=(${sharedSurface.toString()});\n` + source;
  }

  globalThis.ArenaMenuLayoutAdapter = Object.freeze({ patch });
  if (typeof module !== 'undefined' && module.exports) module.exports = Object.freeze({ patch, metrics, sharedSurface });
})();
