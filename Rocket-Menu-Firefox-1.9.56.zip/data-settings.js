// Combined XML saves and secret-code activation under native Settings > Data.
(() => {
  'use strict';
  function createDataSettings() {
    let cleanup = null, cleanupVersions = null, mounted = null, incoming = null;
    let saveName = null, codeStatus = '', selectedSave = null, preparedSave = null;
    function dispose() { cleanup?.(); cleanupVersions?.(); cleanup = null; cleanupVersions = null; mounted = null; }
    function open(options = {}) {
      incoming = options.incoming || null;
      zE({ group: 'data', onClose: options.onClose, onLeave: options.onClose });
    }
    function node(tag, text, className) {
      const element = document.createElement(tag);
      if (text !== undefined) element.textContent = text;
      if (className) element.className = className;
      return element;
    }
    function button(label, action) {
      const element = node('button', label);
      element.type = 'button'; element.dataset.rocketDataAction = action;
      return element;
    }
    function style() {
      if (document.getElementById('rocket-data-style')) return;
      const sheet = node('style'); sheet.id = 'rocket-data-style';
      sheet.textContent = `
        #settings:has([data-rocket-data]) .shell{grid-template-rows:auto minmax(0,1fr)}
        #settings:has([data-rocket-data]) .panel{height:auto;min-height:0;align-self:stretch}
        #settings:has([data-rocket-data]) .rows{flex:1 1 0;min-height:0;overflow-y:auto;overflow-x:hidden;overscroll-behavior:contain;scrollbar-gutter:stable;scroll-padding-block:12px}
        #settings:has([data-rocket-data]) .rows>*{flex-shrink:0}
        #settings [data-rocket-data]{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,360px),1fr));align-items:start;gap:16px;margin:0 0 18px;min-width:0;color:var(--ui-text,#f8f8f8);font:14px/1.5 Silkscreen,monospace}
        #settings .rocket-data-panel{border:2px solid var(--ui-frame-hi,#aeb1cb);box-shadow:inset 0 0 0 2px var(--ui-outline,#0a0c18);background:var(--ui-panel,#272f55);padding:14px;min-width:0}
        #settings .rocket-data-panel h2{font:700 18px/1.4 Silkscreen,monospace;margin:0 0 10px;color:var(--ui-text,#f8f8f8)}
        #settings .rocket-data-panel h3,#settings .rocket-data-panel .save-title{font:700 14px/1.4 Silkscreen,monospace;margin:12px 0 6px}
        #settings .rocket-data-panel p{font:12px/1.5 Silkscreen,monospace;margin:8px 0;overflow-wrap:anywhere}
        #settings .rocket-data-versions{grid-column:1/-1;padding:10px 14px}
        #settings .rocket-data-versions .rocket-data-version-line{display:flex;flex-wrap:wrap;gap:2px 3ch;margin:0;font:700 12px/1.5 Silkscreen,monospace;white-space:normal}
        #settings .rocket-data-versions .rocket-data-version-line+.rocket-data-version-line{margin-top:5px}
        #settings .rocket-data-version-line span{min-width:0;overflow-wrap:anywhere}
        #settings .rocket-data-panel textarea{display:block;box-sizing:border-box;width:100%;min-width:0;min-height:70px;resize:vertical;border:2px solid var(--ui-frame-hi,#aeb1cb);border-radius:0;background:var(--ui-bg,#10142a);color:var(--ui-text,#f8f8f8);padding:8px;font:12px/1.4 monospace;overflow-wrap:anywhere}
        #settings .rocket-save-panel{grid-column:1/-1}
        #settings .rocket-data-field{display:grid;gap:6px;font:700 14px/1.4 Silkscreen,monospace;min-width:0}
        #settings .rocket-data-panel input{box-sizing:border-box;min-width:0;width:100%;border:2px solid var(--ui-frame-hi,#aeb1cb);border-radius:0;background:var(--ui-bg,#10142a);color:var(--ui-text,#f8f8f8);padding:8px;font:12px/1.5 Silkscreen,monospace}
        #settings .rocket-data-panel input[type="file"]{padding:5px;overflow:hidden}
        #settings .rocket-data-panel input::file-selector-button{border:2px solid var(--ui-frame-hi,#aeb1cb);border-radius:0;background:var(--ui-panel,#272f55);color:var(--ui-text,#f8f8f8);padding:6px;margin-right:8px;font:12px/1.4 Silkscreen,monospace;cursor:pointer}
        #settings .rocket-save-export{display:flex;flex-wrap:wrap;align-items:end;gap:10px}
        #settings .rocket-save-export .rocket-data-field{flex:1 1 220px}
        #settings .rocket-data-section{border-top:2px solid var(--ui-frame-hi,#aeb1cb);padding-top:14px;margin-top:14px}
        #settings .rocket-data-panel button{position:static;display:inline-block;width:auto;height:auto;min-height:36px;border:2px solid var(--ui-frame-hi,#aeb1cb);border-radius:0;box-shadow:2px 2px 0 var(--ui-outline,#0a0c18);background:var(--ui-panel,#272f55);color:var(--ui-text,#f8f8f8);padding:6px 10px;font:700 12px/1.4 Silkscreen,monospace;cursor:pointer}
        #settings .rocket-data-panel button:disabled{opacity:.45;cursor:default}
        #settings .rocket-data-panel button:focus-visible,#settings .rocket-data-panel textarea:focus-visible{outline:2px solid var(--ui-cursor,#f87818);outline-offset:3px}
        #settings .rocket-data-panel .save-actions,#settings .rocket-data-actions{display:flex;align-items:center;flex-wrap:wrap;gap:8px;margin:8px 0}
        #settings .rocket-data-panel .save-panel{border:0;padding:0;margin:0;box-shadow:none;background:none}
        #settings .rocket-data-panel .save-status,#settings .rocket-data-status{color:var(--ui-text,#f8f8f8);min-height:1.5em}
        #settings .rocket-data-confirm{border-top:2px solid var(--ui-frame-hi,#aeb1cb);margin-top:12px;padding-top:6px}
        #settings [data-rocket-data] [hidden]{display:none!important}
        @media(max-width:600px){#settings .rocket-data-panel{padding:10px}#settings .rocket-data-panel h2{font-size:16px}}
      `;
      document.head.append(sheet);
    }
    function versionPanel(){
      const panel=node('section',undefined,'rocket-data-panel rocket-data-versions');
      panel.setAttribute('aria-label','Game and Rocket versions');panel.setAttribute('aria-live','polite');
      const game=node('p',undefined,'rocket-data-version-line'),rocket=node('p',undefined,'rocket-data-version-line');
      game.title='Official site release';rocket.title='Rocket release and latest supported site build';
      game.title='Official site release; Rocket may run a verified compatibility client.';
      rocket.title='TARGET is the latest official site build supported by this Rocket release.';
      const siteVersion=node('span'),siteBuild=node('span'),rocketVersion=node('span'),rocketTarget=node('span');
      game.append(siteVersion,siteBuild);rocket.append(rocketVersion,rocketTarget);panel.append(game,rocket);
      const version=value=>typeof value==='string'&&/^v?\d+\.\d+\.\d+(?:[-+][\w.-]+)?$/.test(value.trim())?'v'+value.trim().replace(/^v/,''):'Unknown';
      const build=value=>typeof value==='string'&&/^[a-f\d]{7,64}$/i.test(value.trim())?value.trim().toUpperCase():'Unknown';
      const put=(element,value)=>{if(element.textContent!==value)element.textContent=value;};
      function refresh(){
        const doc=document.documentElement,release=globalThis.ArenaRocketRelease;
        put(siteVersion,'GAME VERSION '+version(doc.getAttribute('data-arena-site-version')));
        put(siteBuild,'BUILD '+build(doc.getAttribute('data-arena-site-build')));
        put(rocketVersion,'ROCKET VERSION '+version(release?.version));
        put(rocketTarget,'TARGET '+build(release?.targetBuild));
      }
      refresh();
      document.addEventListener('arena-site-update',refresh);
      document.addEventListener('arena-site-metadata',refresh);
      const observer=new MutationObserver(refresh);
      observer.observe(document.documentElement,{attributes:true,attributeFilter:['data-arena-site-version','data-arena-site-build']});
      cleanupVersions=()=>{
        observer.disconnect();
        document.removeEventListener('arena-site-update',refresh);
        document.removeEventListener('arena-site-metadata',refresh);
      };
      return panel;
    }
    function savePanel(){
      const panel=node('section',undefined,'rocket-data-panel rocket-save-panel');
      panel.setAttribute('aria-label','Combined save data');
      panel.append(node('h2','Save data'),node('p','Game data, Rocket profile and match history in one XML file. Replays stay on this device.'));
      const exportRow=node('div',undefined,'rocket-save-export'),nameLabel=node('label','Save name','rocket-data-field'),name=node('input');
      name.type='text';name.maxLength=80;name.autocomplete='off';name.spellcheck=false;
      name.value=saveName??(ei().profile.name||'Rocket Save');
      name.addEventListener('input',()=>{saveName=name.value;codeStatus='';status.textContent='';});nameLabel.append(name);
      const exportButton=button('Export XML','export-xml');exportRow.append(nameLabel,exportButton);panel.append(exportRow);
      const importSection=node('div',undefined,'rocket-data-section'),fileLabel=node('label','Import save file','rocket-data-field'),file=node('input');
      file.type='file';file.accept='.xml,application/xml,text/xml';fileLabel.append(file);
      const selected=node('p',selectedSave?'Selected: '+selectedSave.name:'');
      const importButton=button('Import XML','import-xml'),actions=node('div',undefined,'rocket-data-actions');actions.append(importButton);
      const confirm=node('div',undefined,'rocket-data-confirm'),question=node('p'),replace=button('Replace saved data','confirm-xml'),cancel=button('Cancel','cancel-xml');
      const confirmActions=node('div',undefined,'rocket-data-actions');confirmActions.append(replace,cancel);confirm.append(question,confirmActions);confirm.hidden=true;
      const status=node('p','','rocket-data-status');status.setAttribute('role','status');status.setAttribute('aria-live','polite');
      importSection.append(fileLabel,selected,actions,confirm,status);panel.append(importSection);
      let prepared=preparedSave,working=false;
      function preview(token){
        question.textContent='Replace your game data and Rocket profile with “'+token.name+'”? The game will reload. Local replays stay on this device.';
        confirm.hidden=false;status.textContent='Game and Rocket data validated.';
      }
      if(prepared)preview(prepared);
      if(codeStatus)status.textContent=codeStatus;
      function api(){const value=globalThis.ArenaCombinedSave;if(!value)throw Error('Save data is not available. Reload the game and try again.');return value;}
      async function busy(message,action){
        if(working)return;working=true;codeStatus='';status.textContent=message;
        for(const control of panel.querySelectorAll('button,input'))control.disabled=true;
        try{await action();}
        catch(error){if(panel.isConnected)status.textContent=error?.message||'Could not complete the save operation.';}
        finally{working=false;if(panel.isConnected)for(const control of panel.querySelectorAll('button,input'))control.disabled=false;}
      }
      file.addEventListener('change',()=>{selectedSave=file.files?.[0]||null;prepared=preparedSave=null;selected.textContent=selectedSave?'Selected: '+selectedSave.name:'';confirm.hidden=true;codeStatus='';status.textContent='';});
      exportButton.addEventListener('click',()=>void busy('Exporting…',async()=>{
        const value=name.value.trim();
        if(value==='SNEAKYGIO14'||value==='THECLOSET14'){
          const profile=globalThis.ArenaRocketProfile;
          if(!profile?.importSecretCode)throw Error('Rocket codes are not available. Reload the game and try again.');
          const message=profile.importSecretCode(value);
          if(!message)throw Error('Could not activate this code.');
          // CLOSET rebuilds Data in a microtask; keep its feedback through that
          // rebuild and finish before creating any XML or download URL.
          codeStatus=message;status.textContent=message;
          return;
        }
        const saved=await api().exportXml(value),url=URL.createObjectURL(new Blob([saved.xml],{type:'application/xml;charset=utf-8'}));
        const link=node('a');link.href=url;link.download=saved.filename;link.hidden=true;document.body.append(link);link.click();link.remove();
        setTimeout(()=>URL.revokeObjectURL(url),1000);
        if(panel.isConnected)status.textContent='Download ready: '+saved.filename;
      }));
      importButton.addEventListener('click',()=>void busy('Checking save…',async()=>{
        prepared=preparedSave=null;confirm.hidden=true;
        const chosen=file.files?.[0]||selectedSave;if(!chosen)throw Error('Choose an XML save file first.');
        selectedSave=chosen;
        const backend=api();if(chosen.size>backend.maxBytes)throw Error('This save file is too large.');
        const token=await backend.prepareImport(await chosen.text());
        if(chosen!==selectedSave)return;
        preparedSave=token;if(!panel.isConnected)return;
        prepared=token;preview(token);
        setTimeout(()=>{if(panel.isConnected)replace.focus();},0);
      }));
      cancel.addEventListener('click',()=>{prepared=preparedSave=null;confirm.hidden=true;status.textContent='Import cancelled.';importButton.focus();});
      replace.addEventListener('click',()=>void busy('Importing save…',async()=>{
        if(!prepared)throw Error('Choose and validate the save file again.');
        const result=await api().applyImport(prepared);prepared=preparedSave=null;selectedSave=null;confirm.hidden=true;
        status.textContent='Save imported.';
        if(result?.reloadRequired)location.reload();
      }));
      return panel;
    }
    function mount(settings, group, credits = false) {
      dispose();
      if (!settings || group !== 'data' || credits) return;
      const rows = settings.querySelector('.rows'); if (!rows) return;
      style();
      mounted = node('div'); mounted.dataset.rocketData = '';
      mounted.tabIndex = 0; mounted.setAttribute('aria-label', 'Game and Rocket data');
      mounted.append(versionPanel(),savePanel());rows.prepend(mounted);
      const code = incoming; incoming = null;
      if(code){
        const legacy=node('section',undefined,'rocket-data-panel rocket-save-panel'),native=node('div');
        legacy.append(node('h2','Incoming game save'),node('p','This link contains game data only.'),native);mounted.append(legacy);
        cleanup=yC(native,{incoming:code,moduleSize:2});
      }
    }
    return Object.freeze({ mount, dispose, open });
  }

  function patch(source) {
    function once(before, after) {
      const parts = source.split(before);
      if (parts.length !== 2) throw Error('Unsupported game build: Settings data anchor.');
      source = parts.join(after);
    }
    function between(before, after, replacement) {
      const start = source.indexOf(before), end = source.indexOf(after, start + before.length);
      if (start < 0 || end < 0 || source.indexOf(before, start + 1) >= 0) throw Error('Unsupported game build: Settings data section.');
      source = source.slice(0, start) + replacement + source.slice(end);
    }
    // Keep yC's actual export, validator, confirmation, import and reload logic.
    once('return[`reset`,`version`,`credits`]}', 'return[`reset`,`credits`]}');
    once('let l=C(K(`collection.save.share`),`share`);s.append(l);', '');
    once('let d=w(`save-qr-panel`);d.append(X(`h2`,`save-title`,K(`collection.save.qr`)));', '');
    once('let v=X(`div`,`save-install`);e.append(a,d,f,v);', 'e.append(a,f);');
    once('i=await $b(r),n&&(o.value=i,S())', 'i=await $b(r),n&&(o.value=i)');
    between('function S(){if(d.querySelector(`.qr-canvas`)', 'function C(e,t){let n=X(`button`,`pack-btn`,e);', '');
    once('typeof navigator.share!=`function`&&(l.hidden=!0),l.addEventListener(`click`,()=>{navigator.share({text:i}).then(()=>{rf(`save_code`,{action:`share`})}).catch(()=>void 0)});', '');
    once('})()}),function T(e)', '})()});function T(e)');
    once('}),O();let D=x();', '});let D=x();');
    between(';function O(){let e=window.matchMedia?.(`(display-mode: standalone)`)', 'var bC=', '}');

    once('var vC=[MS,ix,Pn];', 'var arenaDataSettings=('+createDataSettings.toString()+')();var vC=[MS,ix,Pn];');
    once('s&&(s.value=TE),', 's&&(s.value=TE),arenaDataSettings.mount(lE,hE,xE),');
    once('function BE(){pE=!1', 'function BE(){arenaDataSettings.dispose();pE=!1');
    once('function BD(){ri(),', 'function BD(){arenaDataSettings.dispose();ri(),');
    once('function GD(e){', 'function GD(e){if(pE&&e.key!==`Escape`&&e.target instanceof Element&&e.target.closest(`[data-rocket-data]`))return;');

    // Existing save links remain useful, but now lead to the single Data page.
    once('function OC(e=`packs`,t={}){if(bC)', 'function OC(e=`packs`,t={}){if(e===`save`){let close=kC();arenaDataSettings.open({incoming:t.importCode,onClose:t.onClose??close});return}if(bC)');
    once('function PC(e){let t=bC;', 'function PC(e){if(e===`save`){arenaDataSettings.open({onClose:kC()});return}let t=bC;');
    once('        <button type="button" class="collection-tab" role="tab" data-tab="save">${K(`collection.tabs.save`)}</button>\n', '');
    between('        <button type="button" class="menu-btn menu-save"', '        <button type="button" class="menu-btn menu-gear"', '');
    once('function GY(e){return[...WY(e),8,3]}', 'function GY(e){return[...WY(e),3]}');
    return source;
  }
  const api = Object.freeze({ patch, createDataSettings });
  globalThis.ArenaDataSettingsAdapter = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})();
