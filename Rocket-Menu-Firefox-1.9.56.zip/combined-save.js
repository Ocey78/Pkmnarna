// One XML document carries game/profile codes and the separate Boss Rush teams.
// Replay blobs remain local.
(() => {
  'use strict';

  function createRocketCombinedSave() {
    const maxBytes = 8 * 1024 * 1024, maxNativeBytes = 4 * 1024 * 1024;
    const journalKey = 'arena.rocket.combined-save.pending.v1';
    const keys = ['poke2d.collection','poke2d.story.progress','poke2d.run.progress','poke2d-arena-teams',
      'rocket-menu.team-book.v1','rocket-menu.team-book.import.v1','poke2d.collection.import-backup','arena.rocket.profile.v1','arena.rocket.boss-teams.v1'];
    const prepared = new WeakMap();
    let applying = false, recoveryError = '';
    const fail = message=>{throw Error(message);};
    const storage = ()=>globalThis.localStorage;
    const profile = ()=>{
      const api = globalThis.ArenaRocketProfile;
      if (!api?.validateCode || !api?.replaceValidated || !api?.snapshot) fail('Rocket save data is not ready. Reload the game.');
      return api;
    };
    function checkedWrite(store,key,value) {
      if (value === null) store.removeItem(key); else store.setItem(key,value);
      if (store.getItem(key) !== value) fail('Firefox did not retain the save update.');
    }
    function restore(store,entries) {
      // Remove changed values first so an oversized failed import does not use
      // the space needed to restore the prior save. Unchanged keys stay intact.
      for (const [key,value] of entries) try { if(store.getItem(key)!==value)store.removeItem(key); } catch {}
      for (const [key,value] of entries) try { if(store.getItem(key)!==value)checkedWrite(store,key,value); } catch {}
      try {return entries.every(([key,value])=>store.getItem(key)===value);} catch {return false;}
    }
    function validJournal(value) {
      return value && Object.keys(value).length===2 && value.v===1 && Array.isArray(value.entries) &&
        [keys.length,keys.length-1].includes(value.entries.length) && value.entries.every((row,index)=>Array.isArray(row)&&row.length===2&&
          row[0]===keys[index]&&(row[1]===null||typeof row[1]==='string'&&row[1].length<=maxBytes));
    }
    function recover() {
      try {
        const store=storage(),text=store.getItem(journalKey);if(text===null)return;
        if(text.length>maxBytes)throw Error();
        const journal=JSON.parse(text);
        if(!validJournal(journal)||!restore(store,journal.entries))throw Error();
        checkedWrite(store,journalKey,null);
      } catch {recoveryError='A previous save import could not be restored. Free browser storage and reload before importing another file.';}
    }
    // Runs before the native game initializes its in-memory saves.
    recover();

    function filenameBase(value) {
      const fallback=ei().profile.name||'Trainer';
      const name=String(value??fallback).replace(/\.xml$/i,'').replace(/[\u0000-\u001f\u007f<>:"/\\|?*]/g,'')
        .trim().replace(/[. ]+$/,'').slice(0,80).replace(/[\uD800-\uDFFF\uFFFE\uFFFF]/gu,'')||'Trainer';
      return /^(?:con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(name)?'_'+name:name;
    }
    function parseXML(text) {
      if(typeof text!=='string'||text.length>maxBytes||new TextEncoder().encode(text).byteLength>maxBytes)
        fail('Choose a Rocket XML save smaller than 8 MiB.');
      if(/<!\s*(?:DOCTYPE|ENTITY)\b/i.test(text))fail('Save XML cannot contain a document type or entities.');
      const doc=new DOMParser().parseFromString(text,'application/xml'),root=doc.documentElement;
      if(doc.getElementsByTagNameNS('*','parsererror').length||!root||root.tagName!=='rocket-save'||root.namespaceURI||
          root.attributes.length!==1||root.getAttribute('version')!=='1')fail('This is not a supported Rocket XML save.');
      for(const node of doc.childNodes)if(node!==root&&!(node.nodeType===3&&!node.textContent.trim()))fail('Unexpected content in the save XML.');
      const children=[...root.children],fields=['name','game-code','rocket-code'];
      if(children.length===4)fields.push('boss-teams');
      if(children.length!==fields.length||children.some((node,index)=>node.tagName!==fields[index]||node.namespaceURI||node.attributes.length))
        fail('The save must contain one name, game code and Rocket code, with optional Boss Rush teams.');
      for(const node of root.childNodes)if(node.nodeType!==1&&!(node.nodeType===3&&!node.textContent.trim()))fail('Unexpected content in the save XML.');
      for(const node of children)for(const child of node.childNodes)if(child.nodeType!==3&&child.nodeType!==4)fail('Save fields must contain plain text.');
      const [name,gameCode,rocketCode,bossText]=children.map(node=>node.textContent.trim());
      if(!name||name.length>81||!gameCode||!rocketCode)fail('The save file is missing required data.');
      let bossTeams=null;
      if(bossText!==undefined){
        try{bossTeams=arenaBossTeams.validate(JSON.parse(bossText));}
        catch{fail('The save contains invalid Boss Rush teams.');}
      }
      return {name,gameCode,rocketCode,bossTeams};
    }
    async function limitedText(stream) {
      const reader=stream.getReader(),parts=[];let length=0;
      try {
        for(;;){const next=await reader.read();if(next.done)break;length+=next.value.byteLength;
          if(length>maxNativeBytes){await reader.cancel();fail('The game save expands beyond the supported size.');}parts.push(next.value);}
      } finally {reader.releaseLock();}
      const bytes=new Uint8Array(length);let at=0;
      for(const part of parts){bytes.set(part,at);at+=part.byteLength;}
      return new TextDecoder('utf-8',{fatal:true}).decode(bytes);
    }
    function normalizeExtras(game) {
      const extras={...game.extras};
      if(extras.story!==undefined){
        const decoded=qS(extras.story);
        if(decoded.status!=='ok')fail('The game code contains invalid story progress.');
        extras.story=JSON.stringify(KS(decoded.value).progress);
      }
      if(extras.run!==undefined){
        let raw;try{raw=JSON.parse(extras.run);}catch{fail('The game code contains invalid Arena Run data.');}
        if(!raw||raw.v!==1)fail('Unsupported Arena Run save.');
        const result=px(raw);if(result.dropped)fail('The game code contains an invalid active Arena Run.');
        extras.run=JSON.stringify(result.book);
      }
      if(extras.teams!==undefined){
        let raw;try{raw=JSON.parse(extras.teams);}catch{fail('The game code contains invalid teams.');}
        if(!raw||!Array.isArray(raw.teams)||raw.teams.length>99)fail('The game code contains an unsupported team book.');
        // The existing adapter preserves all 99 slots, extended moves, duplicates
        // and each species' five named move presets, including when mods are off.
        extras.teams=JSON.stringify(arenaTeamBook(raw));
      }
      return {collection:game.collection,extras};
    }
    async function nativeCode(code) {
      const match=/^(P2D[01])\.([A-Za-z0-9_-]+)\.([a-f0-9]{8})$/.exec(code);
      if(!match||Jb(code.slice(0,code.lastIndexOf('.')))!==match[3])fail('The game save code is damaged or unsupported.');
      const bytes=qb(match[2]);if(!bytes)fail('The game save code is damaged.');
      let text;
      if(match[1]==='P2D1'){
        if(typeof DecompressionStream!=='function')fail('This Firefox version cannot read compressed game saves.');
        try{text=await limitedText(new Blob([bytes]).stream().pipeThrough(new DecompressionStream('deflate-raw')));}
        catch(error){fail(error?.message==='The game save expands beyond the supported size.'?error.message:'The compressed game save is damaged.');}
      }else{
        if(bytes.byteLength>maxNativeBytes)fail('The game save exceeds the supported size.');
        try{text=new TextDecoder('utf-8',{fatal:true}).decode(bytes);}catch{fail('The game save text is damaged.');}
      }
      let raw;try{raw=JSON.parse(text);}catch{fail('The game save code contains invalid data.');}
      if(![1,2].includes(raw?.collection?.v))fail('The game save collection version is unsupported.');
      // Same checksum, base64 decoder and schema/migration as native ex(); only
      // decompression is bounded before handing the payload to native tx().
      const game=tx(raw);if(!game)fail('The game save code is invalid or unsupported.');
      return normalizeExtras(game);
    }
    async function prepareImport(text) {
      const parsed=parseXML(text);
      const [game,rocket]=await Promise.all([nativeCode(parsed.gameCode),profile().validateCode(parsed.rocketCode)]);
      const token=Object.freeze({name:parsed.name,game:Object.freeze(nx(game)),rocket:Object.freeze({
        matches:rocket.online.total,playMs:rocket.playMs,history:rocket.history.length
      })});
      prepared.set(token,{game,rocket,bossTeams:parsed.bossTeams});
      return token;
    }
    async function exportXml(name) {
      if(recoveryError)fail(recoveryError);
      const base=filenameBase(name),snapshot={collection:structuredClone(df()),extras:Af({story:MS,run:ix,teams:Pn})};
      // Read the complete Rocket-aware book, not a stock game's truncated disk copy.
      snapshot.extras.teams=JSON.stringify(er.read());
      const [gameCode,rocketCode]=await Promise.all([$b(normalizeExtras(snapshot)),profile().exportCode()]);
      const doc=document.implementation.createDocument(null,'rocket-save'),root=doc.documentElement;
      root.setAttribute('version','1');
      for(const [tag,value] of [['name',base],['game-code',gameCode],['rocket-code',rocketCode],['boss-teams',JSON.stringify(arenaBossTeams.snapshot())]]){
        const field=doc.createElement(tag);field.textContent=value;root.append(field);
      }
      const xml='<?xml version="1.0" encoding="UTF-8"?>\n'+new XMLSerializer().serializeToString(doc)+'\n';
      if(new TextEncoder().encode(xml).byteLength>maxBytes)fail('This combined save exceeds the 8 MiB file limit.');
      return {xml,filename:base+'.xml'};
    }
    function applyImport(token) {
      if(recoveryError)fail(recoveryError);
      if(applying)fail('A save import is already in progress.');
      const next=prepared.get(token);if(!next)fail('Validate the XML file before replacing your data.');
      applying=true;
      try{return commitImport(token,next);}finally{applying=false;}
    }
    function commitImport(token,next) {
      const api=profile(),store=storage();
      // Flush and snapshot live Rocket time before the synchronous transaction.
      // All imported sections were already validated and remain private here.
      const previousRocket=api.snapshot();
      const entries=keys.map(key=>[key,store.getItem(key)]);
      const journal=JSON.stringify({v:1,entries});
      if(journal.length>maxBytes)fail('The current save is too large to back up safely.');
      let committedRocket=false,started=false;
      try {
        checkedWrite(store,journalKey,journal);started=true;
        const checked={getItem:key=>store.getItem(key),setItem:(key,value)=>checkedWrite(store,key,value),removeItem:key=>checkedWrite(store,key,null)};
        const backup={collection:store.getItem(_d)};
        for(const key of [_d,MS,ix,Pn])backup[key]=store.getItem(key);
        checkedWrite(store,vd,JSON.stringify(backup));
        if(next.game.extras.teams!==undefined&&!arenaImportTeamBook(checked,next.game.extras.teams))fail('Firefox could not save the imported teams.');
        if(!Vd(checked,next.game.collection))fail('Firefox could not save the imported game data.');
        if(next.game.extras.story!==undefined)checkedWrite(store,MS,next.game.extras.story);
        if(next.game.extras.run!==undefined)checkedWrite(store,ix,next.game.extras.run);
        if(next.bossTeams!==null)arenaBossTeams.replaceValidated(next.bossTeams);
        committedRocket=true;api.replaceValidated(next.rocket);
        checkedWrite(store,journalKey,null);
        prepared.delete(token);
        // The UI reloads only after both commits succeed. Keep native readers
        // coherent for the interval before that reload happens.
        of=structuredClone(next.game.collection);er.reset();arenaBossTeams.reset?.();
        try{pf();rf('save_code',{action:'import_ok'});}catch{}
        return {reloadRequired:true};
      }catch(error){
        let restored=true;
        if(started)restored=restore(store,entries);
        if(committedRocket)try{api.replaceValidated(previousRocket);}catch{restored=false;}
        if(started){restored=restore(store,entries)&&restored;
          if(restored)try{checkedWrite(store,journalKey,null);}catch{restored=false;}}
        arenaBossTeams.reset?.();
        if(!restored){recoveryError='Firefox could not finish or fully restore this import. A backup journal is retained. Free browser storage and reload.';fail(recoveryError);}
        fail((error?.message||'The save import failed.')+' Your previous game and Rocket data are kept.');
      }
    }
    async function importXML(text){return applyImport(await prepareImport(text));}
    const api=Object.freeze({maxBytes,exportXml,exportXML:exportXml,prepareImport,inspectXML:prepareImport,applyImport,importXML});
    globalThis.ArenaCombinedSave=api;
    return api;
  }

  function patch(source) {
    if(source.includes('const rocketCombinedSave='))throw Error('Combined save adapter is already installed.');
    for(const anchor of ['async function $b(e){','function tx(e){','function arenaImportTeamBook(storage, text) {',
      'validateCode:code=>get().validateCode(code)','replaceValidated:snapshot=>dataReplaced(get().replaceValidated(snapshot))'])
      if(!source.includes(anchor))throw Error('Unsupported game build for combined XML saves: '+anchor);
    return 'const rocketCombinedSave=('+createRocketCombinedSave.toString()+')();\n'+source;
  }
  const api=Object.freeze({patch});
  globalThis.ArenaCombinedSaveAdapter=api;
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})();
