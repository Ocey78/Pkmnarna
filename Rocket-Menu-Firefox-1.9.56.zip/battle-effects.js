// Combat presentation shared by the live scene, exhibition and local replay.
(() => {
  'use strict';

  function createRocketArenaEffects() {
    const bursts = [];
    const tracks = new Map();
    const moves = new Map();
    const motion = globalThis.matchMedia?.('(prefers-reduced-motion: reduce)');
    const exposureMs = 64;
    let sequence = 0;
    let lastPaintTime = -Infinity;

    function describe(id) {
      let info = moves.get(id);
      if (!info) {
        const move = V(id);
        const art = lN(id);
        info = {move, style:art ? dN(art) : move.shape};
        moves.set(id, info);
      }
      return info;
    }

    function element(info, basic, actor) {
      if (basic && actor && (info.move.power <= 0 || info.move.category === 'status' ||
          (actor.moves?.length && Qe(actor.moves.map(slot => slot.id))[0]?.basicFallback))) {
        return dn(actor.speciesId).types[0] || 'normal';
      }
      return info.move.typeName || 'normal';
    }

    function note(before, state, events) {
      if (!state || state.phase !== 'fight' || motion?.matches || ei().display.reduceFlash) {
        tracks.clear();
        bursts.length = 0;
        return;
      }
      // Removal can happen between rendered frames. Prune on every simulation
      // snapshot, while keeping sampled positions on the presentation clock.
      const active = new Map((state.projectiles || []).slice(0, 48).map(shot => [shot.owner + ':' + shot.id, shot]));
      for (const [key, track] of tracks) {
        const shot = active.get(key);
        if (!shot || shot.move !== track.move || !!shot.basic !== track.basic) tracks.delete(key);
      }
      if (!events.length) return;
      const now = state.tick * q;
      for (const event of events) {
        if (event.type !== 'cast' && event.type !== 'hit') continue;
        if (!event.move || event.chip || (event.type === 'hit' && !(event.amount > 0))) continue;
        if (!Number.isFinite(event.x) || !Number.isFinite(event.y)) continue;
        const hit = event.type === 'hit';
        const victim = hit && state.fighters.find(fighter => fighter.id === event.target);
        const actor = state.fighters.find(fighter => fighter.id === event.actor) ||
          (hit && state.fighters.length === 2 && state.fighters.find(fighter => fighter.id !== event.target));
        const body = (hit ? victim : actor);
        const previous = body && before?.fighters?.find(fighter => fighter.id === body.id);
        const species = (previous && previous.entry !== body.entry ? previous : body)?.speciesId;
        const center = species ? rc(species, event.x, event.y) : event;
        const info = describe(event.move);
        let angle = actor?.castFacing ?? actor?.facing ?? 0;
        if (hit && actor && victim && actor.id !== victim.id) {
          angle = Math.atan2(victim.y - actor.y, victim.x - actor.x);
        }
        const self = info.move.shape === 'self' || info.move.shape === 'ring';
        const offset = !hit && !self ? (actor?.radius || 20) * .85 : 0;
        const power = Math.max(0, Math.min(140, info.move.power || 0));
        const size = event.basic ? (hit ? 17 : 12) : (hit ? 26 : 19) + power * .13;
        if (bursts.length === 36) bursts.shift();
        bursts.push({
          kind:event.type, type:element(info, event.basic, actor), style:info.style,
          x:center.x + Math.cos(angle) * offset, y:center.y + Math.sin(angle) * offset,
          angle, size:Math.min(56, size * (event.crit ? 1.25 : 1)),
          seed:++sequence, born:now, duration:event.basic ? 150 : hit ? 310 : 245, progress:0
        });
      }
    }

    function sampleShot(shot, key, now, info, state) {
      let track = tracks.get(key);
      const latest = track?.points[track.points.length - 1];
      const elapsed = latest ? now - latest.t : 0;
      const radius = Number(shot.radius) || 0;
      let discontinuity = !track || track.move !== shot.move || track.basic !== !!shot.basic ||
        track.radius !== radius || elapsed < 0 || elapsed > exposureMs * 1.5;
      if (latest && !discontinuity) {
        const dx = shot.x - latest.x, dy = shot.y - latest.y;
        const vx = (shot.vx + latest.vx) * .5, vy = (shot.vy + latest.vy) * .5;
        const predictedX = vx * elapsed / 1000, predictedY = vy * elapsed / 1000;
        const allowance = elapsed > 0 ? Math.max(4, Math.hypot(predictedX, predictedY) * .6) : .25;
        discontinuity = Math.hypot(dx - predictedX, dy - predictedY) > allowance;
      }
      if (discontinuity) {
        const owner = state.fighters.find(fighter => fighter.id === shot.owner);
        track = {move:shot.move, basic:!!shot.basic, radius,
          type:element(info, shot.basic, owner), x:shot.x, y:shot.y, points:[]};
        tracks.set(key, track);
      }
      const point = {x:shot.x, y:shot.y, vx:shot.vx, vy:shot.vy, t:now};
      const points = track.points;
      const head = points[points.length - 1];
      // Keep an exact current head and roughly one older point per 16 ms. This
      // preserves the exposure duration on displays faster than 60 Hz.
      if (head && (head.t === now || points.length > 1 && head.t - points[points.length - 2].t < 14)) {
        points[points.length - 1] = point;
      } else {
        points.push(point);
      }
      while (points.length > 5 || points.length > 2 && points[1].t <= now - exposureMs) points.shift();
      track.seen = true;
      return track;
    }

    // Measure the visible distance along a ray. Rock footprints are the same
    // world-space polygons used by the Rock Gym map and its projectile collisions.
    function lineReach(x, y, dx, dy, length, arena) {
      const width = arena?.width || Ca, height = arena?.height || wa;
      let limit = length;
      if (dx > 0) limit = Math.min(limit, (width - x) / dx);
      if (dx < 0) limit = Math.min(limit, -x / dx);
      if (dy > 0) limit = Math.min(limit, (height - y) / dy);
      if (dy < 0) limit = Math.min(limit, -y / dy);
      for (const loop of arena?.combat?.rocks || []) {
        let inside = false;
        for (let i = 0, j = loop.length - 1; i < loop.length; j = i++) {
          const a = loop[j], b = loop[i], ex = b.x - a.x, ey = b.y - a.y;
          if ((a.y > y) !== (b.y > y) && x < ex * (y - a.y) / ey + a.x) inside = !inside;
          const cross = dx * ey - dy * ex;
          if (Math.abs(cross) < 1e-8) continue;
          const ax = a.x - x, ay = a.y - y;
          const along = (ax * ey - ay * ex) / cross, side = (ax * dy - ay * dx) / cross;
          if (side >= 0 && side <= 1 && along >= 0 && along < limit) limit = along;
        }
        if (inside) return 0;
      }
      return Math.max(0, limit);
    }

    function paint(ctx, state, now) {
      if (!state || state.phase !== 'fight' || motion?.matches || ei().display.reduceFlash) {
        bursts.length = 0;
        tracks.clear();
        lastPaintTime = -Infinity;
        return;
      }
      if (!Number.isFinite(now)) return;
      if (now < lastPaintTime || now - lastPaintTime > exposureMs * 1.5) {
        tracks.clear();
        if (now < lastPaintTime) bursts.length = 0;
      }
      lastPaintTime = now;
      for (const track of tracks.values()) track.seen = false;
      const phase = (seed, span) => ((now / span + (seed % 17) / 17) % 1 + 1) % 1;
      ctx.save();
      try {
        ctx.globalCompositeOperation = 'source-over';
        ctx.beginPath();
        ctx.rect(0, 0, state.arena?.width || Ca, state.arena?.height || wa);
        ctx.clip();
        let count = 0;
        for (const fighter of state.fighters) {
          if (fighter.cast !== 'active' || fighter.castBasic || !fighter.castMove || fighter.hp <= 0) continue;
          const info = describe(fighter.castMove);
          if (info.move.shape !== 'stream' || !(info.move.range > 0)) continue;
          if (++count > 12) break;
          const angle = fighter.castFacing, dx = Math.cos(angle), dy = Math.sin(angle);
          const start = aF(fighter.x, fighter.y, angle, fighter.radius, nc(fighter.speciesId));
          const reach = info.move.range - Math.hypot(start.x - fighter.x, start.y - (fighter.y - nc(fighter.speciesId)));
          const length = lineReach(start.x, start.y, dx, dy, reach, state.arena);
          if (length < 2) continue;
          rocketDrawArenaFx(ctx, {kind:'line', type:info.move.typeName, style:'stream',
            ...start, angle, length, size:Math.min(25, Math.max(12, length * .095)),
            seed:count, progress:phase(count, 450)});
        }
        count = 0;
        for (const shot of state.projectiles || []) {
          if (++count > 48) break;
          if (!shot.move || !Number.isFinite(shot.x) || !Number.isFinite(shot.y)) continue;
          const speed = Math.hypot(shot.vx, shot.vy);
          if (!(speed > 0) || !Number.isFinite(speed)) continue;
          const dx = shot.vx / speed, dy = shot.vy / speed, angle = Math.atan2(dy, dx);
          const key = shot.owner + ':' + shot.id, seed = Number(shot.id) || count;
          const info = describe(shot.move);
          const track = sampleShot(shot, key, now, info, state);
          const size = shot.basic ? 10 : Math.max(13, Math.min(27, (shot.radius || 12) * 1.15));
          const long = !shot.basic && (info.style === 'beam' || info.style === 'stream');
          rocketDrawArenaFx(ctx, {kind:'motion', type:track.type, style:info.style,
            x:shot.x, y:shot.y, size:size * (shot.basic ? .28 : .34),
            points:track.points, now, exposureMs});
          const straight = Math.abs((track.x - shot.x) * dy - (track.y - shot.y) * dx) <= 2 &&
            track.points.every(point => Math.abs((point.x - shot.x) * dy -
            (point.y - shot.y) * dx) <= 2 && (point.x - shot.x) * dx + (point.y - shot.y) * dy <= .25);
          if (long && straight) {
            // The leading edge follows the actual projectile. Never extend past
            // its recorded path on the first frame or when seeking a replay.
            const traveled = Math.max(0, (shot.x - track.x) * dx + (shot.y - track.y) * dy);
            const length = lineReach(shot.x, shot.y, -dx, -dy,
              Math.min(traveled, (info.style === 'beam' ? .34 : .22) * speed), state.arena);
            if (length >= 2) rocketDrawArenaFx(ctx, {
              kind:'line', type:track.type, style:info.style, x:shot.x - dx * length, y:shot.y - dy * length,
              angle, length, size:size * .72, seed, progress:phase(seed, 480)
            });
          }
          rocketDrawArenaFx(ctx, {kind:'trail', type:track.type, style:info.style,
            x:shot.x, y:shot.y, angle, size:long ? size * .75 : size, seed,
            progress:.4 + .2 * Math.sin(2 * Math.PI * phase(seed, 500))});
        }
        for (const [key, track] of tracks) if (!track.seen) tracks.delete(key);
        for (let i = 0; i < bursts.length;) {
          const cue = bursts[i];
          cue.progress = (now - cue.born) / cue.duration;
          if (cue.progress >= 1 || cue.progress < 0) bursts.splice(i, 1);
          else { rocketDrawArenaFx(ctx, cue); i++; }
        }
      } finally {
        ctx.restore();
      }
    }

    return {note, paint};
  }

  function rocketAttachBattleEffects(scene) {
    const effects = createRocketArenaEffects();
    const motion = globalThis.matchMedia?.('(prefers-reduced-motion: reduce)');
    const lighting = {
      timeMs:0, reduced:false,
      hiddenFighter:id => scene.flash?.has(id) || scene.balls?.hidesGroundShadow(id) ||
        scene.actors?.get(id)?.sprite?.visible === false,
      spriteFor:id => scene.actors?.get(id)?.sprite
    };
    scene.rocketBattleEffects = effects;
    scene.events.once('shutdown', () => {
      scene.rocketBattleEffects = null;
      scene.rocketEffectsState = null;
    });
    function layer(depth, paint, onError) {
      const object = scene.add.graphics().setDepth(depth);
      object.renderCanvas = (renderer, self, camera) => {
        const state = scene.rocketEffectsState;
        if (!state || camera !== scene.cameras.main) return;
        const ctx = renderer.currentContext;
        ctx.save();
        try {
          // matrixCombined includes viewport, pan, zoom and camera shake.
          camera.matrixCombined.setToContext(ctx);
          paint(ctx, state, state.tick * q);
        } catch (error) {
          object.setVisible(false);
          onError?.();
          console.warn('[Rocket Menu] Could not draw battle layer.', error);
        } finally {
          ctx.restore();
        }
      };
    }
    if (typeof rocketPaintStageLight === 'function') layer(2.8, (ctx, state, now) => {
      lighting.timeMs = now;
      lighting.reduced = ei().display.reduceFlash || motion?.matches;
      rocketPaintStageLight(ctx, state, lighting);
    });
    layer(6.8, effects.paint, () => { scene.rocketBattleEffects = null; });
  }

  function patch(source, painter) {
    if (typeof painter !== 'function') throw Error('Missing Rocket battle effects artwork.');
    const replace = (before, after) => {
      const parts = source.split(before);
      if (parts.length !== 2) throw Error('Unsupported Rocket battle effects anchor: ' + before);
      source = parts.join(after);
    };
    const setup = 'this.worldGraphics=this.add.graphics().setDepth(3),';
    replace(setup, setup + 'rocketAttachBattleEffects(this),');
    const note = 'this.artFx?.note(e,c,t.events),';
    replace(note, note + 'this.rocketBattleEffects?.note(e,c,t.events),');
    const draw = 'let n=this.viewState(e);if(this.worldGraphics.setVisible(t),t)';
    replace(draw, 'let n=this.viewState(e);this.rocketEffectsState=t?n:null;if(this.worldGraphics.setVisible(t),t)');
    return 'const rocketDrawArenaFx=(' + painter.toString() + ');\n' +
      createRocketArenaEffects.toString() + '\n' + rocketAttachBattleEffects.toString() + '\n' + source;
  }

  const api = Object.freeze({patch});
  globalThis.ArenaBattleEffectsAdapter = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})();
