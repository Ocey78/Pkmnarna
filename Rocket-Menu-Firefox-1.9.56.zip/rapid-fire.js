(() => {
  'use strict';

  function patch(source) {
    function replace(before, after) {
      const parts = source.split(before);
      if (parts.length !== 2) throw Error('Unsupported game build. Could not update basic shot timing.');
      source = parts.join(after);
    }
    // Basic projectiles already spawn instantly. Their reuse timer is the
    // only delay between held shots. Skills and ultimates own separate casts.
    replace('this.rememberUlt(e)}for(let t of vc(e.loadout))',
      'this.rememberUlt(e)}if(this.localOption(e,"rapidfire")){let basic=Qe(e.loadout)[0].loadoutIndex;if(Number.isInteger(basic))e.cds[basic]=0;e.basicCd=0}for(let t of vc(e.loadout))');
    replace('e.cds[l]=this.waivesLocalCooldowns(e)?0:m?500:p.cooldownMs',
      'e.cds[l]=this.waivesLocalCooldowns(e)||m&&this.localOption(e,"rapidfire")?0:m?500:p.cooldownMs');
    replace('e.basicCd=this.waivesLocalCooldowns(e)?0:500',
      'e.basicCd=this.waivesLocalCooldowns(e)||this.localOption(e,"rapidfire")?0:500');
    replace('snapshot(e){let free=this.waivesLocalCooldowns(e);',
      'snapshot(e){let free=this.waivesLocalCooldowns(e),rapid=this.localOption(e,"rapidfire");');
    replace('basicCooldownMs:free?0:e.basicCd',
      'basicCooldownMs:free||rapid?0:e.basicCd');
    replace('moves:vc(e.loadout).map(t=>wc(e,t,free))',
      'moves:vc(e.loadout).map(t=>wc(e,t,free||rapid&&t===Qe(e.loadout)[0].loadoutIndex))');
    return source;
  }

  globalThis.ArenaRapidFireAdapter = Object.freeze({patch});
  if (typeof module !== 'undefined' && module.exports) module.exports = {patch};
})();
