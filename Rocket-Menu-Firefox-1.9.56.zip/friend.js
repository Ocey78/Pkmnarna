'use strict';
// Both public and private DIRECT duels have two seats and one native authority.
// Keep the original v1 wire format so private rooms can pair with version 1.1.
function createArenaFriendSession(readOption, report, clock) {
  const names=['cooldowns','aim','god','speed'];
  const extended={rapidfire:'rapid',norecovery:'recovery',supereffective:'effective'};
  const extraControls=['rapidfire','norecovery','supereffective'];
  let current=null, owner=null;
  function matches(s) {
    const c=s.controller, d=s.start.direct, p=c.peer;
    return current===s && c.active && !c.result && c.room?.mode!=='ffa3' &&
      s.start.mode!=='ffa3' && !s.start.teams?.C &&
      (c.you==='A'||c.you==='B') && c.directStart===s.start && c.battle?.matchId===s.start.matchId &&
      d && (d.host==='A'||d.host==='B') && s.peer===p && p?.offer?.id===d.id;
  }
  function connected(s) {
    return matches(s) && !s.controller.linkDown && s.peer.available();
  }
  function localMask() {return names.reduce((mask,key,i)=>mask|(readOption(key)?1<<i:0),0);}
  function transmit(s) {
    if(connected(s)) s.peer.send({t:'arena-friend-flags',v:1,m:s.start.matchId,o:s.start.direct.id,
      mask:localMask(),ack:s.seen,rapid:readOption('rapidfire')===true,
      recovery:readOption('norecovery')===true,effective:readOption('supereffective')===true,
      extra:extraControls});
  }
  function ready(s) {return connected(s) && s.seen && s.ack && clock.now()-s.last<=5000;}
  function clear(c) {
    if(c && c!==owner)return;
    if(current)clock.cancel(current.timer);
    current=null;owner=null;clock.resetReadback?.();report('','setup');
  }
  function updateStatus(s) {
    if(!connected(s)) {report('Direct connection unavailable · local aim only','aim');return;}
    if(s.start.direct.host===s.controller.you) {
      if(!s.controller.authority) {
        report('Direct duel · waiting for the battle host to start','setup');return;
      }
      report(ready(s)?'You host this Direct duel · both Rocket Menus connected':
        'You host this Direct duel · battle controls apply to your Pokémon','all',extraControls,true);
      return;
    }
    if(ready(s)) report('Direct duel · your host supports battle controls','all',s.extra);
    else report('Direct guest · local aim only until the host confirms a compatible menu','aim');
  }
  function tick(s) {
    if(current!==s)return;
    if(!matches(s)){clear(s.controller);return;}
    if(!connected(s)||clock.now()-s.last>5000){s.seen=false;s.ack=false;s.mask=0;s.rapid=false;s.recovery=false;s.effective=false;s.extra=[];}
    transmit(s);
    updateStatus(s);
  }
  function start(c,start,recovering=false) {
    clear();
    owner=c;
    if(start.mode==='ffa3'||c.room?.mode==='ffa3'||start.teams?.C) {
      report('Three-player cloud battle · local aim only','aim');return;
    }
    if(!start.direct) {report('Server-controlled battle · local aim only','aim');return;}
    if(recovering) {report('Restored Direct match · local aim only','aim');return;}
    const s={controller:c,start,peer:c.peer,mask:0,rapid:false,recovery:false,effective:false,extra:[],seen:false,ack:false,last:0,timer:null};
    current=s;
    if(!matches(s)) {current=null;report('Direct authority unavailable · local aim only','aim');return;}
    s.timer=clock.every(()=>tick(s),850);
    tick(s);
    // beginMatch constructs the authority immediately after this hook returns.
    Promise.resolve().then(()=>{if(current===s)updateStatus(s);});
  }
  function receive(c,pkt) {
    const s=current;
    if(!s||s.controller!==c||!connected(s)||pkt.v!==1||pkt.m!==s.start.matchId||pkt.o!==s.start.direct.id||
       !Number.isInteger(pkt.mask)||pkt.mask<0||pkt.mask>15||typeof pkt.ack!=='boolean')return;
    const wasSeen=s.seen;
    s.seen=true;s.ack=pkt.ack;s.mask=pkt.mask;s.rapid=pkt.rapid===true;s.last=clock.now();
    s.recovery=pkt.recovery===true;s.effective=pkt.effective===true;
    s.extra=extraControls.filter(key=>key==='rapidfire'?typeof pkt.rapid==='boolean':Array.isArray(pkt.extra)&&pkt.extra.includes(key));
    if(!wasSeen)transmit(s);
    updateStatus(s);
  }
  function option(c,start,seat,key) {
    const s=current, index=names.indexOf(key);
    if(!s||s.controller!==c||s.start!==start||!connected(s)||(index<0&&!Object.hasOwn(extended,key))||(seat!=='A'&&seat!=='B'))return false;
    if(seat===c.you)return readOption(key);
    return ready(s)&&(Object.hasOwn(extended,key)?s[extended[key]]:Boolean(s.mask&(1<<index)));
  }
  function lobby(c,room) {
    if(!c.active)return;
    clear();owner=c;
    if(!room)report('Online lobby · choose your battle settings','setup');
    else if(room.mode==='ffa3')report('Three-player lobby · the battle will use cloud rules','setup');
    else report('Two-player lobby · controls depend on the match connection','setup');
  }
  function solo() {clear();report('Solo battle · battle controls apply to your Pokémon','all',extraControls,true);}
  function closePeer(c) {if(current?.controller===c)clear(c);}
  return {start,receive,option,clear,closePeer,lobby,solo,changed(){if(current)transmit(current);}};
}

function installFriendBridge() {
  function report(text,controls='setup',extraControls=[],customMoves=false) {
    const doc=document.documentElement;
    const extra=JSON.stringify(extraControls);
    const moves=customMoves?'on':'off';
    if(doc.getAttribute('data-arena-friend-status')===text&&doc.getAttribute('data-arena-online-controls')===controls&&doc.getAttribute('data-arena-extra-controls')===extra&&doc.getAttribute('data-arena-anymove-controls')===moves)return;
    doc.setAttribute('data-arena-friend-status',text);
    doc.setAttribute('data-arena-online-controls',controls);
    doc.setAttribute('data-arena-extra-controls',extra);
    doc.setAttribute('data-arena-anymove-controls',moves);
    document.dispatchEvent(new Event('arena-friend-status'));
  }
  const link=createArenaFriendSession(arenaModEnabled,report,{
    now:()=>performance.now(),every:(fn,ms)=>setInterval(fn,ms),cancel:id=>clearInterval(id),
    resetReadback:()=>{
      const doc=document.documentElement;
      if(!doc.hasAttribute('data-arena-engine-mask')&&!doc.hasAttribute('data-arena-host-timers'))return;
      doc.removeAttribute('data-arena-engine-mask');
      doc.removeAttribute('data-arena-host-timers');
      doc.removeAttribute('data-arena-host-sampled');
      document.dispatchEvent(new Event('arena-engine-readback'));
    }
  });
  document.addEventListener('arena-mod-settings',()=>link.changed());
  report('','setup');
  return {link,report};
}

function patchFriendTransport(source) {
  function replace(a,b) {
    if(!source.includes(a)||source.indexOf(a)!==source.lastIndexOf(a))throw Error('Unsupported friend-room anchor: '+a.slice(0,80));
    source=source.replace(a,()=>b);
  }
  replace('this.battle=a,this.networkTelemetry=', 'this.battle=a,arenaFriendBridge.link.start(this,e,!!t),this.networkTelemetry=');
  replace('closePeer(){this.peer?.close()', 'closePeer(){arenaFriendBridge.link.closePeer(this);this.peer?.close()');
  replace('peerData(e){let t=this.directStart;', 'peerData(e){if(e.t==="arena-friend-flags"){arenaFriendBridge.link.receive(this,e);return}let t=this.directStart;');
  // Both the service socket and WebRTC parse JSON. Identify the data channel
  // via its liveness timestamp so optional settings never enter the service path.
  replace('let n=t;if(this.lastSeen=performance.now(),this.pc?.connectionState',
    'if(t.t==="arena-friend-flags"){this.on.data(t);return}let n=t;if(this.lastSeen=performance.now(),this.pc?.connectionState');
  replace('this.room=e,e.cloud&&', 'this.room=e,(!this.battle&&arenaFriendBridge.link.lobby(this,e)),e.cloud&&');
  replace('async showLobby(e){this.mode=`lobby`', 'async showLobby(e){arenaFriendBridge.link.lobby(this,null);this.mode=`lobby`');
  replace('e.t===`countdown`){this.cancelCloudProbe()', 'e.t===`countdown`){arenaFriendBridge.link.lobby(this,this.room);this.cancelCloudProbe()');
  replace('stop(){this.active&&(this.networkSetup?.finish(`leave`)', 'stop(){arenaFriendBridge.link.clear(this);this.active&&(this.networkSetup?.finish(`leave`)');
  replace('init(e){this.loadEpoch+=1,this.net=e?.net??null', 'init(e){if(!e?.net)arenaFriendBridge.link.solo();this.loadEpoch+=1,this.net=e?.net??null');
  replace('this.game.canvas.dataset.mode=`menu`,this.game.canvas.dataset.phase=`menu`', 'arenaFriendBridge.link.clear(),this.game.canvas.dataset.mode=`menu`,this.game.canvas.dataset.phase=`menu`');
  return source;
}
const ArenaFriendAdapter=Object.freeze({
  patch:patchFriendTransport,
  prelude:()=>[createArenaFriendSession.toString(),installFriendBridge.toString(),
    'const arenaFriendBridge=installFriendBridge();',
    'function arenaFriendOption(c,start,seat,key){return arenaFriendBridge.link.option(c,start,seat,key)}'].join('\n')+'\n'
});
if(typeof module!=='undefined'&&module.exports)module.exports={ArenaFriendAdapter,createArenaFriendSession};
