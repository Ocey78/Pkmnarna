// Auto Evolve uses the ordinary Mega input and the battle's existing limits.
(() => {
  'use strict';
  function createRocketAutoEvolve(){
    const scenes=new WeakMap();
    return function autoEvolve(scene,state,command){
      if(!command||state?.phase!=='fight'||scene.artVariant||scene.paused||Z.isPaused()||
          !scene.controls?.enabled||arenaKeybinds.blocked()||state.hitStopFrames>0)return command;
      const net=scene.net,actor=state.fighters?.find(fighter=>fighter.id==='player');
      if(net&&(net.spectating?.()||!net.acceptsInput()||net.enabled===false||!net.connected||net.frozenMs!=null))return command;
      if(!net&&scene.world?.acceptsInput&&!scene.world.acceptsInput())return command;
      if(!actor||actor.hp<=0||state.megaUsed?.player||!arenaMegaSelector.autoEnabled(actor.speciesId,scene.world)||
          sn(actor.speciesId,actor.moves.map(move=>move.id))===null)return command;
      // These timers decrease before the simulator handles the Mega button.
      if(actor.cast!=='idle'||actor.recoverMs>q||actor.switchMs>q||actor.iframeMs>q||
          actor.protectMs>0||actor.ailment==='sleep'||actor.ailment==='freeze'||
          command.switchSlot!=null||command.buttons.dodge||command.buttons.mega)return command;
      // Do not replace an imminent defensive response with the evolution animation.
      if(rocketAutoProtect.reserved(scene)||actor.moves.some((move,index)=>
          command.buttons.attacks[index]&&V(move.id).status==='protect'))return command;
      let memory=scenes.get(scene);
      if(!memory||memory.world!==scene.world||memory.epoch!==scene.loadEpoch||memory.entry!==actor.entry||
          memory.species!==actor.speciesId||state.tick<memory.tick){
        memory={world:scene.world,epoch:scene.loadEpoch,entry:actor.entry,species:actor.speciesId,
          tick:state.tick,retryAt:0,attempts:0};scenes.set(scene,memory);
      }
      memory.tick=state.tick;
      const now=performance.now();
      if(now<memory.retryAt||memory.attempts>=4)return command;
      const rtt=Number.isFinite(net?.pingYou)?Math.max(0,net.pingYou):120;
      memory.retryAt=now+(net?Math.max(300,Math.min(1000,rtt*2+150)):150);
      memory.attempts++;
      return {...command,buttons:{...command.buttons,mega:true}};
    };
  }
  function patch(source){
    const anchor='let e=this.net?this.netPresented??c:c,t=this.world.step(s);',parts=source.split(anchor);
    if(parts.length!==2)throw Error('Unsupported Auto Evolve input anchor.');
    return 'const rocketAutoEvolve=('+createRocketAutoEvolve.toString()+')();\n'+
      parts.join('s=rocketAutoEvolve(this,c,s);'+anchor);
  }
  const api=Object.freeze({patch});globalThis.ArenaAutoEvolveAdapter=api;
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})();
