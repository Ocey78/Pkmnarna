// Submit normal ability inputs for the game's supported self-boost moves.
(() => {
  'use strict';

  function createRocketAutoStatus() {
    const scenes=new WeakMap(), boosts=new Set(['swords','nasty','dragon','bulk','calm']);
    return function rocketAutoStatus(scene,state,command) {
      if(!command||!rocketCloset.getAutoStatus()||state?.phase!=='fight'||document.hidden||
          !scene.controls?.acceptsPress()||arenaKeybinds.blocked()||scene.net?.spectating()||state.hitStopFrames>0)return command;
      if(rocketAutoProtect.reserved(scene))return command;
      const actor=state.fighters[0],net=scene.net;
      if(!actor||actor.hp<=0||actor.switchMs>0||actor.cast!=='idle'||actor.iframeMs>0||
          actor.ailment==='sleep'||actor.ailment==='freeze'||command.switchSlot!==null||
          command.buttons.dodge||command.buttons.mega)return command;
      if(net&&(!net.acceptsInput()||!net.enabled||!net.connected||net.frozenMs!==null))return command;
      const plan=Qe(actor.moves.map(move=>move.id));
      // Protect (manual or automatic) always wins over an automatic boost.
      if(plan.some(slot=>Number.isInteger(slot.loadoutIndex)&&command.buttons.attacks[slot.loadoutIndex]&&
          slot.moveId&&V(slot.moveId).status==='protect'))return command;
      const tick=state.tick,now=performance.now();
      let memory=scenes.get(scene);
      if(!memory||memory.world!==scene.world||memory.entry!==actor.entry||memory.species!==actor.speciesId||tick<memory.tick){
        memory={world:scene.world,entry:actor.entry,species:actor.speciesId,tick,retryAt:0,lastSlot:-1};
        scenes.set(scene,memory);
      }
      memory.tick=tick;
      if(now<memory.retryAt)return command;
      // Native advance decreases these timers before trying the next ability.
      const ready={...actor,recoverMs:Math.max(0,actor.recoverMs-q),
        moves:actor.moves.map(move=>({...move,cooldownMs:Math.max(0,move.cooldownMs-q)}))};
      const candidates=plan.filter(slot=>{
        if(slot.dash||slot.basicFallback||slot.role==='basic'||!Number.isInteger(slot.loadoutIndex)||
            !slot.moveId||rl(ready,slot)!==null)return false;
        const move=V(slot.moveId);
        return move.shape==='self'&&boosts.has(move.status);
      }).sort((a,b)=>a.loadoutIndex-b.loadoutIndex);
      if(!candidates.length)return command;
      // Rotate eligible slots so multiple equipped boosts can all be used.
      const chosen=candidates.find(slot=>slot.loadoutIndex>memory.lastSlot)||candidates[0];
      const rtt=Number.isFinite(net?.pingYou)?Math.max(0,net.pingYou):120;
      memory.retryAt=now+(!net||net.direct?.step?2*q:Math.max(100,Math.min(450,rtt+2*q)));
      memory.lastSlot=chosen.loadoutIndex;
      const attacks=command.buttons.attacks.map((_,index)=>index===chosen.loadoutIndex);
      return {...command,buttons:{...command.buttons,attacks,basic:false,heatGate:false,
        ultGate:chosen.role==='ultimate'}};
    };
  }

  function patch(source) {
    const step='let e=this.net?this.netPresented??c:c,t=this.world.step(s);',parts=source.split(step);
    if(parts.length!==2)throw Error('Unsupported battle input for Auto Status.');
    return 'const rocketAutoStatus=('+createRocketAutoStatus.toString()+')();\n'+
      parts.join('s=rocketAutoStatus(this,c,s);'+step);
  }
  globalThis.ArenaAutoStatusAdapter=Object.freeze({patch});
})();
