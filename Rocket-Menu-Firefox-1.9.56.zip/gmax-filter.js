// Restrict automatic selection and the picker, without rewriting saved teams.
(() => {
  'use strict';
  function arenaGmaxSpecies(species) {
    // The pinned catalog marks these as alternate forms and supplies both the
    // canonical "gmax" ID suffix and the human-readable "-Gmax" form suffix.
    return species?.baseForm === false &&
      (species.id.endsWith('gmax') || species.name.endsWith('-Gmax') || species.name.endsWith('-Gigantamax'));
  }
  function patch(original) {
    let source=original;
    function replace(before,after){const parts=source.split(before);if(parts.length!==2)throw Error('Unsupported Gmax filter anchor: '+before.slice(0,80));source=parts.join(after);}
    if(source.includes('function arenaGmaxSpecies('))throw Error('Gmax filter already applied.');
    replace('function ud(e,t,forRoster=false){',arenaGmaxSpecies.toString()+'\nfunction ud(e,t,forRoster=false){');
    replace('currentPool(){return arenaRosterOrder(z_(this.arenaRosterOffline?Zt:rn,',
      'currentPool(){return arenaRosterOrder(z_((this.arenaRosterOffline?Zt:rn).filter(mon=>!arenaGmaxSpecies(mon)),');
    replace('let a=n?.fullRoster?Zt.filter(mon=>!r.has(mon.dex)):',
      'let a=n?.fullRoster?Zt.filter(mon=>!r.has(mon.dex)&&!arenaGmaxSpecies(mon)):');
    replace('n=(e.featuredIds??Zt.map(mon=>mon.id)).filter(e=>e.length>0)',
      'n=(e.featuredIds??Zt.filter(mon=>!arenaGmaxSpecies(mon)).map(mon=>mon.id)).filter(e=>e.length>0)');
    return source;
  }
  const api=Object.freeze({patch});
  globalThis.ArenaGmaxFilterAdapter=api;
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})();
