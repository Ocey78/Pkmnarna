// Bake incident light into an individual animation frame, preserving its source pixels and alpha.
(() => {
  'use strict';

  function rocketFighterMaterial(image, sx, sy, sw, sh) {
    if (!image || typeof image !== 'object' || image.complete === false ||
        !Number.isInteger(sx) || !Number.isInteger(sy) || !Number.isInteger(sw) || !Number.isInteger(sh) ||
        sx < 0 || sy < 0 || sw < 1 || sh < 1 || sw > 256 || sh > 256 || sw * sh > 49152) return null;
    const imageW = image.naturalWidth ?? image.width;
    const imageH = image.naturalHeight ?? image.height;
    if (!(sx + sw <= imageW && sy + sh <= imageH)) return null;

    const cache = rocketFighterMaterial.cache ||= {
      sources: new WeakMap(), blocked: new WeakSet(), frames: new Map(), serial: 0, pixels: 0
    };
    if (cache.blocked.has(image)) return null;
    let id = cache.sources.get(image);
    if (id === undefined) {
      id = ++cache.serial;
      cache.sources.set(image, id);
    }
    const key = id + ':' + sx + ':' + sy + ':' + sw + ':' + sh;
    const saved = cache.frames.get(key);
    if (saved) return saved;

    try {
      const frame = typeof OffscreenCanvas === 'function' ? new OffscreenCanvas(sw, sh) : document.createElement('canvas');
      if (frame.width !== sw) frame.width = sw;
      if (frame.height !== sh) frame.height = sh;
      const brush = frame.getContext('2d', {willReadFrequently: true});
      if (!brush) return null;
      brush.imageSmoothingEnabled = false;
      brush.drawImage(image, sx, sy, sw, sh, 0, 0, sw, sh);
      const pixels = brush.getImageData(0, 0, sw, sh);
      const rgba = pixels.data, stride = sw * 4;
      let left = sw, right = -1, top = sh, bottom = -1;
      for (let y = 0; y < sh; y++) {
        for (let x = 0; x < sw; x++) {
          if (rgba[y * stride + x * 4 + 3] < 32) continue;
          if (x < left) left = x;
          if (x > right) right = x;
          if (y < top) top = y;
          if (y > bottom) bottom = y;
        }
      }
      // Normalize across occupied pixels, so asymmetric poses and padded frames receive consistent light.
      const spanX = Math.max(1, right - left), spanY = Math.max(1, bottom - top);
      for (let y = top; y <= bottom; y++) {
        for (let x = left; x <= right; x++) {
          const i = y * stride + x * 4, alpha = rgba[i + 3];
          if (!alpha) continue;
          const north = y === 0 ? 0 : rgba[i - stride + 3];
          const west = x === 0 ? 0 : rgba[i - 4 + 3];
          const south = y === sh - 1 ? 0 : rgba[i + stride + 3];
          const east = x === sw - 1 ? 0 : rgba[i + 4 + 3];
          const facingLight = Math.max(0, alpha - north) * .64 + Math.max(0, alpha - west) * .36;
          const facingShade = Math.max(0, alpha - south) * .64 + Math.max(0, alpha - east) * .36;
          const height = (y - top) / spanY, across = (x - left) / spanX;
          const plane = .52 - .66 * height - .34 * across;
          const warm = facingLight / 255 * .19 + Math.max(plane, 0) * .105;
          const cool = facingShade / 255 * .13 + Math.max(-plane, 0) * .13;
          const r = rgba[i], g = rgba[i + 1], b = rgba[i + 2];
          // A tinted key light and deep blue ambient shadow preserve the original palette and ink.
          rgba[i]     = r + (255 - r) * warm - r * cool;
          rgba[i + 1] = g + (247 - g) * warm * .78 - g * cool * .81;
          rgba[i + 2] = b + (220 - b) * warm * .45 + (62 - b) * cool * .57;
        }
      }
      brush.putImageData(pixels, 0, 0);
      while (cache.frames.size >= 240 || cache.pixels + sw * sh > 1280 * 1024) {
        const oldest = cache.frames.keys().next().value;
        const oldFrame = cache.frames.get(oldest);
        cache.pixels -= oldFrame.width * oldFrame.height;
        cache.frames.delete(oldest);
      }
      cache.frames.set(key, frame);
      cache.pixels += sw * sh;
      return frame;
    } catch (error) {
      // The same cross-origin atlas would reject every subsequent pixel read.
      if (error?.name === 'SecurityError') cache.blocked.add(image);
      return null;
    }
  }

  globalThis.rocketFighterMaterial = rocketFighterMaterial;
})();
