// Five named, explicitly saved movesets per species. No battle or wire hooks.
(() => {
  'use strict';
  function arenaNormalizeMovePresets(raw) {
    const result={};
    if(!raw||typeof raw!=='object'||Array.isArray(raw))return result;
    for(const id of Object.keys(raw).slice(0,1200)){
      if(!hn.has(id)||!Array.isArray(raw[id]))continue;
      const sets=[0,1,2,3,4].map(index=>{
        const item=raw[id][index],fallback='Moveset '+(index+1);
        const rawName=item&&!Array.isArray(item)&&typeof item.name==='string'?item.name:'';
        const name=rawName.replace(/[\u0000-\u001f\u007f-\u009f<>]/g,'').trim().slice(0,24)||fallback;
        const moves=Array.isArray(item)?item:item?.moves;
        if(!Array.isArray(moves)||moves.length<4||moves.length>5||moves.some(move=>typeof move!=='string'))return {name,moves:null};
        const defaults=un(id),recommended=moves.length===defaults.length&&moves.every((move,i)=>move===defaults[i]);
        return {name,moves:Tn(id,moves,true)||recommended?moves.slice():null};
      });
      if(sets.some((slot,index)=>slot.moves||slot.name!=='Moveset '+(index+1)))result[id]=sets;
    }
    return result;
  }
  function patchData(source) {
    if(source.includes('function arenaNormalizeMovePresets('))throw Error('Shared move presets already applied.');
    const replace=(before,after)=>{const pieces=source.split(before);if(pieces.length!==2)throw Error('Unsupported shared move preset data anchor.');source=pieces.join(after);};
    replace('book.active = zn(Number(raw.active));',
      'book.movePresets = arenaNormalizeMovePresets(raw.movePresets);\n    book.active = zn(Number(raw.active));');
    replace('raw = {...raw, teams: [...raw.teams, ...prior.teams.slice(raw.teams.length)]};',
      'raw = {...raw, teams: [...raw.teams, ...prior.teams.slice(raw.teams.length)], movePresets:Object.hasOwn(raw,"movePresets")?raw.movePresets:prior.movePresets};');
    return arenaNormalizeMovePresets.toString()+'\n'+source;
  }
  function createArenaMovePresets() {
    const messages=new WeakMap();
    const same=(a,b)=>a.length===b.length&&a.every((move,index)=>move===b[index]);
    const empty=()=>Array.from({length:5},(_,index)=>({name:'Moveset '+(index+1),moves:null}));
    const valid=index=>Number.isInteger(index)&&index>=0&&index<5;
    function stored(ui,id){return arenaNormalizeMovePresets({[id]:ui.teamBook?.movePresets?.[id]})[id]||empty();}
    function canLoad(id,moves){return !!moves&&(Tn(id,moves)||same(moves,un(id)));}
    function note(ui,id,message){messages.set(ui,{id,message});}
    function write(ui,id,sets){
      const presets=arenaNormalizeMovePresets({...ui.teamBook.movePresets,[id]:sets});
      ui.teamBook={...ui.teamBook,movePresets:presets,everSaved:true};
      const saved=er.save(ui.teamBook);ui.paintTeams();return saved;
    }
    function rename(ui,index,name,id=ui.detailId){
      if(!valid(index)||!hn.has(id))return;
      const sets=stored(ui,id);sets[index]={...sets[index],name};
      const saved=write(ui,id,sets);note(ui,id,saved?'Name saved.':'Name kept for this visit only.');paint(ui);
    }
    function save(ui,index){
      const id=ui.detailId,at=ui.pickTeam.indexOf(id);if(!valid(index)||at<0||!hn.has(id))return;
      const moves=Nn(id,ui.pickMoves[at]).slice(),sets=stored(ui,id);sets[index]={...sets[index],moves};
      const normalized=arenaNormalizeMovePresets({[id]:sets});
      if(!normalized[id]?.[index]?.moves){note(ui,id,'This moveset cannot be saved.');paint(ui);return;}
      const saved=write(ui,id,sets);note(ui,id,saved?'Saved '+stored(ui,id)[index].name+'.':'Moves saved for this visit only.');paint(ui);
    }
    function load(ui,index){
      const id=ui.detailId,at=ui.pickTeam.indexOf(id),slot=valid(index)?stored(ui,id)[index]:null,moves=slot?.moves;
      if(at<0||!moves)return;
      if(!canLoad(id,moves)){note(ui,id,'Enable Any move to load this moveset.');paint(ui);return;}
      const next=ui.pickMoves.map(set=>set?set.slice():null);
      next[at]=same(moves,un(id))?null:moves.slice();
      ui.pickMoves=next;ui.movePick=null;ui.candidatePage=0;ui.persistMoves();
      note(ui,id,er.saved?'Loaded '+slot.name+'.':'Loaded for this visit only.');ui.renderPick();
    }
    function paint(ui){
      const detail=ui.pick?.querySelector('.pick-detail'),art=detail?.querySelector('.detail-art');if(!detail||!art)return;
      let current=detail.querySelector('.rocket-preset-current'),panel=detail.querySelector('.rocket-move-presets');
      if(!current){
        current=document.createElement('div');current.className='rocket-preset-current';
        for(const node of [...detail.children])current.append(node);
        detail.append(current);detail.classList.add('rocket-has-presets');
      }
      if(!panel){
        panel=document.createElement('section');panel.className='rocket-move-presets';panel.setAttribute('aria-label','Shared movesets');
        const heading=document.createElement('h3');heading.textContent='MOVESETS';panel.append(heading);
        for(let i=0;i<5;i++){
          const row=document.createElement('article');row.className='rocket-preset-row';row.dataset.movePreset=String(i);
          const head=document.createElement('div');head.className='rocket-preset-head';
          const name=document.createElement('input');name.type='text';name.maxLength=24;name.autocomplete='off';name.spellcheck=false;name.dataset.presetName=String(i);name.setAttribute('aria-label','Moveset '+(i+1)+' name');
          name.addEventListener('change',()=>rename(ui,i,name.value,name.dataset.species));
          name.addEventListener('keydown',event=>{event.stopPropagation();if(event.key==='Enter'){event.preventDefault();name.blur();}if(event.key==='Escape'){event.preventDefault();name.value=stored(ui,name.dataset.species)[i].name;name.blur();}});
          const saveButton=document.createElement('button');saveButton.type='button';saveButton.textContent='SAVE';saveButton.dataset.presetSave=String(i);saveButton.addEventListener('click',()=>save(ui,i));
          const loadButton=document.createElement('button');loadButton.type='button';loadButton.textContent='LOAD';loadButton.dataset.presetLoad=String(i);loadButton.addEventListener('click',()=>load(ui,i));
          const moves=document.createElement('ol');moves.className='rocket-preset-moves';moves.setAttribute('aria-label','Saved moves');
          head.append(name,saveButton,loadButton);row.append(head,moves);panel.append(row);
        }
        const status=document.createElement('p');status.dataset.presetStatus='';status.setAttribute('role','status');panel.append(status);
        for(const type of ['keydown','keyup'])panel.addEventListener(type,event=>{if(event.key!=='Escape')event.stopPropagation();});
        detail.append(panel);
      }
      const id=ui.detailId,known=hn.has(id),selected=known&&ui.pickTeam.includes(id),sets=known?stored(ui,id):empty();
      panel.hidden=!known;detail.classList.toggle('rocket-presets-open',known);
      panel.setAttribute('aria-label',known?dn(id).name+' shared movesets':'Shared movesets');
      for(let i=0;i<5;i++){
        const row=panel.querySelector('[data-move-preset="'+i+'"]'),name=row.querySelector('[data-preset-name]'),saveButton=row.querySelector('[data-preset-save]'),loadButton=row.querySelector('[data-preset-load]'),slot=sets[i],moves=slot.moves;
        row.dataset.filled=String(!!moves);name.dataset.species=id||'';name.title=slot.name;
        if(name!==document.activeElement)name.value=slot.name;
        name.disabled=!known;
        saveButton.disabled=!selected;saveButton.setAttribute('aria-label','Save current moveset to '+slot.name);saveButton.title=moves?'Replace '+slot.name:'Save '+slot.name;
        loadButton.disabled=!selected||!canLoad(id,moves);loadButton.setAttribute('aria-label','Load '+slot.name+' onto this team');
        loadButton.title=!moves?'Empty slot':!selected?'Add this Pokémon to the current team first':!canLoad(id,moves)?'Enable Any move to load this moveset':'Load '+slot.name;
        const list=row.querySelector('.rocket-preset-moves'),signature=JSON.stringify(moves);
        if(list.dataset.moves!==signature){
          list.dataset.moves=signature;list.replaceChildren();
          if(!moves){const label=document.createElement('li');label.className='rocket-preset-empty';label.textContent='EMPTY';list.append(label);}
          else for(const move of moves){
            const definition=V(move),type=definition.typeName||'normal',tile=document.createElement('li');
            tile.dataset.move=move;tile.dataset.moveType=type;tile.textContent=definition.name;tile.title=definition.name+' · '+type;
            tile.style.background='var(--type-'+type+',#65718a)';
            tile.style.color=['normal','electric','ice','ground','steel','fairy'].includes(type)?'#10142a':'#fff';list.append(tile);
          }
        }
      }
      const message=messages.get(ui);panel.querySelector('[data-preset-status]').textContent=message?.id===id?message.message:selected?'Shared across teams.':'Add to your team to save or load.';
    }
    if(typeof document!=='undefined')document.addEventListener('arena-mod-settings',()=>{if(typeof Z!=='undefined'&&Z?.pick?.isConnected&&!Z.pick.classList.contains('is-hidden'))paint(Z);});
    return{paint,save,load,rename};
  }

  function patch(source) {
    source=patchData(source);
    const replace=(before,after)=>{const pieces=source.split(before);if(pieces.length!==2)throw Error('Unsupported shared move preset picker anchor.');source=pieces.join(after);};
    replace('paintDetail(){let e=this.pick?.querySelector(`.pick-detail`);', 'paintDetail(){arenaMovePresets.paint(this);let e=this.pick?.querySelector(`.pick-detail`);');
    replace('Iy(e,K(`pick.edit`),{font:wy,color:Ey(`--ui-on-accent`),background:Ey(`--ui-accent`),shadow:``,scale:Math.min(2,Dy())})',
      'Iy(e,K(`pick.edit`),{font:wy,color:`#FFFFFF`,background:Ey(`--ui-accent`),shadow:``,scale:Math.min(2,Dy())})');
    // Native odd-width snapping otherwise writes a zero left margin and a fixed
    // width over the preset column's responsive inset, moving the whole pager.
    replace('placePager(){let e=this.pick?.querySelector(`.pager-bar`);if(!e)return;let t=e.clientWidth;',
      'placePager(){let e=this.pick?.querySelector(`.pager-bar`);if(!e)return;if(!this.pick.classList.contains(`is-phone`)&&this.pick.querySelector(`.pick-detail.rocket-has-presets`)){e.style.removeProperty(`width`);e.style.removeProperty(`margin-left`);e.style.removeProperty(`margin-right`);return}let t=e.clientWidth;');
    const css="<style>\n.pick:not(.is-phone) .pick-detail.rocket-has-presets{display:grid;grid-template-columns:minmax(0,.9fr) minmax(0,1.1fr);gap:8px;padding:8px;align-items:stretch}\n.pick .rocket-preset-current{display:flex;flex-direction:column;gap:4px;min-width:0;min-height:0;overflow:auto;overscroll-behavior:contain}\n.pick .rocket-preset-current>.detail-art{width:100%;max-width:160px;flex:none;align-self:center;margin:0!important}\n.pick .rocket-preset-current .detail-moves{min-width:0}.pick .rocket-preset-current .detail-move-block{min-width:0}\n.pick .rocket-move-presets{box-sizing:border-box;display:grid;grid-template-rows:auto repeat(5,minmax(min-content,1fr)) auto;gap:6px;min-width:0;min-height:0;overflow:auto;overscroll-behavior:contain;color:var(--ui-text,#f8f8f8);font:700 11px/1.3 Silkscreen,monospace}\n.pick .rocket-move-presets[hidden]{display:none}.pick .rocket-move-presets h3{margin:0;font:inherit;font-size:12px}\n.pick .rocket-preset-row{box-sizing:border-box;display:grid;grid-template-rows:auto minmax(0,1fr);gap:4px;min-width:0;padding:5px;border:2px solid var(--ui-frame-hi,#b4b8d3);background:var(--ui-panel,#272f55)}\n.pick .rocket-preset-row[data-filled=\"true\"]{border-color:var(--ui-frame,#e8e0cc)}\n.pick .rocket-preset-head{display:grid;grid-template-columns:minmax(0,1fr) auto auto;gap:3px;align-items:center;min-width:0}\n.pick .rocket-preset-head input{box-sizing:border-box;width:100%;min-width:0;height:24px;border:0;border-bottom:2px solid var(--ui-frame-hi,#b4b8d3);border-radius:0;padding:2px;background:var(--ui-input-bg,#10152a);color:var(--ui-text,#f8f8f8);font:inherit;font-size:11px}\n.pick .rocket-move-presets button{box-sizing:border-box;min-width:0;min-height:24px;padding:2px 3px;border:2px solid var(--ui-outline,#080b18);border-radius:0;background:var(--ui-input-bg,#10152a);color:var(--ui-text,#f8f8f8);font:inherit;font-size:9px;cursor:pointer}\n.pick .rocket-move-presets button:hover:not(:disabled){background:var(--ui-cell-selected,#343e70)}.pick .rocket-move-presets button:disabled{opacity:.4;cursor:default}\n.pick .rocket-move-presets :is(button,input):focus-visible{outline:2px solid var(--ui-cursor,#f87818);outline-offset:-2px}\n.pick .rocket-preset-moves{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));grid-auto-rows:minmax(16px,1fr);gap:3px;min-width:0;padding:0;margin:0;list-style:none}\n.pick .rocket-preset-moves>li{box-sizing:border-box;display:flex;align-items:center;justify-content:center;min-width:0;padding:2px 3px;text-align:center;font-size:10px;line-height:1.15;overflow-wrap:anywhere;border:1px solid var(--ui-outline,#080b18);text-shadow:0 1px 1px #0005}\n.pick .rocket-preset-moves>li:nth-child(5){grid-column:1 / -1}.pick .rocket-preset-moves>.rocket-preset-empty{grid-column:1 / -1;color:var(--ui-text-muted,#bbc1df);border:0;background:var(--ui-input-bg,#10152a)}\n.pick [data-preset-status]{margin:0;min-height:12px;overflow-wrap:anywhere;color:var(--ui-text-dim,#bbc1df);font-size:9px;line-height:1.3}\n.pick.is-phone .rocket-preset-current{display:contents}.pick.is-phone .rocket-move-presets{grid-column:1 / -1;grid-row:7;margin-top:8px;overflow:visible;grid-template-rows:auto repeat(5,minmax(84px,auto)) auto}\n.pick.is-phone .pick-detail.rocket-has-presets{overflow:auto;overscroll-behavior:contain}.pick.is-phone .rocket-preset-current>.detail-art{width:56px;max-width:none}.pick.is-phone .pick-detail:has(.detail-recommend:not([hidden])) .rocket-preset-current>.detail-art{width:48px}\n</style>";
    const currentMoveCss=`<style>
      .pick.is-editing .pick-main>.pick-slots{display:none}
      .pick.is-editing .pick-main>.move-editor{grid-column:1 / -1}
      .pick:not(.is-phone).is-editing .pick-detail.rocket-has-presets{display:none}
      .pick:not(.is-phone) .rocket-preset-current{box-sizing:border-box;padding-bottom:calc(var(--pager-h) + 10px)}
      .pick:not(.is-phone) .rocket-preset-current .detail-moves li{display:grid;grid-template-columns:24px 6px minmax(0,1fr);gap:4px;margin:0;padding:4px}
      .pick:not(.is-phone) .rocket-preset-current .move-key{width:24px}
      .pick:not(.is-phone) .rocket-preset-current .detail-moves li>i{width:6px}
      .pick:not(.is-phone) .rocket-preset-current .detail-move-action{display:grid;grid-template-columns:minmax(0,1fr);grid-template-rows:auto auto;gap:3px;align-content:center;justify-items:start;overflow:visible}
      .pick:not(.is-phone) .rocket-preset-current .move-name{width:100%;overflow:visible}
      .pick:not(.is-phone) .rocket-preset-current .move-name canvas{display:block;max-width:100%;height:auto!important}
      .pick:not(.is-phone) .rocket-preset-current .move-edit-mark{margin:0;justify-self:start}
      .pick:not(.is-phone):not(.is-editing) .pick-main:has(>.rocket-has-presets)>.pager-bar{box-sizing:border-box;display:grid;grid-template-columns:var(--pager-w) minmax(0,1fr) var(--pager-w);width:calc(45% - 10.8px);min-height:calc(var(--pager-h) + 10px);margin-left:8px;justify-self:start;align-items:center;gap:6px;padding:0 8px 10px}
      .pick:not(.is-phone) .pick-main:has(>.rocket-has-presets)>.pager-bar .pager-label{display:flex;align-items:center;justify-content:center;min-width:0;text-align:center}
      .pick:not(.is-phone) .pick-main:has(>.rocket-has-presets)>.pager-bar .pager-label canvas{display:block;max-width:100%;height:auto!important;margin-inline:auto}
      .pick:not(.is-phone) .pick-main:has(>.rocket-has-presets)>.pager-bar :is(.pager-prev,.pager-next){display:flex;align-items:center;justify-content:center}
    </style>`;
    replace('function wb(){return`','function wb(){return`'+css+currentMoveCss);
    return 'const arenaMovePresets=('+createArenaMovePresets.toString()+')();\n'+source;
  }
  function helperSource(){return '(()=>{\n'+arenaNormalizeMovePresets.toString()+'\n'+patchData.toString()+'\nglobalThis.ArenaMovePresetsAdapter=Object.freeze({patch:patchData,patchData});\n})();';}
  const api={patch,patchData,helperSource,arenaNormalizeMovePresets,createArenaMovePresets};
  globalThis.ArenaMovePresetsAdapter=Object.freeze(api);
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})();
