// Simultaneous offline CPU teams reuse the native combat engine and its moves.
(() => {
  'use strict';
  function arenaCpuModeSpec(value) {
    let id=typeof value==='string'?value:value?.id||value?.type||'classic';
    let count=typeof value==='object'?Number(value?.count):NaN;
    const match=/^ffa[-:]?(\d+)$/.exec(id);
    if(match){id='ffa';count=Number(match[1]);}
    if(id==='ffa'){
      count=Math.max(3,Math.min(12,Number.isFinite(count)?Math.round(count):3));
      return {id,count,sizes:Array(count).fill(1)};
    }
    const sizes={'5v5':[5,5],'4v4':[4,4],'3v3v3':[3,3,3],'3v3':[3,3],'2v2':[2,2],'2v2v2v2':[2,2,2,2]}[id];
    return sizes?{id,count:sizes.reduce((sum,n)=>sum+n,0),sizes}:null;
  }
  function arenaCpuWorldType() {
    return class ArenaCpuWorld extends bc {
      constructor(options={}) {
        const mode=arenaCpuModeSpec(options.arenaCpuMode);
        if(!mode)return new bc(options);
        const normal=species=>!(typeof arenaGmaxSpecies==='function'?arenaGmaxSpecies(species):/gmax$/i.test(species.id)||/-(?:Gmax|Gigantamax)$/i.test(species.name));
        const pool=Zt.filter(normal).map(species=>species.id),allowed=new Set(pool);
        const valid=id=>{try{const species=dn(options.rosterForms===true?id:yc(id));return allowed.has(species.id)?species.id:null;}catch{return null;}};
        const random=lo(((options.seed??1)^0x43c0ffee)>>>0),used=new Set();
        for(let index=pool.length-1;index>0;index--){const other=Math.floor(random()*(index+1));[pool[index],pool[other]]=[pool[other],pool[index]];}
        let cursor=0;
        const pick=()=>{while(cursor<pool.length&&used.has(pool[cursor]))cursor++;const id=pool[cursor++]||pool[Math.floor(random()*pool.length)];used.add(id);return id;};
        const chosen=(lead,ids,loadouts)=>{
          const list=(Array.isArray(ids)?ids:[]).map((id,index)=>({id:valid(id),loadout:loadouts?.[index]})).filter(row=>row.id);
          const first=valid(lead)||list[0]?.id||pick(),at=list.findIndex(row=>row.id===first);
          const head=at>=0?list.splice(at,1)[0]:{id:first,loadout:null};
          return [head,...list];
        };
        const own=chosen(options.playerSpeciesId,options.partyIds,options.partyLoadouts);
        const foe=chosen(options.opponentSpeciesId,options.opponentPartyIds,options.opponentPartyLoadouts);
        for(const row of [...own,...foe])used.add(row.id);
        super({...options,playerSpeciesId:own[0].id,opponentSpeciesId:foe[0].id,
          partyIds:[own[0].id],opponentPartyIds:[foe[0].id],partyLoadouts:[own[0].loadout],opponentPartyLoadouts:[foe[0].loadout],
          partyHpRatio:null,thirdPartyIds:undefined,thirdPartyLoadouts:undefined,ai:true,playerAi:false,cpuSwitch:false});
        this.arenaCpuMode={id:mode.id,count:mode.count};
        this.arenaCpuOptions={...options,arenaCpuMode:{...this.arenaCpuMode}};
        this.arenaCpuMembers=new Map();this.arenaCpuMemories=new Map();this.arenaCpuMega=new Set();
        this.arenaCpuTeams=mode.sizes.map((size,index)=>({id:'team-'+index,size,members:[]}));
        this.arenaCpuFighters=[];this.arenaCpuWinner=null;this.arenaCpuDisposed=false;
        // Interleave teams so the canonical opponent is always an enemy and
        // the first three actor IDs remain compatible with native art/events.
        for(let slot=0;slot<Math.max(...mode.sizes);slot++)for(let team=0;team<mode.sizes.length;team++){
          if(slot>=mode.sizes[team])continue;
          const index=this.arenaCpuFighters.length,id=['player','opponent','third'][index]||'cpu-'+index;
          const row=(team===0?own:team===1?foe:[])[slot]||{id:pick(),loadout:null};
          const members=this.membersFrom([row.id],[row.loadout]);this.arenaCpuMembers.set(id,members);
          const point=this.arenaCpuSpawn(team,slot,mode.sizes[team],members[0].species.radius);
          const fighter=this.makeFighter(id,members[0].species,point.x,point.y,point.facing);
          fighter.arenaCpuTeam=this.arenaCpuTeams[team].id;
          this.arenaCpuFighters.push(fighter);this.arenaCpuTeams[team].members.push(id);this.arenaCpuMemories.set(id,Yo());
        }
        this.player=this.arenaCpuFighters[0];this.opponent=this.arenaCpuFighters[1];this.third=this.arenaCpuFighters[2];
        this.party=this.partyOf('player');this.foeParty=this.partyOf('opponent');this.thirdParty=this.partyOf('third');
        this.activeIndex=this.foeActiveIndex=this.thirdActiveIndex=0;
        this.switchCd=this.foeSwitchCd=this.thirdSwitchCd=0;this.switchLock=this.foeSwitchLock=this.thirdSwitchLock=0;
        this.bossAdvantage=undefined;
      }
      arenaCpuSpawn(team,slot,size,radius) {
        const bounds=this.combat,left=bounds.left,right=bounds.right,top=bounds.top,bottom=bounds.bottom;
        const cx=(left+right)/2,cy=(top+bottom)/2,teams=this.arenaCpuTeams.length;
        const angle=Math.PI+team*Math.PI*2/teams,ring=Math.min(right-left,bottom-top)*.32;
        const spread=(slot-(size-1)/2)*Math.min(110,(bottom-top)/(size+1));
        const point=Ia(cx+Math.cos(angle)*ring-Math.sin(angle)*spread,cy+Math.sin(angle)*ring+Math.cos(angle)*spread,radius,bounds);
        return {...point,facing:Math.atan2(cy-point.y,cx-point.x)};
      }
      fighters(){return this.arenaCpuFighters||super.fighters();}
      fighterOf(id){
        if(!this.arenaCpuFighters)return super.fighterOf(id);
        const fighter=this.arenaCpuFighters.find(actor=>actor.id===id);
        if(!fighter)throw Error('Unknown CPU battle fighter.');
        return fighter;
      }
      partyOf(id){return this.arenaCpuMembers?.get(id)||super.partyOf(id);}
      activeOf(id){return this.arenaCpuMembers?0:super.activeOf(id);}
      cooldownOf(id){return this.arenaCpuMembers?0:super.cooldownOf(id);}
      lockOf(id){return this.arenaCpuMembers?0:super.lockOf(id);}
      megaUsedOf(id){return this.arenaCpuMega?this.arenaCpuMega.has(id):super.megaUsedOf(id);}
      setMegaUsed(id){
        if(!this.arenaCpuMega)return super.setMegaUsed(id);
        this.arenaCpuMega.add(id);
        if(id==='player')this.playerMegaUsed=true;else if(id==='opponent')this.foeMegaUsed=true;else if(id==='third')this.thirdMegaUsed=true;
      }
      trySwitch(){}
      sendOut(){}
      enemies(actor){return this.fighters().filter(other=>other!==actor&&other.arenaCpuTeam!==actor.arenaCpuTeam&&other.hp>0);}
      nearestEnemy(actor){return this.enemies(actor).sort((a,b)=>Math.hypot(a.x-actor.x,a.y-actor.y)-Math.hypot(b.x-actor.x,b.y-actor.y))[0]||null;}
      landHit(actor,target,...args){return actor.arenaCpuTeam===target.arenaCpuTeam?0:super.landHit(actor,target,...args);}
      landBasic(actor,target,...args){return actor.arenaCpuTeam===target.arenaCpuTeam?0:super.landBasic(actor,target,...args);}
      hurt(target,amount,move,guard=true,details={}){
        const actor=details.actor&&this.arenaCpuFighters?.find(fighter=>fighter.id===details.actor);
        if(actor&&actor!==target&&actor.arenaCpuTeam===target.arenaCpuTeam)return;
        return super.hurt(target,amount,move,guard,details);
      }
      spawnZone(actor,move,x,y){
        const spec=Go(move)?Wo:so(move);if(!spec||this.phase!=='fight')return;
        this.zones=this.zones.filter(zone=>zone.owner!==actor.id);
        const zone={id:this.nextZone++,owner:actor.id,ownerEntry:actor.entry,move,x,y,r:spec.r,
          warnTicks:spec.warnTicks,hitTicks:spec.hitTicks,age:0,fresh:true,cursor:0,book:null};
        this.zones.push(zone);this.events.push({type:'ultZone',actor:actor.id,id:zone.id,x,y,r:zone.r,warnTicks:zone.warnTicks,hitTicks:zone.hitTicks,move});
      }
      arenaCpuFinish(result,winnerTeam=null){
        if(this.phase!=='fight')return;
        this.phase=result;this.arenaCpuWinner=winnerTeam;this.winner=result==='victory'?'player':result==='defeat'?'opponent':null;
        this.bullets=[];this.zones=[];this.supply=null;this.pendingKnocks=[];this.cancelBufferedInput();
        for(const actor of this.fighters()){actor.cast=null;actor.recoverMs=0;actor.pendingAction=null;}
        this.events.push({type:'match',result,winnerTeam});
      }
      resolveKnockouts(){
        if(!this.arenaCpuFighters)return super.resolveKnockouts();
        for(const actor of this.fighters()){
          this.rememberHp(actor);
          if(actor.hp>0)continue;
          actor.cast=null;actor.pendingAction=null;actor.recoverMs=0;
          this.bullets=this.bullets.filter(shot=>shot.owner!==actor.id);this.zones=this.zones.filter(zone=>zone.owner!==actor.id);
        }
        const alive=this.arenaCpuTeams.filter(team=>team.members.some(id=>this.fighterOf(id).hp>0));
        if(!alive.length)this.arenaCpuFinish('draw');
        else if(!alive.some(team=>team.id==='team-0'))this.arenaCpuFinish('defeat',alive.length===1?alive[0].id:null);
        else if(alive.length===1)this.arenaCpuFinish('victory',alive[0].id);
      }
      finishByTime(){
        const teams=this.arenaCpuTeams.map(team=>({id:team.id,score:team.members.reduce((sum,id)=>{const actor=this.fighterOf(id);return sum+Math.max(0,actor.hp)/actor.maxHp;},0)})).sort((a,b)=>b.score-a.score);
        if(!teams[0]||Math.abs(teams[0].score-teams[1].score)<1e-9)this.arenaCpuFinish('draw');
        else this.arenaCpuFinish(teams[0].id==='team-0'?'victory':'defeat',teams[0].id);
      }
      knockOutOpponent(){for(const actor of this.fighters())if(actor.arenaCpuTeam!=='team-0')this.setMemberHp(actor.id,0,0);}
      eliminateTeam(id){
        const team=this.arenaCpuTeams.find(team=>team.id===id||team.members.includes(id));
        if(team)for(const actor of team.members)this.setMemberHp(actor,0,0);
      }
      step(input=bo()){
        this.events=[];
        if(this.arenaCpuDisposed)return {state:this.getState(),events:[]};
        this.inputFrame++;
        if(this.gated&&!this.acceptsInput())return {state:this.getState(),events:[]};
        if(this.phase!=='fight')return {state:this.getState(),events:[]};
        if(this.stopTicks>0){this.bufferInput(input);this.stopTicks--;return {state:this.getState(),events:[]};}
        if(this.bufferedInput){this.bufferInput(input);input=this.bufferedInput;this.bufferedInput=null;}
        for(const knock of this.pendingKnocks){const actor=this.fighterOf(knock.target);if(actor.entry===knock.entry&&actor.hp>0)this.knock(actor,knock.vx,knock.vy,knock.amount);}
        this.pendingKnocks=[];this.resolveKnockouts();
        if(this.phase!=='fight')return {state:this.getState(),events:this.events};
        if(this.clock==='countdown'&&this.remainingMs<=0){this.finishByTime();return {state:this.getState(),events:this.events};}
        this.tick++;this.elapsedMs+=q;if(this.clock==='countdown')this.remainingMs=Math.max(0,this.remainingMs-q);
        const item=this.supply?{kind:this.supply.kind,x:this.supply.x,y:this.supply.y}:null;
        const commands=this.fighters().map((actor,index)=>{
          const target=this.nearestEnemy(actor);let command=input;
          if(actor.id!=='player'&&actor.hp>0&&target)command=ms({tick:this.tick,seed:this.seed^(Math.imul(index+1,2654435769)>>>0),
            self:this.aiBody(actor),foe:this.aiBody(target),tuning:this.tuning,memory:this.arenaCpuMemories.get(actor.id),item,canMega:this.canMega(actor.id)});
          return {actor,target,command};
        });
        for(const {actor,target,command} of commands){
          if(actor.hp<=0||!target)continue;
          this.tickFighterUltPassive(actor,this.ultPassivePerSec*q/1000);
          this.advance(actor,command,target,rc(actor.speciesId,actor.x,actor.y),{x:target.x,y:target.y,hp:target.hp});
        }
        this.updateBullets();this.updateZones();this.separate();this.tickItems();
        if(this.stopTicks===0){this.resolveKnockouts();if(this.phase==='fight'&&this.clock==='countdown'&&this.remainingMs<=0)this.finishByTime();}
        return {state:this.getState(),events:this.events};
      }
      getState(){
        if(!this.arenaCpuFighters)return super.getState();
        for(const actor of this.fighters())this.rememberHp(actor);
        const state=super.getState();delete state.ffa;
        state.fighters=this.fighters().map(actor=>({...this.snapshot(actor),arenaCpuTeam:actor.arenaCpuTeam}));
        state.megaUsed=Object.fromEntries(this.fighters().map(actor=>[actor.id,this.megaUsedOf(actor.id)]));
        state.winner=this.winner;state.result=this.phase==='fight'?null:this.phase;
        state.cpuBattle={mode:{...this.arenaCpuMode},playerTeam:'team-0',winnerTeam:this.arenaCpuWinner,
          teams:this.arenaCpuTeams.map(team=>({id:team.id,members:team.members.slice(),alive:team.members.filter(id=>this.fighterOf(id).hp>0).length}))};
        return state;
      }
      reset(){const fresh=new this.constructor(this.arenaCpuOptions);if(fresh.gated)fresh.markAssetsReady();Object.assign(this,fresh);}
      dispose(){this.arenaCpuDisposed=true;this.events=[];this.bullets=[];this.zones=[];this.supply=null;this.pendingKnocks=[];this.cancelBufferedInput();for(const actor of this.fighters()){actor.cast=null;actor.pendingAction=null;}}
    };
  }
  function patch(source){
    const anchor='var M1=class extends FQ',parts=source.split(anchor);
    if(parts.length!==2||source.includes('function arenaCpuWorldType('))throw Error('Unsupported CPU battle anchor.');
    return parts.join(arenaCpuModeSpec.toString()+'\n'+arenaCpuWorldType.toString()+'\n'+anchor);
  }
  const api=Object.freeze({patch,arenaCpuWorldType,arenaCpuModeSpec});globalThis.ArenaCpuBattleAdapter=api;
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})();
