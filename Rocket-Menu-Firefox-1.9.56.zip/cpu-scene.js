// Local CPU modes use the normal arena scene, sprites, controls and effects.
(() => {
  'use strict';

  function arenaCpuColors(team) {
    const colors=['#3890F8','#F03848','#F8C830','#48C878','#B888F8','#F89048','#48D0D8','#F888B8','#A8C858','#C89868','#9898F8','#E8E8F8'];
    return colors[arenaCpuTeamIndex(team)%colors.length];
  }

  function arenaCpuTeamIndex(team) {
    return Math.abs(Number(String(team).replace(/^team-/,''))||0);
  }

  function arenaCpuSceneCamera(scene,state) {
    const camera=scene.cameras.main,player=state.fighters.find(actor=>actor.id==='player');
    if(!player)return;
    const width=state.arena?.width||Ca,height=state.arena?.height||wa;
    // Keep normal battle magnification. Large windows may need a higher
    // minimum zoom so the visible world never extends past the map edges.
    const zoom=Math.max(scene.cameraZoom,camera.width/width,camera.height/height);
    if(camera.zoom!==zoom)camera.setZoom(zoom);
    const shown=scene.shown.get(player.id),focus=shown??player;
    const x=kH(focus.x,camera.width,zoom,width),y=kH(focus.y,camera.height,zoom,height);
    if(!scene.cameraReady){camera.scrollX=x;camera.scrollY=y;scene.cameraReady=true;return;}
    const follow=shown?.simFreeze?0:.22;
    // Clamp after interpolation too: a resize can invalidate the old scroll.
    camera.scrollX=kH(camera.scrollX+(x-camera.scrollX)*follow+camera.width/2,camera.width,zoom,width);
    camera.scrollY=kH(camera.scrollY+(y-camera.scrollY)*follow+camera.height/2,camera.height,zoom,height);
  }

  function arenaCpuHudLayout(hud,layout,width,height) {
    if(!hud)return;
    hud.rocketCpuLayout={layout,width,height};
    const tray=hud.rocketCpuTeams;if(!tray)return;
    const mobile=layout.mode==='mobile';
    const left=mobile?8:layout.foe.x,top=mobile?Math.max(layout.player.y+layout.player.h,layout.timer.y+layout.timer.h,layout.pause.y+layout.pause.h)+6:layout.foe.y;
    const available=mobile?Math.max(1,width-16):layout.foe.w;
    const columns=tray.classList.contains('is-ffa')?Math.min(6,tray.childElementCount):mobile?tray.childElementCount:1;
    const css='left:'+Math.round(left)+'px;top:'+Math.round(top)+'px;width:'+Math.round(available)+'px;grid-template-columns:repeat('+Math.max(1,columns)+',minmax(0,1fr))';
    if(tray.dataset.layout!==css){tray.style.cssText=css;tray.dataset.layout=css;}
    tray.classList.toggle('is-compact',mobile);
  }

  function arenaCpuSceneDraw(scene,state) {
    if(!state.cpuBattle)return;
    if(!scene.rocketCpuView){
      if(!document.getElementById('rocket-cpu-scene-style')){
        const style=document.createElement('style');style.id='rocket-cpu-scene-style';
        style.textContent=`
          .hud.rocket-cpu-battle .cluster.foe,.hud.rocket-cpu-battle .party{display:none!important}
          .rocket-cpu-teams{box-sizing:border-box;position:absolute;top:12px;right:12px;width:180px;display:grid;grid-template-columns:minmax(0,1fr);gap:4px;pointer-events:none;image-rendering:pixelated}
          .rocket-cpu-teams *{box-sizing:border-box}
          .rocket-cpu-team{min-width:0;padding:3px;border:1px solid var(--ui-frame-hi,#46508a);border-left:3px solid var(--cpu-color);background:var(--ui-panel,#272f55);box-shadow:1px 1px 0 #080b18}
          .rocket-cpu-members{display:flex;gap:3px;justify-content:flex-start}
          .rocket-cpu-member{display:block;flex:0 1 26px;min-width:0;width:26px;max-width:26px}
          .rocket-cpu-member img{display:block;width:100%;height:26px;object-fit:contain;image-rendering:pixelated}
          .rocket-cpu-member.is-out{opacity:.35}
          .rocket-cpu-member i{display:block;height:4px;border:1px solid #080b18;background:#080b18}
          .rocket-cpu-member b{display:block;height:100%;background:#48d878}
          .rocket-cpu-teams.is-compact{gap:3px}.rocket-cpu-teams.is-compact .rocket-cpu-team{padding:2px}.rocket-cpu-teams.is-compact .rocket-cpu-members{gap:2px}.rocket-cpu-teams.is-compact .rocket-cpu-member{flex-basis:20px;width:20px;max-width:20px}.rocket-cpu-teams.is-compact .rocket-cpu-member img{height:20px}
        `;document.head.append(style);
      }
      const hud=Z.hud,teams=document.createElement('div');teams.className='rocket-cpu-teams';teams.setAttribute('role','group');teams.setAttribute('aria-label','CPU battle teams');
      hud?.classList.add('rocket-cpu-battle');hud?.append(teams);if(hud)hud.rocketCpuTeams=teams;
      const view={hud,teams,cards:new Map(),bars:scene.add.graphics().setDepth(99)};
      scene.rocketCpuView=view;
      scene.events.once('shutdown',()=>{
        view.teams.remove();view.hud?.classList.remove('rocket-cpu-battle');
        if(view.hud?.rocketCpuTeams===teams)delete view.hud.rocketCpuTeams;
        view.bars.destroy();scene.rocketCpuView=null;
      });
      const groups=new Map();
      for(const fighter of state.fighters){const team=fighter.arenaCpuTeam;let members=groups.get(team);if(!members)groups.set(team,members=[]);members.push(fighter);}
      teams.classList.toggle('is-ffa',state.cpuBattle.mode.id==='ffa');
      for(const [team,members] of groups){
        const group=document.createElement('div');group.className='rocket-cpu-team';group.style.setProperty('--cpu-color',arenaCpuColors(team));
        group.setAttribute('role','group');group.setAttribute('aria-label',(members.some(actor=>actor.id==='player')?'Your team':'Team '+(arenaCpuTeamIndex(team)+1)));
        const row=document.createElement('div');row.className='rocket-cpu-members';group.append(row);teams.append(group);
        for(const fighter of members){
          const card=document.createElement('span');card.className='rocket-cpu-member';
          const img=document.createElement('img');img.alt=dn(fighter.speciesId).name;img.src=yp({id:fighter.speciesId});img.draggable=false;
          const track=document.createElement('i'),fill=document.createElement('b');track.append(fill);card.append(img,track);row.append(card);
          view.cards.set(fighter.id,{card,img,fill,species:fighter.speciesId});
        }
      }
      if(hud?.rocketCpuLayout){const {layout,width,height}=hud.rocketCpuLayout;arenaCpuHudLayout(hud,layout,width,height);}
    }
    const view=scene.rocketCpuView,zoom=scene.cameras.main.zoom||1;
    view.bars.clear();
    for(const fighter of state.fighters){
      const ratio=Math.max(0,Math.min(1,fighter.hp/Math.max(1,fighter.maxHp))),record=view.cards.get(fighter.id);
      if(record){
        if(record.species!==fighter.speciesId){record.species=fighter.speciesId;record.img.src=yp({id:fighter.speciesId});record.img.alt=dn(fighter.speciesId).name;}
        record.card.classList.toggle('is-out',fighter.hp<=0);record.fill.style.width=(ratio*100)+'%';
        record.fill.style.background=ratio>.5?'#48D878':ratio>.2?'#F8C830':'#F03848';
        record.card.title=record.img.alt+' · '+Math.ceil(fighter.hp)+' / '+fighter.maxHp+' HP';
      }
      const visible=state.phase==='fight'&&fighter.hp>0&&!scene.balls?.hidesGroundShadow(fighter.id);
      if(!visible)continue;
      const x=fighter.x-12/zoom,y=fighter.y+10/zoom;
      view.bars.fillStyle(0x080b18,1).fillRect(x-1/zoom,y-1/zoom,26/zoom,4/zoom);
      view.bars.fillStyle(parseInt(arenaCpuColors(fighter.arenaCpuTeam).slice(1),16),1).fillRect(x,y,24*ratio/zoom,2/zoom);
    }
  }

  function patch(original) {
    let source=original;
    const replace=(before,after)=>{const parts=source.split(before);if(parts.length!==2)throw Error('Unsupported CPU arena anchor: '+before.slice(0,100));source=parts.join(after);};
    replace('this.world=new bc({rosterForms:this.aiEnabled','this.world=new (arenaCpuWorldType())({arenaCpuMode:!this.net&&this.battleSource===`cpu`?e?.arenaCpuMode:null,rosterForms:this.aiEnabled');
    // Every simultaneous fighter must be in the critical sprite/effect load set.
    replace('l=[...new Set([...s,...c,...i.ffa?.teams.flatMap(e=>e.party.map(e=>e.speciesId))??[],...Vk([...s,...c,...i.ffa?.teams.flatMap(e=>e.party.map(e=>e.speciesId))??[]])])]',
      'l=[...new Set([...s,...c,...i.fighters.map(e=>e.speciesId),...i.ffa?.teams.flatMap(e=>e.party.map(e=>e.speciesId))??[],...Vk([...s,...c,...i.fighters.map(e=>e.speciesId),...i.ffa?.teams.flatMap(e=>e.party.map(e=>e.speciesId))??[]])])]');
    replace('dH(o,l,t.id,_,u,i.fighters.map(e=>e.speciesId))',
      'dH(o,l,t.id,_,u,i.fighters.map(e=>e.speciesId),i.cpuBattle?i.fighters.flatMap(e=>e.moves.map(e=>e.id)):null)');
    replace('async function dH(e,t,n,r,i,a){let o=oH;return o&&await o.promise,fH(e,t,n,r,i,a)}',
      'async function dH(e,t,n,r,i,a,arenaCpuMoves){let o=oH;return o&&await o.promise,fH(e,t,n,r,i,a,arenaCpuMoves)}');
    replace('async function fH(e,t,n,r,i,a){let o=new Set',
      'async function fH(e,t,n,r,i,a,arenaCpuMoves){let o=new Set');
    replace('l=Uk(t),u=async t=>','l=[...new Set([...Uk(t),...(arenaCpuMoves??[])])],u=async t=>');
    // Keep native map bounds for CPU modes; only native online FFA removes them.
    replace('placeCamera(e){let t=e.fighters[0]', 'placeCamera(e){if(e.cpuBattle){arenaCpuSceneCamera(this,e);return}let t=e.fighters[0]');
    replace('document.documentElement.style.setProperty(`--k`,String(a.k))}bindMega(){',
      'document.documentElement.style.setProperty(`--k`,String(a.k)),arenaCpuHudLayout(this.hud,a,e,t)}bindMega(){');
    replace('this.paintAim(e),this.combatGeometry?.paint(e,','arenaCpuSceneDraw(this,e),this.paintAim(e),this.combatGeometry?.paint(e,');
    replace('function Ac(e){let t=e.fighters[0];return e.fighters.filter(e=>e.id!==t.id&&e.hp>0)',
      'function Ac(e){let t=e.fighters[0];return e.fighters.filter(e=>e.id!==t.id&&e.hp>0&&(e.arenaCpuTeam===undefined||e.arenaCpuTeam!==t.arenaCpuTeam))');
    replace('i=e.ffa?Ac(e):e.fighters[1]??null','i=e.ffa||e.cpuBattle?Ac(e):e.fighters[1]??null');
    replace('n.dataset.roomMode=e.ffa?`ffa3`:`duel`','n.dataset.roomMode=e.cpuBattle?(e.cpuBattle.mode.id===`ffa`?`ffa-`+e.cpuBattle.mode.count:e.cpuBattle.mode.id):e.ffa?`ffa3`:`duel`');
    return [arenaCpuTeamIndex,arenaCpuColors,arenaCpuSceneCamera,arenaCpuHudLayout,arenaCpuSceneDraw].map(fn=>fn.toString()).join('\n')+'\n'+source;
  }
  const api=Object.freeze({patch});globalThis.ArenaCpuSceneAdapter=api;
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})();
