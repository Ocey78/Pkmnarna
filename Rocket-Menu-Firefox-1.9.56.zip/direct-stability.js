// Retry an inconclusive first RTT window using later real samples. The native
// deadline, quality thresholds, transport and service-selected host stay intact.
(() => {
  'use strict';
  function patch(source) {
    const before='!this.voted&&this.samples.length>=4&&(this.voted=!0,this.on.vote(mw(this.samples)))';
    const after='!this.voted&&performance.now()<this.attemptUntil&&this.samples.length>=4&&(()=>{const arenaDirectMeasured=mw(this.samples.slice(-4));arenaDirectMeasured!==null&&(this.voted=!0,this.on.vote(arenaDirectMeasured))})()';
    const parts=source.split(before);
    if(parts.length!==2)throw Error('Unsupported game build: Direct stability decision anchor.');
    return parts.join(after);
  }
  const api=Object.freeze({patch});
  globalThis.ArenaDirectStabilityAdapter=api;
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})();
