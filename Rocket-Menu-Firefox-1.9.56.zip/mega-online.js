// A Direct authority can publish its own native Mega choice. No wire fields or
// moves are changed, and a remote authority retains the stock move-based choice.
(() => {
  'use strict';
  function createArenaMegaOnline(){
    let lastStatus='';
    function controller(){return typeof hO==='undefined'?null:hO;}
    function owns(world,actor){
      const current=controller(),seat=current?.you,authority=current?.authority;
      if(!current?.active||!world||authority?.world!==world||
          (seat!=='A'&&seat!=='B')||authority.start?.direct?.host!==seat||
          world.arenaHostCooldownSeat!==seat)return false;
      return actor===(seat==='A'?world.player:world.opponent);
    }
    function targetFor(world,actor,fallback){
      if(!owns(world,actor))return fallback;
      const family=arenaMegaFamily(actor.speciesId);
      if(!family)return fallback;
      const preferred=er.read().megaForms?.[family.base];
      return preferred===family.x||preferred===family.y?preferred:fallback;
    }
    function status(offline=false){
      if(offline)return{kind:'offline',canChoose:true,label:'YOUR CHOICE'};
      const current=controller();
      if(!current?.active||!current.room||!['vs','fight'].includes(current.mode))
        return{kind:'pending',canChoose:false,label:'X/Y: DIRECT HOST ONLY'};
      const world=current.authority?.world;
      const actor=current.you==='A'?world?.player:current.you==='B'?world?.opponent:null;
      if(owns(world,actor))return{kind:'direct-host',canChoose:true,label:'DIRECT HOST CHOICE'};
      if(current.battle?.direct||current.directStart?.direct)
        return{kind:'direct-guest',canChoose:false,label:'DIRECT GUEST: FROM MOVES'};
      return{kind:'cloud',canChoose:false,label:'CLOUD: FROM MOVES'};
    }
    function changed(){
      const value=status(),key=value.kind+':'+value.canChoose;
      if(lastStatus===key)return;
      lastStatus=key;document.dispatchEvent(new Event('arena-mega-capability'));
    }
    return Object.freeze({owns,targetFor,status,changed});
  }
  function patch(source){
    function once(before,after){
      const parts=source.split(before);
      if(parts.length!==2)throw Error('Unsupported online Mega choice anchor: '+before.slice(0,90));
      source=parts.join(after);
    }
    once('this.mode=`vs`,t||cO(ZD(),e.teams,this.you,`FIGHT`);',
      'this.mode=`vs`,arenaMegaOnline.changed(),t||cO(ZD(),e.teams,this.you,`FIGHT`);');
    once('rocketLobbyMenus.roomPainted(this)',
      '(rocketLobbyMenus.roomPainted(this),arenaMegaOnline.changed())');
    once('function yO(){hO?.stop(),hO=null,QD()}',
      'function yO(){hO?.stop(),hO=null,QD(),arenaMegaOnline.changed()}');
    return 'const arenaMegaOnline=('+createArenaMegaOnline.toString()+')();globalThis.arenaMegaOnline=arenaMegaOnline;\n'+source;
  }
  globalThis.ArenaMegaOnlineAdapter=Object.freeze({patch});
  if(typeof module!=='undefined'&&module.exports)module.exports={patch};
})();
