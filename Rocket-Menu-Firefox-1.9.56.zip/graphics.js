// Use Phaser's native Canvas renderer for this Firefox build. Gameplay and
// networking stay on the same engine; only the rendering backend changes.
(() => {
  'use strict';
  function patch(source) {
    const before='new G.Game({type:G.AUTO,parent:e';
    const parts=source.split(before);
    if(parts.length!==2)throw Error('Unsupported game build. Could not apply compatible graphics.');
    return parts.join('new G.Game({type:G.CANVAS,parent:e');
  }
  const api=Object.freeze({patch});
  globalThis.ArenaGraphicsAdapter=api;
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})();
