(() => {
  'use strict';
  const storageKey='rocket-update-notices-v1';
  let dismissed=[],ready=false,shown='',host=null;
  function sync(){
    const key=document.documentElement?.getAttribute('data-arena-update-warning');
    if(!ready||!key||key===shown||dismissed.includes(key))return;
    shown=key;host?.remove();
    host=document.createElement('div');host.id='rocket-update-notice';
    const root=host.attachShadow({mode:'open'}),style=document.createElement('style');
    style.textContent=`:host{position:fixed;z-index:2147483640;left:50%;bottom:16px;transform:translateX(-50%);width:min(520px,calc(100vw - 24px));pointer-events:none}
      *{box-sizing:border-box}section{position:relative;padding:12px 42px 12px 14px;border:2px solid #eeaa53;background:#252c49;color:#fff;box-shadow:3px 3px #080918;pointer-events:auto;font:12px/1.6 Silkscreen,monospace}
      strong{display:block;color:#ffdb96;font-size:13px}p{margin:4px 0 0}button{position:absolute;right:6px;top:6px;width:28px;height:28px;border:2px solid #8795bf;background:#343d60;color:#fff;font:20px/1 monospace;cursor:pointer}button:focus-visible{outline:2px solid #ffdb96;outline-offset:2px}`;
    const panel=document.createElement('section');panel.setAttribute('role','status');
    const title=document.createElement('strong');title.textContent='GAME UPDATE DETECTED';
    const text=document.createElement('p');text.textContent='Rocket Menu is using its verified compatibility client. Online play may need a further update.';
    const close=document.createElement('button');close.type='button';close.textContent='×';close.setAttribute('aria-label','Dismiss game update warning');
    close.addEventListener('click',()=>{
      dismissed=[...dismissed.filter(value=>value!==key),key].slice(-16);
      void browser.storage.local.set({[storageKey]:dismissed}).catch(()=>{});
      host?.remove();host=null;
    });
    panel.append(title,text,close);root.append(style,panel);document.documentElement.append(host);
  }
  document.addEventListener('arena-site-update',sync);
  document.addEventListener('DOMContentLoaded',sync,{once:true});
  browser.storage.local.get(storageKey).then(saved=>{
    if(Array.isArray(saved[storageKey]))dismissed=saved[storageKey].filter(value=>typeof value==='string').slice(-16);
  }).catch(()=>{}).finally(()=>{ready=true;sync();});
})();
