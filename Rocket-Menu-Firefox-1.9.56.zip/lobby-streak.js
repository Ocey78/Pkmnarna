// Display the local trainer's recorded streak beside their native lobby name.
(() => {
  'use strict';
  function createRocketLobbyStreak() {
    let currentController = null, subscribed = false;
    function paint(controller) {
      currentController = controller;
      const profile = globalThis.ArenaRocketProfile;
      if (!subscribed && profile?.subscribe) {
        profile.subscribe(() => { if (currentController?.active) paint(currentController); });
        subscribed = true;
      }
      const room = document.querySelector('[data-screen="room"]');
      if (!room || !controller.active || !controller.room) return;
      room.querySelectorAll('.rocket-lobby-streak').forEach(node => node.remove());
      const streak = profile?.summary().streaks?.current || 0;
      if (streak < 3) return;
      const seat = controller.room.mode === 'ffa3' ? controller.room.you : 'you';
      if (!['you','A','B','C'].includes(seat)) return;
      const name = room.querySelector('[data-seat="' + seat + '"] .seat-name');
      if (!name) return;
      if (!document.getElementById('rocket-lobby-streak-style')) {
        const style = document.createElement('style');
        style.id = 'rocket-lobby-streak-style';
        style.textContent = '.rocket-lobby-streak{display:block;width:fit-content;max-width:100%;margin-top:7px;padding:3px 6px;border:2px solid #eeaa53;background:#47311f;color:#ffdb96;font:12px/1.4 Silkscreen,monospace;white-space:normal;overflow-wrap:anywhere}';
        document.head.append(style);
      }
      const badge = document.createElement('span');
      badge.className = 'rocket-lobby-streak';
      badge.textContent = streak + ' WIN STREAK';
      badge.title = 'Your recorded consecutive online wins';
      name.append(badge);
    }
    return {paint};
  }
  function patch(source) {
    const anchor = 'arenaTrainingLobby.roomPainted(this)}sendCurrentTeam(){';
    const parts = source.split(anchor);
    if (parts.length !== 2) throw Error('Unsupported lobby streak anchor.');
    return 'const rocketLobbyStreak=(' + createRocketLobbyStreak.toString() + ')();\n' +
      parts.join('arenaTrainingLobby.roomPainted(this);rocketLobbyStreak.paint(this)}sendCurrentTeam(){');
  }
  globalThis.ArenaLobbyStreakAdapter = Object.freeze({patch});
})();
