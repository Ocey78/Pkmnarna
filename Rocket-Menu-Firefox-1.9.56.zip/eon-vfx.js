// Latios/Latias boss presentation: native actors and exact combat segments.
(() => {
  'use strict';
  function createRocketEonVfx() {
    const scenes=new WeakMap();let serial=0;
    const cyan={key:'cyan',dark:0x092d65,edge:0x168bc9,light:0x6be9ff,core:0xf0ffff};
    const crimson={key:'crimson',dark:0x5b153f,edge:0xd52f65,light:0xff89b7,core:0xfff0f5};
    const fusion={key:'fusion',dark:0x42267d,edge:0xa28bea,light:0xdacbff,core:0xffffff};
    const frost={key:'frost',dark:0x306d9c,edge:0x70bfdc,light:0xc7f7ff,core:0xffffff};
    const metal={key:'metal',dark:0x26394d,edge:0x819bb0,light:0xd8edff,core:0xffffff};
    const psychic={key:'psychic',dark:0x33185e,edge:0x9145d1,light:0xee9dff,core:0xfff3ff};
    const rage={key:'rage',dark:0x661e19,edge:0xca462b,light:0xffb856,core:0xffe9ac};
    const clamp=value=>Math.max(0,Math.min(1,value||0));
    const css=color=>'#'+color.toString(16).padStart(6,'0');
    const rgba=(color,a)=>'rgba('+[(color>>16)&255,(color>>8)&255,color&255,a].join(',')+')';
    const identity=value=>{const id=String(value?.speciesId||value?.actorId||value?.owner||value||'');return id==='third'||id.includes('latias')?crimson:cyan;};
    const point=(origin,angle,distance,side=0)=>({x:origin.x+Math.cos(angle)*distance-Math.sin(angle)*side,
      y:origin.y+Math.sin(angle)*distance+Math.cos(angle)*side});

    function texture(record,kind,p,frame=0) {
      const id=kind+':'+p.key+':'+frame;
      if(record.textures.has(id))return record.textures.get(id);
      const [w,h]=kind==='trail'?[256,96]:[256,256];
      const key='rocket-eon-fx-'+record.id+'-'+id.replace(/:/g,'-');
      const canvas=record.scene.textures.createCanvas(key,w,h),ctx=canvas.getContext(),cx=w/2,cy=h/2,r=Math.min(w,h)*.44;
      ctx.clearRect(0,0,w,h);ctx.imageSmoothingEnabled=true;
      if(kind==='glow'){
        const g=ctx.createRadialGradient(cx,cy,0,cx,cy,w*.5);
        g.addColorStop(0,rgba(p.core,.85));g.addColorStop(.25,rgba(p.light,.5));g.addColorStop(.65,rgba(p.edge,.13));g.addColorStop(1,rgba(p.edge,0));
        ctx.fillStyle=g;ctx.fillRect(0,0,w,h);
      }else if(kind==='shell'){
        // An open crescent, so rotating energy never reads as a solid disk.
        ctx.beginPath();ctx.arc(cx,cy,r,-1.25,1.25);ctx.quadraticCurveTo(cx+r*.1,cy,cx+Math.cos(-1.25)*r,cy+Math.sin(-1.25)*r);
        const g=ctx.createLinearGradient(cx-r*.2,0,cx+r,0);g.addColorStop(0,rgba(p.edge,0));
        g.addColorStop(.7,rgba(p.light,.7));g.addColorStop(1,rgba(p.core,.95));ctx.fillStyle=g;ctx.fill();
      }else if(kind==='spark'){
        ctx.beginPath();ctx.moveTo(cx,12);ctx.lineTo(cx+10,cy-10);ctx.lineTo(w-12,cy);ctx.lineTo(cx+10,cy+10);
        ctx.lineTo(cx,h-12);ctx.lineTo(cx-10,cy+10);ctx.lineTo(12,cy);ctx.lineTo(cx-10,cy-10);ctx.closePath();
        ctx.fillStyle=css(p.light);ctx.fill();ctx.fillStyle=css(p.core);ctx.fillRect(cx-5,cy-5,10,10);
      }else if(kind==='trail'){
        const g=ctx.createLinearGradient(0,0,w,0);g.addColorStop(0,rgba(p.edge,0));g.addColorStop(.5,rgba(p.edge,.18));g.addColorStop(1,rgba(p.light,.65));
        ctx.fillStyle=g;ctx.beginPath();ctx.moveTo(0,cy);ctx.bezierCurveTo(w*.5,cy*.8,w*.8,0,w,cy*.35);
        ctx.quadraticCurveTo(w*1.05,cy,w,cy*1.65);ctx.bezierCurveTo(w*.8,h,w*.5,cy*1.2,0,cy);ctx.fill();
        ctx.strokeStyle=rgba(p.core,.35);ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(w*.25,cy);ctx.lineTo(w,cy);ctx.stroke();
      }else if(kind==='ring'){
        const g=ctx.createRadialGradient(cx,cy,r*.55,cx,cy,r*1.08);
        g.addColorStop(0,rgba(p.edge,0));g.addColorStop(.55,rgba(p.edge,.15));g.addColorStop(.75,rgba(p.light,.85));g.addColorStop(.82,rgba(p.core,.95));g.addColorStop(1,rgba(p.edge,0));
        ctx.fillStyle=g;ctx.fillRect(0,0,w,h);
      }else if(kind==='crystal'){
        ctx.beginPath();ctx.moveTo(cx,12);ctx.lineTo(w*.76,h*.42);ctx.lineTo(cx,h-12);ctx.lineTo(w*.24,h*.58);ctx.closePath();
        const g=ctx.createLinearGradient(w*.25,0,w*.75,h);g.addColorStop(0,css(p.edge));g.addColorStop(.45,css(p.core));g.addColorStop(1,css(p.dark));
        ctx.fillStyle=g;ctx.fill();ctx.lineWidth=3;ctx.strokeStyle=css(p.light);ctx.stroke();
        ctx.beginPath();ctx.moveTo(cx,12);ctx.lineTo(cx,h-12);ctx.moveTo(w*.24,h*.58);ctx.lineTo(w*.76,h*.42);ctx.strokeStyle=rgba(p.core,.8);ctx.lineWidth=2;ctx.stroke();
      }else{
        ctx.save();ctx.beginPath();ctx.arc(cx,cy,r,0,Math.PI*2);ctx.clip();
        const g=ctx.createRadialGradient(cx-r*.23,cy-r*.25,0,cx,cy,r);
        g.addColorStop(0,css(p.core));g.addColorStop(.27,css(p.light));g.addColorStop(.7,css(p.edge));g.addColorStop(1,css(p.dark));
        ctx.fillStyle=g;ctx.fillRect(0,0,w,h);
        ctx.strokeStyle=rgba(p.core,.6);ctx.lineWidth=5;ctx.beginPath();ctx.arc(cx,cy,r*.7,Math.PI*1.05,Math.PI*1.55);ctx.stroke();
        ctx.fillStyle=rgba(p.core,.65);ctx.fillRect(cx-r*.3,cy-r*.4,r*.15,r*.15);
        ctx.restore();ctx.strokeStyle=rgba(p.light,.85);ctx.lineWidth=3;ctx.beginPath();ctx.arc(cx,cy,r,0,Math.PI*2);ctx.stroke();
      }
      canvas.refresh();record.textures.set(id,key);return key;
    }
    function image(record,kind,p,x,y,w,h,angle=0,alpha=1,depth=5.8,origin=.5,frame=0,flip=false) {
      const key=texture(record,kind,p,frame),index=record.used++;let sprite=record.images[index];
      if(!sprite){sprite=record.scene.add.image(0,0,key);record.images.push(sprite);}
      if(sprite.texture.key!==key)sprite.setTexture(key);
      sprite.setPosition(x,y).setOrigin(origin,.5).setDisplaySize(Math.max(1,w),Math.max(1,h))
        .setRotation(angle).setAlpha(clamp(alpha)).setDepth(depth).setFlipX(false).setFlipY(flip)
        .setBlendMode('NORMAL').clearTint().setVisible(true);return sprite;
    }
    function nativeImage(record,key,frameName,x,y,w,h,angle,alpha,depth,ox=.5,oy=.5,tint=null) {
      const index=record.used++;let sprite=record.images[index];
      if(!sprite){sprite=record.scene.add.image(0,0,key,frameName);record.images.push(sprite);}
      sprite.setTexture(key,frameName).setPosition(x,y).setOrigin(ox,oy).setDisplaySize(Math.max(1,w),Math.max(1,h))
        .setRotation(angle).setAlpha(clamp(alpha)).setDepth(depth).setFlipX(false).setFlipY(false)
        .setBlendMode('NORMAL').clearTint().setVisible(true);
      if(tint!==null)sprite.setTint(tint);return sprite;
    }
    function line(g,points,color,width,alpha=1) {
      if(points.length<2)return;g.lineStyle(width,color,alpha);g.beginPath();g.moveTo(points[0].x,points[0].y);
      for(let i=1;i<points.length;i++)g.lineTo(points[i].x,points[i].y);g.strokePath();
    }
    function circle(g,center,r,color,alpha=.75,width=2) {g.lineStyle(width,color,alpha);g.strokeCircle(center.x,center.y,r);}
    function plus(g,x,y,size,color,alpha) {g.fillStyle(color,alpha);g.fillRect(x-size,y-2,size*2,4);g.fillRect(x-2,y-size,4,size*2);}
    function ribbon(g,from,angle,length,width,color,alpha,phase=0,bend=0,decay=0) {
      if(length<1||width<=0||alpha<=0)return;
      const steps=Math.min(56,Math.max(12,Math.ceil(length/20))),cap=Math.min(length*.3,Math.max(width*.65,12));
      const dx=Math.cos(angle),dy=Math.sin(angle);g.fillStyle(color,alpha);g.beginPath();
      // Sample both edges of the same continuously moving, rounded ribbon.
      // No mesh/cache allocation per frame, and neither edge passes its segment endpoints.
      for(let side=1;side>=-1;side-=2)for(let i=0;i<=steps;i++){
        const f=side===1?i/steps:1-i/steps,x=f*length;
        const end=Math.min(1,x/cap,(length-x)/cap),round=Math.sqrt(Math.max(0,1-(1-end)*(1-end)));
        const wave=Math.sin(x*.032-phase),center=wave*bend*Math.sin(Math.PI*f)*Math.exp(-decay*f);
        const y=center+side*width*.5*round*(.93+.07*Math.sin(x*.021-phase));
        const px=from.x+dx*x-dy*y,py=from.y+dy*x+dx*y;
        if(side===1&&i===0)g.moveTo(px,py);else g.lineTo(px,py);
      }
      g.closePath();g.fillPath();
    }
    function gathering(record,at,angle,radius,p,progress,time,reduced,merged=false) {
      const size=radius*(.2+.35*progress),turn=reduced?0:time/280;
      image(record,'glow',p,at.x,at.y,size*3,size*3,0,reduced?.12:.26,5.6);
      image(record,'shell',p,at.x,at.y,size*2,size*1.5,angle+turn,reduced?.4:.8,5.75);
      const count=reduced?2:5;
      for(let i=0;i<count;i++){
        const f=(progress*1.65+i/count)%1,a=angle+i*Math.PI*2/count+turn*.35;
        const distance=radius*(1.15-f*.95),start=point(at,a,distance+radius*.16),end=point(at,a,distance);
        const color=merged?(i%2?crimson:cyan):p;
        ribbon(record.front,start,a+Math.PI,radius*.18,Math.max(2,radius*.055),color.light,Math.sin(f*Math.PI)*.7);
        image(record,'spark',color,end.x,end.y,5,5,a,Math.sin(f*Math.PI)*.65,5.8);
      }
    }
    function corridor(record,from,to,width,p,progress) {
      const angle=Math.atan2(to.y-from.y,to.x-from.x),length=Math.hypot(to.x-from.x,to.y-from.y),half=width/2;
      const points=[point(from,angle,0,-half),point(from,angle,length,-half),point(from,angle,length,half),point(from,angle,0,half)];
      const g=record.ground;g.fillStyle(p.edge,.08);g.lineStyle(2,p.light,.65);g.beginPath();g.moveTo(points[0].x,points[0].y);
      for(let i=1;i<4;i++)g.lineTo(points[i].x,points[i].y);g.closePath();g.fillPath();g.strokePath();
      for(let distance=60;distance<length;distance+=150){const at=point(from,angle,distance);line(g,[point(at,angle,-6,-5),at,point(at,angle,-6,5)],p.light,2,.2+progress*.2);}
    }
    function restore(record) {
      if(!record)return;
      for(const base of record.owned){if(!base.sprite?.scene)continue;
        base.sprite.setPosition(base.x,base.y).setScale(base.sx,base.sy).setRotation(base.rotation)
          .setOrigin(base.ox,base.oy).setAlpha(base.alpha).setDepth(base.depth);
      }
      record.owned.length=0;
    }
    function beforeDraw(scene) {restore(scenes.get(scene));}
    function frame(actor,pose,angle,progress,loop=false) {
      if(actor.still)return;if(!actor.clips?.[pose])pose='idle';const animation=actor.clips?.[pose];if(!animation)return;
      const clip=animation.clip,row=clip.rows>1?Math.min(clip.rows-1,mp(angle)):0,cycle=loop?((progress%1)+1)%1:clamp(progress);
      const column=Math.min(clip.frames-1,Math.floor(cycle*clip.frames));actor.sprite.setTexture(animation.key,row*clip.frames+column);
      const anchor=XO(actor.speciesId,pose,row,column,clip.anchor);if(anchor)actor.sprite.setOrigin(anchor[0]/clip.frameWidth,anchor[1]/clip.frameHeight);
    }

    function hull(points) {
      const sorted=points.slice().sort((a,b)=>a.x-b.x||a.y-b.y),turn=(a,b,c)=>(b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x);
      if(sorted.length<3)return sorted;const lower=[],upper=[];
      for(const p of sorted){while(lower.length>1&&turn(lower[lower.length-2],lower[lower.length-1],p)<=0)lower.pop();lower.push(p);}
      for(let i=sorted.length-1;i>=0;i--){const p=sorted[i];while(upper.length>1&&turn(upper[upper.length-2],upper[upper.length-1],p)<=0)upper.pop();upper.push(p);}
      lower.pop();upper.pop();return lower.concat(upper);
    }
    function beamWarning(record,beam,p) {
      const samples=beam.sweepSamples?.length?beam.sweepSamples:[beam,...(beam.sweepEnd?[beam.sweepEnd]:[])];
      if(samples.length<2){corridor(record,beam.from,beam.to,beam.width,p,.5);return;}
      const points=[];
      for(const sample of samples){
        const angle=Math.atan2(sample.to.y-sample.from.y,sample.to.x-sample.from.x),half=beam.width/2;
        for(const end of [sample.from,sample.to])for(const side of [-1,1])points.push(point(end,angle,0,side*half));
      }
      const shape=hull(points),g=record.ground;
      if(shape.length>2){g.fillStyle(p.edge,.08);g.lineStyle(2,p.light,.65);g.beginPath();g.moveTo(shape[0].x,shape[0].y);
        for(let i=1;i<shape.length;i++)g.lineTo(shape[i].x,shape[i].y);g.closePath();g.fillPath();g.strokePath();}
      line(g,[beam.from,beam.to],p.light,1,.25);
    }
    function animate(record,state,boss,beams,time,reduced) {
      const fighter=state.fighters.find(f=>f.id===boss.actorId),actor=record.scene.actors?.get(boss.actorId),sprite=actor?.sprite;
      if(!fighter||fighter.hp<=0||!sprite?.scene||!sprite.visible||actor.speciesId!==fighter.speciesId||record.scene.megaFx?.holdsOld(boss.actorId)){
        record.motion.delete(boss.actorId);return;
      }
      const a=boss.attack,p=clamp(a.progress),unit=fighter.radius/28,strength=reduced?.4:1;
      // Leave native idle/movement frames alone between attacks.
      if(a.phase==='idle'){record.motion.delete(boss.actorId);return;}
      const beam=beams.find(item=>item.actorId===boss.actorId&&!item.merged);
      let angle=beam?Math.atan2(beam.to.y-beam.from.y,beam.to.x-beam.from.x):a.facing;
      const base={sprite,x:sprite.x,y:sprite.y,sx:sprite.scaleX,sy:sprite.scaleY,rotation:sprite.rotation,
        ox:sprite.originX,oy:sprite.originY,alpha:sprite.alpha,depth:sprite.depth};record.owned.push(base);
      if(a.kind==='dive'&&['rise','hover','mark','fall'].includes(a.phase)){
        flight(record,fighter,actor,a,base,time,reduced);record.motion.delete(boss.actorId);return;
      }
      if(rocketEonMouths.ranged(a)){
        // Use the same frame, pivot, world rounding and scale as the simulation
        // socket. Cosmetic recoil/rotation must not pull a mouth off its beam.
        const socket=rocketEonMouths.frame(fighter.speciesId,a,a.facing),animation=actor.clips?.shoot;
        if(socket&&!actor.still&&animation){
          sprite.setTexture(animation.key,socket.row*animation.clip.frames+socket.column)
            .setOrigin(socket.anchor[0]/socket.width,socket.anchor[1]/socket.height)
            .setPosition(Math.round(fighter.x),Math.round(fighter.y))
            .setScale(rocketEonMouths.scale(fighter,socket.body)).setRotation(0).setFlipX(false).setFlipY(false);
          record.motion.delete(boss.actorId);return;
        }
      }
      let sx=1,sy=1,roll=0,lift=0,forward=0,pose='shoot',poseAt=.52;
      if(a.phase==='mega'){
        const wave=Math.sin(Math.PI*p);sx=sy=1+.025*wave;lift=2*unit*wave;poseAt=p;
      }else if(a.phase==='windup'){
        poseAt=p*.52;
        if(a.kind==='plasma')forward=-2*unit*p;
        else if(a.kind==='charge'||a.kind==='cross')roll=-.025*Math.sin(p*Math.PI);
        else if(a.kind==='field'||a.kind==='heal')lift=unit*Math.sin(p*Math.PI);
      }else if(a.phase==='active'){
        // Sustained attacks hold their native firing pose at the real beam origin.
        poseAt=.52+p*.1;
        if(a.kind==='plasma'){
          const kick=Math.sin(Math.PI*clamp(p*2))*Math.exp(-p*2);forward=-6*unit*kick;
          poseAt=.52+p*.26;
        }else if(a.kind==='charge'||a.kind==='cross'){
          poseAt=.52+p*.18;roll=.025*Math.sin(p*Math.PI);
        }else if(a.kind==='heal'||a.kind==='field'){
          lift=unit*Math.sin(p*Math.PI);
        }
      }else if(a.phase==='recover'){
        const start=a.kind==='plasma'?.78:['charge','cross','dive'].includes(a.kind)?.7:.62;poseAt=start+p*(1-start);
      }
      let motion=record.motion.get(boss.actorId);
      const target={sx:1+(sx-1)*strength,sy:1+(sy-1)*strength,x:Math.cos(angle)*forward*strength,
        y:Math.sin(angle)*forward*strength-lift*strength,roll:roll*strength};
      if(!motion||motion.entry!==fighter.entry||motion.species!==fighter.speciesId||time<motion.time||time-motion.time>250){
        motion={...target,angle,time,entry:fighter.entry,species:fighter.speciesId};record.motion.set(boss.actorId,motion);
      }else{
        const mix=1-Math.exp(-Math.max(0,time-motion.time)/Math.min(38,Math.max(12,a.durationMs*.12)));
        for(const key of ['sx','sy','x','y','roll'])motion[key]+=(target[key]-motion[key])*mix;
        motion.angle+=Math.atan2(Math.sin(angle-motion.angle),Math.cos(angle-motion.angle))*mix;motion.time=time;
      }
      angle=motion.angle;frame(actor,pose,angle,poseAt);
      const direction=Math.PI/2-mp(angle)*Math.PI/4,residual=actor.still?0:Math.max(-.08,Math.min(.08,Math.atan2(Math.sin(angle-direction),Math.cos(angle-direction))));
      sprite.setPosition(base.x+motion.x,base.y+motion.y).setScale(base.sx*motion.sx,base.sy*motion.sy)
        .setRotation(base.rotation+residual+motion.roll);
      if(['charge','cross'].includes(a.kind)&&['windup','active'].includes(a.phase)){
        // The metal sheen follows the actual wing pixels, not oversized replacement polygons.
        let sheen=record.sheens.get(boss.actorId);
        if(!sheen){sheen=record.scene.add.image(0,0,sprite.texture.key);record.sheens.set(boss.actorId,sheen);}
        sheen.setTexture(sprite.texture.key,sprite.frame.name).setOrigin(sprite.originX,sprite.originY)
          .setPosition(sprite.x,sprite.y).setScale(sprite.scaleX,sprite.scaleY).setRotation(sprite.rotation)
          .setFlipX(sprite.flipX).setFlipY(sprite.flipY).setTint(a.kind==='cross'?identity(boss).light:metal.light).setBlendMode('ADD')
          .setDepth(sprite.depth+.01).setAlpha(sprite.alpha*(reduced?.08:.2)*(a.phase==='windup'?p:1)).setVisible(true);
        if(a.phase==='active'){
          const body={x:fighter.x,y:fighter.y-fighter.radius*.5},r=fighter.radius;
          if(a.kind==='cross'){
            const color=identity(boss),distance=Math.hypot(fighter.x-a.from.x,fighter.y-a.from.y);
            // Echo the real native frame along the traversed path only.
            for(let i=reduced?1:3;i>0;i--){
              const back=Math.min(distance,i*r*.9),at=point(sprite,angle,-back);
              if(back<2)continue;
              nativeImage(record,sprite.texture.key,sprite.frame.name,at.x,at.y,sprite.displayWidth,sprite.displayHeight,
                sprite.rotation,(reduced?.07:.2)*(1-i/4),sprite.depth-.02*i,sprite.originX,sprite.originY,color.light);
            }
            ribbon(record.front,body,angle+Math.PI,Math.min(distance,r*5),r*.6,color.edge,reduced?.12:.3,time/80,r*.12);
          }
          for(const side of [-1,1]){
            const tip=point(body,angle,-r*.25,side*r*.8);
            const color=a.kind==='cross'?identity(boss):metal;
            ribbon(record.front,tip,angle+Math.PI,r*(a.kind==='cross'?4:2.5+.35*Math.sin(p*Math.PI)),r*.16,color.light,reduced?.2:.48,time/110,r*.04);
            image(record,'spark',metal,tip.x,tip.y,8,4,angle,reduced?.25:.6,5.8);
          }
        }
      }
    }
    function landingWarning(record,at,radius,p,progress,reduced) {
      const g=record.ground;
      g.fillStyle(p.edge,reduced?.025:.05);g.fillCircle(at.x,at.y,radius);
      circle(g,at,radius,p.light,.8,2);
      circle(g,at,radius*(1-clamp(progress)),p.light,reduced?.3:.5,2);
      // Four fixed inward chevrons make the locked landing readable without flashing.
      for(let i=0;i<4;i++){
        const angle=i*Math.PI/2,tip=point(at,angle,radius+3),outer=radius+13;
        line(g,[point(at,angle,outer,-6),tip,point(at,angle,outer,6)],p.core,2,.75);
      }
      plus(g,at.x,at.y,5,p.light,.75);
    }
    function flight(record,fighter,actor,a,base,time,reduced) {
      const sprite=actor.sprite,p=identity(fighter),progress=clamp(a.progress);
      const height=Math.max(0,Number(a.flyHeight)||0),altitude=clamp(height/240),lift=height*2.8;
      const facing=a.phase==='fall'?Math.PI/2:a.phase==='rise'?-Math.PI/2:a.facing;
      if(a.phase==='fall')frame(actor,'shoot',facing,.42+progress*.35);
      else frame(actor,'idle',facing,time/720,true);
      const size=1-altitude*.28,fade=1-clamp((altitude-.76)/.24)*.94;
      sprite.setPosition(Math.round(fighter.x),Math.round(fighter.y)-lift)
        .setScale(base.sx*size,base.sy*size).setRotation(base.rotation)
        .setDepth(Math.max(6.15,base.depth)).setAlpha(base.alpha*fade);
      const shadowRadius=fighter.radius*(1-.65*altitude),g=record.ground;
      if(height>0){g.fillStyle(0x0b1124,.12+.17*(1-altitude));g.fillEllipse(fighter.x,fighter.y,shadowRadius*2,shadowRadius*.7);}
      if(a.phase==='mark'||a.phase==='fall'){
        const warning=a.phase==='mark'?progress*.65:.65+progress*.35;
        landingWarning(record,a.to,a.radius,p,warning,reduced);
      }
      if(a.phase==='rise'||a.phase==='fall'){
        const falling=a.phase==='fall',direction=falling?-Math.PI/2:Math.PI/2;
        const body={x:sprite.x,y:sprite.y-fighter.radius*size*.5};
        const tail=(falling?115:75)*(reduced?.7:1),alpha=fade*(reduced?.2:.6);
        for(const side of [-1,1]){
          const wing={x:body.x+side*fighter.radius*size*.8,y:body.y};
          ribbon(record.front,wing,direction,tail,fighter.radius*.18,p.light,alpha,time/100,fighter.radius*.045);
        }
        if(falling){
          ribbon(record.front,body,-Math.PI/2,tail*1.45,fighter.radius*size*.55,p.edge,alpha*.35,time/85,3);
          image(record,'shell',p,body.x,body.y+fighter.radius*.2,fighter.radius*size*1.5,fighter.radius*.6,
            Math.PI/2,fade*(reduced?.25:.55),6.18);
        }
      }
    }
    function beam(record,segment,time,reduced) {
      const p=segment.merged?fusion:segment.kind==='ice'?frost:identity(segment),from=segment.from,to=segment.to;
      const angle=Math.atan2(to.y-from.y,to.x-from.x),length=Math.hypot(to.x-from.x,to.y-from.y),width=segment.width;
      if(!(length>0&&width>0))return;
      const progress=clamp(segment.progress),duration=Math.max(1,segment.durationMs||1000);
      const elapsed=Number.isFinite(segment.elapsedMs)?segment.elapsedMs:progress*duration,phase=reduced?0:time/105;
      if(segment.phase==='windup'){
        beamWarning(record,segment,p);
        gathering(record,from,angle,width*.55,p,progress,time,reduced,segment.merged);
        return;
      }
      if(segment.phase!=='active')return;
      const g=record.front,ignition=clamp(elapsed/85),release=clamp((duration-elapsed)/95),sweep=Math.min(ignition,release);
      const bodyLength=length*(.12+.88*(sweep*sweep*(3-2*sweep))),combined=segment.merged;
      // The low-energy envelope always shows the entire dangerous segment, even
      // while the much brighter rounded front grows/retracts inside it.
      ribbon(g,from,angle,length,width,p.edge,reduced?.12:.19,phase*.5);
      ribbon(g,from,angle,length,width*.63,p.light,reduced?.15:.28,phase*.7,width*.025);
      ribbon(g,from,angle,bodyLength,width*(combined?.7:.52),p.light,reduced?.36:.65,phase,width*.035);
      if(combined){
        // The two source colors braid into one pale core; no extra downstream lasers.
        for(const [color,offset] of [[cyan,0],[crimson,Math.PI]])
          ribbon(g,from,angle,bodyLength,width*.1,color.light,reduced?.35:.75,phase+offset,width*.27,2.4);
      }else if(segment.kind!=='ice'){
        for(const offset of [0,Math.PI])ribbon(g,from,angle,bodyLength,width*.055,p.core,reduced?.3:.6,phase+offset,width*.19);
      }
      ribbon(g,from,angle,bodyLength,width*(combined?.26:.15),p.core,reduced?.65:.95,phase*.8,width*.018);
      const tipWidth=Math.min(width*.28,bodyLength*.4),tip=point(from,angle,bodyLength-tipWidth*.5);
      image(record,'shell',p,tip.x,tip.y,tipWidth,width*(combined?.7:.5),angle,reduced?.35:.75,6.08);
      image(record,'glow',p,from.x,from.y,width*.9,width*.9,0,reduced?.1:combined?.32:.2,5.65);
      if(combined){
        const burst=1-clamp(elapsed/240),turn=reduced?0:time/240;
        for(const [color,offset] of [[cyan,0],[crimson,Math.PI]])
          image(record,'shell',color,from.x,from.y,width*(.5+burst*.25),width*.38,turn+offset,reduced?.3:.65,6.08);
        image(record,'spark',fusion,from.x,from.y,width*(.35+burst*.5),width*(.25+burst*.45),angle,burst*(reduced?.25:.65),6.1);
      }
      if(segment.kind==='ice'){
        const count=Math.min(14,Math.max(3,Math.floor(length/65))),size=Math.min(12,width*.2,length*.15);
        for(let i=0;i<count;i++){
          const f=reduced?(i+.5)/count:((i/count+time/950)%1),sizeNow=size*(.7+.3*Math.sin(f*Math.PI));
          const distance=size+(length-size*2)*f,at=point(from,angle,distance,Math.sin(f*9+phase*.3+i*Math.PI)*width*.22);
          image(record,'trail',frost,at.x,at.y,Math.min(sizeNow*3,distance),sizeNow*.55,angle,reduced?.12:.3,5.65,1);
          image(record,'crystal',frost,at.x,at.y,sizeNow,sizeNow*1.8,angle+Math.PI/2+Math.sin(f*7+i)*.18,Math.sin(f*Math.PI)*.85,6.1);
        }
      }
    }
    function projectile(record,shot,time,reduced) {
      if(shot.kind==='psy-bomb'){psyBomb(record,shot,time,reduced);return;}
      if(shot.kind==='hurricane'){hurricane(record,shot,reduced);return;}
      const p=identity(shot),angle=Math.atan2(shot.vy,shot.vx),r=shot.radius,phase=reduced?0:shot.ageMs/115;
      const tail=point(shot,angle,-r*.6),length=r*(4.4+.45*Math.sin(phase));
      ribbon(record.front,tail,angle+Math.PI,length,r*.75,p.edge,reduced?.22:.45,phase,r*.2);
      for(const offset of [0,Math.PI])ribbon(record.front,tail,angle+Math.PI,length*.85,r*.13,p.light,
        reduced?.35:.75,phase+offset,r*.25);
      image(record,'glow',p,shot.x,shot.y,r*2.4,r*2.4,0,reduced?.1:.22,5.7);
      image(record,'orb',p,shot.x,shot.y,r*1.45,r*1.45,angle,.95,5.9);
      for(const offset of [0,Math.PI])image(record,'shell',p,shot.x,shot.y,r*2/.88,r*1.95/.88,
        angle+phase*.7+offset,reduced?.5:.85,6.05);
    }
    function hurricane(record,shot,reduced,windup=false) {
      const pixels=record.nativePixels;pixels.length=0;
      const origin=windup?shot.from:shot,angle=windup?shot.facing:Math.atan2(shot.vy,shot.vx);
      const age=Number.isFinite(shot.elapsedMs)?shot.elapsedMs:shot.ageMs||0;
      const output=new FW(pixels,'hurricane',windup?'windup':'active',{x:origin.x,y:origin.y},angle);
      // Use the exact pixel animation used by the equipped Hurricane ultimate.
      if(windup)aG(output,age,shot.radius,reduced,clamp(shot.progress));
      else cG(output,age,shot.radius,reduced);
      for(const pixel of pixels)record.front.fillStyle(pixel.color,1).fillRect(pixel.x,pixel.y,pixel.width,pixel.height);
      pixels.length=0;
    }
    function psyBomb(record,shot,time,reduced) {
      const p=psychic,r=shot.radius,orbit=shot.phase==='orbit',angle=Math.atan2(shot.vy||0,shot.vx||0);
      const turn=reduced?0:time/240+(shot.orbitAngle||0),armed=orbit?clamp(shot.ageMs/Math.max(1,shot.launchMs||1)):1;
      if(orbit){
        // Orbiting seeds are hollow and soft; the opaque comet appears only once armed.
        image(record,'glow',p,shot.x,shot.y,r*2,r*2,0,reduced?.07:.14,5.7);
        image(record,'orb',p,shot.x,shot.y,r*(.65+armed*.22),r*(.65+armed*.22),turn,.48,5.9);
        image(record,'shell',p,shot.x,shot.y,r*1.7,r*1.25,turn,reduced?.35:.6,6.08);
        image(record,'shell',crimson,shot.x,shot.y,r*1.35,r*1.7,turn+Math.PI,reduced?.2:.45,6.08);
        return;
      }
      record.projectileSeen.add(shot.id);
      let trail=record.projectileTrails.get(shot.id);
      if(!trail){trail=[];record.projectileTrails.set(shot.id,trail);}
      const previous=trail[trail.length-1];
      if(!previous||time<previous.time){trail.length=0;trail.push({x:shot.x,y:shot.y,time});}
      else if(time-previous.time>=18&&Math.hypot(shot.x-previous.x,shot.y-previous.y)>1)trail.push({x:shot.x,y:shot.y,time});
      while(trail.length>14||(trail.length>1&&time-trail[0].time>220))trail.shift();
      // Follow the actual curved flight history instead of pointing a rectangle behind it.
      for(let i=1;i<trail.length;i++){
        const fade=i/trail.length,points=[trail[i-1],trail[i]];
        line(record.front,points,p.edge,r*.7*fade,fade*(reduced?.18:.35));
        line(record.front,points,p.light,Math.max(1,r*.23*fade),fade*(reduced?.4:.75));
      }
      const tail=point(shot,angle,-r*.35);
      ribbon(record.front,tail,angle+Math.PI,r*3.2,r*.45,p.light,reduced?.28:.6,turn,r*.12);
      image(record,'glow',p,shot.x,shot.y,r*2.8,r*2.8,0,reduced?.08:.23,5.7);
      image(record,'orb',p,shot.x,shot.y,r*1.6,r*1.6,angle,.98,6.08);
      for(const offset of [0,Math.PI])image(record,'shell',p,shot.x,shot.y,r*2.2,r*1.6,turn+offset,reduced?.4:.8,6.1);
      image(record,'spark',p,shot.x,shot.y,r*.8,r*.5,angle,reduced?.35:.65,6.12);
    }
    function mapField(record,center,bounds,p,age,life,reduced,windup=false) {
      if(!bounds)return;
      const {left,top,right,bottom}=bounds,w=right-left,h=bottom-top;
      if(!(w>0&&h>0))return;
      const progress=clamp(age/Math.max(1,life)),fade=windup?1:clamp((life-age)/350),g=record.ground;
      g.lineStyle(2,p.light,(windup?.18+progress*.25:.35)*fade);g.strokeRect(left+2,top+2,w-4,h-4);
      if(windup)return;
      g.fillStyle(p.edge,(reduced?.012:.022)*fade);g.fillRect(left,top,w,h);
      if(age<700){
        const extent=Math.hypot(Math.max(Math.abs(center.x-left),Math.abs(center.x-right)),Math.max(Math.abs(center.y-top),Math.abs(center.y-bottom)));
        const radius=extent*clamp(age/700),alpha=(1-age/700)*(reduced?.12:.4);let joined=false;
        g.lineStyle(2,p.light,alpha);g.beginPath();
        // Clip the activation wave to the playable rectangle without a giant disk.
        for(let i=0;i<=96;i++){
          const angle=i*Math.PI/48,x=center.x+Math.cos(angle)*radius,y=center.y+Math.sin(angle)*radius;
          if(x>=left&&x<=right&&y>=top&&y<=bottom){if(joined)g.lineTo(x,y);else g.moveTo(x,y);joined=true;}else joined=false;
        }
        g.strokePath();
      }
      const seconds=Math.ceil((1-progress)*5),x=Math.max(left+18,Math.min(right-18,center.x)),y=Math.max(top+12,Math.min(bottom-12,center.y+28));
      for(let i=0;i<5;i++){g.fillStyle(p.light,(i<seconds?.65:.12)*fade);g.fillRect(x-14+i*6,y,4,3);}
      if(!reduced)for(let i=0;i<6;i++){
        const f=(age/1800+i/6)%1,mx=left+w*(.1+(i*.618)%0.8),my=top+h*(.15+(i*.381)%0.7)-f*8;
        image(record,'spark',p,mx,my,5,5,0,Math.sin(f*Math.PI)*.25*fade,3.2);
      }
    }
    function field(record,zone,time,reduced) {
      const p=identity(zone),center={x:zone.x,y:zone.y},progress=clamp(zone.ageMs/Math.max(1,zone.lifeMs));
      if(zone.mapWide){mapField(record,center,zone.bounds,p,zone.ageMs,zone.lifeMs,reduced);return;}
      image(record,'glow',p,zone.x,zone.y,zone.radius*2,zone.radius*2,0,reduced?.04:.07,3.1);
      circle(record.ground,center,zone.radius,p.light,.45,2);
      const remaining=1-progress,count=Math.ceil(remaining*12);
      for(let i=0;i<12;i++){
        const angle=i*Math.PI/6-Math.PI/2,at=point(center,angle,zone.radius);
        line(record.ground,[point(at,angle,-3),point(at,angle,3)],p.light,2,i<count?.65:.12);
      }
    }
    function heal(record,boss,time,reduced) {
      const a=boss.attack,p=identity(boss),progress=clamp(a.progress);
      if(!['windup','active'].includes(a.phase))return;
      const angle=Math.atan2(a.to.y-a.from.y,a.to.x-a.from.x),length=Math.hypot(a.to.x-a.from.x,a.to.y-a.from.y);
      line(record.front,[a.from,a.to],p.light,2,a.phase==='active'?.32:.15);
      if(a.phase==='active'){
        for(let i=0;i<2;i++){
          const f=reduced?(i+.5)/2:((progress+i/2)%1),at=point(a.from,angle,length*f);
          plus(record.front,at.x,at.y,3,p.light,Math.sin(f*Math.PI)*.55);
        }
        const radius=Math.max(24,a.radius||45);
        image(record,'glow',p,a.to.x,a.to.y,radius*1.8,radius*1.8,0,reduced?.06:.13,5.6);
      }
    }
    function enrageAura(record,fighter,boss,time,reduced) {
      const actor=record.scene.actors?.get(boss.actorId),sprite=actor?.sprite;
      if(!sprite?.scene||!sprite.visible||fighter.hp<=0||actor.speciesId!==fighter.speciesId||record.scene.megaFx?.holdsOld(boss.actorId))return;
      // Read the final native pose (including Dive altitude); never tint or move it.
      const r=fighter.radius,center={x:sprite.x,y:sprite.y-r*.45},alpha=sprite.alpha;
      image(record,'glow',rage,center.x,center.y,r*3.1,r*3.7,0,alpha*(reduced?.035:.09),sprite.depth-.04);
      for(const side of [-1,1]){
        const at={x:center.x+side*r*.65,y:center.y+r*.35};
        if(reduced){
          line(record.ground,[{x:fighter.x+side*r*.85,y:fighter.y+3},{x:fighter.x+side*r*1.08,y:fighter.y-3}],rage.light,2,.3*alpha);
        }else{
          const phase=time/480+side;
          ribbon(record.front,at,-Math.PI/2,r*1.5,r*.075,rage.light,.32*alpha,phase,r*.12);
          const f=((time/1500+(side+1)*.25)%1),mote={x:at.x+Math.sin(f*3+side)*r*.12,y:at.y-f*r*1.65};
          image(record,'spark',rage,mote.x,mote.y,3,5,0,Math.sin(f*Math.PI)*.45*alpha,Math.max(6.1,sprite.depth+.01));
        }
      }
    }
    function impact(record,event,reduced) {
      const p=event.kind==='enrage'?rage:event.kind==='charge'?metal:event.kind==='mega'?fusion:event.kind==='psy-bomb'?psychic:identity(event),progress=clamp(event.ageMs/Math.max(1,event.lifeMs));
      const radius=event.radius*(.4+progress*.6),alpha=1-progress;
      if(event.kind==='enrage'){
        const fade=alpha*clamp(progress*8),spread=event.radius*(.35+.65*progress);
        image(record,'ring',rage,event.x,event.y,spread*2,spread*1.4,0,fade*(reduced?.18:.55),5.75);
        if(!reduced){
          image(record,'glow',rage,event.x,event.y,radius*2.1,radius*1.65,0,fade*.16,5.6);
          for(let i=0;i<6;i++){
            const angle=i*Math.PI/3+.2,at=point(event,angle,spread*.8);
            image(record,'spark',rage,at.x,at.y-progress*16,4,8,angle,fade*.65,6.1);
          }
        }
        return;
      }
      if(event.kind==='dive'||event.kind==='cross'){
        const dive=event.kind==='dive',spread=event.radius*(.3+.7*Math.sqrt(progress));
        image(record,'ring',p,event.x,event.y,spread*2,spread*(dive?1.1:1.6),0,alpha*(reduced?.35:.7),5.75);
        image(record,'glow',p,event.x,event.y,radius*1.8,radius*1.2,0,alpha*(reduced?.06:.2),5.6);
        for(let i=0;i<(reduced?4:8);i++){
          const angle=i*Math.PI/(reduced?2:4)+.22,at=point(event,angle,spread*.55);
          ribbon(record.front,at,angle,event.radius*(.12+.32*progress),Math.max(2,event.radius*.035),
            p.light,alpha*(reduced?.3:.7),progress*4,event.radius*.025);
          if(dive){
            const stone=point(event,angle,spread*.78);stone.y-=Math.sin(progress*Math.PI)*event.radius*.22;
            record.front.fillStyle(i%2?0x728293:0xabb5bc,alpha*.7);
            record.front.fillRect(stone.x-2,stone.y-2,3+3*alpha,2+3*alpha);
          }
        }
        return;
      }
      if(event.kind==='plasma'||event.kind==='psy-bomb'){
        const spread=event.radius*(.25+Math.sqrt(progress)*.9);
        image(record,'spark',p,event.x,event.y,radius*1.8,radius*1.2,.35,alpha*(reduced?.3:.8),5.85);
        for(let i=0;i<6;i++){
          const angle=i*Math.PI/3+.3,at=point(event,angle,spread*.6);
          ribbon(record.front,at,angle,event.radius*(.22+progress*.3),event.radius*.09,p.light,alpha*(reduced?.3:.8),progress*4,event.radius*.04);
          if(i%2===0)image(record,'shell',p,at.x,at.y,radius*.65,radius*.4,angle+progress,alpha*.65,5.8);
        }
        return;
      }
      image(record,'ring',p,event.x,event.y,radius*2,radius*2,0,alpha*(reduced?.35:.55),5.75);
      image(record,'glow',p,event.x,event.y,radius*2,radius*2,0,alpha*(reduced?.05:.14),5.6);
      if(event.kind==='heal')for(let i=0;i<2;i++){
        const at=point(event,i*Math.PI,radius*.45);plus(record.front,at.x,at.y-progress*8,4,p.light,alpha*.55);
      }
    }
    function paint(record,state,bossState,time,reduced) {
      const beams=bossState.beams||[];
      for(const boss of bossState.bosses||[]){
        const fighter=state.fighters.find(f=>f.id===boss.actorId);if(!fighter||fighter.hp<=0)continue;
        animate(record,state,boss,beams,time,reduced);
        if(boss.enraged||boss.attack.enraged)enrageAura(record,fighter,boss,time,reduced);
        const a=boss.attack,p=identity(boss),progress=clamp(a.progress);
        if(a.phase==='mega'){
          const center={x:fighter.x,y:fighter.y-fighter.radius},radius=fighter.radius*(1.2+progress);
          image(record,'ring',p,center.x,center.y,radius*2,radius*2,0,Math.sin(progress*Math.PI)*(reduced?.3:.55),5.5);
          image(record,'glow',p,center.x,center.y,radius*2,radius*2,0,reduced?.06:.16,5.55);
        }
        if(a.kind==='charge'&&a.phase==='windup')corridor(record,a.from,a.to,a.width,metal,progress);
        if(a.kind==='cross'&&a.phase==='windup'){
          corridor(record,a.from,a.to,a.width,p,progress);
          gathering(record,{x:fighter.x,y:fighter.y-fighter.radius*.4},a.facing,fighter.radius*.8,p,progress,time,reduced);
        }
        if(a.kind==='plasma'&&a.phase==='windup'){
          const radius=Math.max(4,a.radius*(.2+progress*.8));
          gathering(record,a.from,a.facing,Math.max(radius,a.radius*.7),p,progress,time,reduced);
          image(record,'orb',p,a.from.x,a.from.y,radius*1.35,radius*1.35,0,.9,5.9);
        }
        if(a.kind==='hurricane'&&a.phase==='windup')hurricane(record,a,reduced,true);
        if(a.kind==='field'&&a.phase==='windup'){
          if(a.mapWide){
            mapField(record,a.from,a.bounds,p,progress*a.durationMs,a.durationMs,reduced,true);
            gathering(record,a.from,a.facing,32,p,progress,time,reduced);
          }else{
            circle(record.ground,a.from,Math.max(1,a.radius),p.light,.5,2);
            image(record,'ring',p,a.from.x,a.from.y,a.radius*2*progress,a.radius*2*progress,0,.3,3.2);
          }
        }
        if(a.kind==='heal')heal(record,boss,time,reduced);
        if(a.kind==='orbit'&&a.phase==='windup'){
          const at={x:fighter.x,y:fighter.y-fighter.radius*.5};
          gathering(record,at,a.facing,fighter.radius*1.7,psychic,progress,time,reduced);
        }
      }
      for(const zone of bossState.zones||[])field(record,zone,time,reduced);
      for(const segment of beams)beam(record,segment,time,reduced);
      const orbitOwners=new Set();
      for(const shot of bossState.projectiles||[])if(shot.kind==='psy-bomb'&&shot.phase==='orbit'&&!orbitOwners.has(shot.actorId)){
        orbitOwners.add(shot.actorId);
        const fighter=state.fighters.find(f=>f.id===shot.actorId);
        if(fighter&&fighter.hp>0){circle(record.ground,shot.orbitCenter||fighter,shot.orbitRadius||70,psychic.light,reduced?.12:.22,1);}
      }
      for(const shot of bossState.projectiles||[]){
        if(shot.enraged&&shot.phase!=='orbit'){
          // A restrained warm halo retains each attack's own art, especially Hurricane.
          image(record,'glow',rage,shot.x,shot.y,shot.radius*2.3,shot.radius*2.3,0,reduced?.025:.07,5.65);
        }
        projectile(record,shot,time,reduced);
      }
      for(const event of bossState.impacts||[])impact(record,event,reduced);
    }
    function clear(scene) {
      const record=scenes.get(scene);if(!record)return;restore(record);
      for(const sprite of record.images)sprite.destroy();record.ground.destroy();record.front.destroy();
      for(const sprite of record.sheens.values())sprite.destroy();
      record.projectileTrails.clear();record.projectileSeen.clear();
      record.nativePixels.length=0;
      for(const key of record.textures.values())if(scene.textures.exists(key))scene.textures.remove(key);
      scene.events?.off('shutdown',record.dispose);scene.events?.off('destroy',record.dispose);scenes.delete(scene);
    }
    function draw(scene,state) {
      const bossState=state?.rocketEonBoss;
      if(!bossState||scene.net||state.phase!=='fight'){clear(scene);return;}
      let record=scenes.get(scene);if(record&&record.world!==scene.world){clear(scene);record=null;}
      if(!record){record={scene,world:scene.world,id:++serial,textures:new Map(),images:[],used:0,owned:[],motion:new Map(),sheens:new Map(),
        projectileTrails:new Map(),projectileSeen:new Set(),nativePixels:[],
        ground:scene.add.graphics().setDepth(3.15),front:scene.add.graphics().setDepth(6)};
        record.dispose=()=>clear(scene);scenes.set(scene,record);scene.events.once('shutdown',record.dispose);scene.events.once('destroy',record.dispose);
      }
      record.used=0;record.ground.clear();record.front.clear();
      record.projectileSeen.clear();
      for(const sprite of record.sheens.values())sprite.setVisible(false);
      const reduced=ei().display.reduceFlash||Wq(),time=(state.tick||0)*q;
      paint(record,state,bossState,time,reduced);
      for(const id of record.projectileTrails.keys())if(!record.projectileSeen.has(id))record.projectileTrails.delete(id);
      for(let i=record.used;i<record.images.length;i++)record.images[i].setVisible(false);
    }
    return Object.freeze({beforeDraw,draw,clear});
  }
  function patch(source) {
    return 'const rocketEonVfx=('+createRocketEonVfx.toString()+')();globalThis.rocketEonVfx=rocketEonVfx;\n'+source;
  }
  const api=Object.freeze({patch});globalThis.ArenaEonVfxAdapter=api;
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})();
