// Render the Pokémon comparisons inside the profile's Stats tab.
(() => {
  'use strict';

  function createArenaCareerChart() {
    const views = new WeakMap();
    const percent = new Intl.NumberFormat(undefined, {style:'percent',maximumFractionDigits:1});
    const count = new Intl.NumberFormat();
    const titles = {playMs:'Playtime',winRate:'Win rate',pickRate:'Pick rate',played:'Matches Played'};

    function node(tag, className, text) {
      const el = document.createElement(tag);
      if (className) el.className = className;
      if (text !== undefined) el.textContent = text;
      return el;
    }

    function duration(ms) {
      if (ms > 0 && ms < 1000) return '<1s';
      const seconds = Math.floor(ms/1000), minutes = Math.floor(seconds/60);
      if (minutes >= 60) return Math.floor(minutes/60)+'h '+minutes%60+'m';
      if (minutes) return minutes+'m '+seconds%60+'s';
      return seconds+'s';
    }

    function installStyle() {
      if (document.getElementById('rocket-career-chart-style')) return;
      const css = node('style');
      css.id = 'rocket-career-chart-style';
      css.textContent = `
        .rocket-career-chart{--chart-grid:#424c75;--chart-dim:var(--ui-text-muted,#c1c9e1);
          --chart-columns:minmax(114px,1.3fr) minmax(90px,4fr) minmax(70px,1fr);
          box-sizing:border-box;background:var(--ui-panel,#272f55);border:2px solid var(--ui-frame-hi,#8292bb);
          border-top:4px solid var(--ui-cursor,#f87818);box-shadow:2px 2px 0 var(--ui-outline,#080b18);
          color:var(--ui-text,#f4f6ff);font:14px/1.4 Silkscreen,monospace;container-type:inline-size}
        .rocket-career-chart *{box-sizing:border-box}
        .rocket-career-head{display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;padding:16px 16px 0}
        .rocket-career-head h2{margin:0;color:inherit;font:700 clamp(16px,2.2vw,23px)/1.2 Silkscreen,monospace}
        .rocket-career-head select{border:2px solid var(--ui-frame-hi,#8292bb);border-radius:0;
          padding:6px 8px;min-height:36px;background:var(--ui-input-bg,#171e38);color:inherit;font:inherit;cursor:pointer}
        .rocket-career-note,.rocket-career-empty{margin:0;padding:6px 16px 14px;color:var(--chart-dim);font-size:12px}
        .rocket-career-empty{padding-top:18px;padding-bottom:22px}
        .rocket-career-chart [hidden]{display:none!important}
        .rocket-career-rows{list-style:none;margin:0;padding:0}
        .rocket-career-axis,.rocket-career-row{display:grid;grid-template-columns:var(--chart-columns);align-items:center;
          gap:12px;padding:8px 16px;min-width:0;border-top:1px solid var(--chart-grid)}
        .rocket-career-axis{color:var(--chart-dim);font-size:11px;line-height:1.1}
        .rocket-career-axis .scale{display:flex;justify-content:space-between;gap:4px;font-variant-numeric:tabular-nums}
        .rocket-career-axis .unit{text-align:right}
        .rocket-career-row:nth-child(even){background:rgba(7,12,31,.15)}
        .rocket-career-mon{display:flex;align-items:center;min-width:0;gap:8px;overflow-wrap:anywhere}
        .rocket-career-mon span{min-width:0}
        .rocket-career-mon img{width:38px;height:38px;object-fit:contain;image-rendering:pixelated;flex:none}
        .rocket-career-track{position:relative;height:18px;border:1px solid #12192d;background-color:var(--ui-input-bg,#151c32);
          background-image:linear-gradient(to right,var(--chart-grid) 1px,transparent 1px);background-size:25% 100%}
        .rocket-career-bar{position:absolute;inset:0 auto 0 0;background-color:#df8d43;border-top:2px solid #ffbb70}
        .rocket-career-chart[data-metric=winRate] .rocket-career-bar{background-color:#69b79d;border-color:#a5e5c9}
        .rocket-career-chart[data-metric=pickRate] .rocket-career-bar{background-color:#649cd9;border-color:#a0caff}
        .rocket-career-chart[data-metric=played] .rocket-career-bar{background-color:#9683cb;border-color:#d0bdf8}
        .rocket-career-number{display:grid;justify-items:end;text-align:right;font-variant-numeric:tabular-nums}
        .rocket-career-number strong{font:700 15px/1.2 Silkscreen,monospace}
        .rocket-career-number small{font-size:11px;color:var(--chart-dim)}
        @container(max-width:510px){.rocket-career-axis,.rocket-career-row{grid-template-columns:minmax(82px,1.2fr) minmax(42px,1fr) minmax(62px,.8fr);gap:6px;padding:7px 8px}
          .rocket-career-mon{font-size:12px;gap:4px}.rocket-career-mon img{width:26px;height:28px}
          .rocket-career-head{padding:10px 8px 0}.rocket-career-note,.rocket-career-empty{padding-inline:8px}
          .rocket-career-axis .middle{display:none}.rocket-career-number strong{font-size:13px}.rocket-career-track{height:14px}}
      `;
      document.head.append(css);
    }

    function createView(host, metric) {
      installStyle();
      const root = node('section','rocket-career-chart');
      root.setAttribute('aria-label','Pokémon performance');
      const header = node('header','rocket-career-head'), title = node('h2');
      const select = node('select');
      select.setAttribute('aria-label','Chart metric');
      for (const [value,label] of Object.entries(titles)) select.add(new Option(label,value));
      select.value = metric;
      header.append(title,select);
      const note = node('p','rocket-career-note'), axis = node('div','rocket-career-axis');
      axis.setAttribute('aria-hidden','true');
      const scale = node('span','scale'), zero = node('span'), mid = node('span','middle'), end = node('span');
      scale.append(zero,mid,end);
      const unit = node('span','unit');
      axis.append(node('span','','Pokémon'),scale,unit);
      const rows = node('ul','rocket-career-rows'), empty = node('p','rocket-career-empty');
      root.append(header,note,axis,rows,empty);
      host.replaceChildren(root);
      const view = {root,select,title,note,axis,zero,mid,end,unit,rows,empty};
      select.addEventListener('change',()=>paint(view));
      return view;
    }

    function rate(numerator,denominator) {
      if (!Number.isFinite(numerator) || !(denominator > 0)) return null;
      return Math.max(0,Math.min(1,numerator/denominator));
    }

    function addRow(list, row, value, metric, max, games, name) {
      const item = node('li','rocket-career-row'), mon = node('span','rocket-career-mon');
      const img = node('img');
      img.alt = '';
      img.loading = 'lazy';
      img.decoding = 'async';
      img.onerror = () => {
        const base = Ep(row.id);
        if (!img.dataset.retried && base && base!==row.id) {
          img.dataset.retried = '1';
          img.src = yp({id:base});
        } else img.hidden = true;
      };
      img.src = yp({id:row.id});
      mon.append(img,node('span','',name));
      const track = node('span','rocket-career-track'), bar = node('span','rocket-career-bar');
      track.setAttribute('aria-hidden','true');
      bar.style.width = (value===null ? 0 : 100*value/max)+'%';
      track.append(bar);
      const column = node('span','rocket-career-number');
      column.append(node('strong','',value===null?'—':metric==='playMs'?duration(value):metric==='played'?count.format(value):percent.format(value)));
      if (metric==='winRate' && row.decided>0) column.append(node('small','',count.format(row.wins)+' / '+count.format(row.decided)));
      if (metric==='pickRate' && games>0) column.append(node('small','',count.format(row.picks)+' / '+count.format(games)));
      if (value===null) column.setAttribute('aria-label','No recorded '+titles[metric].toLowerCase());
      item.append(mon,track,column);
      list.append(item);
    }

    function paint(view) {
      const metric = view.select.value, {rows,games,partialPickHistory,partialPlayedHistory} = view.snapshot;
      const records = rows.filter(row=>metric!=='played'||row.played>0).map(row=>{
        const value = metric==='playMs' ? (row.playMs>0?row.playMs:null) :
          metric==='played' ? row.played : metric==='winRate' ? rate(row.wins,row.decided) : rate(row.picks,games);
        return {row,value,name:dn(row.id).name};
      });
      records.sort((a,b)=>(b.value??-1)-(a.value??-1)||a.name.localeCompare(b.name)||a.row.id.localeCompare(b.row.id));
      view.root.dataset.metric = metric;
      view.title.textContent = titles[metric]+' by Pokémon';
      view.unit.textContent = metric==='playMs'?'Time':metric==='played'?'Matches':'Rate';
      if (metric==='pickRate') {
        view.note.textContent = games===null ? 'The total number of tracked battles is unknown for this save.' :
          'Battles with this Pokémon on your team / '+count.format(games)+' tracked battles.'+
          (partialPickHistory ? ' Older battles with incomplete team records are excluded.' : '');
      } else if (metric==='winRate') {
        view.note.textContent = 'Team wins / recorded results with this Pokémon. Draws count; No Contest is excluded.';
      } else if (metric==='played') {
        view.note.textContent = 'Counts each match once when this Pokémon enters battle. Unused team members do not count.'+
          (partialPlayedHistory ? ' Older saves did not record who entered battle; those matches are excluded.' : '');
      } else {
        view.note.textContent = 'Active battle time with each Pokémon since per-Pokémon tracking began.';
      }
      const hasData = records.some(record=>record.value!==null);
      view.empty.hidden = hasData;
      view.empty.textContent = metric==='playMs' ? 'No active Pokémon time recorded yet.' :
        metric==='played' ? 'No matches recorded with a Pokémon sent into battle yet.' :
        metric==='winRate' ? 'No match results recorded by Pokémon yet.' : 'No pick rates available yet.';
      view.axis.hidden = !hasData;
      view.rows.hidden = !hasData;
      const signature = JSON.stringify([metric,games,records.map(({row,value})=>
        [row.id,value,metric==='winRate'?row.decided:0])]);
      if (signature === view.signature) return;
      view.signature = signature;
      view.rows.replaceChildren();
      if (!hasData) return;
      // Percentage graphs use the full 0–100% scale. Time is relative to the
      // longest recorded duration. Match counts use whole-number tick increments.
      let max = 1;
      if (metric==='playMs') {
        const longest = records[0].value;
        const step = longest>7200000 ? 3600000 : longest>120000 ? 60000 : 1000;
        max = Math.ceil(longest/(2*step))*2*step;
      } else if (metric==='played') {
        const half=Math.max(1,records[0].value/2),unit=10**Math.floor(Math.log10(half));
        const step=[1,2,5,10].find(value=>value*unit>=half)*unit;
        max=step*2;
      }
      view.zero.textContent = metric==='playMs'?'0s':metric==='played'?'0':'0%';
      view.mid.textContent = metric==='playMs'?duration(max/2):metric==='played'?count.format(max/2):'50%';
      view.end.textContent = metric==='playMs'?duration(max):metric==='played'?count.format(max):'100%';
      const list = document.createDocumentFragment();
      for (const {row,value,name} of records) addRow(list,row,value,metric,max,games,name);
      view.rows.replaceChildren(list);
    }

    function render(host,snapshot) {
      let view = views.get(host);
      if (!view || view.root.parentNode!==host) {
        view = createView(host,view?.select.value || 'playMs');
        views.set(host,view);
      }
      view.snapshot = snapshot;
      paint(view);
    }
    return {render};
  }

  function patch(source) {
    return 'const arenaCareerChart=('+createArenaCareerChart.toString()+')();\n'+source;
  }
  const api=Object.freeze({patch});
  globalThis.ArenaCareerChartAdapter=api;
  if(typeof module!=='undefined' && module.exports) module.exports=api;
})();
