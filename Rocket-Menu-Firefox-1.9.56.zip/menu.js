(() => {
  'use strict';
  const popup = location.protocol === 'moz-extension:';
  const battleKeys = ['cooldowns','aim','god','speed','rapidfire','norecovery','supereffective'];
  const extraKeys = ['rapidfire','norecovery','supereffective'];
  const options = [
    ['cooldowns','No cooldowns'],
    ['god','God mode'],
    ['speed','2× speed'],
    ['rapidfire','Rapid fire'],
    ['norecovery','No recovery'],
    ['supereffective','Always super effective'],
    ['anymove','Any move']
  ];
  const host = document.createElement('div');
  host.id='arena-mod-menu';
  const root=host.attachShadow({mode:'open'});
  const style=document.createElement('style');
  style.textContent = `
    :host{all:initial;font:14px/1.4 system-ui,sans-serif;color:#f5f5f7;color-scheme:dark}
    :host([data-game]){position:fixed;z-index:2147483630;right:10px;top:42%;pointer-events:none}
    *,*::before,*::after{box-sizing:border-box}
    [hidden]{display:none!important}
    button,input,label{font:inherit}button{cursor:pointer}button:disabled{cursor:default;opacity:.55}
    #menu-button,.panel{pointer-events:auto}
    #menu-button{display:grid;place-items:center;margin-left:auto;background:transparent;border:0;border-radius:4px;
      width:36px;height:40px;padding:2px;filter:drop-shadow(1px 2px 1px #000)}
    .launcher-mark{color:#ff405f;font:italic 900 32px/1 Arial,sans-serif}
    #menu-button:hover .launcher-mark{color:#ff8197}
    .panel{color:#f5f5f7;background:#19191f;border:1px solid #4b343c;border-radius:12px;
      padding:0 16px 16px;width:320px;max-width:calc(100vw - 20px);box-shadow:0 10px 36px #0009;
      scrollbar-width:thin;scrollbar-color:#71505b #19191f}
    :host([data-game]) .panel{position:fixed;right:10px;top:50%;transform:translateY(-50%);max-height:calc(100vh - 24px);
      overflow:auto;overscroll-behavior:contain}
    :host([data-popup]) .panel{border:0;border-radius:0;width:320px;max-width:100%;max-height:560px;
      overflow-y:auto;overflow-x:hidden;overscroll-behavior:contain;box-shadow:none}
    .head{display:flex;align-items:center;justify-content:space-between;gap:8px;position:sticky;top:0;z-index:2;
      margin:0 -16px;padding:16px;background:#19191f;border-bottom:2px solid #d82e4b}
    .brand{display:flex;align-items:center;gap:11px;min-width:0}
    .rocket-mark{color:#ff405f;font:italic 900 43px/.95 Arial,sans-serif;text-shadow:2px 2px 0 #650e25}
    h1{font-size:20px;line-height:1.25;letter-spacing:-.3px;margin:0;font-weight:780}
    #close{display:grid;place-items:center;flex:0 0 30px;width:30px;height:30px;color:#eee8eb;
      background:#29272f;border:1px solid #51414a;border-radius:6px;padding:0;font-size:22px;line-height:1}
    #close:hover{background:#44232e;border-color:#d34760}
    label{display:flex;justify-content:space-between;align-items:center;gap:14px;min-height:45px;padding:10px 0;border-bottom:1px solid #36323b;cursor:pointer}
    label strong{display:block;font-size:14px;line-height:1.3;font-weight:700}
    label:has(input:disabled){cursor:default}
    label:has(input:disabled) strong{color:#97919c}
    input{display:grid;place-items:center;appearance:none;position:relative;width:22px;height:22px;flex:0 0 22px;
      border-radius:0;margin:0;background:#242129;border:2px solid #8b828f;cursor:pointer}
    input::before{content:"";font:700 22px/16px Arial,sans-serif;color:#fff}
    input:checked{background:#c72343;border-color:#fa617d}
    input:checked::before{content:'×'}
    input:disabled{cursor:default;opacity:.45}
    button:focus-visible,input:focus-visible,textarea:focus-visible{outline:3px solid #ff9fb0;outline-offset:3px}
    .helper{display:block;width:100%;border:1px solid #69505b;background:#30252d;color:#fff;padding:9px 10px;
      font-size:12px;font-weight:650;border-radius:6px;margin-top:10px;line-height:1.4}
    .helper:hover:not(:disabled){background:#49232f;border-color:#e7546e}
    textarea{font:12px/1.5 system-ui,sans-serif;width:100%;min-height:72px;margin-top:8px;padding:8px;
      color:#f5f5f7;background:#111116;border:1px solid #69505b;border-radius:5px;resize:vertical}
    @media(max-height:420px){.head{padding-top:10px;padding-bottom:10px}.rocket-mark{font-size:35px}}
  `;
  function element(tag,text){const el=document.createElement(tag);if(text!==undefined)el.textContent=text;return el;}
  const launcher=element('button');
  const launcherMark=element('span','R');launcherMark.className='launcher-mark';launcherMark.setAttribute('aria-hidden','true');
  launcher.append(launcherMark);launcher.setAttribute('aria-label','Rocket Menu');
  launcher.id='menu-button';launcher.type='button';launcher.setAttribute('aria-controls','panel');
  const panel=element('section');panel.className='panel';panel.id='panel';panel.setAttribute('aria-labelledby','title');
  const header=element('div');header.className='head';
  const brand=element('div');brand.className='brand';
  const mark=element('span','R');mark.className='rocket-mark';mark.setAttribute('aria-hidden','true');
  const title=element('h1','Rocket Menu');title.id='title';
  brand.append(mark,title);
  const close=element('button','×');close.id='close';close.type='button';close.setAttribute('aria-label','Close Rocket Menu');
  header.append(brand,close);
  panel.append(header);
  function diagnostic(text){host.dataset.status=text;panel.dataset.status=text;launcher.title='Rocket Menu';}
  const inputs=new Map();
  const preferences=new Map();
  let loadIssue='';
  let storageReady=false;
  let accessUnlocked=false;
  let launcherHidden=false;
  let capability='setup',canUseAnyMove=true;
  let extraControls=null;
  let repairRequested=false;
  let repairAfter=Infinity;
  let repairBootAfter=Infinity;
  function maybeRepair(){
    if(popup||!storageReady||repairRequested||document.readyState==='loading')return;
    const doc=document.documentElement;
    if(!doc)return;
    const failed=doc.getAttribute('data-arena-recovery-state')==='error';
    const canvas=document.querySelector('#app canvas');
    const current=doc.getAttribute('data-arena-mod-build')==='1.9.56';
    if(!failed){
      if(current&&canvas)return;
      if(performance.now()<(canvas?repairAfter:repairBootAfter))return;
    }
    repairRequested=true;
    browser.runtime.sendMessage({type:'arena-mod-repair-tab'}).catch(()=>diagnostic('Automatic reload unavailable. Reload this tab once.'));
  }
  function armRepair(){
    repairAfter=performance.now()+5000;
    repairBootAfter=performance.now()+20000;
    maybeRepair();setTimeout(maybeRepair,5000);setTimeout(maybeRepair,20000);
  }
  if(!popup){
    if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',armRepair,{once:true});
    else armRepair();
  }
  for(const [key,name] of options) {
    const row=element('label');row.htmlFor=key;
    const label=element('strong',name);
    const input=element('input');input.id=key;input.type='checkbox';input.setAttribute('aria-label',name);
    input.disabled=true;
    input.addEventListener('change',async()=>{
      if(!accessUnlocked||input.disabled){update(key,false);notify();return;}
      const next=input.checked;
      update(key,next);notify();
      let delivered=!popup;
      if(popup){
        try{
          const [tab]=await browser.tabs.query({active:true,currentWindow:true});
          if(tab?.id!==undefined)delivered=await browser.tabs.sendMessage(tab.id,{type:'arena-mod-apply-setting',key,value:next})===true;
        }catch{}
      }
      if(!delivered){update(key,false);connectionStatus();}
      try {await browser.storage.local.set({[key]:delivered&&next});}
      catch {diagnostic(delivered?'Applied in this tab. Firefox could not remember the setting.':'The game did not receive the change. Reload this tab once.');}
    });
    inputs.set(key,input);row.append(label,input);panel.append(row);
  }
  if(popup){
    const copy=element('button','Copy host helper');copy.type='button';copy.className='helper';copy.disabled=true;copy.dataset.rocketAccessRequired='';
    const manual=element('textarea');manual.readOnly=true;manual.hidden=true;manual.setAttribute('aria-label','Host helper bookmark address');
    panel.append(copy,manual);
    fetch(browser.runtime.getURL('host-helper.txt')).then(r=>{
      if(!r.ok)throw Error('unavailable');
      return r.text();
    }).then(text=>{
      const value=text.trim();if(!value.startsWith('javascript:'))throw Error('invalid');
      copy.dataset.ready='true';copy.disabled=!accessUnlocked;
      copy.addEventListener('click',async()=>{
        if(!accessUnlocked)return;
        try{await navigator.clipboard.writeText(value);copy.textContent='Copied';setTimeout(()=>{copy.textContent='Copy host helper';},1600);}
        catch{manual.value=value;manual.hidden=false;manual.focus();manual.select();}
      });
    }).catch(()=>{copy.hidden=true;});
  }
  root.append(style,launcher,panel);
  function show(open) {
    if(!popup&&!accessUnlocked)open=false;
    launcher.hidden=popup||!accessUnlocked||open||launcherHidden;panel.hidden=!open;
    launcher.setAttribute('aria-expanded',String(open));
    if(!popup && open)close.focus();
  }
  function closePanel(){
    show(false);
    const arena=document.querySelector('#app canvas');
    if(!arena){launcher.focus();return;}
    if(!arena.hasAttribute('tabindex'))arena.tabIndex=-1;
    arena.focus({preventScroll:true});
  }
  launcher.addEventListener('click',()=>show(true));
  close.addEventListener('click',()=>{if(popup)window.close();else closePanel();});
  if (!popup) {
    const rocketShortcut=e=>e.ctrlKey&&!e.shiftKey&&!e.altKey&&!e.metaKey&&
      (e.code==='KeyR'||e.key?.toLowerCase()==='r');
    // Capture before the game's keyboard listeners. Ctrl+R is a menu shortcut
    // while this game page has focus; ordinary R and hard refresh stay native.
    window.addEventListener('keydown',e=>{
      if(!accessUnlocked||!rocketShortcut(e))return;
      e.preventDefault();e.stopImmediatePropagation();
      if(e.repeat)return;
      launcherHidden=!launcherHidden;closePanel();
    },true);
    window.addEventListener('keyup',e=>{
      if(accessUnlocked&&rocketShortcut(e)){e.preventDefault();e.stopImmediatePropagation();}
    },true);
    root.addEventListener('keydown',e=>{if(e.key==='Escape'&&!panel.hidden){e.preventDefault();closePanel();}});
    for(const type of ['pointerdown','pointerup','mousedown','mouseup','click','dblclick','keydown','keyup','touchstart','touchend','wheel','contextmenu']) {
      root.addEventListener(type,e=>e.stopPropagation());
    }
  }
  host.setAttribute(popup?'data-popup':'data-game','');show(popup);
  function currentMatch() {
    const doc=document.documentElement;
    const access={unlocked:accessUnlocked,settings:Object.fromEntries(preferences)};
    if(doc?.hasAttribute('data-arena-host-helper'))return {...access,mode:'unavailable',text:'Host helper tab · your own switches are off here.'};
    if(doc?.getAttribute('data-arena-mod-build')!=='1.9.56')return {...access,mode:'unavailable',text:doc?.getAttribute('data-arena-launch-error')||loadIssue||'Waiting for Rocket Menu 1.9.56.'};
    let mode=doc.getAttribute('data-arena-online-controls')||'setup';
    let text=doc.getAttribute('data-arena-friend-status')||'Rocket Menu 1.9.56 is loaded. Choose a battle.';
    let supportedExtra=null;
    const rawExtra=doc.getAttribute('data-arena-extra-controls');
    if(rawExtra!==null){
      try{const value=JSON.parse(rawExtra);supportedExtra=Array.isArray(value)?value.filter(key=>extraKeys.includes(key)):[];}
      catch{supportedExtra=[];}
    }
    const mask=doc.getAttribute('data-arena-engine-mask');
    const inBattle=document.querySelector('#app canvas[data-mode="fight"]');
    let anyMoveAvailable=!inBattle||doc.getAttribute('data-arena-anymove-controls')==='on';
    const hostTimers=doc.getAttribute('data-arena-host-timers');
    const sampleAge=performance.now()-Number(doc.getAttribute('data-arena-host-sampled'));
    if(inBattle && hostTimers && sampleAge>=0 && sampleAge<1500){
      anyMoveAvailable=true;
      if(mode!=='all')mode='host-cooldowns';
      supportedExtra=[...extraKeys];
      text='You run this Direct fight';
      if(mask!==null){
        const count=battleKeys.filter((_,i)=>Number(mask)&(1<<i)).length;
        text+=' · Battle engine: '+count+' of '+battleKeys.length+' on.';
      }
      if(hostTimers==='waived')text+=' · Cooldowns are zero.';
      else if(hostTimers==='clearing')text+=' · Clearing your cooldowns.';
    }else if(mode==='all' && mask!==null && inBattle) {
      const count=battleKeys.filter((_,i)=>Number(mask)&(1<<i)).length;
      text+=' · Battle engine: '+count+' of '+battleKeys.length+' on.';
    }
    return {...access,mode,text,extraControls:supportedExtra,anyMoveAvailable};
  }
  function displayControl(key) {
    const input=inputs.get(key);
    const restricted=capability==='unavailable'||(key==='anymove'&&!canUseAnyMove)||(key!=='anymove'&&(
      capability==='aim'||
      (capability==='host-cooldowns'&&key==='god')))||
      ((capability==='all'||capability==='host-cooldowns')&&extraControls!==null&&
        extraKeys.includes(key)&&!extraControls.includes(key));
    input.disabled=!storageReady||!accessUnlocked||restricted;
    input.checked=accessUnlocked&&!restricted&&preferences.get(key)===true;
    input.title=accessUnlocked?'':'Unlock Rocket Menu in Settings > Data.';
  }
  function showMatch(info) {
    if(popup){
      accessUnlocked=info.unlocked===true;
      for(const key of inputs.keys())preferences.set(key,accessUnlocked&&info.settings?.[key]===true);
    }
    host.dataset.access=panel.dataset.access=accessUnlocked?'unlocked':'locked';
    if(!popup){
      if(!accessUnlocked)show(false);
      else launcher.hidden=!panel.hidden||launcherHidden;
    }
    for(const control of root.querySelectorAll('[data-rocket-access-required]'))control.disabled=!accessUnlocked||control.dataset.ready!=='true';
    canUseAnyMove=info.anyMoveAvailable!==false;
    capability=info.mode;extraControls=Array.isArray(info.extraControls)?info.extraControls.filter(key=>extraKeys.includes(key)):null;
    host.dataset.controls=info.mode;panel.dataset.controls=info.mode;diagnostic(info.text);
    for(const key of inputs.keys())displayControl(key);
  }
  let popupRequest=0;
  async function connectionStatus() {
    if(!popup){showMatch(currentMatch());maybeRepair();return;}
    const sequence=++popupRequest;
    let info={mode:'unavailable',text:'No active game in this tab.'};
    try{
      const [tab]=await browser.tabs.query({active:true,currentWindow:true});
      if(tab?.id!==undefined)info=await browser.tabs.sendMessage(tab.id,{type:'public-mod-match-info'})||info;
    }catch{}
    if(sequence===popupRequest)showMatch(info);
  }
  if(!popup)browser.runtime.onMessage.addListener((msg,sender)=>{
    if(sender.id!==browser.runtime.id)return;
    if(msg?.type==='public-mod-match-info')return Promise.resolve(currentMatch());
    if(msg?.type==='arena-mod-apply-setting'&&inputs.has(msg.key)&&typeof msg.value==='boolean'){
      if(!accessUnlocked||!storageReady||inputs.get(msg.key).disabled)return Promise.resolve(false);
      update(msg.key,msg.value);notify();return Promise.resolve(true);
    }
  });
  function mount() {
    if(!document.documentElement)return false;
    const container=popup?document.body:document.documentElement;
    if(!container)return false;
    if(!host.isConnected)container.append(host);
    connectionStatus();
    return true;
  }
  function update(key,value) {
    const enabled=accessUnlocked&&value===true;
    preferences.set(key,enabled);
    displayControl(key);
    if(!popup && document.documentElement)document.documentElement.setAttribute('data-arena-mod-'+key,enabled?'on':'off');
  }
  function notify(){if(!popup){document.documentElement?.setAttribute('data-arena-mod-aim','off');document.dispatchEvent(new Event('arena-mod-settings'));}}
  function resetSwitches(){
    for(const key of inputs.keys())update(key,false);
    notify();
    void browser.storage.local.set(Object.fromEntries([...inputs.keys(),'aim'].map(key=>[key,false]))).catch(()=>{});
  }
  function syncAccess(){
    if(popup)return;
    const next=document.documentElement?.getAttribute('data-arena-rocket-access')==='unlocked';
    if(next!==accessUnlocked){accessUnlocked=next;launcherHidden=false;resetSwitches();}
    connectionStatus();
  }
  browser.storage.onChanged.addListener((changes,area)=>{
    if(area!=='local')return;
    for(const [key,change] of Object.entries(changes))if(inputs.has(key)){
      update(key,change.newValue);
    }
    notify();
  });
  async function start(){
    mount();
    if(!popup)browser.runtime.sendMessage({type:'arena-mod-load-issue'}).then(issue=>{loadIssue=issue||'';connectionStatus();}).catch(()=>{});
    storageReady=true;
    if(popup)await connectionStatus();
    else{
      accessUnlocked=document.documentElement?.getAttribute('data-arena-rocket-access')==='unlocked';
      resetSwitches();connectionStatus();
    }
    maybeRepair();
  }
  document.addEventListener('arena-mod-ready',()=>{
    if(storageReady)for(const key of inputs.keys())update(key,preferences.get(key));
    notify();connectionStatus();
  });
  document.addEventListener('arena-engine-readback',connectionStatus);
  document.addEventListener('arena-friend-status',connectionStatus);
  document.addEventListener('arena-rocket-access',syncAccess);
  if(!popup)setTimeout(connectionStatus,3500);
  setInterval(connectionStatus,1200);
  if((popup && !document.body)||!document.documentElement)document.addEventListener('DOMContentLoaded',start,{once:true});
  else start();
})();
