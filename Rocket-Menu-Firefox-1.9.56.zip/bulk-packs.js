// Queue native card purchases; every pack still pays and grants cards normally.
(() => {
  'use strict';

  function createRocketPackDuplicates() {
    function snapshot(renderer) {
      // Native purchases create pending choices; only Keep adds an unlocked key.
      // Freeze this pack's baseline so its new selection never becomes a duplicate.
      renderer.rocketOwnedBeforePack = new Set(df().unlocked || []);
    }
    function mark(front, card, renderer) {
      if (!renderer.rocketOwnedBeforePack?.has(card.key)) return;
      if (!document.getElementById('rocket-pack-duplicate-style')) {
        const style = document.createElement('style');
        style.id = 'rocket-pack-duplicate-style';
        style.textContent = `
          .pack-stage .rocket-pack-duplicate{position:absolute;left:calc(var(--k)*5px);top:calc(var(--k)*5px);
            z-index:8;max-width:calc(var(--k)*45px);box-sizing:border-box;padding:calc(var(--k)*1px) calc(var(--k)*2px);
            border:1px solid #8fcaff;background:#17477f;color:#e0f2ff;box-shadow:1px 1px 0 #071c38,inset 1px 1px 0 #3478bd;
            font:calc(var(--k)*4px)/1.2 var(--font-ui,Silkscreen,monospace);font-weight:normal;
            text-align:center;white-space:nowrap;letter-spacing:0;text-shadow:1px 1px 0 #0a2a51;pointer-events:none}
        `;
        document.head.append(style);
      }
      const badge = X('span', 'rocket-pack-duplicate', 'DUPLICATE');
      badge.title = 'Owned before opening this pack';
      badge.setAttribute('aria-label', 'Duplicate card: already owned');
      front.append(badge);
    }
    return {snapshot,mark};
  }

  function createRocketBulkPacks(alive, open) {
    let active = false, remaining = 0, total = 0, opened = 0, generation = 0, status = null;

    function offer() {
      const save = df(), pool = dd(save.unlocked);
      let coins = save.coins, count = 0, cost = 0;
      const costs = [0];
      // Prices increase with packsOpened, so coins/currentPrice is not enough.
      if (!save.pending?.length) for (let index = 0; index < pool.length; index++) {
        const price = Gl(save.packsOpened + index);
        if (!Number.isFinite(price) || price <= 0 || coins < price) break;
        coins -= price; cost += price; count++;
        costs.push(cost);
      }
      return {count, costs};
    }

    function cancel() {
      active = false; remaining = 0; generation++;
      status?.remove(); status = null;
    }

    function advance(quick) {
      if (!active || !alive() || remaining <= 0) { cancel(); return; }
      remaining--; opened++;
      // open uses the native Ff validator and writes its exact resulting save.
      // Never charge the unstarted remainder; pending cards survive exit/reload.
      if (!open(quick)) cancel();
    }

    function start(requested) {
      if (active || !alive()) return;
      const available = offer();
      const count = requested === 'max' ? available.count : requested;
      if (!Number.isInteger(count) || count <= 0 || count > available.count) return;
      total = count; remaining = count; opened = 0; active = true; generation++;
      advance(false);
    }

    function controls(host) {
      if (!document.getElementById('rocket-bulk-packs-style')) {
        const style = document.createElement('style');
        style.id = 'rocket-bulk-packs-style';
        style.textContent = `
          .rocket-bulk-packs{display:flex;flex-wrap:wrap;justify-content:center;gap:8px;margin-top:6px;max-width:100%}
          .rocket-bulk-packs .pack-btn{min-height:40px;padding:6px 10px}
          .rocket-bulk-status{position:absolute;top:8px;left:8px;right:8px;z-index:4;display:flex;align-items:flex-start;justify-content:space-between;gap:8px;pointer-events:none}
          .rocket-bulk-status .pack-btn{pointer-events:auto;min-height:32px;padding:4px 8px}
          .rocket-bulk-count{font:var(--fs-1)/1.4 var(--font-ui);color:var(--ui-text);background:var(--ui-panel);border:2px solid var(--ui-outline);padding:5px 8px}
        `;
        document.head.append(style);
      }
      const available = offer(), row = X('div', 'rocket-bulk-packs');
      row.setAttribute('aria-label', 'Buy multiple packs');
      for (const count of [10, 25, 'max']) {
        const quantity = count === 'max' ? available.count : count;
        const button = X('button', 'pack-btn', count === 'max' ? 'BUY MAX (' + quantity + ')' : 'BUY ' + count);
        button.type = 'button';
        button.disabled = active || quantity <= 0 || quantity > available.count;
        button.title = button.disabled ? 'Not enough coins or cards for this many packs.' :
          available.costs[quantity] + ' coins total. Charged one pack at a time; stopping keeps unspent coins.';
        button.addEventListener('click', () => start(count));
        row.append(button);
      }
      host.append(row);
    }

    function stage(host) {
      status?.remove(); status = null;
      if (!active) return;
      status = X('div', 'rocket-bulk-status');
      const count = X('span', 'rocket-bulk-count', 'PACK ' + opened + ' / ' + total);
      count.setAttribute('aria-live', 'polite');
      const stop = X('button', 'pack-btn', 'STOP BATCH');
      stop.type = 'button';
      stop.title = 'Finish this paid pack; cancel the remaining purchases.';
      stop.addEventListener('click', event => { event.stopPropagation(); cancel(); });
      status.append(count, stop); host.append(status);
    }

    function kept(cleanup) {
      if (!active) return;
      if (remaining <= 0) { cancel(); return; }
      const current = generation;
      // The native keep handler still renders once after onKeep. Wait until it
      // returns before destroying its animation and starting the next choices.
      queueMicrotask(() => {
        if (!active || generation !== current || !alive()) return;
        if (df().pending?.length) { cancel(); return; }
        cleanup();
        advance(true);
      });
    }

    return {controls, stage, kept, cancel, get active() { return active; }};
  }

  function patch(source) {
    function replace(before, after, label) {
      const parts = source.split(before);
      if (parts.length !== 2) throw Error('Unsupported game build for bulk packs: ' + label + '.');
      source = parts.join(after);
    }

    replace('play(e){this.opts=e,this.reduced=e.reduced,this.views=[]',
      'play(e){rocketPackDuplicates.snapshot(this);this.opts=e,this.reduced=e.reduced,this.views=[]',
      'ownership before card reveal');
    replace('n.append(r,i,a,o),e.append(n),e.dataset.key=t.key,this.cardsHost.append(e)',
      'rocketPackDuplicates.mark(i,t,this),n.append(r,i,a,o),e.append(n),e.dataset.key=t.key,this.cardsHost.append(e)',
      'duplicate card front');
    replace('let n=Xp({id:e.card.ids[0],k:t.cardK,tier:e.card.tier});e.front.replaceWith(n)',
      'let n=Xp({id:e.card.ids[0],k:t.cardK,tier:e.card.tier});rocketPackDuplicates.mark(n,e.card,this);e.front.replaceWith(n)',
      'duplicate badge after card resize');

    // Keep native currency validation, pending-save creation, analytics and card
    // generation. Only the queue and presentation are new.
    replace(
      'e.append(n);let i=null,a=!1,o=()=>{let e=dd(df().unlocked);',
      'e.append(n);let i=null,a=!1,rocketBulk=createRocketBulkPacks(()=>!a,quick=>{if(a)return!1;let before=df(),purchase=Ff(before);if(!purchase.ok){rocketBulk.cancel();s();return!1}hf(()=>purchase.save),rf(`pack_open`,{pack_index:purchase.save.packsOpened,price:Gl(before.packsOpened),pool_left:dd(before.unlocked).length}),t.refresh(),l(purchase.cards,quick);return!0}),o=()=>{let e=dd(df().unlocked);',
      'native purchase queue'
    );
    replace(
      'h.addEventListener(`click`,()=>{let e=Ff(df());',
      'h.addEventListener(`click`,()=>{if(rocketBulk.active)return;let e=Ff(df());',
      'single-pack reentry guard'
    );
    replace(
      'g.append(X(`p`,`packs-next-label`,K(`collection.packs.next`)),m,h),p.append(g),n.append(p);',
      'g.append(X(`p`,`packs-next-label`,K(`collection.packs.next`)),m,h),rocketBulk.controls(g),p.append(g),n.append(p);',
      'purchase buttons'
    );
    replace(
      'd=X(`div`,`packs-stage`);e.append(d),i=new bm(d),i.play({',
      'd=X(`div`,`packs-stage`);e.append(d),i=new bm(d),rocketBulk.stage(d),i.play({',
      'queue progress'
    );
    replace(
      'navigator.storage?.persist?.().catch(()=>void 0)),t.refresh())},onAnother:()=>{i?.destroy(),i=null,d.remove(),s()},onView:e=>{let n=ed.get(e);n?.ids[0]&&t.openDex(n.ids[0])},onDone:()=>{i?.destroy(),i=null,d.remove(),s()},',
      'navigator.storage?.persist?.().catch(()=>void 0)),t.refresh(),rocketBulk.kept(()=>{i?.destroy(),i=null,d.remove()}))},onAnother:()=>{rocketBulk.cancel(),i?.destroy(),i=null,d.remove(),s()},onView:e=>{rocketBulk.cancel();let n=ed.get(e);n?.ids[0]&&t.openDex(n.ids[0])},onDone:()=>{rocketBulk.cancel(),i?.destroy(),i=null,d.remove(),s()},',
      'successful native keep and cancellation'
    );
    replace(
      'onChange:()=>t.refresh()})};return s(),()=>{a=!0,i?.destroy(),i=null}}function zb(e)',
      'onChange:()=>t.refresh()})};return s(),()=>{a=!0,rocketBulk.cancel(),i?.destroy(),i=null}}function zb(e)',
      'page disposal'
    );
    return 'const rocketPackDuplicates=('+createRocketPackDuplicates.toString()+')();\n'+
      createRocketBulkPacks.toString() + '\n' + source;
  }

  const api = Object.freeze({patch});
  globalThis.ArenaBulkPacksAdapter = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})();
