// Private boss arena: layered stonework above clouds, generated once per texture manager.
(() => {
  'use strict';

  function createArenaSkyPillar() {
    const id = 'rocket-sky-pillar', width = 2048, height = 1280;
    const combat = {left:250,top:324,right:1798,bottom:1010,rocks:[]};
    const stage = Object.freeze({id,labelKey:'stages.rocket.skyPillar',
      file:'rocket-private/sky-pillar',backdrop:'#c2d9e3'});
    const key = suffix => id + '-' + suffix;

    function random(seed) {
      return () => {
        seed |= 0; seed = seed + 0x6D2B79F5 | 0;
        let n = Math.imul(seed ^ seed >>> 15,1 | seed);
        n = n + Math.imul(n ^ n >>> 7,61 | n) ^ n;
        return ((n ^ n >>> 14) >>> 0) / 4294967296;
      };
    }
    function polygon(ctx,points,fill,stroke) {
      ctx.beginPath();ctx.moveTo(points[0][0],points[0][1]);
      for (let i=1;i<points.length;i++) ctx.lineTo(points[i][0],points[i][1]);
      ctx.closePath();ctx.fillStyle=fill;ctx.fill();
      if (stroke) {ctx.strokeStyle=stroke;ctx.lineWidth=2;ctx.stroke();}
    }
    function line(ctx,points,color,width=1) {
      ctx.beginPath();ctx.moveTo(points[0][0],points[0][1]);
      for (let i=1;i<points.length;i++) ctx.lineTo(points[i][0],points[i][1]);
      ctx.strokeStyle=color;ctx.lineWidth=width;ctx.stroke();
    }
    function stone(ctx,x,y,w,h,rng,dark=false) {
      const tone=Math.floor((dark?84:170)+rng()*(dark?28:25));
      ctx.fillStyle=`rgb(${tone+22},${tone+13},${tone-8})`;
      ctx.fillRect(x+1,y+1,w-2,h-2);
      line(ctx,[[x+2,y+h-2],[x+2,y+2],[x+w-3,y+2]],dark?'#b0a17b88':'#f4e1b780',2);
      line(ctx,[[x+w-2,y+2],[x+w-2,y+h-2],[x+2,y+h-2]],'#403b2b60',2);
      for(let i=0;i<8;i++) {
        ctx.fillStyle=i%2?'#fff0c417':'#40382b18';
        ctx.fillRect(Math.floor(x+3+rng()*(w-7)),Math.floor(y+3+rng()*(h-7)),2+rng()*4,1+rng()*2);
      }
      if(rng()<.15) {
        const a=x+w*(.2+rng()*.6),b=y+h*(.2+rng()*.5);
        line(ctx,[[a,y+1],[a-4,b],[a+4,b+5],[a-2,y+h-2]],'#51473580');
        if(rng()<.4)line(ctx,[[a-4,b],[a-11,b+4],[a-19,b+2]],'#51473570');
      }
    }
    function masonry(ctx,x,y,w,h,rng,bw=64,bh=38,dark=false) {
      ctx.save();ctx.beginPath();ctx.rect(x,y,w,h);ctx.clip();
      ctx.fillStyle=dark?'#5b503c':'#837559';ctx.fillRect(x,y,w,h);
      let row=0;
      for(let py=y;py<y+h;py+=bh,row++)
        for(let px=x-(row%2)*bw/2;px<x+w;px+=bw)stone(ctx,px,py,bw,bh,rng,dark);
      ctx.restore();
    }
    function tiles(ctx,x,y,w,h,rng,size=82) {
      ctx.save();ctx.beginPath();ctx.rect(x,y,w,h);ctx.clip();
      ctx.fillStyle='#8c8669';ctx.fillRect(x,y,w,h);
      for(let py=y;py<y+h;py+=size)for(let px=x;px<x+w;px+=size) {
        stone(ctx,px,py,size,size,rng);
        if(rng()<.32) {
          const corner=rng()<.5?px+2:px+size-2;
          polygon(ctx,[[corner,py+3],[corner+(corner===px+2?7:-7),py+2],
            [corner,py+9]],'#8b8467');
        }
        if(rng()<.28) {
          ctx.fillStyle='#626c3b26';ctx.fillRect(px+1,py+size-4,14+rng()*40,3);
          ctx.fillRect(px+1,py+size-17,3,15);
        }
      }
      ctx.restore();
    }
    function clipped(ctx,shape,paint) {
      ctx.save();ctx.beginPath();ctx.moveTo(...shape[0]);
      for(const p of shape.slice(1))ctx.lineTo(...p);
      ctx.closePath();ctx.clip();paint();ctx.restore();
    }
    function cloud(ctx,x,y,w,h,rng,alpha=1) {
      ctx.save();ctx.globalAlpha=alpha;
      for(let i=0;i<10;i++) {
        const px=x+w*(i/11+.04),py=y+h*(.35+rng()*.3),rx=w*(.12+rng()*.06),ry=h*(.28+rng()*.18);
        const g=ctx.createRadialGradient(px-ry*.2,py-ry*.3,ry*.12,px,py,Math.max(rx,ry));
        g.addColorStop(0,'#ffffff');g.addColorStop(.58,'#eaf4f8db');g.addColorStop(1,'#d4e8f000');
        ctx.fillStyle=g;ctx.beginPath();ctx.ellipse(px,py,rx,ry,0,0,Math.PI*2);ctx.fill();
      }
      ctx.restore();
    }

    function sky(ctx) {
      const rng=random(38413);
      const sky=ctx.createLinearGradient(0,0,0,height);
      sky.addColorStop(0,'#81b6d5');sky.addColorStop(.44,'#c1dfed');sky.addColorStop(1,'#f5f7ee');
      ctx.fillStyle=sky;ctx.fillRect(0,0,width,height);
      for(let i=0;i<32;i++)cloud(ctx,-250+rng()*width,-100+rng()*height,300+rng()*600,140+rng()*190,rng,.86);
      const sun=ctx.createRadialGradient(615,120,5,615,120,650);
      sun.addColorStop(0,'#fffefbd0');sun.addColorStop(.2,'#fffefb38');sun.addColorStop(1,'#fffefb00');
      ctx.fillStyle=sun;ctx.fillRect(0,0,width,height);
    }

    function floor(ctx) {
      const rng=random(47389);
      // The entire roof sits on a sheer tower. Its masonry falls into the cloud
      // bank; the projecting stair tower is drawn separately in front of it.
      polygon(ctx,[[202,328],[232,300],[232,1036],[174,1280],[174,390]],'#68664a');
      polygon(ctx,[[1816,300],[1846,328],[1874,1280],[1816,1036]],'#4f563f');
      const plinth=[[202,1004],[1846,1004],[1874,1280],[174,1280]];
      clipped(ctx,plinth,()=>{
        masonry(ctx,174,1004,1700,276,rng,104,34,true);
        for(let x=210;x<1840;x+=210){ctx.fillStyle='#333b2d16';ctx.fillRect(x,1004,18,276);}
        const fall=ctx.createLinearGradient(0,1080,0,1280);
        fall.addColorStop(0,'#e7f0e900');fall.addColorStop(1,'#e7f0e9d8');
        ctx.fillStyle=fall;ctx.fillRect(174,1080,1700,200);
      });
      ctx.fillStyle='#575d42';ctx.fillRect(232,300,1584,712);
      tiles(ctx,250,324,1548,686,rng,62);
      const sun=ctx.createRadialGradient(940,570,45,1030,640,870);
      sun.addColorStop(0,'#fff7d33a');sun.addColorStop(.6,'#e2d4ad10');sun.addColorStop(1,'#3a443c35');
      ctx.fillStyle=sun;ctx.fillRect(250,324,1548,686);
      // Long, unadorned parapet slabs match the reference's silhouette.
      ctx.fillStyle='#8d8c65';ctx.fillRect(232,300,1584,24);
      ctx.fillStyle='#b4af86';ctx.fillRect(234,300,1580,5);
      ctx.fillStyle='#5f674c';ctx.fillRect(232,324,18,686);ctx.fillRect(1798,324,18,686);
      ctx.fillStyle='#b6b18a';ctx.fillRect(232,324,5,686);ctx.fillRect(1798,324,5,686);
      line(ctx,[[250,324],[250,1010]],'#404d3430',7);
      line(ctx,[[1797,324],[1797,1010]],'#404d3430',7);
      // Fine paving and a narrow weathered edge leave the entire roof open.
      // The only architectural shadow belongs to the rear sanctuary ramp.
      line(ctx,[[264,330],[264,994],[1784,994],[1784,330]],'#746f5145',3);
      polygon(ctx,[[800,324],[1255,324],[1300,363],[840,363]],'#474b3928');
      for(let i=0;i<210;i++) {
        const x=258+rng()*1530,y=i%2?330+rng()*20:975+rng()*20;
        ctx.fillStyle=i%3?'#68744435':'#d6cc9b80';
        ctx.fillRect(x,y,2+rng()*7,2+rng()*4);
      }
      for(const [x,y] of [[605,414],[1360,477],[845,827],[1510,741]]) {
        line(ctx,[[x,y],[x+10,y+17],[x+5,y+37],[x+27,y+48],[x+31,y+76]],'#655c4380',2);
        line(ctx,[[x+5,y+37],[x-13,y+44],[x-17,y+59]],'#655c4360');
      }
    }

    function rear(ctx) {
      const rng=random(1979);
      // A steep stone ramp rises to thin upright teeth, rather than a wide
      // fortress wall. Its side buttresses are the angular shoulders in the art.
      const ramp=[[176,348],[496,348],[444,100],[256,100]];
      polygon(ctx,[[143,348],[176,348],[256,100],[234,78]],'#61684b','#414c38');
      polygon(ctx,[[496,348],[530,348],[467,78],[444,100]],'#454e39','#39432f');
      polygon(ctx,ramp,'#a29875','#5c6349');
      // Project the same square paving up the raised sanctuary face.
      const point=(u,v)=>[256+(444-256)*u+(-80+132*u)*v,100+248*v];
      for(let row=0;row<7;row++)for(let col=0;col<6;col++) {
        const a=point(col/6,row/7),b=point((col+1)/6,row/7),
          c=point((col+1)/6,(row+1)/7),d=point(col/6,(row+1)/7);
        const t=127+Math.floor(rng()*29);
        polygon(ctx,[a,b,c,d],`rgb(${t+23},${t+11},${t-10})`,'#726c5360');
        if(rng()<.22)line(ctx,[a,[(a[0]+c[0])/2+4,(a[1]+c[1])/2],c],'#5d614775');
      }
      const crest=[[234,112],[234,68],[250,63],[250,89],[278,89],[278,39],[296,34],
        [300,80],[327,80],[327,12],[345,8],[350,70],[373,70],[376,0],[394,4],
        [397,77],[421,80],[421,36],[440,43],[440,95],[461,101],[467,127]];
      polygon(ctx,crest,'#666b4c','#414b36');
      for(const [x,y,h] of [[234,68,44],[278,39,50],[327,12,68],[376,4,70],[421,40,55]]) {
        ctx.fillStyle='#9a9a6d';ctx.fillRect(x,y,5,h);
        line(ctx,[[x,y],[x+15,y-3]],'#b2ad8155',2);
      }
      polygon(ctx,[[143,348],[173,246],[204,239],[176,348]],'#8c9065','#535d40');
      polygon(ctx,[[496,348],[475,240],[509,247],[530,348]],'#505c40','#3c4933');
      polygon(ctx,[[173,246],[202,219],[226,225],[204,239]],'#b0ad7f');
      polygon(ctx,[[475,240],[459,225],[487,219],[509,247]],'#8f9168');
      polygon(ctx,[[123,348],[123,304],[178,293],[178,348]],'#8b8e64','#525d40');
      polygon(ctx,[[494,348],[494,293],[550,304],[550,348]],'#687351','#45523b');
      line(ctx,[[179,345],[256,102]],'#d1c7a15c',3);
      line(ctx,[[493,345],[444,102]],'#b2ad785c',3);
    }

    function front(ctx) {
      const rng=random(48219);
      // A low roof lip, slim descending stairs and a projecting landing match
      // the reference without freestanding columns obscuring the battle.
      for(const x of [0,952]) {
        ctx.fillStyle='#827e56';ctx.fillRect(x,0,632,42);
        ctx.fillStyle='#aca67c';ctx.fillRect(x,0,632,7);
        ctx.fillStyle='#3f4b3560';ctx.fillRect(x,36,632,6);
        masonry(ctx,x,42,632,38,rng,74,38);
        masonry(ctx,x,80,632,210,rng,102,32,true);
        ctx.fillStyle='#b1aa7c';ctx.fillRect(x,80,632,7);
        ctx.fillStyle='#39462d45';ctx.fillRect(x,89,632,6);
      }
      polygon(ctx,[[632,10],[952,10],[1062,238],[522,238]],'#3c4832');
      polygon(ctx,[[632,0],[952,0],[1004,158],[580,158]],'#7e815a','#505b3e');
      polygon(ctx,[[650,0],[934,0],[974,158],[610,158]],'#b2aa83');
      for(let i=0;i<18;i++) {
        const y=i*8.6,x=650-i*2.25,w=284+i*4.5;
        ctx.fillStyle=i%2?'#bbb18a':'#afa77d';ctx.fillRect(x,y,w,5.8);
        ctx.fillStyle='#5f6247';ctx.fillRect(x,y+5.8,w,2.8);
        ctx.fillStyle='#e0d5a7';ctx.fillRect(x,y,w,1.2);
        if(i%4===1)line(ctx,[[x+95,y],[x+98,y+5]],'#7d795975');
      }
      polygon(ctx,[[548,158],[1036,158],[1048,238],[536,238]],'#a19b73','#5a6445');
      clipped(ctx,[[548,158],[1036,158],[1048,238],[536,238]],()=>tiles(ctx,536,158,512,80,rng,39));
      // A small recessed stairwell on the landing is a distinctive reference detail.
      polygon(ctx,[[744,174],[840,174],[849,222],[735,222]],'#585f42','#cdc196');
      polygon(ctx,[[754,180],[830,180],[837,215],[747,215]],'#25382b');
      for(let i=0;i<6;i++)line(ctx,[[753-i,181+i*5],[830+i,181+i*5]],'#868566',2);
      line(ctx,[[742,174],[733,222]],'#ded1a2',3);
      line(ctx,[[842,174],[851,222]],'#a5a276',3);
      // Landing parapets, then the smaller foreground tower disappearing down.
      polygon(ctx,[[548,158],[564,159],[552,232],[536,238]],'#6f7951','#4d5b3a');
      polygon(ctx,[[1020,159],[1036,158],[1048,238],[1032,232]],'#69754d','#4d5b3a');
      masonry(ctx,536,238,512,52,rng,92,26,true);
      ctx.fillStyle='#ada77d';ctx.fillRect(536,238,512,7);
      ctx.fillStyle='#39432f40';ctx.fillRect(536,246,512,6);
      line(ctx,[[632,0],[580,158],[548,158]],'#c4bd90',5);
      line(ctx,[[952,0],[1004,158],[1036,158]],'#aeb085',5);
      const fog=ctx.createLinearGradient(0,208,0,290);
      fog.addColorStop(0,'#edf4ef00');fog.addColorStop(1,'#edf4efa0');
      ctx.fillStyle=fog;ctx.fillRect(0,208,1584,82);
    }

    function texture(scene,name,w,h,paint) {
      if(scene.textures.exists(name))return;
      const canvas=document.createElement('canvas');canvas.width=w;canvas.height=h;
      const ctx=canvas.getContext('2d');
      if(!ctx)throw Error('Sky Pillar canvas unavailable');
      ctx.imageSmoothingEnabled=false;paint(ctx);
      const result=scene.textures.addCanvas(name,canvas);
      if(!result)throw Error('Sky Pillar texture unavailable');
      result.setFilter(G.Textures.FilterMode.NEAREST);
    }
    async function load(scene,progress) {
      const floorKey=su(id);progress?.track(floorKey);
      try {
        texture(scene,key('sky'),width,height,sky);
        texture(scene,key('rear'),800,350,ctx=>{
          // Keep the highest broken teeth inside the native world camera bounds.
          ctx.translate(15,30);ctx.scale(1.12,.9);rear(ctx);
        });
        texture(scene,key('front'),1584,290,front);
        texture(scene,key('mist'),1024,180,ctx=>cloud(ctx,-30,-25,1080,240,random(735),.92));
        // Publish the native stage key last, after the architectural layers.
        texture(scene,floorKey,width,height,floor);
        progress?.finish(floorKey);return true;
      } catch(error) {
        progress?.resetInflight(floorKey);
        console.warn('[Rocket Menu] Could not prepare Sky Pillar.',error);return false;
      }
    }
    function place(scene) {
      if(!scene.textures.exists(su(id)))return;
      // Sky and drifting mist keep their atmospheric colors; only the solid
      // roof and architecture receive the game's stone material treatment.
      scene.add.image(0,0,key('sky')).setOrigin(0,0).setDepth(-1);
      const ground=scene.add.image(0,0,su(id)).setOrigin(0,0).setDepth(0);
      rocketArenaMaterial.ground(ground,id);
      scene.rocketArenaScenery=true;
      const add=(name,x,y,foot)=>{
        const sprite=scene.add.image(x,y,key(name)).setOrigin(0,0).setDepth(4+foot/1000000);
        rocketArenaMaterial.ground(sprite,id,[x/width,y/height,sprite.width/width,sprite.height/height]);
        return sprite;
      };
      add('rear',624,-26,324);
      add('front',232,990,1010);
      const mist=[];
      for(const [x,y,scale,alpha] of [[-350,1170,1.3,.74],[1390,1182,1.2,.73],[-570,60,.7,.35],[1650,95,.7,.38]]) {
        const sprite=scene.add.image(x,y,key('mist')).setOrigin(0,0).setDepth(4.9).setScale(scale).setAlpha(alpha);
        mist.push(sprite);
        scene.tweens.add({targets:sprite,x:x+26,y:y+6,duration:15000,delay:mist.length*900,yoyo:true,repeat:-1,ease:'Sine.easeInOut'});
      }
      scene.events.once('shutdown',()=>{
        scene.rocketArenaScenery=false;
        for(const sprite of mist)scene.tweens.killTweensOf(sprite);
      });
    }
    return Object.freeze({id,width,height,stage,combat,load,place});
  }

  function patch(source) {
    function once(before,after) {
      const chunks=source.split(before);
      if(chunks.length!==2)throw Error('Unsupported Sky Pillar anchor: '+before);
      source=chunks.join(after);
    }
    // Deliberately do not register in ou/ru: only the boss scene requests this ID.
    once('function cu(e){','function cu(e){if(e===arenaSkyPillar.id)return arenaSkyPillar.stage;');
    once('function Pa(e){','function Pa(e){if(e===arenaSkyPillar.id)return arenaSkyPillar.combat;');
    once('function K(e){','function K(e){if(e===arenaSkyPillar.stage.labelKey)return "Sky Pillar";');
    once('async function pH(e,t,n){','async function pH(e,t,n){if(t===arenaSkyPillar.id){const ready=await arenaSkyPillar.load(e,n);hH(e,ai(`vfx/fire/stat_down_tag.png`),`stat-down`);return ready}');
    once('placeGround(e){','placeGround(e){if(e===arenaSkyPillar.id){if(!this.groundPlaced&&this.alive&&this.textures.exists(su(e))){this.groundPlaced=true;arenaSkyPillar.place(this)}return}');
    return 'const arenaSkyPillar=('+createArenaSkyPillar.toString()+')();globalThis.arenaSkyPillar=arenaSkyPillar;\n'+source;
  }
  const api=Object.freeze({patch});
  globalThis.ArenaSkyPillarAdapter=api;
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})();
