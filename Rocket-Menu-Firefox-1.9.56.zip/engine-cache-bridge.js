// Isolated-world bridge: only the fixed verified public engine can be returned.
(() => {
  'use strict';
  if (location.origin !== 'https://poke2darena.com' ||
      !['/play-online/','/play-online'].includes(location.pathname)) return;
  let pending = false, requests = 0;
  window.addEventListener('message',async event=>{
    const data = event.data;
    if (event.source !== window || event.origin !== location.origin || data?.type !== 'rocket-engine-cache-request' ||
        typeof data.requestId !== 'string' || !/^[a-f0-9]{32}$/.test(data.requestId) || pending || requests >= 3) return;
    pending = true; requests++;
    let response = null;
    try { response = await browser.runtime.sendMessage({type:'arena-compatible-engine-cache'}); } catch {}
    let engine = response?.engine;
    if (typeof engine?.source !== 'string' || engine.source.length > 8 * 1024 * 1024) engine = null;
    window.postMessage({type:'rocket-engine-cache-response',requestId:data.requestId,engine,metadata:response?.metadata},location.origin);
    pending = false;
  });
})();
