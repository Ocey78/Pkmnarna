// A local, open-ended practice duel using the game's standard party and switch logic.
(() => {
  'use strict';

  function arenaTrainingWorldType() {
    function initialTeam(lead, slots, moves) {
      const members = [];
      function add(id, set) {
        if (!id || members.length === 3 || members.some(member => member.id === id)) return;
        members.push({id: dn(id).id, set: set ? set.slice() : null});
      }
      for (const [index, id] of (slots || []).entries()) add(id, moves?.[index]);
      if (!members.length) add(lead);
      // The classic opponent configuration can contain just its lead.
      const preferred = lead || members[0]?.id || rn[0].id;
      for (const species of Ha(preferred)) add(species.id);
      for (const species of rn) {
        if (members.length === 3) break;
        add(species.id);
      }
      return {slots: members.map(member => member.id), moves: members.map(member => member.set)};
    }

    return class ArenaTrainingWorld extends bc {
      constructor(options = {}) {
        const player = initialTeam(options.playerSpeciesId, options.partyIds, options.partyLoadouts);
        const opponent = initialTeam(options.opponentSpeciesId, options.opponentPartyIds, options.opponentPartyLoadouts);
        const lead = player.slots.includes(options.playerSpeciesId) ? options.playerSpeciesId : player.slots[0];
        const foe = opponent.slots.includes(options.opponentSpeciesId) ? options.opponentSpeciesId : opponent.slots[0];
        super({...options, ai: true, playerAi: false, cpuSwitch: true, difficulty: options.difficulty ?? 'hard', clock: 'countup',
          rosterForms: true, thirdPartyIds: undefined, thirdPartyLoadouts: undefined, partyHpRatio: null,
          bossAdvantage: undefined, playerSpeciesId: lead, opponentSpeciesId: foe,
          partyIds: player.slots, partyLoadouts: player.moves, opponentPartyIds: opponent.slots, opponentPartyLoadouts: opponent.moves});
        this.arenaTraining = true;
        this.trainingEvents = [];
        this.activeIndex = this.partyIds.indexOf(lead);
        this.player.loadout = this.memberLoadout('player', this.playerSpecies).slice();
      }

      getState() {
        const state = super.getState();
        state.training = true;
        return state;
      }

      configureCpu(ai, difficulty) {
        this.ai = ai;
        this.cpuSwitch = ai;
        this.tuning = Jo(difficulty);
        this.aiMemory = Yo();
        if (!ai) {
          this.cancelBufferedInput('opponent');
          this.opponent.cast = null;
          this.opponent.pendingAction = null;
          this.opponent.dodgeVx = 0;
          this.opponent.dodgeVy = 0;
        }
      }

      step(...commands) {
        const next = super.step(...commands);
        if (this.trainingEvents.length) next.events = this.trainingEvents.splice(0).concat(next.events);
        return next;
      }

      reset() {
        super.reset();
        this.activeIndex = Math.max(0, this.partyIds.indexOf(this.playerSpecies.id));
        this.player.loadout = this.memberLoadout('player', this.playerSpecies).slice();
        this.trainingEvents = [];
      }

      // sendOut normally writes the outgoing fighter back to the old active
      // slot. The replacement party already contains its intended HP and moves.
      trainingSendOut(side, members, slot, cause) {
        if (side === 'player') {
          this.party = members;
          this.activeIndex = -1;
        } else {
          this.foeParty = members;
          this.foeActiveIndex = -1;
        }
        this.zones = this.zones.filter(zone => zone.owner !== side);
        this.sendOut(side, slot, cause);
      }

      resolveKnockouts() {
        for (const side of ['player', 'opponent']) {
          const fighter = this.fighterOf(side);
          this.rememberHp(fighter);
          if (fighter.hp > 0) continue;
          const reserve = nt(this.partyOf(side), this.activeOf(side));
          if (reserve !== null) {
            this.sendOut(side, reserve, 'faint');
            continue;
          }
          const player = side === 'player';
          const members = player ? this.makeParty() : this.makeFoeParty();
          if (player) this.playerMegaUsed = false;
          else this.foeMegaUsed = false;
          this.trainingSendOut(side, members, 0, 'faint');
          fighter.energy = 100;
          fighter.dodgeCd = 0;
        }
      }

      applyTrainingTeam(side, team) {
        if (side !== 'player' && side !== 'opponent') throw Error('Choose a training side.');
        const slots = team?.slots;
        if (!Array.isArray(slots) || slots.length !== 3 || new Set(slots).size !== 3 || slots.some(id => !hn.has(id))) {
          throw Error('Choose three different Pokémon.');
        }
        const moves = slots.map((id, index) => {
          const set = team.moves?.[index];
          if (set == null) return null;
          const normalized = Array.isArray(set) ? Mn(id, set) : null;
          if (!normalized) throw Error('Check the moves for ' + dn(id).name + '.');
          return normalized.slice();
        });
        // Validate the complete edit before changing live battle state.
        const fresh = this.membersFrom(slots, moves);
        const player = side === 'player';
        const originalIds = player ? this.partyIds : this.foePartyIds;
        const party = this.partyOf(side);
        const fighter = this.fighterOf(side);
        const oldSlot = this.activeOf(side);
        const preservedSlot = slots.indexOf(originalIds[oldSlot]);
        this.rememberHp(fighter);
        this.rememberField(fighter);
        const members = fresh.map((member, slot) => {
          const oldIndex = originalIds.indexOf(slots[slot]);
          if (oldIndex < 0) return member;
          const old = party[oldIndex];
          // A member can currently be Mega Evolved. Keep its battle form and
          // damage when moving its slot or changing only its equipment.
          const cds = member.cds.map((_, index) => old.loadout[index] === member.loadout[index] ? old.cds[index] : 0);
          return {...old, loadout: member.loadout.slice(), cds};
        });
        // A reorder can put an already-fainted teammate in the vacated slot.
        // At least one newly added member is healthy when the active ID changes.
        const nextSlot = preservedSlot >= 0 ? preservedSlot : members[oldSlot].hp > 0 ? oldSlot : members.findIndex(member => member.hp > 0);
        if (player) {
          this.partyIds = slots.slice(); this.partyLoadouts = moves; this.playerSpecies = dn(slots[0]);
        } else {
          this.foePartyIds = slots.slice(); this.foePartyLoadouts = moves; this.opponentSpecies = dn(slots[0]);
        }
        if (preservedSlot >= 0) {
          if (player) { this.party = members; this.activeIndex = nextSlot; }
          else { this.foeParty = members; this.foeActiveIndex = nextSlot; }
          const member = members[nextSlot];
          if (fighter.loadout.length !== member.loadout.length || fighter.loadout.some((id, i) => id !== member.loadout[i])) {
            fighter.cast = null; fighter.pendingAction = null; this.cancelBufferedInput(side);
            fighter.loadout = member.loadout.slice(); fighter.cds = member.cds.slice();
          }
        } else {
          const previousEvents = this.events;
          this.events = [];
          try {
            this.trainingSendOut(side, members, nextSlot, 'swap');
            this.trainingEvents.push(...this.events);
          } finally { this.events = previousEvents; }
        }
        return this.getState();
      }
    };
  }

  function patch(source) {
    return arenaTrainingWorldType.toString() + '\n' + source;
  }
  const api = Object.freeze({patch, arenaTrainingWorldType});
  globalThis.ArenaTrainingWorldAdapter = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})();
