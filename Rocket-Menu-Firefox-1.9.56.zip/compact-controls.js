// Keep the native button artwork, input bindings and HUD geometry in agreement.
(() => {
  'use strict';

  function arenaCompactDesktopAttacks(width, height, scale) {
    const moveWidth = 84 * scale;
    const mobilityWidth = 44 * scale;
    const gap = 4 * scale;
    const bottom = height - 4 * scale;
    const rowWidth = 4 * moveWidth + mobilityWidth + 4 * gap;
    let x = Math.round((width - rowWidth) / 2);
    const buttons = [];
    // The native row places Dash before the four move keys.
    for (const slot of [2, 0, 1, 3, 4]) {
      const w = slot === 2 ? mobilityWidth : moveWidth;
      const h = (slot === 2 ? 22 : 27) * scale;
      buttons[slot] = {x, y: bottom - h, w, h};
      x += w + gap;
    }
    return buttons;
  }

  function arenaCompactTouchAttacks(buttons, width, height, leftHanded) {
    return buttons.map((rect, slot) => {
      // Pull the thumb fan toward its own corner on either handedness. Keep
      // a full touch target underneath the smaller visible mobility disc.
      const originalCenter = rect.x + rect.w / 2;
      const fromEdge = leftHanded ? originalCenter : width - originalCenter;
      const x = leftHanded ? fromEdge * 0.9 : width - fromEdge * 0.9;
      const y = height - (height - rect.y - rect.h / 2) * 0.9;
      const w = slot === 2 ? 44 : Math.max(44, Math.round(rect.w * 0.88));
      const h = w + 4;
      return {x:Math.round(x - w / 2), y:Math.round(y - h / 2), w, h};
    });
  }

  function patch(source) {
    function replace(before, after) {
      const parts = source.split(before);
      if (parts.length !== 2) throw Error('Unsupported game build for compact ability controls: ' + before);
      source = parts.join(after);
    }
    replace('attacks:Wm(i,a,o)', 'attacks:arenaCompactDesktopAttacks(i,a,o)');
    replace('attacks:Hm(i,a,n)', 'attacks:arenaCompactTouchAttacks(Hm(i,a,n),i,a,n.leftHanded)');

    // The same native seconds label supplies both the spoken description and
    // the visible timer. Keep native cooldown bars and rings underneath.
    const state = 'e.disabled=!1,e.dataset.state=l.state,e.setAttribute(`aria-label`,';
    replace(state, 'e.disabled=!1,e.dataset.state=l.state,' +
      'l.face.kind===`cd`&&e.dataset.cooldownSeconds!==l.face.label&&(e.dataset.cooldownSeconds=l.face.label),' +
      'e.setAttribute(`aria-label`,');
    for (const [face,draw] of [
      ['_', 'Ng(o,_.label,r-4-e,3,i,n.outline)'],
      ['g', 'Ng(o,g.label,b-Math.ceil(e/2),b-5,r,n.outline)']
    ]) replace(draw, face + '.kind!==`cd`&&' + draw);

    const touchRule = '.dock.mobile .attack { border-radius: 50%; }';
    replace(touchRule, touchRule + `
      .hud .dock.mobile .attack[data-slot="2"] .attack-skin {
        inset: 16%; width: 68%; height: 68%;
      }
      .hud .dock.desktop .attack[data-slot="2"] .attack-key {
        max-width: 78%; object-fit: contain; object-position: left center;
      }
      .hud .attack[data-state="cd"][data-cooldown-seconds]::after {
        content: attr(data-cooldown-seconds);
        position: absolute; z-index: 3; top: -2px; right: 1px;
        box-sizing: border-box; min-width: 1.2em; padding: 0 0.15em;
        border: 1px solid #a9cde5; border-radius: 0;
        background: #182239; color: #fff3ba;
        font: bold clamp(13px, calc(12px * var(--k, 1)), 48px)/1 Silkscreen, monospace;
        font-variant-numeric: tabular-nums; text-align: center; pointer-events: none;
      }
      .hud .dock.mobile .attack[data-state="cd"]::after {
        top: 50%; left: 50%; right: auto; transform: translate(-50%, -50%);
        font-size: 18px;
      }
    `);
    return arenaCompactDesktopAttacks.toString() + '\n' + arenaCompactTouchAttacks.toString() + '\n' + source;
  }

  const api = Object.freeze({patch});
  globalThis.ArenaCompactControlsAdapter = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})();
