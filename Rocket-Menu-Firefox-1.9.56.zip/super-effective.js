(() => {
  'use strict';

  function patch(original) {
    let source = original;
    function replace(before, after) {
      const parts = source.split(before);
      if (parts.length !== 2) throw Error('Unsupported game build. Could not update damage type effectiveness.');
      source = parts.join(after);
    }

    // Leave the game's damage formulas, caps, STAB, buffs and defense intact.
    // A native 4x matchup stays 4x; the formulas retain their own normal caps.
    replace('damage(e,t,n,r=!1){let i=V(n);',
      'arenaTypeMultiplier(actor,type,types){let value=Ba(type,types);return actor&&this.localOption(actor,"supereffective")?Math.max(2,value):value}' +
      'damage(e,t,n,r=!1){let i=V(n);');
    replace('landBasic(e,t,n,r,i){let a=dn(t.speciesId).types,o=Ba(r,a)',
      'landBasic(e,t,n,r,i){let a=dn(t.speciesId).types,o=this.arenaTypeMultiplier(e,r,a)');
    replace('if(r)return ao(t.maxHp,Ba(Dc(i),a));',
      'if(r)return ao(t.maxHp,this.arenaTypeMultiplier(e,Dc(i),a));');
    replace('s=dn(e.speciesId).types,c=Ba(Dc(i),a);return Kt(',
      's=dn(e.speciesId).types,c=this.arenaTypeMultiplier(e,Dc(i),a);return Kt(');

    // Immunity is checked before normal damage. Use the same actor-specific
    // matchup for that gate and the native hit event shown by either client.
    replace('hitEffect(e,t){if(e.power<=0||e.category===`status`)return null;let n=Ba(Dc(e),dn(t.speciesId).types);',
      'hitEffect(e,t,actor){if(e.power<=0||e.category===`status`)return null;let n=this.arenaTypeMultiplier(actor,Dc(e),dn(t.speciesId).types);');
    replace('let o=V(n),s=this.hitEffect(o,t),c=!1;',
      'let o=V(n),s=this.hitEffect(o,t,e),c=!1;');

    // Ground ultimates have their own max-HP segments, bypassing damage().
    replace('let t=Ba(V(e.move).typeName,dn(n.speciesId).types);e.book=',
      'let t=this.arenaTypeMultiplier(this.fighterOf(e.owner),V(e.move).typeName,dn(n.speciesId).types);e.book=');
    replace('c=this.hitEffect(V(e.move),n)??void 0;',
      'c=this.hitEffect(V(e.move),n,this.fighterOf(e.owner))??void 0;');

    // Segment totals are cached. A live toggle invalidates only that actor's
    // remaining damage book, so later hits obey the current switch setting.
    replace('o=`${t.id}:${a}:${t.speciesId}`;n.hitBook?.key!==o',
      'o=`${t.id}:${a}:${t.speciesId}:${this.localOption(e,"supereffective")}`;n.hitBook?.key!==o');
    replace('o=`${n.id}:${a}:${n.speciesId}`;if(!e.book||e.book.key!==o)',
      'o=`${n.id}:${a}:${n.speciesId}:${this.localOption(this.fighterOf(e.owner),"supereffective")}`;if(!e.book||e.book.key!==o)');
    replace('if(a&&!r){let e=String(t.entry);this.third?(a.hitBooks??={},a.hitBooks[e]??=co(l,o.ticks),l=a.hitBooks[e][o.ticks-a.ticksLeft-1]??0):(a.hitBook?.key!==e&&(a.hitBook={key:e,segs:co(l,o.ticks)}),l=a.hitBook.segs[o.ticks-a.ticksLeft-1]??0)}',
      'if(a&&!r){let key=String(t.entry)+":"+this.localOption(e,"supereffective");this.third?(a.hitBooks??={},a.hitBooks[key]??=co(l,o.ticks),l=a.hitBooks[key][o.ticks-a.ticksLeft-1]??0):(a.hitBook?.key!==key&&(a.hitBook={key,segs:co(l,o.ticks)}),l=a.hitBook.segs[o.ticks-a.ticksLeft-1]??0)}');

    // Hit graphics already use event.effect. Native hit audio instead inferred
    // types again, so prefer an authoritative super event without changing
    // the sounds for other stock effects.
    replace('i=n?Ba(r.typeName,dn(n.speciesId).types):1;for(let e of _T(t.amount,i,!1))',
      'i=n?Ba(r.typeName,dn(n.speciesId).types):1;i=t.effect===`super`?Math.max(2,i):i;for(let e of _T(t.amount,i,!1))');
    return source;
  }

  const api = Object.freeze({patch});
  globalThis.ArenaSuperEffectiveAdapter = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})();
