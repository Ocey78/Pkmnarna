// Replays render recorded state with detached native painters, never a simulator.
(() => {
  'use strict';
  function createArenaReplayVfx(replay, tools, canvas) {
    let current=null, generation=0, index=0, previous=null, lastTime=-1, closed=false, error='';
    const timeline=[], moves=new Set(), options={statusEffects:true};
    for(const frame of replay.frames||[]) {
      timeline.push({time:frame.t,frame,events:[]});
      const groups=new Map();
      for(const event of tools.nativeEvents(replay,frame)||[]) {
        const time=Number.isFinite(event.replayTime)?event.replayTime:frame.t;
        const key=time+':'+event.tick, group=groups.get(key)||{time,frame:null,events:[],tick:event.tick};
        group.events.push(event);groups.set(key,group);
        if(event.move)moves.add(event.move);
      }
      timeline.push(...groups.values());
      const state=tools.nativeState(replay,frame);
      for(const actor of state?.fighters||[])if(actor.castMove)moves.add(actor.castMove);
      for(const shot of state?.projectiles||[])if(shot.move)moves.add(shot.move);
      for(const zone of state?.zones||[])if(zone.move)moves.add(zone.move);
    }
    // A switch event at a sample boundary needs the previous actor before the
    // new snapshot replaces it, even when both share the same recorded time.
    timeline.sort((a,b)=>a.time-b.time||Number(!!a.frame)-Number(!!b.frame));
    function destroy() {
      const fx=current;current=null;previous=null;
      if(!fx)return;
      fx.disposed=true;fx.abort.abort();
      try{fx.sprites?.dispose();}catch{}
      try{fx.balls?.destroy();}catch{}
      for(const key of ['art','moves','fire','status','zones','items'])try{fx[key]?.destroy();}catch{}
      for(const object of fx.objects)if(object.scene)try{object.destroy();}catch{}
      fx.objects.clear();fx.actors.clear();fx.texture?.destroy();
    }
    function loader(scene,fx) {
      const listeners=new Map();let files=[];
      const api={
        on(name,fn){const list=listeners.get(name)||[];list.push({fn,once:false});listeners.set(name,list);return api;},
        once(name,fn){const list=listeners.get(name)||[];list.push({fn,once:true});listeners.set(name,list);return api;},
        off(name,fn){listeners.set(name,(listeners.get(name)||[]).filter(item=>item.fn!==fn));return api;},
        spritesheet(key,url,config){files.push({key,url,frameWidth:config.frameWidth,frameHeight:config.frameHeight});return api;},
        image(key,url){files.push({key,url});return api;},
        start(){
          const batch=files;files=[];
          const emit=(name,value)=>{for(const item of [...(listeners.get(name)||[])]){if(item.once)api.off(name,item.fn);item.fn(value);}};
          const finish=result=>{for(const key of fx.disposed?batch.map(file=>file.key):[...result.failed,...result.absent])emit('loaderror',{key});emit('complete');};
          if(fx.disposed)queueMicrotask(()=>finish({failed:[],absent:[]}));
          else vz(cH(scene),batch).then(finish,()=>finish({failed:batch.map(file=>file.key),absent:[]}));
          return api;
        }
      };
      return api;
    }
    function create() {
      destroy();
      const scene=arenaReplayVfxGame?.scene?.getScenes(true).find(scene=>scene.add&&scene.textures&&scene.sys?.isActive());
      if(!scene)throw Error('No native scene is available for replay art.');
      const fx={scene,objects:new Set(),actors:new Map(),abort:new AbortController(),disposed:false};current=fx;generation++;
      const proxy=Object.create(scene);proxy.add={};proxy.game=Object.create(scene.game);proxy.game.canvas=canvas;
      for(const method of ['graphics','image','sprite','tileSprite'])proxy.add[method]=(...args)=>{
        if(fx.disposed)throw Error('Replay art has closed.');
        const object=scene.add[method](...args);object.removeFromDisplayList();object.removeFromUpdateList?.();
        fx.objects.add(object);return object;
      };
      proxy.load=loader(scene,fx);fx.proxy=proxy;
      fx.texture=scene.textures.addDynamicTexture('rocket-replay-'+(++arenaReplayVfxSerial),2,2);
      if(!fx.texture?.canvas)throw Error('Native replay art requires Canvas graphics.');
      proxy.cameras={main:fx.texture.camera};
      fx.art=new _q(proxy,false,true,true,JK(false,''),true);fx.art.hideLabDuringDischarge=()=>{};
      fx.moves=new GV(proxy);fx.fire=new kz(proxy,fx.actors);fx.status=new yq(proxy);fx.zones=new Yq(proxy,true);
      fx.arenaEffects=createRocketArenaEffects();
      if(typeof createArenaReplayBalls==='function')fx.balls=createArenaReplayBalls(proxy,canvas);
      if(typeof createArenaReplaySprites==='function')fx.sprites=createArenaReplaySprites(proxy,fx.actors,fx.balls);
      const itemScene=Object.create(proxy),prefix='rocket-replay-ghost-'+arenaReplayVfxSerial+'-';itemScene.textures={};
      for(const method of ['exists','get','addSpriteSheet'])itemScene.textures[method]=scene.textures[method].bind(scene.textures);
      itemScene.textures.addCanvas=(key,image)=>scene.textures.addCanvas(prefix+key,image);
      itemScene.textures.remove=key=>{if(key.startsWith(prefix))scene.textures.remove(key);};
      fx.items=new Fq(itemScene);fx.items.arrow=()=>null;fx.items.placeArrow=()=>{};
      const ghost=fx.items.ghostTextureFor.bind(fx.items);
      fx.items.ghostTextureFor=(sprite,layer)=>{
        const key=JSON.stringify([sprite.texture.key,sprite.frame.name,layer]),cached=fx.items.ghostTextures.has(key),texture=ghost(sprite,layer);
        if(cached)return texture;
        const privateKey=prefix+texture;fx.items.ghostTextures.set(key,privateKey);return privateKey;
      };
      fx.assets=Promise.allSettled([Rz(cH(scene),[...moves]),qV(cH(scene),[...moves]),fx.art.loadPolished(),fx.items.load()]);
    }
    function stateAt(time,frame,tick) {
      const source=frame||tools.sample(replay,time), state=tools.nativeState(replay,source);
      if(!state)return null;
      const offset=Math.max(0,time-(source?.t??time));
      state.tick=Number.isFinite(tick)?tick:state.tick+offset/q;
      state.elapsedMs+=offset;
      return state;
    }
    function apply(state,events,note) {
      if(!state||!current)return;
      const fx=current,now=state.tick*q,reduced=ei().display.reduceFlash||Wq();
      fx.state=state;
      if(fx.balls){fx.balls.now=now;if(note)fx.balls.note(events,fx.actors,previous,state);fx.balls.advance();}
      fx.sprites?.update(state,now,events);
      if(note) {
        fx.arenaEffects.note(previous||state,state,events);
        fx.art.note(previous||state,state,events);fx.status.note(previous||state,state,events);fx.fire.noteCombat(events);
        fx.zones.note(fx.art.thunderFieldEnabled?events.filter(event=>!(event.type==='ultZone'&&Go(event.move))&&!(event.type==='hit'&&event.zone&&Go(event.move))):events,state.tick);
        for(const event of events)if(event.type==='hit'&&event.amount>0&&event.zone!==true&&event.basic!==true&&(event.chip||!Pe(event.move))){
          fx.fire.burst(event.chip?'burn-chip':event.move,event.target,event.x,event.y,now,event.actor);
          if(!event.chip)fx.moves.hit(event.move,event.x,event.y,now);
        }
        fx.items.now=now;
        for(const event of events)if(event.type==='itemPick'&&['heal','energy','speed'].includes(event.kind))fx.items.burst(event.x,event.y,event.kind);
        fx.items.paintSpeed(state,fx.actors,true);
        previous=state;
      }
      // Native zone strikes otherwise play an audio cue while drawing.
      for(const zone of fx.zones.lives)zone.voiced=true;
      const zones=fx.zones.sync(state.tick,now,true,()=>{},fx.art.owned,reduced),fallback=LU(state);
      fx.moves.sync(fallback,now,true);fx.art.sync(state,now,true,reduced);
      fx.status.sync(state,options.statusEffects,reduced);fx.fire.sync(fallback,now,true,zones);
      fx.items.sync(state,true,now,()=>({x:0,y:0}),reduced);
    }
    function fail(cause){error=cause?.message||String(cause);destroy();}
    function update(time,frame) {
      if(closed||error)return;
      try {
        if(!current||time<lastTime){create();index=0;}
        for(;index<timeline.length&&timeline[index].time<=time;index++){
          const item=timeline[index],state=stateAt(item.time,item.frame,item.tick);
          if(previous&&state&&state.tick<previous.tick)create();
          apply(state,item.events,true);
        }
        apply(stateAt(time,frame),[],false);lastTime=time;
        canvas.dataset.replayPolished=String(current?.art?.polishedDraws?.length||0);
        canvas.dataset.replayObjects=String([...current?.objects||[]].filter(object=>object.scene&&object.visible!==false&&object.alpha!==0).length);
      }catch(cause){fail(cause);}
    }
    function paint(ctx,front=false) {
      const fx=current;if(closed||error||!fx||fx.disposed)return;
      try {
        const matrix=ctx.getTransform(),texture=fx.texture;
        if(!matrix.a||!matrix.d||matrix.b||matrix.c)return;
        if(texture.width!==canvas.width||texture.height!==canvas.height)texture.setSize(canvas.width,canvas.height,false);
        texture.camera.setOrigin(0,0).setZoom(matrix.a,matrix.d).setScroll(-matrix.e/matrix.a,-matrix.f/matrix.d);texture.camera.roundPixels=true;
        if(fx.balls){fx.balls.setView(matrix);fx.sprites?.paint();}
        if(!front&&fx.state)rocketPaintStageLight(ctx,fx.state,{timeMs:fx.state.tick*q,
          reduced:ei().display.reduceFlash||Wq(),spriteFor:id=>fx.actors.get(id)?.sprite,
          hiddenFighter:id=>fx.balls?.hidesGroundShadow(id)||fx.actors.get(id)?.sprite?.visible===false});
        const objects=[...fx.objects].filter(object=>object.scene&&object.visible!==false&&object.alpha!==0&&(object.depth>=4)===front).sort((a,b)=>a.depth-b.depth);
        const renderer=fx.scene.game.renderer,previousContext=renderer.currentContext;
        try{texture.clear().draw(objects).render();}finally{renderer.setContext(previousContext);}
        ctx.save();try{ctx.setTransform(1,0,0,1,0,0);ctx.imageSmoothingEnabled=false;ctx.drawImage(texture.canvas,0,0);}finally{ctx.restore();}
        if(front&&fx.state){
          fx.arenaEffects.paint(ctx,fx.state,fx.state.tick*q);
          fx.balls?.draw(ctx,fx.actors,fx.state.fighters);
        }
      }catch(cause){fail(cause);}
    }
    return {update,paint,setOptions(next={}){if(typeof next.statusEffects==='boolean')options.statusEffects=next.statusEffects;},dispose(){closed=true;destroy();},get available(){return !!current&&!error;},get error(){return error;},get generation(){return generation;},get scene(){return current?.proxy;},get actors(){return current?.actors;},get hiddenActors(){return new Set(current?.balls?.active.keys()||[]);}};
  }
  function patch(source) {
    const replace=(before,after)=>{const parts=source.split(before);if(parts.length!==2)throw Error('Unsupported replay art anchor.');source=parts.join(after);};
    replace('callbacks:{preBoot:e=>{n&&e.registry.set', 'callbacks:{preBoot:e=>{arenaReplayVfxGame=e;n&&e.registry.set');
    replace('var M1=class extends FQ', 'var arenaReplayVfxGame=null,arenaReplayVfxSerial=0;\n'+createArenaReplayVfx.toString()+'\nvar M1=class extends FQ');
    return source;
  }
  const api=Object.freeze({patch,createArenaReplayVfx});globalThis.ArenaReplayVfxAdapter=api;
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})();
