// Per-frame Shoot head/mouth sockets from the matching PMDCollab source sheets.
// Source: https://github.com/PMDCollab/SpriteCollab/tree/master/sprite
// Latias/Latios: CHUNSOFT. Mega forms: Emmuffin. See README for credits.
(() => {
  'use strict';
  function createRocketEonMouths(){
    const sheets={"latios":{"width":72,"height":88,"frames":12,"anchor":[36,46],"body":32,"points":[[[36,26],[36,25],[36,30],[36,49],[36,51],[37,51],[36,51],[37,51],[36,51],[37,51],[36,51],[36,49]],[[47,24],[46,23],[49,26],[55,42],[59,46],[60,45],[59,46],[60,45],[59,46],[60,45],[59,46],[56,46]],[[53,18],[52,18],[55,16],[60,26],[64,27],[64,28],[64,27],[64,28],[64,27],[64,28],[64,27],[65,30]],[[47,10],[46,11],[49,8],[54,15],[58,11],[59,12],[58,11],[59,12],[58,11],[59,12],[58,11],[58,17]],[[36,10],[36,11],[36,6],[36,11],[36,9],[37,9],[36,9],[37,9],[36,9],[37,9],[36,9],[36,13]],[[25,10],[26,11],[23,8],[18,15],[14,11],[13,12],[14,11],[13,12],[14,11],[13,12],[14,11],[14,17]],[[19,18],[20,18],[17,16],[12,26],[8,27],[8,28],[8,27],[8,28],[8,27],[8,28],[8,27],[7,30]],[[24,24],[25,23],[22,26],[16,42],[12,46],[11,45],[12,46],[11,45],[12,46],[11,45],[12,46],[16,46]]]},"latias":{"width":64,"height":80,"frames":12,"anchor":[32,42],"body":29,"points":[[[32,26],[32,25],[32,30],[32,36],[32,49],[33,49],[32,49],[33,49],[32,49],[33,49],[32,49],[32,48]],[[38,22],[37,21],[40,24],[44,28],[52,44],[53,43],[52,44],[53,43],[52,44],[53,43],[52,44],[49,43]],[[44,23],[43,23],[46,21],[50,22],[58,32],[58,33],[58,32],[58,33],[58,32],[58,33],[58,32],[54,31]],[[39,19],[38,20],[41,17],[43,15],[51,15],[52,16],[51,15],[52,16],[51,15],[52,16],[51,15],[51,19]],[[32,14],[32,15],[32,10],[32,8],[32,7],[33,7],[32,7],[33,7],[32,7],[33,7],[32,7],[32,14]],[[24,19],[25,20],[22,17],[20,15],[12,15],[11,16],[12,15],[11,16],[12,15],[11,16],[12,15],[12,19]],[[19,23],[20,23],[17,21],[13,22],[5,32],[5,33],[5,32],[5,33],[5,32],[5,33],[5,32],[9,31]],[[25,22],[26,21],[23,24],[19,28],[11,44],[10,43],[11,44],[10,43],[11,44],[10,43],[11,44],[14,43]]]},"latiosmega":{"width":88,"height":96,"frames":12,"anchor":[44,50],"body":36,"points":[[[44,50],[44,15],[44,19],[44,53],[44,55],[45,55],[44,55],[45,55],[44,55],[45,55],[44,62],[44,54]],[[61,45],[55,12],[58,14],[63,50],[67,54],[68,53],[67,54],[68,53],[67,54],[68,53],[71,55],[65,50]],[[69,35],[59,16],[62,14],[71,46],[75,47],[75,48],[75,47],[75,48],[75,47],[75,48],[77,35],[73,35]],[[61,25],[49,16],[52,12],[57,31],[61,27],[62,28],[61,27],[62,28],[61,27],[62,28],[69,17],[66,20]],[[44,21],[44,14],[44,8],[44,24],[44,22],[45,22],[44,22],[45,22],[44,22],[45,22],[44,13],[44,17]],[[27,25],[39,16],[36,12],[31,31],[27,27],[26,28],[27,27],[26,28],[27,27],[26,28],[19,17],[22,20]],[[19,35],[29,16],[26,14],[17,46],[13,47],[13,48],[13,47],[13,48],[13,47],[13,48],[11,35],[15,35]],[[26,45],[32,12],[29,14],[24,50],[20,54],[19,53],[20,54],[19,53],[20,54],[19,53],[16,55],[23,50]]]},"latiasmega":{"width":80,"height":88,"frames":12,"anchor":[40,46],"body":32,"points":[[[40,47],[40,14],[40,18],[40,50],[40,52],[41,52],[40,52],[41,52],[40,52],[41,52],[40,59],[40,51]],[[56,43],[50,11],[53,13],[57,47],[61,51],[62,50],[61,51],[62,50],[61,51],[62,50],[66,53],[59,47]],[[63,32],[54,14],[57,12],[65,43],[69,44],[69,45],[69,44],[69,45],[69,44],[69,45],[71,32],[67,32]],[[57,24],[45,13],[48,9],[52,28],[56,24],[57,25],[56,24],[57,25],[56,24],[57,25],[65,16],[61,19]],[[40,18],[40,10],[40,5],[40,21],[40,19],[41,19],[40,19],[41,19],[40,19],[41,19],[40,10],[40,16]],[[23,24],[35,13],[32,9],[28,28],[24,24],[23,25],[24,24],[23,25],[24,24],[23,25],[15,16],[19,19]],[[17,32],[26,14],[23,12],[15,43],[11,44],[11,45],[11,44],[11,45],[11,44],[11,45],[9,32],[13,32]],[[23,43],[29,11],[26,13],[22,47],[18,51],[17,50],[18,51],[17,50],[18,51],[17,50],[13,53],[21,47]]]}};
    const ranged=attack=>['laser','ice','plasma','hurricane'].includes(attack?.kind);
    const clamp=value=>Math.max(0,Math.min(1,Number(value)||0)),beamFrames=[6,7,8,9,4,5];
    function pose(attack={},facing=0){
      const p=clamp(attack.progress),beam=attack.kind==='laser'||attack.kind==='ice'||attack.kind==='hurricane';let progress=.52,column;
      if(attack.phase==='windup')progress=p*.52;
      else if(attack.phase==='active'&&beam){
        // The authored firing/breathing frames repeat while energy is emitted.
        // Use simulation time, never a separate render clock: mouth and damage
        // origins must resolve the identical frame even when rendering pauses.
        const elapsed=Number.isFinite(attack.elapsedMs)?Math.max(0,attack.elapsedMs):p*(Number(attack.durationMs)||1000);
        column=beamFrames[Math.floor(elapsed/85)%beamFrames.length];progress=(column+.5)/12;
      }else if(attack.phase==='active')progress=.52+p*(attack.kind==='plasma'?.26:.1);
      else if(attack.phase==='recover'){
        const saved=attack.recoveryColumn;
        const start=Number.isInteger(saved)?Math.max(0,Math.min(11,saved)):attack.kind==='plasma'?9:6;
        column=Math.min(11,start+Math.floor(p*(12-start)));progress=(column+.5)/12;
      }
      const angle=Number.isFinite(facing)?facing:0;
      // A beam cast can lock its sprite direction while the beam sweeps. This
      // breaks the mouth-position/aim feedback at eight-direction boundaries.
      const row=Number.isInteger(attack.socketRow)&&attack.socketRow>=0&&attack.socketRow<8?attack.socketRow:
        (Math.round(-(angle-Math.PI/2)/(Math.PI/4))%8+8)%8;
      return {name:'shoot',row,column:column??Math.min(11,Math.floor(clamp(progress)*12)),progress};
    }
    function frame(species,attack,facing){
      const sheet=sheets[species];if(!sheet)return null;
      const state=pose(attack,facing),point=sheet.points[state.row][state.column];
      // These four sheets have no native per-frame pivot override, but preserve
      // one if the native renderer provides it in a compatible game update.
      const anchor=typeof XO==='function'?XO(species,'shoot',state.row,state.column,sheet.anchor):sheet.anchor;
      return {...state,point,anchor,width:sheet.width,height:sheet.height,body:sheet.body};
    }
    function scale(actor,body){
      const nominal=typeof Qs!=='undefined'&&typeof ec==='function'?Qs[ec(actor.speciesId)]:null;
      const height=Number.isFinite(nominal)&&Number.isFinite(actor.rocketBossScale)?nominal*actor.rocketBossScale:100;
      return height/body;
    }
    function world(actor,attack={},facing=actor?.facing||0){
      const x=Math.round(Number(actor?.x)||0),y=Math.round(Number(actor?.y)||0),socket=frame(actor?.speciesId,attack,facing);
      if(!socket)return{x,y:y-(Number(actor?.radius)||30)};
      const factor=scale(actor,socket.body);
      return{x:x+(socket.point[0]-socket.anchor[0])*factor,y:y+(socket.point[1]-socket.anchor[1])*factor};
    }
    return Object.freeze({ranged,pose,frame,scale,world});
  }
  function patch(source){return 'const rocketEonMouths=('+createRocketEonMouths.toString()+')();globalThis.rocketEonMouths=rocketEonMouths;\n'+source;}
  const api=Object.freeze({patch});globalThis.ArenaEonMouthsAdapter=api;
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})();
