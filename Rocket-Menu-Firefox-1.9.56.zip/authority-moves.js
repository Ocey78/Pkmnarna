(() => {
  'use strict';

  function arenaAnyMoveStart(start, seat, selectedTeam, selectedMoves) {
    if (!arenaModEnabled('anymove') || (seat !== 'A' && seat !== 'B') ||
        start?.direct?.host !== seat || start.mode === 'ffa3' || start.teams?.C ||
        !Array.isArray(selectedTeam) || !Array.isArray(selectedMoves)) return start;
    const team = start.teams?.[seat];
    if (!Array.isArray(team)) return start;
    const original = start.loadouts?.[seat] || [];
    const moves = team.map((species, index) => {
      const selected = selectedMoves[selectedTeam.indexOf(species)];
      if (Array.isArray(selected) && Tn(species, selected, true)) return selected.slice();
      return original[index] ? original[index].slice() : null;
    });
    // Only the browser selected by the game's Direct handshake constructs Cw.
    // Keep the accepted match metadata and give its own fighter the chosen
    // loadout. Native snapshots publish these moves to the ordinary opponent.
    return {...start, loadouts: {...start.loadouts, [seat]: moves}};
  }

  function patch(source) {
    const anchor = 'this.authority=new Cw(e,';
    const parts = source.split(anchor);
    if (parts.length !== 2) throw Error('Unsupported game build. Could not find the Direct authority constructor.');
    return arenaAnyMoveStart.toString() + '\n' +
      parts.join('this.authority=new Cw(arenaAnyMoveStart(e,this.you,this.team,this.moves),');
  }

  globalThis.ArenaAuthorityMovesAdapter = Object.freeze({patch});
  if (typeof module !== 'undefined' && module.exports) module.exports = {patch, arenaAnyMoveStart};
})();
