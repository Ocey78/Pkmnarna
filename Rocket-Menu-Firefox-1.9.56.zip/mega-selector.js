// Saved Mega evolution preferences and Auto Evolve; native teams store base forms.
(() => {
  'use strict';

  function arenaMegaFamily(id) {
    if(typeof id!=='string')return null;
    const base=an(id)??id,forms=on(base);
    const x=forms.find(form=>form.endsWith('x')&&hn.has(form));
    const y=forms.find(form=>form.endsWith('y')&&hn.has(form));
    return x&&y?{base,x,y}:null;
  }
  function arenaNormalizeMegaForms(raw) {
    const result={};
    if(!raw||typeof raw!=='object'||Array.isArray(raw))return result;
    for(const base of Object.keys(raw).slice(0,1200)) {
      const family=arenaMegaFamily(base);
      if(family?.base===base&&(raw[base]===family.x||raw[base]===family.y))result[base]=raw[base];
    }
    return result;
  }
  function arenaMegaOptions(id) {
    if(typeof id!=='string')return null;
    const base=an(id)??id,forms=on(base).filter(form=>hn.has(form));
    return forms.length?{base,forms}:null;
  }
  function arenaNormalizeAutoMega(raw) {
    const result={};
    if(!raw||typeof raw!=='object'||Array.isArray(raw))return result;
    for(const base of Object.keys(raw).slice(0,1200))
      if(raw[base]===true&&arenaMegaOptions(base)?.base===base)result[base]=true;
    return result;
  }
  function patchData(source) {
    const once=(before,after)=>{
      const parts=source.split(before);
      if(parts.length!==2)throw Error('Unsupported Mega choice data anchor: '+before.slice(0,80));
      source=parts.join(after);
    };
    once('book.active = zn(Number(raw.active));',
      'book.megaForms = arenaNormalizeMegaForms(raw.megaForms);\n    book.autoMega = arenaNormalizeAutoMega(raw.autoMega);\n    book.active = zn(Number(raw.active));');
    // Preserve choices if an older native client only rewrites its three teams.
    // Explicit imports still pass through arenaTeamBook directly, so an older
    // imported save has no invented preference and retains native auto-choice.
    once('movePresets:Object.hasOwn(raw,"movePresets")?raw.movePresets:prior.movePresets};',
      'movePresets:Object.hasOwn(raw,"movePresets")?raw.movePresets:prior.movePresets, megaForms:Object.hasOwn(raw,"megaForms")?raw.megaForms:prior.megaForms, autoMega:Object.hasOwn(raw,"autoMega")?raw.autoMega:prior.autoMega};');
    return [arenaMegaFamily,arenaNormalizeMegaForms,arenaMegaOptions,arenaNormalizeAutoMega].map(fn=>fn.toString()).join('\n')+'\n'+source;
  }

  function createArenaMegaSelector() {
    let autoCache=null;
    const bossWorld=world=>!!(world?.arenaBossRush||world?.arenaEonBoss||world?.arenaMewtwoBoss);
    function choose(ui,target) {
      const family=arenaMegaFamily(ui.detailId);
      if(ui.movePick||!family||![family.x,family.y].includes(target))return;
      ui.teamBook={...ui.teamBook,megaForms:arenaNormalizeMegaForms({...ui.teamBook.megaForms,[family.base]:target}),everSaved:true};
      er.save(ui.teamBook);
      ui.paintTeams();ui.paintDetail();
    }
    function autoEnabled(id,world) {
      const options=arenaMegaOptions(id);
      if(!options)return false;
      if(bossWorld(world))return arenaBossTeams.read().autoMega?.[options.base]===true;
      autoCache??=arenaNormalizeAutoMega(er.read().autoMega);
      return autoCache[options.base]===true;
    }
    function noteSaved(book) {if(book?.scope!=='boss-rush')autoCache=arenaNormalizeAutoMega(book?.autoMega);}
    function setAuto(ui,enabled) {
      const options=arenaMegaOptions(ui.detailId);
      if(!options||ui.movePick)return;
      const next={...ui.teamBook.autoMega};
      if(enabled===true)next[options.base]=true;else delete next[options.base];
      const normalized=arenaNormalizeAutoMega(next);
      if(ui.teamBook.scope!=='boss-rush')autoCache=normalized;
      ui.teamBook={...ui.teamBook,autoMega:normalized,everSaved:true};
      er.save(ui.teamBook);ui.paintTeams();ui.paintDetail();
    }
    function capability(ui) {
      if(ui.arenaRosterOffline===true)return {canChoose:true,kind:'offline',label:'ON EVOLVE'};
      const status=typeof arenaMegaOnline!=='undefined'?arenaMegaOnline.status():null;
      return status&&status.kind!=='offline'?status:{canChoose:false,kind:'pending',label:'X/Y: DIRECT HOST ONLY'};
    }
    function targetFor(world,actor,fallback) {
      const boss=bossWorld(world);
      if(!boss&&world.arenaSoloMods!==true)return arenaMegaOnline.targetFor(world,actor,fallback);
      if(actor!==world.player)return fallback;
      const family=arenaMegaFamily(actor.speciesId);
      if(!family)return fallback;
      const target=(boss?arenaBossTeams.read():er.read()).megaForms?.[family.base];
      return target===family.x||target===family.y?target:fallback;
    }
    function paint(ui) {
      const detail=ui.pick?.querySelector('.pick-detail'),presets=detail?.querySelector('.rocket-move-presets');
      if(!detail||!presets)return;
      const options=arenaMegaOptions(ui.detailId),family=arenaMegaFamily(ui.detailId),visible=!!options&&!ui.movePick;
      detail.classList.toggle('rocket-has-mega-choice',visible);
      let panel=detail.querySelector('.rocket-mega-selector');
      if(!visible){if(panel)panel.hidden=true;return;}
      if(!panel) {
        panel=document.createElement('section');panel.className='rocket-mega-selector';
        panel.setAttribute('aria-label','Mega evolution');
        const heading=document.createElement('h3');heading.textContent='MEGA';
        const preview=document.createElement('span');preview.className='rocket-mega-preview';
        const art=document.createElement('span');art.className='fit-host';preview.append(art);
        const buttons=document.createElement('div');buttons.className='rocket-mega-options';
        buttons.setAttribute('role','group');buttons.setAttribute('aria-label','Mega evolution form');
        for(const letter of ['X','Y']) {
          const button=document.createElement('button');button.type='button';
          button.dataset.megaChoice=letter.toLowerCase();button.textContent='MEGA '+letter;
          button.addEventListener('click',()=>{
            const selected=arenaMegaFamily(ui.detailId);
            if(selected)choose(ui,selected[button.dataset.megaChoice]);
          });
          buttons.append(button);
        }
        const caption=document.createElement('span');caption.className='rocket-mega-caption';caption.textContent='ON EVOLVE';
        const auto=document.createElement('label');auto.className='rocket-mega-auto';
        const checkbox=document.createElement('input');checkbox.type='checkbox';checkbox.dataset.autoMega='';
        checkbox.addEventListener('change',()=>setAuto(ui,checkbox.checked));
        const autoText=document.createElement('span');autoText.textContent='AUTO EVOLVE';auto.append(checkbox,autoText);
        const notice=document.createElement('span');notice.className='rocket-mega-notice';
        panel.append(heading,preview,buttons,auto,caption,notice);
        for(const type of ['keydown','keyup'])panel.addEventListener(type,event=>{if(event.key!=='Escape')event.stopPropagation();});
        detail.insertBefore(panel,presets);
      }
      panel.hidden=false;
      const slot=ui.pickTeam.indexOf(ui.detailId),moves=Nn(options.base,slot>=0?ui.pickMoves[slot]:null);
      const explicit=ui.teamBook.megaForms?.[options.base],support=capability(ui);
      const target=family&&(explicit===family.x||explicit===family.y)?explicit:sn(options.base,moves);
      const art=panel.querySelector('.fit-host');
      if(art.dataset.species!==target)ui.mountFit(art,target,false);
      panel.querySelector('.rocket-mega-preview').setAttribute('aria-label',dn(target).name+' evolution preview');
      panel.title='Preferred evolution: '+dn(target).name+'. Your starting form and moves stay the same.';
      panel.querySelector('.rocket-mega-options').hidden=!family;
      const automatic=panel.querySelector('[data-auto-mega]');automatic.checked=ui.teamBook.autoMega?.[options.base]===true;
      automatic.title='Use the normal Mega action as soon as evolution is available.';
      panel.querySelector('.rocket-mega-caption').textContent=family&&!support.canChoose?'PREFERRED':'ON EVOLVE';
      const notice=panel.querySelector('.rocket-mega-notice');notice.hidden=!family||ui.arenaRosterOffline===true;
      notice.textContent=support.label||'X/Y: DIRECT HOST ONLY';
      notice.title='X/Y applies when you host Direct. Otherwise the battle uses the native move-based form.';
      for(const button of panel.querySelectorAll('[data-mega-choice]')) {
        const selected=!!family&&target===family[button.dataset.megaChoice];
        button.classList.toggle('is-on',selected);button.setAttribute('aria-pressed',String(selected));
      }
    }
    if(typeof window!=='undefined')window.addEventListener('storage',event=>{
      if(event.key===null||event.key===Pn||event.key==='rocket-menu.team-book.v1')autoCache=null;
    });
    if(typeof document!=='undefined')document.addEventListener('arena-mega-capability',()=>{
      if(typeof Z!=='undefined'&&Z?.pick?.isConnected&&!Z.pick.classList.contains('is-hidden'))paint(Z);
    });
    return {paint,choose,targetFor,autoEnabled,setAuto,capability,noteSaved};
  }

  function patch(source) {
    source=patchData(source);
    const once=(before,after)=>{
      const parts=source.split(before);
      if(parts.length!==2)throw Error('Unsupported Mega selector anchor: '+before.slice(0,80));
      source=parts.join(after);
    };
    once('paintDetail(){arenaMovePresets.paint(this);',
      'paintDetail(){arenaMovePresets.paint(this);arenaMegaSelector.paint(this);');
    once('save(n){try{let r=e();if(!r)throw Error(`Storage unavailable`);return qn(r,n),t=null,!0}',
      'save(n){arenaMegaSelector.noteSaved(n);try{let r=e();if(!r)throw Error(`Storage unavailable`);return qn(r,n),t=null,!0}');
    once('tryMega(e){if(!this.canMega(e.id))return;let t=sn(e.speciesId,e.loadout);',
      'tryMega(e){if(!this.canMega(e.id))return;let t=arenaMegaSelector.targetFor(this,e,sn(e.speciesId,e.loadout));');
    const css=`<style>
      .pick:not(.is-phone) .pick-detail.rocket-has-presets.rocket-has-mega-choice{grid-template-columns:minmax(0,.9fr) 80px minmax(0,1.1fr);gap:6px}
      .pick .rocket-mega-selector{box-sizing:border-box;display:flex;flex-direction:column;align-self:start;gap:5px;min-width:0;padding:5px 3px;border:2px solid var(--ui-frame-hi,#b4b8d3);background:var(--ui-panel,#272f55);color:var(--ui-text,#f8f8f8);font:700 10px/1.3 Silkscreen,monospace;text-align:center}
      .pick .rocket-mega-selector[hidden],.pick.is-editing .rocket-mega-selector{display:none}
      .pick .rocket-mega-selector h3{margin:0;font:inherit;font-size:11px}
      .pick .rocket-mega-preview{display:block;position:relative;width:64px;height:68px;max-width:100%;align-self:center;overflow:hidden}
      .pick .rocket-mega-preview>.fit-host{display:block;width:100%;height:100%}
      .pick .rocket-mega-options{display:grid;gap:4px;min-width:0}
      .pick .rocket-mega-options[hidden]{display:none}
      .pick .rocket-mega-options button{box-sizing:border-box;min-width:0;min-height:29px;padding:3px 1px;border:2px solid var(--ui-outline,#080b18);border-radius:0;background:var(--ui-input-bg,#10152a);color:var(--ui-text,#f8f8f8);font:inherit;font-size:9px;cursor:pointer;white-space:nowrap}
      .pick .rocket-mega-options button:hover{background:var(--ui-cell-selected,#343e70)}
      .pick .rocket-mega-options button.is-on{background:var(--ui-frame,#e8e0cc);color:var(--ui-on-frame,#10142a)}
      .pick .rocket-mega-options button:focus-visible{outline:2px solid var(--ui-cursor,#f87818);outline-offset:1px}
      .pick .rocket-mega-caption{font-size:8px;line-height:1.3;color:var(--ui-text-dim,#bbc1df)}
      .pick .rocket-mega-auto{display:grid;grid-template-columns:16px minmax(0,1fr);align-items:center;gap:4px;min-width:0;margin:2px 0 0;text-align:left;font:inherit;font-size:8px;cursor:pointer}
      .pick .rocket-mega-auto input{appearance:none;box-sizing:border-box;display:block;width:16px;height:16px;margin:0;padding:0;border:2px solid var(--ui-frame-hi,#b4b8d3);border-radius:0;background:var(--ui-input-bg,#10152a);color:var(--ui-text,#fff);cursor:pointer}
      .pick .rocket-mega-auto input:checked::after{content:'X';display:block;font:700 11px/12px Silkscreen,monospace;text-align:center}
      .pick .rocket-mega-auto input:focus-visible{outline:2px solid var(--ui-cursor,#f87818);outline-offset:1px}
      .pick .rocket-mega-notice{font-size:8px;line-height:1.4;color:var(--ui-text-dim,#bbc1df);overflow-wrap:anywhere}
      .pick .rocket-mega-notice[hidden]{display:none}
      .pick:not(.is-phone):not(.is-editing) .pick-main:has(>.rocket-has-presets.rocket-has-mega-choice)>.pager-bar{width:calc(45% - 48.6px)}
      .pick.is-phone .rocket-mega-selector{grid-column:1 / -1;grid-row:7;display:grid;grid-template-columns:auto 48px minmax(0,1fr);gap:6px;align-items:center;margin-top:5px}
      .pick.is-phone .rocket-mega-selector[hidden],.pick.is-phone.is-editing .rocket-mega-selector{display:none}
      .pick.is-phone .rocket-mega-selector h3{grid-column:1;grid-row:1}
      .pick.is-phone .rocket-mega-preview{width:48px;height:44px;grid-column:2;grid-row:1 / 3}
      .pick.is-phone .rocket-mega-options{grid-template-columns:repeat(2,minmax(0,1fr));grid-column:3;grid-row:1}
      .pick.is-phone .rocket-mega-auto{grid-column:3;grid-row:2;justify-self:start}
      .pick.is-phone .rocket-mega-caption{grid-column:1;grid-row:2}
      .pick.is-phone .rocket-mega-notice{grid-column:1 / -1;grid-row:3}
      .pick.is-phone .rocket-has-mega-choice .rocket-move-presets{grid-row:8}
      @media(max-width:480px){.pick.is-phone .rocket-mega-caption{display:none}.pick.is-phone .rocket-mega-selector{grid-template-columns:auto 44px minmax(0,1fr)}}
    </style>`;
    once('function wb(){return`','function wb(){return`'+css);
    return 'const arenaMegaSelector=('+createArenaMegaSelector.toString()+')();\n'+source;
  }
  function helperSource() {
    return '(()=>{\n'+[arenaMegaFamily,arenaNormalizeMegaForms,arenaMegaOptions,arenaNormalizeAutoMega,patchData].map(fn=>fn.toString()).join('\n')+
      '\nglobalThis.ArenaMegaSelectorAdapter=Object.freeze({patch:patchData,patchData});\n})();';
  }
  const api=Object.freeze({patch,patchData,helperSource});
  globalThis.ArenaMegaSelectorAdapter=api;
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})();
