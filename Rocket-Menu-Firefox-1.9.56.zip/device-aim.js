// Make the native saved Auto-aim option available to every input device.
(() => {
  'use strict';

  function arenaDeviceAim(command, controls, slot) {
    if (!ei().controls.autoAim || !controls.pcControls()) return command;
    const buttons = command.buttons;
    if (buttons.dodge || (!buttons.basic && !buttons.attacks.some(Boolean))) return command;

    // A held skill is the desktop equivalent of dragging a touch skill button:
    // its explicit pointer direction continues to override native tap assist.
    if (slot !== 0 && controls.holdToAim) return command;
    const plan = controls.plan[slot];
    const directional = entry => entry && (entry.dash || entry.role === 'mobility' || (entry.moveId && V(entry.moveId).shape === 'dash'));
    if (!plan || directional(plan)) return command;
    // Native execution may select a higher loadout index than the first UI
    // latch, so simultaneous directional/mobility requests must also stay manual.
    if (controls.plan.some(entry => entry && entry.loadoutIndex !== null && buttons.attacks[entry.loadoutIndex] && directional(entry))) return command;

    // Native mobile taps send this same intent. The simulator decides whether
    // a living opponent is in reach; no target position or movement is invented.
    command.aim = { x: 0, y: 0 };
    buttons.snapAim = true;
    buttons.trackMelee = true;
    return command;
  }

  function patch(source) {
    function replace(before, after) {
      const parts = source.split(before);
      if (parts.length !== 2) throw Error('Unsupported game build. Could not enable native Auto-aim for every device.');
      source = parts.join(after);
    }
    replace('if(t===`pc`)return[`hints`,`holdToAim`,`keys`];',
      'if(t===`pc`)return n.autoAim?[`hints`,`autoAim`,`holdToAim`,`keys`]:[`hints`,`holdToAim`,`keys`];');
    replace('t.switchSlot=this.switchSlot,t.buttons.mega=this.megaLatch,t}consumeSample(){',
      't.switchSlot=this.switchSlot,t.buttons.mega=this.megaLatch,arenaDeviceAim(t,this,a)}consumeSample(){');
    return arenaDeviceAim.toString() + '\n' + source;
  }

  const api = Object.freeze({ patch });
  globalThis.ArenaDeviceAimAdapter = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})();
