// Apply after Private Combat and Rapid Fire. This removes only the post-attack
// recovery timer for actors authorized by the shared localOption resolver.
(() => {
  'use strict';
  function patch(original) {
    let source=original;
    function replace(anchor,replacement) {
      const at=source.indexOf(anchor);
      if(at<0||source.indexOf(anchor,at+anchor.length)!==-1)
        throw new Error('Unsupported game build. Missing or ambiguous recovery anchor: '+anchor.slice(0,80));
      source=source.slice(0,at)+replacement+source.slice(at+anchor.length);
    }
    // Tag provenance even while disabled, so enabling during a real recovery
    // clears that remaining delay without clearing unrelated native locks.
    replace('endCast(e,t){let n=V(t.moveId);e.cast=null,!t.basic&&n.shape!==`self`&&(e.recoverMs=n.recoverMs)}',
      'postAttackRecovery(e,ms){e.arenaAttackRecovery=true;return this.localOption(e,"norecovery")?0:ms}endCast(e,t){let n=V(t.moveId);e.cast=null,!t.basic&&n.shape!==`self`&&(e.recoverMs=this.postAttackRecovery(e,n.recoverMs))}');
    replace('this.shoot(e,t,s,i),e.recoverMs=t.recoverMs',
      'this.shoot(e,t,s,i),e.recoverMs=this.postAttackRecovery(e,t.recoverMs)');
    // Keep `a` from before clearing: native buffered actions must still release
    // when recovery ends because the option was enabled mid-recovery.
    replace('let a=e.recoverMs>0;e.recoverMs=kc(e.recoverMs)',
      'let a=e.recoverMs>0;if(e.arenaAttackRecovery&&this.localOption(e,"norecovery"))e.recoverMs=0;e.recoverMs=kc(e.recoverMs)');

    // Mega transformation is the only other positive recoverMs writer in this
    // build. Preserve its 700ms transition, plus native iframe/switch timers.
    replace('e.recoverMs=Math.max(e.recoverMs,700)',
      'e.arenaAttackRecovery=false,e.recoverMs=Math.max(e.recoverMs,700)');
    replace('i.cast=null,i.recoverMs=0,i.pendingAction=null',
      'i.cast=null,i.recoverMs=0,i.arenaAttackRecovery=false,i.pendingAction=null');
    replace('e.hp<=0&&(e.cast=null,e.recoverMs=0,e.pendingAction=null)',
      'e.hp<=0&&(e.cast=null,e.recoverMs=0,e.arenaAttackRecovery=false,e.pendingAction=null)');

    // Publish the effective post-attack state without consuming the pending
    // input buffer. The following simulation tick performs the actual clear.
    replace('recoverMs:e.recoverMs,hp:e.hp',
      'recoverMs:e.arenaAttackRecovery&&this.localOption(e,"norecovery")?0:e.recoverMs,hp:e.hp');
    replace('*(e.recoverMs>0?re:1)',
      '*(e.recoverMs>0&&!(e.arenaAttackRecovery&&this.localOption(e,"norecovery"))?re:1)');
    return source;
  }
  const api=Object.freeze({patch});
  globalThis.ArenaNoRecoveryAdapter=api;
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})();
