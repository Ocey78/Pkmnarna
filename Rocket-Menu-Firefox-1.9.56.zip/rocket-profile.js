// Separate, versioned Rocket history. Native saves and online packets are unchanged.
(() => {
  'use strict';
  function createRocketProfileBadges(){
    const artwork=new Map(),selectedSlots=new WeakMap();
    const badges=[
      {id:'streak-10',name:'Poké Ball',requirement:'10 online wins in a row',kind:'poke'},
      {id:'streak-20',name:'Great Ball',requirement:'20 online wins in a row',kind:'great'},
      {id:'streak-50',name:'Ultra Ball',requirement:'50 online wins in a row',kind:'ultra'},
      {id:'streak-100',name:'Master Ball',requirement:'100 online wins in a row',kind:'master'},
      {id:'streak-250',name:'Crown',requirement:'250 online wins in a row',kind:'crown'},
      {id:'rayquaza-expert',name:'Rayquaza · Expert',requirement:'Defeat Rayquaza on Expert',kind:'boss',metal:'silver',species:['rayquaza']},
      {id:'rayquaza-champion',name:'Rayquaza · Champion',requirement:'Defeat Rayquaza on Champion',kind:'boss',metal:'gold',species:['rayquaza']},
      {id:'eon-expert',name:'Eon Duo · Expert',requirement:'Defeat Latios and Latias on Expert',kind:'boss',metal:'silver',species:['latios','latias']},
      {id:'eon-champion',name:'Eon Duo · Champion',requirement:'Defeat Latios and Latias on Champion',kind:'boss',metal:'gold',species:['latios','latias']},
      {id:'mewtwo-expert',name:'Mewtwo · Expert',requirement:'Defeat Mewtwo on Expert',kind:'boss',metal:'silver',species:['mewtwo']},
      {id:'mewtwo-champion',name:'Mewtwo · Champion',requirement:'Defeat Mewtwo on Champion',kind:'boss',metal:'gold',species:['mewtwo']},
      {id:'story-gold',name:'Story Complete',requirement:'Complete every story stage',kind:'story',metal:'gold'}
    ];
    const node=(tag,className,text)=>{const element=document.createElement(tag);if(className)element.className=className;if(text!==undefined)element.textContent=text;return element;};
    function styles(){
      if(document.getElementById('rocket-profile-badges-style'))return;
      const style=node('style');style.id='rocket-profile-badges-style';style.textContent=`
        .rocket-profile-badges{margin:16px 0 0;min-width:0;color:var(--ui-text,#f8f8f8);font:700 10px/1.4 Silkscreen,monospace}
        .rocket-badges-heading{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:8px}
        .rocket-badges-heading h2{margin:0;font:700 12px/1.4 Silkscreen,monospace;text-transform:uppercase}
        .rocket-badges-count{color:var(--ui-text-muted,#bbc1df);font-size:10px;white-space:nowrap}
        .rocket-badges-slots{display:grid;grid-template-columns:repeat(3,minmax(0,160px));gap:8px;margin-bottom:10px}
        .rocket-badge-slot{position:relative;min-width:0}
        .rocket-badge-slot>.rocket-profile-badge{width:100%;min-height:58px;padding-right:20px}
        .rocket-badge-slot.is-selected>.rocket-profile-badge{outline:2px solid var(--ui-cursor,#f87818);outline-offset:1px}
        .rocket-badge-clear{position:absolute;top:3px;right:3px;width:18px;height:18px;padding:0;border:0;background:transparent;color:var(--ui-text,#f8f8f8);font:700 12px/1 Silkscreen,monospace;cursor:pointer}
        .rocket-badges-hint{margin:0 0 8px;color:var(--ui-text-muted,#bbc1df);font-size:10px}
        .rocket-badges-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(155px,1fr));gap:7px;list-style:none;margin:0;padding:0}
        .rocket-badges-grid>li{min-width:0}
        .rocket-profile-badge{box-sizing:border-box;display:flex;align-items:center;gap:7px;min-width:0;width:100%;padding:6px;border:2px solid var(--ui-frame,#8b94b9);border-radius:0;background:var(--ui-panel,#272f55);color:inherit;font:inherit;cursor:pointer;
          box-shadow:inset 0 0 0 1px var(--ui-outline,#080b18),2px 2px 0 var(--ui-outline,#080b18);text-align:left;overflow-wrap:anywhere}
        .rocket-profile-badge:hover{background:var(--ui-cell-selected,#343e70)}
        .rocket-profile-badge[aria-pressed=true]{background:var(--ui-cell-selected,#343e70);border-color:var(--ui-cursor,#f87818)}
        .rocket-badge-art{width:40px;height:40px;flex:0 0 40px;position:relative;display:flex;align-items:center;justify-content:center;isolation:isolate;margin:0}
        .rocket-badge-art img{display:block;object-fit:contain;image-rendering:pixelated;flex:none}
        .rocket-badge-art img[hidden]{display:none}
        .rocket-badge-icon{width:32px;height:32px;position:relative;z-index:1}
        .rocket-badge-crown{width:36px;height:36px}
        .rocket-badge-medal{position:absolute;inset:0;width:40px;height:40px;margin:auto;z-index:0}
        .rocket-badge-sprites{display:flex;justify-content:center;align-items:center;position:relative;z-index:1}
        .rocket-badge-sprite{width:34px;height:34px}
        .rocket-badge-sprites.is-duo .rocket-badge-sprite{width:28px;height:28px;margin:0 -5px}
        .rocket-badge-sprites.is-duo .rocket-badge-sprite:first-child{translate:0 -4px}
        .rocket-badge-sprites.is-duo .rocket-badge-sprite:last-child{translate:0 4px}
        .rocket-profile-badge[data-metal=silver] .rocket-badge-sprite{filter:grayscale(1) brightness(1.3) contrast(1.1)}
        .rocket-profile-badge[data-metal=gold] .rocket-badge-sprite,.rocket-badge-story{filter:grayscale(1) sepia(1) saturate(3) brightness(1.15)}
        .rocket-profile-badge[data-metal=silver][data-earned=true]{border-color:#d0dce9}
        .rocket-profile-badge[data-metal=gold][data-earned=true]{border-color:#d8af56}
        .rocket-badge-name{display:block;font-size:10px;line-height:1.4}
        .rocket-badge-state{display:block;margin-top:3px;font-size:9px;color:#ffe1a0}
        .rocket-profile-badge[data-metal=silver] .rocket-badge-state{color:#dcecff}
        @container(max-width:450px){.rocket-badges-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.rocket-badge-slot>.rocket-profile-badge{flex-direction:column;align-items:flex-start;padding-right:6px}.rocket-badges-count{font-size:9px}}
      `;document.head.append(style);
    }
    function pixelArt(kind){
      if(artwork.has(kind))return artwork.get(kind);
      const canvas=document.createElement('canvas');canvas.width=canvas.height=32;
      const ctx=canvas.getContext('2d');if(!ctx)return '';
      const rect=(x,y,w,h,color)=>{ctx.fillStyle=color;ctx.fillRect(x,y,w,h);};
      if(kind==='crown'){
        // Pixel crown with an outlined, stepped silhouette and five raised points.
        const palette={outline:'#3d2b32',shade:'#aa6d2d',gold:'#e9b948',light:'#fff0a3',gem:'#e65e70'};
        for(const [x,y,w,h]of [[3,7,4,16],[7,12,3,12],[10,5,4,19],[14,11,4,13],[18,5,4,19],[22,12,3,12],[25,7,4,16],[5,20,22,7]])rect(x,y,w,h,palette.outline);
        for(const [x,y,w,h]of [[4,9,2,13],[6,15,5,8],[11,7,2,16],[13,14,6,9],[19,7,2,16],[21,15,5,8],[26,9,2,13],[6,21,20,4]])rect(x,y,w,h,palette.gold);
        rect(6,23,20,2,palette.shade);rect(6,21,20,1,palette.light);
        for(const x of [4,11,19,26])rect(x,8,2,3,palette.light);
        rect(14,17,4,4,palette.outline);rect(15,18,2,2,palette.gem);
      }else{
        const silver=kind==='silver';
        const edge=silver?'#53677f':'#88602e',dark=silver?'#304359':'#533c2c';
        const fill=silver?'#9babbd':'#c79b43',light=silver?'#e7f1f6':'#ffdf80',shade=silver?'#6e839c':'#a17832';
        for(const [x,y,w,h]of [[9,1,14,30],[5,3,22,26],[3,5,26,22],[1,9,30,14]])rect(x,y,w,h,dark);
        for(const [x,y,w,h]of [[9,2,14,28],[5,4,22,24],[4,5,24,22],[2,9,28,14]])rect(x,y,w,h,edge);
        for(const [x,y,w,h]of [[9,4,14,24],[6,6,20,20],[4,9,24,14]])rect(x,y,w,h,fill);
        rect(9,3,14,1,light);rect(6,5,20,1,light);rect(4,9,1,13,light);
        rect(9,27,14,2,shade);rect(25,9,2,14,shade);rect(9,6,14,1,light);
        for(let y=9;y<25;y+=4)rect(7,y,18,1,shade);
      }
      const value=canvas.toDataURL('image/png');artwork.set(kind,value);return value;
    }
    function image(src,className){
      const img=node('img',className);img.alt='';img.loading='lazy';img.decoding='async';img.src=src;
      img.addEventListener('error',()=>{img.hidden=true;},{once:true});return img;
    }
    function art(badge){
      const host=node('div','rocket-badge-art');host.setAttribute('aria-hidden','true');
      if(badge.metal)host.append(image(pixelArt(badge.metal),'rocket-badge-medal'));
      if(badge.kind==='boss'){
        const sprites=node('div','rocket-badge-sprites'+(badge.species.length>1?' is-duo':''));
        for(const id of badge.species)sprites.append(image(yp({id}),'rocket-badge-sprite'));
        host.append(sprites);
      }else if(badge.kind==='story'){
        // Exactly the icon used by the game's Story Mode menu entry, tinted gold.
        host.append(image(ai('ui/menu/icons/menu_icon_story.png'),'rocket-badge-icon rocket-badge-story'));
      }else if(badge.kind==='crown')host.append(image(pixelArt('crown'),'rocket-badge-icon rocket-badge-crown'));
      else{
        const src=badge.kind==='great'?arenaMainMenuOnline.icon(12):badge.kind==='master'?arenaMainMenuOnline.icon(10):
          ai('ui/menu/icons/menu_icon_'+(badge.kind==='ultra'?'quick':'cpu')+'.png');
        host.append(image(src,'rocket-badge-icon'));
      }
      return host;
    }
    function render(host,summary,mode='showcase'){
      styles();host.querySelector(':scope > .rocket-profile-badges')?.remove();
      const owned=new Set(summary.badges||[]),equipped=summary.equippedBadges||[],earned=badges.filter(badge=>owned.has(badge.id));
      const section=node('section','rocket-profile-badges');section.setAttribute('aria-label','Profile badges');
      const heading=node('header','rocket-badges-heading');heading.append(node('h2','',mode==='collection'?'Badges':'Showcase'),node('span','rocket-badges-count',mode==='collection'?owned.size+' / '+badges.length+' EARNED':equipped.length+' / 3 EQUIPPED'));
      const slots=node('div','rocket-badges-slots');slots.setAttribute('aria-label','Equipped badges');
      let selected=selectedSlots.get(host);if(!Number.isInteger(selected)||selected<0||selected>2)selected=-1;
      function refresh(){render(host,globalThis.ArenaRocketProfile.summary(),mode);}
      function button(badge){
        const card=node('button','rocket-profile-badge');card.type='button';card.dataset.badge=badge.id;card.dataset.earned='true';
        if(badge.metal)card.dataset.metal=badge.metal;
        card.title=badge.name+' — '+badge.requirement+'.';card.append(art(badge));return card;
      }
      for(let index=0;index<3;index++){
        const badge=badges.find(value=>value.id===equipped[index]),slot=node('div','rocket-badge-slot'+(selected===index?' is-selected':''));
        const pick=badge?button(badge):node('button','rocket-profile-badge');pick.type='button';
        pick.setAttribute('aria-label','Badge slot '+(index+1)+': '+(badge?badge.name+'. Select to replace.':'empty. Select to add a badge.'));pick.setAttribute('aria-pressed',String(selected===index));
        pick.append(node('strong','rocket-badge-name',badge?badge.name:'SLOT '+(index+1)));
        pick.addEventListener('click',()=>{const next=Math.min(index,equipped.length);selectedSlots.set(host,selected===next?-1:next);refresh();});slot.append(pick);
        if(badge){const clear=node('button','rocket-badge-clear','×');clear.type='button';clear.title='Unequip '+badge.name;clear.setAttribute('aria-label',clear.title);clear.addEventListener('click',()=>{selectedSlots.delete(host);globalThis.ArenaRocketProfile.unequipBadge(badge.id);});slot.append(clear);}
        slots.append(slot);
      }
      const hint=node('p','rocket-badges-hint',!earned.length?'No badges earned yet.':selected>=0?'Choose a badge for slot '+(selected+1)+'.':equipped.length===3?'Select a slot to replace its badge.':'Select a slot to showcase a badge.');
      hint.setAttribute('aria-live','polite');
      const grid=node('ul','rocket-badges-grid');
      for(const badge of (mode==='collection'?badges:earned)){
        const item=node('li'),card=button(badge),active=equipped.includes(badge.id),label=node('span');
        if(!owned.has(badge.id)){card.disabled=true;card.dataset.earned='false';card.style.opacity='.5';label.append(node('span','rocket-badge-state','LOCKED'));}
        label.append(node('strong','rocket-badge-name',badge.name));if(active)label.append(node('span','rocket-badge-state','EQUIPPED'));
        card.append(label);card.setAttribute('aria-pressed',String(active));
        card.addEventListener('click',()=>{
          if(mode==='collection')return;
          if(active){selectedSlots.delete(host);globalThis.ArenaRocketProfile.unequipBadge(badge.id);return;}
          if(selected<0&&equipped.length===3){hint.textContent='Select a slot to replace its badge.';slots.querySelector('button')?.focus();return;}
          selectedSlots.delete(host);globalThis.ArenaRocketProfile.equipBadge(badge.id,selected<0?undefined:selected);
        });item.append(card);grid.append(item);
      }
      if(mode==='collection')section.append(heading,grid);
      else {section.append(heading,slots,hint);if(selected>=0)section.append(grid);}
      host.append(section);
    }
    return Object.freeze({render});
  }
  function createRocketProfile(options) {
    const key='arena.rocket.profile.v1', maxBytes=1500000, maxSeen=4096, maxTeams=4096;
    const now=options.now||Date.now, listeners=new Set();let persisted=true,lastRaw=null,quarantined=false;
    const badgeIds=new Set(['streak-10','streak-20','streak-50','streak-100','streak-250','rayquaza-expert','rayquaza-champion','eon-expert','eon-champion','mewtwo-expert','mewtwo-champion','story-gold']);
    const blankCareer=()=>({games:0,partialPickHistory:false,partialPlayedHistory:false,rows:[],participation:[]});
    const blank=()=>({v:1,startedAt:now(),updatedAt:now(),playMs:0,pokemon:[],teams:[],online:{total:0,wins:0,losses:0,draws:0,noContests:0},achievements:{cleanSweeps:0,aces:0},streaks:{current:0,best:0},badges:[],equippedBadges:[],starts:[],results:[],history:[],career:blankCareer()});
    const fail=()=>{throw Error('This Rocket data code is invalid or unsupported.');};
    const integer=(v,max=1e9)=>Number.isSafeInteger(v)&&v>=0&&v<=max;
    const exact=(v,keys)=>v&&typeof v==='object'&&!Array.isArray(v)&&Object.keys(v).length===keys.length&&keys.every(k=>Object.hasOwn(v,k));
    const species=id=>typeof id==='string'&&/^[a-z0-9-]{1,40}$/.test(id)&&options.validSpecies(id);
    const text=(v,max)=>typeof v==='string'&&v.length<=max&&!/[\u0000-\u001f\u007f-\u009f\u202a-\u202e\u2066-\u2069]/.test(v);
    function validateHistory(row){
      if(!exact(row,['id','matchId','roomCode','roomName','ownSeat','startedAt','endedAt','stage','teams','names','remainingHp','winner','result','reason','replayId'])||
        typeof row.id!=='string'||!/^online:[A-Za-z0-9:_-]{1,90}$/.test(row.id)||!/^[a-f0-9]{8}$/.test(row.matchId)||
        !(row.roomCode===null||text(row.roomCode,32))||!(row.roomName===null||text(row.roomName,64))||!['A','B','C'].includes(row.ownSeat)||
        !integer(row.startedAt,8640000000000000)||!(row.endedAt===null||integer(row.endedAt,8640000000000000)&&row.endedAt>=row.startedAt)||
        typeof row.stage!=='string'||!/^[a-z0-9_-]{1,40}$/.test(row.stage)||!['win','loss','draw','nocontest','unknown'].includes(row.result)||
        !(row.winner===null||['A','B','C'].includes(row.winner))||!(row.reason===null||text(row.reason,64))||
        !(row.replayId===null||typeof row.replayId==='string'&&/^[A-Za-z0-9:_-]{1,120}$/.test(row.replayId)))fail();
      if(!row.teams||typeof row.teams!=='object'||Array.isArray(row.teams))fail();const seats=Object.keys(row.teams);
      if(seats.length<2||seats.length>3||seats.some(seat=>!['A','B','C'].includes(seat))||!seats.includes(row.ownSeat)||!exact(row.names,seats)||!exact(row.remainingHp,seats))fail();
      for(const seat of seats){const team=row.teams[seat],hp=row.remainingHp[seat];
        if(!Array.isArray(team)||team.length<1||team.length>3||!team.every(species)||new Set(team).size!==team.length||!text(row.names[seat],64)||!Array.isArray(hp)||hp.length!==team.length)fail();
        for(let i=0;i<hp.length;i++){const item=hp[i],amount=n=>n===null||typeof n==='number'&&Number.isFinite(n)&&n>=0&&n<=1e9;
          if(!exact(item,['species','hp','maxHp'])||item.species!==team[i]||!amount(item.hp)||!amount(item.maxHp)||item.hp!==null&&item.maxHp!==null&&item.hp>item.maxHp)fail();}
      }
      if(row.winner!==null&&!seats.includes(row.winner)||row.result==='win'&&row.winner!==row.ownSeat||row.result==='loss'&&row.winner===row.ownSeat||['draw','nocontest'].includes(row.result)&&row.winner!==null||row.result!=='unknown'&&row.endedAt===null)fail();
      return structuredClone(row);
    }
    function validate(value) {
      const keys=['v','startedAt','updatedAt','playMs','pokemon','teams','online','starts','results','history'];
      if(Object.hasOwn(value||{},'achievements'))keys.push('achievements');
      if(Object.hasOwn(value||{},'career'))keys.push('career');
      if(Object.hasOwn(value||{},'streaks'))keys.push('streaks');
      if(Object.hasOwn(value||{},'badges'))keys.push('badges');
      if(Object.hasOwn(value||{},'equippedBadges'))keys.push('equippedBadges');
      if(!exact(value,keys)||value.v!==1||
        !integer(value.startedAt,8640000000000000)||!integer(value.updatedAt,8640000000000000)||value.updatedAt<value.startedAt||!integer(value.playMs,1e12))fail();
      const onlineKeys=['total','wins','losses','draws'];
      if(Object.hasOwn(value.online||{},'noContests'))onlineKeys.push('noContests');
      if(!exact(value.online,onlineKeys)||Object.values(value.online).some(n=>!integer(n))||value.online.total!==value.online.wins+value.online.losses+value.online.draws+(value.online.noContests||0))fail();
      const achievements=Object.hasOwn(value,'achievements')?value.achievements:{cleanSweeps:0,aces:0};
      if(!exact(achievements,['cleanSweeps','aces'])||Object.values(achievements).some(n=>!integer(n,value.online.wins)))fail();
      if(!Array.isArray(value.pokemon)||value.pokemon.length>2048||!Array.isArray(value.teams)||value.teams.length>maxTeams)fail();
      const mons=new Set(),teams=new Set();
      for(const row of value.pokemon){if(!Array.isArray(row)||row.length!==2||!species(row[0])||!integer(row[1])||row[1]===0||mons.has(row[0]))fail();mons.add(row[0]);}
      for(const row of value.teams){if(!Array.isArray(row)||row.length!==2||!Array.isArray(row[0])||row[0].length!==3||!row[0].every(species)||new Set(row[0]).size!==3||!integer(row[1])||row[1]===0)fail();const name=[...row[0]].sort().join(',');if(row[0].join(',')!==name||teams.has(name))fail();teams.add(name);}
      for(const name of ['starts','results'])if(!Array.isArray(value[name])||value[name].length>maxSeen||value[name].some(id=>typeof id!=='string'||!/^[A-Za-z0-9:_-]{1,100}$/.test(id))||new Set(value[name]).size!==value[name].length)fail();
      if(!Array.isArray(value.history)||value.history.length>200||new Set(value.history.map(row=>row?.id)).size!==value.history.length)fail();for(const row of value.history)validateHistory(row);
      const career=Object.hasOwn(value,'career')?validateCareer(value.career):migrateCareer(value);
      const streaks=Object.hasOwn(value,'streaks')?value.streaks:migrateStreaks(value);
      if(!exact(streaks,['current','best'])||!integer(streaks.best,value.online.wins)||!integer(streaks.current,streaks.best))fail();
      const badges=Object.hasOwn(value,'badges')?value.badges:[];
      if(!Array.isArray(badges)||badges.length>badgeIds.size||badges.some(id=>!badgeIds.has(id))||new Set(badges).size!==badges.length)fail();
      const earned=streakBadges(badges,streaks.best),equippedBadges=Object.hasOwn(value,'equippedBadges')?value.equippedBadges:[];
      if(!Array.isArray(equippedBadges)||equippedBadges.length>3||new Set(equippedBadges).size!==equippedBadges.length||equippedBadges.some(id=>!badgeIds.has(id)||!earned.includes(id)))fail();
      const starts=new Set(value.starts);if(career.participation.some(([id])=>!starts.has(id)))fail();
      return structuredClone({...value,online:{...value.online,noContests:value.online.noContests||0},achievements,career,streaks,badges:earned,equippedBadges});
    }
    function streakBadges(badges,best){return [...new Set([...badges,...[10,20,50,100,250].filter(n=>best>=n).map(n=>'streak-'+n)])];}
    function migrateStreaks(value) {
      // An all-win lifetime total is exact even when older history was pruned.
      if(value.online.total-(value.online.noContests||0)===value.online.wins)return{current:value.online.wins,best:value.online.wins};
      const history=new Map(value.history.map(match=>[match.id,match]));
      let current=0,best=0;
      for(const id of value.results){
        if(!id.startsWith('online:'))continue;
        if(history.get(id)?.result==='nocontest'||history.get(id)?.reason==='nocontest')continue;
        // Missing outcomes break the known run; never bridge a history gap.
        current=history.get(id)?.result==='win'?current+1:0;
        best=Math.max(best,current);
      }
      return{current:Math.min(current,value.online.wins),best:Math.min(best,value.online.wins)};
    }
    function validateCareer(stats) {
      const modern=Object.hasOwn(stats||{},'partialPlayedHistory')||Object.hasOwn(stats||{},'participation');
      if(!exact(stats,modern?['games','partialPickHistory','partialPlayedHistory','rows','participation']:['games','partialPickHistory','rows'])||!integer(stats.games)||
        typeof stats.partialPickHistory!=='boolean'||!Array.isArray(stats.rows)||stats.rows.length>2048)fail();
      const ids=new Set();
      for(const row of stats.rows){
        if(!exact(row,modern?['id','picks','played','wins','decided','playMs']:['id','picks','wins','decided','playMs'])||!species(row.id)||ids.has(row.id)||
          !integer(row.picks,stats.games)||!integer(row.decided,row.picks)||!integer(row.wins,row.decided)||
          !integer(row.playMs,1e12)||modern&&!integer(row.played,row.picks))fail();
        ids.add(row.id);
      }
      if(!modern)return {...stats,partialPlayedHistory:stats.games>0,rows:stats.rows.map(row=>({...row,played:0})),participation:[]};
      if(typeof stats.partialPlayedHistory!=='boolean'||!Array.isArray(stats.participation)||stats.participation.length>maxSeen)fail();
      const matches=new Set(),counts=new Map();
      for(const row of stats.participation){
        if(!Array.isArray(row)||row.length!==2||typeof row[0]!=='string'||!/^[A-Za-z0-9:_-]{1,100}$/.test(row[0])||matches.has(row[0])||
          !Array.isArray(row[1])||row[1].length>6||!row[1].length||new Set(row[1]).size!==row[1].length||row[1].some(id=>!ids.has(id)))fail();
        matches.add(row[0]);for(const id of row[1])counts.set(id,(counts.get(id)||0)+1);
      }
      if(stats.rows.some(row=>(counts.get(row.id)||0)>row.played))fail();
      return stats;
    }
    function careerRow(stats,id) {
      let row=stats.rows.find(row=>row.id===id);
      if(!row){row={id,picks:0,played:0,wins:0,decided:0,playMs:0};stats.rows.push(row);}
      return row;
    }
    function recordPick(stats,party) {
      if(stats.games>=1e9)return;
      stats.games++;
      for(const id of new Set(party))careerRow(stats,id).picks++;
    }
    function recordOutcome(stats,party,outcome) {
      for(const id of new Set(party)){
        const row=stats.rows.find(row=>row.id===id);
        if(!row||row.decided>=row.picks)continue;
        row.decided++;
        if(outcome==='win')row.wins++;
      }
    }
    function migrateCareer(value) {
      const stats=blankCareer(), starts=new Set(value.starts), results=new Set(value.results);
      const retained=value.history.filter(match=>starts.has(match.id)||results.has(match.id));
      const picks=value.pokemon.reduce((sum,row)=>sum+row[1],0);
      const complete=starts.size<maxSeen&&picks>=starts.size&&picks<=6*starts.size&&
        value.pokemon.every(row=>row[1]<=starts.size);
      if(complete){
        stats.games=starts.size;
        for(const [id,count] of value.pokemon)careerRow(stats,id).picks=count;
      }else{
        // A full ID ring cannot give a lifetime denominator. Include only
        // games whose teams survived, for both the numerator and denominator.
        stats.partialPickHistory=true;
        for(const match of retained)recordPick(stats,match.teams[match.ownSeat]);
      }
      for(const match of retained){
        if(results.has(match.id)&&['win','loss','draw'].includes(match.result))
          recordOutcome(stats,match.teams[match.ownSeat],match.result);
      }
      stats.partialPlayedHistory=stats.games>0;
      return stats;
    }
    let data=blank();
    function reload(){try{const raw=options.storage?.getItem(key);if(raw&&raw.length<=maxBytes&&raw!==lastRaw){const next=validate(JSON.parse(raw));data=next;lastRaw=raw;quarantined=false;persisted=true;}else if(raw&&raw.length>maxBytes)fail();return true;}catch{persisted=false;quarantined=true;return false;}}
    reload();
    const changed=()=>{const value=summary();for(const fn of listeners)try{fn(value);}catch{}};
    function save(next,strict=false){
      const text=JSON.stringify(validate(next));if(text.length>maxBytes)throw Error('Rocket history is too large to save.');
      if(quarantined&&!strict){persisted=false;data=next;changed();return;}
      let previousRaw=null,attempted=false,read=false;
      try{if(!options.storage)throw Error('Storage unavailable');previousRaw=options.storage.getItem(key);read=true;attempted=true;options.storage.setItem(key,text);if(options.storage.getItem(key)!==text)throw Error('Storage did not retain the update');lastRaw=text;persisted=true;quarantined=false;}
      catch{persisted=false;let restored=!attempted;
        if(attempted&&read){try{if(previousRaw===null)options.storage.removeItem(key);else options.storage.setItem(key,previousRaw);}catch{}try{restored=options.storage.getItem(key)===previousRaw;}catch{restored=false;}}
        if(!restored)quarantined=true;
        if(strict)throw Error(restored?'Firefox could not save Rocket data. Your previous data is unchanged.':'Firefox could not confirm the save or restore the previous Rocket data. Keep your backup code and retry when storage is available.');
      }
      data=next;changed();
    }
    function update(fn){if(persisted)reload();const next=structuredClone(data);if(fn(next)===false)return false;next.updatedAt=Math.max(now(),next.startedAt);save(next);return true;}
    function start(id,party){
      if(typeof id!=='string'||!/^[A-Za-z0-9:_-]{1,100}$/.test(id)||!Array.isArray(party)||!party.length||party.length>6||!party.every(species))return false;
      return update(next=>{if(next.starts.includes(id))return false;next.starts.push(id);next.starts=next.starts.slice(-maxSeen);
        const retained=new Set(next.starts);next.career.participation=next.career.participation.filter(([match])=>retained.has(match));
        recordPick(next.career,party);
        for(const mon of new Set(party)){const row=next.pokemon.find(row=>row[0]===mon);if(row)row[1]=Math.min(1e9,row[1]+1);else next.pokemon.push([mon,1]);}
        if(party.length===3&&new Set(party).size===3){const team=[...party].sort(),label=team.join(','),row=next.teams.find(row=>row[0].join(',')===label);if(row)row[1]=Math.min(1e9,row[1]+1);else if(next.teams.length<maxTeams)next.teams.push([team,1]);}
      });
    }
    function played(id,mons){
      if(typeof id!=='string'||!Array.isArray(mons)||!mons.length||mons.length>6||!mons.every(species))return false;
      const cached=data.career.participation.find(row=>row[0]===id);
      if(cached&&mons.every(mon=>cached[1].includes(mon)))return false;
      return update(next=>{
        if(!next.starts.includes(id)||next.results.includes(id))return false;
        const previous=next.career.participation.find(row=>row[0]===id),seen=new Set(previous?.[1]||[]);
        const added=[...new Set(mons)].filter(mon=>!seen.has(mon)&&next.career.rows.some(row=>row.id===mon&&row.played<row.picks));
        if(!added.length||seen.size+added.length>6)return false;
        for(const mon of added){next.career.rows.find(row=>row.id===mon).played++;seen.add(mon);}
        if(previous)previous[1]=[...seen];else next.career.participation.push([id,[...seen]]);
      });
    }
    function awardBadge(id){
      if(!badgeIds.has(id))return false;
      if(data.badges.includes(id))return false;
      return update(next=>{if(next.badges.includes(id))return false;next.badges.push(id);});
    }
    function equipBadge(id,slot){
      if(!badgeIds.has(id)||slot!==undefined&&(!Number.isInteger(slot)||slot<0||slot>2))return false;
      return update(next=>{
        if(!next.badges.includes(id)||next.equippedBadges.includes(id))return false;
        const index=slot===undefined?next.equippedBadges.length:Math.min(slot,next.equippedBadges.length);
        if(index>2)return false;
        next.equippedBadges[index]=id;
      });
    }
    function unequipBadge(id){
      if(!badgeIds.has(id))return false;
      return update(next=>{const index=next.equippedBadges.indexOf(id);if(index<0)return false;next.equippedBadges.splice(index,1);});
    }
    function result(id,outcome,awards,party){
      if(typeof id!=='string'||!['win','loss','draw','nocontest'].includes(outcome))return false;
      return update(next=>{if(!id.startsWith('online:')||!next.starts.includes(id)||next.results.includes(id)||next.online.total>=1e9)return false;
        next.results.push(id);next.results=next.results.slice(-maxSeen);next.online.total++;
        if(outcome==='nocontest'){next.online.noContests++;return;}
        next.online[{win:'wins',loss:'losses',draw:'draws'}[outcome]]++;
        next.streaks.current=outcome==='win'?next.streaks.current+1:0;
        next.streaks.best=Math.max(next.streaks.best,next.streaks.current);
        next.badges=streakBadges(next.badges,next.streaks.best);
        const match=next.history.find(row=>row.id===id);
        recordOutcome(next.career,party??match?.teams[match.ownSeat]??[],outcome);
        if(outcome==='win'){if(awards?.cleanSweep===true)next.achievements.cleanSweeps++;if(awards?.ace===true)next.achievements.aces++;}
      });
    }
    function soloResult(id,party,outcome){
      if(!['win','loss','draw'].includes(outcome)||!id.startsWith('solo:'))return false;
      return update(next=>{if(!next.starts.includes(id))return false;recordOutcome(next.career,party,outcome);});
    }
    function addTime(ms,fieldTime=[]){
      if(!integer(ms,300000)||(!ms&&!fieldTime.length))return false;
      return update(next=>{
        next.playMs=Math.min(1e12,next.playMs+ms);
        for(const [id,amount] of fieldTime){
          if(!integer(amount,1e12)||!amount||!species(id))continue;
          const row=careerRow(next.career,id);
          row.playMs=Math.min(1e12,row.playMs+amount);
        }
      });
    }
    function createHistory(record){const valid=validateHistory(record);update(next=>{if(next.history.some(row=>row.id===valid.id))return false;next.history.push(valid);next.history.sort((a,b)=>b.startedAt-a.startedAt);next.history=next.history.slice(0,200);});return listHistory().find(row=>row.id===valid.id);}
    function updateHistory(id,patch){if(!patch||typeof patch!=='object'||Array.isArray(patch)||Object.keys(patch).some(key=>!['endedAt','remainingHp','winner','result','reason','replayId'].includes(key)))fail();let found=false;
      update(next=>{const at=next.history.findIndex(row=>row.id===id);if(at<0)return false;next.history[at]=validateHistory({...next.history[at],...patch});found=true;});return found;}
    function listHistory(){return structuredClone(data.history).sort((a,b)=>b.startedAt-a.startedAt);}
    function summary(){
      const pokemon=[...data.pokemon].sort((a,b)=>b[1]-a[1]||a[0].localeCompare(b[0]))[0],team=[...data.teams].sort((a,b)=>b[1]-a[1]||a[0].join(',').localeCompare(b[0].join(',')))[0];
      const decided=data.online.total-data.online.noContests;
      return{startedAt:data.startedAt,updatedAt:data.updatedAt,playMs:data.playMs,online:{...data.online,winRate:decided?100*data.online.wins/decided:0},achievements:{...data.achievements},streaks:{...data.streaks},badges:streakBadges(data.badges,data.streaks.best),equippedBadges:[...data.equippedBadges],
        favoritePokemon:pokemon?{id:pokemon[0],name:options.speciesName(pokemon[0]),battles:pokemon[1]}:null,
        favoriteTeam:team?{ids:[...team[0]],names:team[0].map(options.speciesName),battles:team[1]}:null,
        completion:options.completion?.()||{},persisted,notice:(quarantined?' Stored Rocket data could not be read or verified; it is preserved. Import a valid code to resume saving.':'')};
    }
    async function digest(bytes){const hash=await options.crypto.subtle.digest('SHA-256',bytes);return [...new Uint8Array(hash)].map(n=>n.toString(16).padStart(2,'0')).join('');}
    const to64=bytes=>{let text='';for(let i=0;i<bytes.length;i+=8192)text+=String.fromCharCode(...bytes.subarray(i,i+8192));return options.btoa(text).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');};
    const from64=text=>{if(!/^[A-Za-z0-9_-]+$/.test(text)||text.length>maxBytes*2)fail();let binary;try{binary=options.atob(text.replace(/-/g,'+').replace(/_/g,'/'));}catch{fail();}return Uint8Array.from(binary,ch=>ch.charCodeAt(0));};
    async function exportCode(){if(persisted)reload();const bytes=new TextEncoder().encode(JSON.stringify(validate(data)));return 'ROCKET1.'+to64(bytes)+'.'+await digest(bytes);}
    async function validateCode(code){
      if(typeof code!=='string'||code.length>maxBytes*2+100)fail();const match=/^ROCKET1\.([A-Za-z0-9_-]+)\.([a-f0-9]{64})$/.exec(code.trim());if(!match)fail();
      const bytes=from64(match[1]);if(bytes.byteLength>maxBytes||await digest(bytes)!==match[2])fail();let next;try{next=validate(JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(bytes)));}catch{fail();}
      return next;
    }
    function replaceValidated(snapshot){save(validate(snapshot),true);return summary();}
    async function importCode(code){return replaceValidated(await validateCode(code));}
    return{summary,start,played,awardBadge,equipBadge,unequipBadge,result,soloResult,addTime,career:()=>structuredClone(data.career),createHistory,updateHistory,listHistory,exportCode,importCode,validateCode,replaceValidated,reset(){save(blank(),true);return summary();},subscribe(fn){listeners.add(fn);return()=>listeners.delete(fn);},refresh(){reload();changed();},validate,snapshot:()=>structuredClone(data)};
  }
  // Only accepted native snapshots feed this observer. It never changes a
  // fighter, result, packet or replay, and an interrupted observation cannot win
  // a bonus. HP is indexed by original party slot, not the active portrait.
  function createRocketAchievements(teams,ownSeat,recovered=false){
    const seats=Object.keys(teams),order=[ownSeat,...['A','B','C'].filter(seat=>seat!==ownSeat&&seats.includes(seat))];
    let complete=!recovered,started=false,lastTick=-1,lastElapsed=-1,lastPhase=null,previous=null,damaged=false,ownFainted=false,foesDefeated=new Set();
    const ownCount=teams[ownSeat]?.length||0,duel=seats.length===2&&ownCount===3&&teams[order[1]]?.length===3;
    function parties(state){
      const rows=state.ffa?order.map((_,i)=>state.ffa.teams?.find(team=>team.id===['player','opponent','third'][i])?.party):[state.party,state.foeParty];
      if(rows.length!==seats.length||rows.some((party,i)=>!Array.isArray(party)||party.length!==teams[order[i]].length))return null;
      const result=[];
      for(let i=0;i<rows.length;i++){
        const party=rows[i],slots=new Set();
        for(const row of party)if(!row||!Number.isInteger(row.slot)||row.slot<0||row.slot>=party.length||slots.has(row.slot)||typeof row.speciesId!=='string'||!Number.isFinite(row.hp)||!Number.isFinite(row.maxHp)||row.maxHp<=0||row.hp<0||row.hp>row.maxHp)return null;else slots.add(row.slot);
        result.push([...party].sort((a,b)=>a.slot-b.slot).map(row=>({speciesId:row.speciesId,hp:row.hp,maxHp:row.maxHp})));
      }
      return result;
    }
    function observe(state,events){
      if(!complete)return;
      if(!state||!Array.isArray(events)||!Number.isSafeInteger(state.tick)||state.tick<0||!Number.isFinite(state.elapsedMs)||state.elapsedMs<0){complete=false;return;}
      const current=parties(state);if(!current){complete=false;return;}
      if(!started){
        // The native match publishes its untouched tick-zero state while both
        // clients load. A late recovery must never pretend that was observed.
        if(state.tick!==0||state.elapsedMs!==0||current.some((party,i)=>party.some((row,j)=>row.hp!==row.maxHp||row.speciesId!==teams[order[i]][j]))){complete=false;return;}
        started=true;
      }else if(state.tick<lastTick||state.elapsedMs<lastElapsed||state.elapsedMs-lastElapsed>1000){complete=false;return;}
      const ownMega=events.some(event=>event.type==='mega'&&event.actor==='player');
      for(const event of events){
        if(event.type==='hit'&&event.target==='player'&&typeof event.amount==='number'&&event.amount>0)damaged=true;
        if(event.type==='faint'&&event.target==='player')ownFainted=true;
        if(event.type==='switch'&&event.actor==='player'&&event.cause==='faint')ownFainted=true;
      }
      for(let i=0;i<current[0].length;i++){
        const row=current[0][i],old=previous?.[0][i];
        if(row.hp<=0)ownFainted=true;
        if(old&&row.hp<old.hp){
          // Mega adoption can clamp unchanged health to the new max HP. A
          // genuine hit in the same snapshot is still sticky via native events.
          const clamped=ownMega&&row.speciesId!==old.speciesId&&row.hp===Math.min(old.hp,row.maxHp);
          if(!clamped)damaged=true;
        }
        if(old&&row.speciesId!==old.speciesId&&!ownMega)complete=false;
      }
      if(duel)for(let i=0;i<3;i++)if(current[1][i].hp===0)foesDefeated.add(i);
      previous=current;lastTick=state.tick;lastElapsed=state.elapsedMs;lastPhase=state.phase;
    }
    return{observe,interrupt(){complete=false;},awards(){
      const observedWin=complete&&started&&lastTick>0&&lastPhase==='victory';
      return{cleanSweep:observedWin&&duel&&!ownFainted&&foesDefeated.size===3&&previous[1].every(row=>row.hp===0),ace:observedWin&&!damaged&&!ownFainted};
    }};
  }
  function createArenaRocketRuntime() {
    let core=null,currentScene=null,activity=null,lastTime=performance.now(),lastMouse=lastTime,pendingMs=0,offline=0,lastSaved=lastTime,lastVisible=!document.hidden&&document.hasFocus(),careerGeneration=0;
    let nextStoryCheck=0;
    const scenes=new WeakMap(),battles=new WeakMap(),observers=new Set(),battleObservers=new Set(),session=Math.random().toString(36).slice(2)+Date.now().toString(36);
    const fieldTime=new Map();
    const completion=()=>{const collection=df(),story=ZS(BS()),ratio=(done,total)=>({done,total,percent:total?100*done/total:0});
      const stages=Object.values(dS).flat(),cleared=new Set(Object.values(story.completed).flat()),cards=new Set(collection.unlocked),seen=new Set([...collection.lit,...collection.megaLit]);
      return{story:ratio(stages.filter(id=>cleared.has(id)).length,stages.length),cards:ratio(Ju.filter(card=>cards.has(card.key)).length,Ju.length),pokedex:ratio(Zt.filter(mon=>seen.has(mon.id)).length,Zt.length)};};
    function get(){if(core)return core;let storage=null;try{storage=localStorage;}catch{}const species=new Set(Zt.map(mon=>mon.id));
      core=createRocketProfile({storage,crypto:globalThis.crypto,btoa:value=>globalThis.btoa(value),atob:value=>globalThis.atob(value),validSpecies:id=>species.has(id),speciesName:id=>dn(id).name,completion});
      core.subscribe(value=>{render();for(const fn of observers)try{fn(value);}catch{}});return core;
    }
    function syncStoryBadge(force=false){
      const time=performance.now();if(!force&&time<nextStoryCheck)return;nextStoryCheck=time+5000;
      try{const story=completion().story;if(story.total>0&&story.done>=story.total)get().awardBadge('story-gold');}catch{}
    }
    function emit(event){if(!battleObservers.size)return;const value=structuredClone(event);for(const fn of battleObservers)try{fn(value);}catch{}}
    function onlinePrepared(controller,start,battle,recovery){
      const id='online:'+controller.code+':'+start.matchId+':'+controller.you,teams=structuredClone(start.teams),names={},remainingHp={};
      for(const seat of Object.keys(teams)){names[seat]=controller.room?.seats[Fc(seat)]?.name||'';remainingHp[seat]=teams[seat].map(species=>({species,hp:null,maxHp:null}));}
      const recovered=!!recovery||get().listHistory().some(record=>record.id===id),record=get().createHistory({id,matchId:start.matchId,roomCode:controller.code||null,roomName:controller.room?.name||null,ownSeat:controller.you,startedAt:Date.now(),endedAt:null,stage:start.stage,teams,names,remainingHp,winner:null,result:'unknown',reason:null,replayId:null});
      const match={id,seat:controller.you,record,party:teams[controller.you].slice(),fielded:new Set(),generation:careerGeneration,
        lastFrame:0,events:[],ended:record.endedAt!==null,achievements:createRocketAchievements(teams,controller.you,recovered)};battles.set(battle,match);emit({type:'start',...record,recovered});
    }
    function onlineSnapshot(battle,state,events){
      const match=battles.get(battle);if(!match||match.ended)return;
      match.achievements.observe(state,events);
      if(state.phase==='fight'&&match.generation===careerGeneration&&!battle.spectating?.()&&battle.connected!==false){
        if(!match.started){get().start(match.id,match.party);match.started=true;}
        observeFielded(state,match);
      }
    }
    function onlineInterrupted(battle){
      battles.get(battle)?.achievements.interrupt();
      if(currentScene?.net===battle){const record=scenes.get(currentScene);if(record)record.activeSpecies=null;}
    }
    function teamAtStart(state,online){
      if(online)return online.record.teams[online.seat].slice();
      if(state.cpuBattle)return state.fighters.filter(f=>f.arenaCpuTeam===state.cpuBattle.playerTeam).map(f=>f.speciesId);
      return state.party.map(mon=>mon.speciesId);
    }
    function observeFielded(state,record){
      if(state.phase!=='fight'||record.generation!==careerGeneration)return;
      const fighters=state.cpuBattle?state.fighters.filter(f=>f.arenaCpuTeam===state.cpuBattle.playerTeam):state.fighters.filter(f=>f.id==='player');
      const entered=[];
      for(const fighter of fighters){
        if(!(fighter.hp>0)||fighter.switchMs>0)continue;
        const id=state.cpuBattle?record.actorSlots?.get(fighter.id):record.party[state.activeSlot]??
          (record.party.includes(fighter.speciesId)?fighter.speciesId:null);
        if(id&&!record.fielded.has(id)){record.fielded.add(id);entered.push(id);}
      }
      if(entered.length)get().played(record.id,entered);
    }
    function observeCareer(scene,state,record){
      if(!record||record.epoch!==scene.loadEpoch||record.generation!==careerGeneration||record.finished)return;
      const clock=state.elapsedMs, time=performance.now(), previous=record.clock;
      // Reconciled online frames can briefly repeat or rewind the displayed clock.
      if(Number.isFinite(clock))record.clock=Math.max(previous??clock,clock);
      // Use only elapsed simulation time actually seen in this live scene.
      // A late join, pause or connection jump has no assignable time.
      const fighter=state.fighters?.find(f=>f.id==='player');
      const eligible=!!fighter&&fighter.hp>0&&scene.net?.connected!==false&&!scene.paused&&!scene.net?.spectating?.()&&
        !Z.isPaused()&&(!scene.world?.acceptsInput||scene.world.acceptsInput());
      if(eligible)observeFielded(state,record);
      const delta=clock-previous;
      if(eligible&&record.activeSpecies&&Number.isFinite(previous)&&clock>previous&&delta<=1000&&time-record.lastObservation<=1000){
        fieldTime.set(record.activeSpecies,(fieldTime.get(record.activeSpecies)||0)+delta);
      }
      record.lastObservation=time;
      // Track the originally selected slot. Temporary transformations still
      // belong to that pick; AI allies in simultaneous modes get no playtime.
      record.activeSpecies=eligible&&state.phase==='fight'?(state.cpuBattle?record.party[0]:
        record.party[state.activeSlot]??(record.party.includes(fighter.speciesId)?fighter.speciesId:null)):null;
      if(!scene.net&&['victory','defeat','draw'].includes(state.phase)){
        record.finished=true;
        get().soloResult(record.id,record.party,{victory:'win',defeat:'loss',draw:'draw'}[state.phase]);
        flush();
      }
    }
    function battleTick(scene,state){
      currentScene=scene;activity={scene,epoch:scene.loadEpoch,phase:scene.artVariant?'art':state.phase,at:performance.now()};
      if(scene.artVariant||scene.rocketLobbyTraining)return;
      let record=scenes.get(scene);
      if(!record||record.epoch!==scene.loadEpoch){
        if(state.phase!=='fight'||scene.net?.spectating?.())return;
        const online=scene.net?battles.get(scene.net):null;
        if(scene.net&&(!online||online.ended))return;
        record={epoch:scene.loadEpoch,generation:careerGeneration,id:online?.id||'solo:'+session+':'+(++offline),party:teamAtStart(state,online),fielded:online?.fielded||new Set(),
          clock:state.elapsedMs,lastObservation:performance.now(),activeSpecies:null,finished:false};
        if(state.cpuBattle)record.actorSlots=new Map(state.fighters.filter(f=>f.arenaCpuTeam===state.cpuBattle.playerTeam).map((fighter,index)=>[fighter.id,record.party[index]]));
        scenes.set(scene,record);get().start(record.id,record.party);
      }
      observeCareer(scene,state,record);
    }
    function finish(match,result,state,forfeit=false){if(match.ended)return;const winner=result.winner;if(winner!==null&&!['A','B','C'].includes(winner))return;
      const outcome=forfeit?'loss':result.reason==='nocontest'?'nocontest':winner===null?'draw':winner===match.seat?'win':'loss';
      get().result(match.id,outcome,forfeit?null:match.achievements.awards(),match.record.teams[match.seat]);const patch={endedAt:Date.now(),winner,result:outcome,reason:result.reason||null};get().updateHistory(match.id,patch);match.ended=true;
      emit({type:'end',id:match.id,...patch,state:state||null,events:match.events.splice(0)});
    }
    function onlineResult(controller,result){const match=battles.get(controller.battle);if(match&&result){if(activity?.scene.net===controller.battle)activity.phase='finished';finish(match,result,controller.battle.getState());}}
    function onlineEnded(controller,message,reason){
      const match=battles.get(controller.battle);
      if(!match||match.ended||controller.result||!get().snapshot().starts.includes(match.id))return;
      // A temporary drop is recoverable. Only the native terminal timeout or
      // an explicit server network/ping dismissal ends a match as No Contest.
      const networkMessage=['error','kicked','dissolved'].includes(reason)&&typeof message==='string'&&message.length<1024&&
        /\b(?:(?:high|excessive|unstable)\s+(?:ping|latency)|(?:ping|latency)\s+(?:is\s+)?(?:too\s+high|exceeded|timeout|timed\s+out)|(?:network|connection|ping)\s+(?:was\s+)?(?:lost|timeout|timed\s+out|disconnected))\b/i.test(message);
      if(reason!=='timeout'&&!networkMessage)return;
      const state=controller.battle.getState();
      // A final snapshot may precede its result packet. Keep that native result.
      if(['victory','defeat','draw'].includes(state.phase))return;
      match.achievements.interrupt();
      if(activity?.scene.net===controller.battle)activity.phase='finished';
      finish(match,{winner:null,reason:'nocontest'},state);
    }
    function forfeit(controller){const match=battles.get(controller.battle);if(controller.active&&['vs','fight'].includes(controller.mode)&&!controller.result&&match&&get().snapshot().starts.includes(match.id))finish(match,{winner:null,reason:'forfeit'},controller.battle.getState(),true);}
    function battleFrame(scene,state,events){activity={scene,epoch:scene.loadEpoch,phase:scene.artVariant?'art':state.phase,at:performance.now()};observeCareer(scene,state,scenes.get(scene));const match=scene.net&&battles.get(scene.net);if(!match||match.ended)return;match.events.push(...events);if(match.events.length>200)match.events=match.events.slice(-200);const at=performance.now();if(at-match.lastFrame<1000/15)return;match.lastFrame=at;emit({type:'frame',id:match.id,at:Date.now(),state,events:match.events.splice(0)});}
    function activeFight(){try{return activity?.scene===currentScene&&activity.epoch===currentScene.loadEpoch&&activity.phase==='fight'&&performance.now()-activity.at<2000&&currentScene.alive&&currentScene.ready&&!currentScene.paused&&!Z.isPaused()&&!currentScene.net?.spectating?.();}catch{return false;}}
    function tick(){const time=performance.now(),from=lastTime,gap=Math.max(0,time-from);lastTime=time;
      syncStoryBadge();
      const visible=!document.hidden&&document.hasFocus();
      const fighting=activeFight();
      if(fighting||visible&&lastVisible){const eligible=fighting?gap:Math.max(0,Math.min(time,lastMouse+120000)-from);pendingMs+=Math.floor(Math.min(5000,eligible));}lastVisible=visible;
      if((pendingMs||fieldTime.size)&&time-lastSaved>=30000)persistTime();
    }
    function persistTime(){
      if(!pendingMs&&!fieldTime.size)return;
      const amount=pendingMs, played=[...fieldTime].map(([id,ms])=>[id,Math.round(ms)]);
      pendingMs=0;fieldTime.clear();lastSaved=performance.now();
      get().addTime(amount,played);
    }
    function flush(){tick();persistTime();syncStoryBadge(true);}
    function career(){
      const stats=get().career();
      stats.streaks=get().summary().streaks;
      for(const [id,ms] of fieldTime){
        const row=stats.rows.find(row=>row.id===id);
        if(row)row.playMs+=Math.round(ms);
      }
      return stats;
    }
    function summary(){const value=get().summary();value.playMs+=pendingMs;return value;}
    const renderedProfiles=new WeakMap();
    let profileView=null;
    function html(){return '<section class="rocket-profile" data-rocket-profile aria-label="Trainer statistics" tabindex="0"></section>';}
    function closeProfile(){
      if(!profileView)return;
      const view=profileView;profileView=null;
      view.history?.dispose();
      view.unsubscribe();
      view.dialog.close();
      view.dialog.remove();
      if(view.previous?.isConnected)view.previous.focus({preventScroll:true});
    }
    function openProfile(initial='profile'){
      syncStoryBadge(true);
      if(profileView?.dialog.open){profileView.select(initial);return;}
      const dialog=document.createElement('dialog');dialog.id='rocket-profile-screen';dialog.className='rocket-profile-screen';dialog.setAttribute('aria-labelledby','rocket-profile-heading');
      dialog.innerHTML='<header class="rocket-profile-header"><span class="rocket-profile-emblem" aria-hidden="true">R</span><div class="rocket-profile-identity"><p class="rocket-profile-eyebrow">TRAINER PROFILE</p><h1 id="rocket-profile-heading" data-rocket-trainer-name></h1></div><div class="rocket-profile-actions"><button type="button" data-rocket-profile-edit>EDIT NAME</button><button type="button" data-rocket-profile-close>BACK</button></div></header><div class="rocket-profile-tabs" role="tablist" aria-label="Trainer pages"></div>';
      const previous=document.activeElement, tablist=dialog.querySelector('[role="tablist"]'), edit=dialog.querySelector('[data-rocket-profile-edit]');
      const pages=new Map();
      for(const name of ['profile','history','stats','collection']){
        const button=document.createElement('button'),panel=document.createElement('section');
        button.type='button';button.id='rocket-tab-'+name;button.textContent=name.toUpperCase();button.setAttribute('role','tab');
        panel.id='rocket-page-'+name;panel.className='rocket-profile-page';panel.hidden=true;
        panel.setAttribute('role','tabpanel');panel.setAttribute('aria-labelledby',button.id);
        button.setAttribute('aria-controls',panel.id);
        if(name==='profile')panel.innerHTML=html();
        pages.set(name,{button,panel});tablist.append(button);dialog.append(panel);
        button.addEventListener('click',()=>select(name));
      }
      function refreshChart(){if(view.page==='stats')arenaCareerChart.render(pages.get('stats').panel,globalThis.ArenaRocketProfile.career());}
      function select(name){
        if(!pages.has(name))name='profile';
        if(view.page===name)return;
        view.history?.dispose();view.history=null;
        view.page=name;
        for(const [id,{button,panel}] of pages){
          const active=id===name;
          button.setAttribute('aria-selected',String(active));button.tabIndex=active?0:-1;panel.hidden=!active;
        }
        edit.hidden=name!=='profile';
        if(name==='history')view.history=globalThis.ArenaRocketReplays.mountPage(pages.get(name).panel);
        else if(name==='stats')refreshChart();
        else if(name==='collection')renderCollection(pages.get(name).panel);
        else render();
        if(dialog.open)pages.get(name).button.focus({preventScroll:true});
      }
      const view={dialog,previous,history:null,page:null,select,unsubscribe:globalThis.ArenaRocketProfile.subscribe(()=>{refreshChart();if(view.page==='collection')renderCollection(pages.get('collection').panel);})};
      profileView=view;
      function back(){if(!view.history?.back())closeProfile();}
      dialog.querySelector('[data-rocket-profile-close]').addEventListener('click',back);
      edit.addEventListener('click',()=>{arenaNames.editTrainer(false);document.getElementById('arena-name-editor')?.addEventListener('close',render,{once:true});});
      tablist.addEventListener('keydown',event=>{
        const names=[...pages.keys()],index=names.indexOf(view.page);
        let next;
        switch(event.key){
          case 'ArrowLeft':next=names[(index+names.length-1)%names.length];break;
          case 'ArrowRight':next=names[(index+1)%names.length];break;
          case 'Home':next=names[0];break;
          case 'End':next=names[names.length-1];break;
          default:return;
        }
        event.preventDefault();select(next);
      });
      dialog.addEventListener('cancel',event=>{event.preventDefault();back();});
      dialog.addEventListener('keydown',event=>{event.stopPropagation();if(event.key==='Escape'&&!event.defaultPrevented){event.preventDefault();if(!event.repeat)back();}});
      for(const kind of ['keyup','pointerdown','pointerup','click'])dialog.addEventListener(kind,event=>event.stopPropagation());
      document.body.append(dialog);dialog.showModal();select(initial);
    }
    function renderCollection(host){
      host.replaceChildren();
      const collection=df(),owned=new Set(collection.unlocked),cards=Ju.filter(card=>owned.has(card.key));
      const node=(tag,text)=>{const element=document.createElement(tag);if(text!==undefined)element.textContent=text;return element;};
      const heading=node('h2','UNLOCKED CARDS · '+cards.length);host.append(heading);
      const grid=node('div');grid.className='rocket-collection-cards';host.append(grid);
      for(const card of cards){
        const cell=node('figure'),art=Xp({id:card.ids[0],k:1,tier:card.tier});
        cell.append(art,node('figcaption',card.name));grid.append(cell);
      }
      if(!cards.length)grid.append(node('p','No cards unlocked yet.'));
      host.append(node('h2','SHINIES'),node('p','No shinies recorded in this game build.'));
      arenaRocketBadges.render(host,summary(),'collection');
    }
    function render(){
      const trainer=document.querySelector('[data-rocket-trainer-name]');if(trainer)trainer.textContent=ei().profile.name;
      if(profileView&&profileView.page!=='profile')return;
      const targets=document.querySelectorAll('[data-rocket-profile]');if(!targets.length)return;const s=summary(),hours=Math.floor(s.playMs/3600000),minutes=Math.floor(s.playMs/60000)%60;
      const signature=JSON.stringify([hours,minutes,s.favoritePokemon,s.favoriteTeam,s.online,s.achievements,s.streaks,s.badges,s.equippedBadges,s.completion,s.persisted,s.notice]);
      const node=(tag,className,text)=>{const value=document.createElement(tag);if(className)value.className=className;if(text!==undefined)value.textContent=text;return value;};
      const battles=count=>count.toLocaleString()+(count===1?' battle':' battles');
      function portrait(id,name){
        const frame=node('span','rocket-stat-portrait'),image=node('img');image.alt='';image.loading='lazy';image.decoding='async';image.src=yp({id});frame.append(image);
        let retried=false;image.onerror=()=>{let fallback=null;try{fallback=Ep(id);}catch{}if(!retried&&fallback){retried=true;image.src=yp({id:fallback});return;}image.remove();frame.append(node('span','rocket-stat-missing','—'));frame.setAttribute('aria-label',name+' sprite unavailable');};
        return frame;
      }
      for(const target of targets){
        if(renderedProfiles.get(target)===signature)continue;
        renderedProfiles.set(target,signature);target.replaceChildren();
        const grid=node('div','rocket-stats-grid');target.append(grid);
        function card(label,id,extra=''){
          const box=node('article','rocket-profile-card '+extra);box.dataset.rocketStat=id;box.setAttribute('aria-label',label);box.append(node('h2','rocket-stat-label',label));grid.append(box);return box;
        }
        const favorite=card('Favorite Pokémon','favorite-pokemon','rocket-stat-feature');
        if(s.favoritePokemon){const mon=s.favoritePokemon,body=node('div','rocket-stat-favorite'),details=node('div','rocket-stat-mon-detail');details.append(node('strong','rocket-stat-mon-name',mon.name),node('span','rocket-stat-caption',battles(mon.battles)));body.append(portrait(mon.id,mon.name),details);favorite.append(body);}
        else{const body=node('div','rocket-stat-favorite');body.append(node('span','rocket-stat-portrait rocket-stat-empty','?'),node('p','rocket-stat-caption','Play a battle to discover your favorite.'));favorite.append(body);}
        const team=card('Favorite team','favorite-team','rocket-stat-feature rocket-stat-team-card'),party=node('div','rocket-stat-party');team.append(party);
        for(let i=0;i<3;i++){
          const member=node('div','rocket-stat-member');
          if(s.favoriteTeam){const id=s.favoriteTeam.ids[i],name=s.favoriteTeam.names[i];member.append(portrait(id,name),node('span','rocket-stat-team-name',name));}
          else member.append(node('span','rocket-stat-portrait rocket-stat-empty','—'),node('span','rocket-stat-team-name','Slot '+(i+1)));
          party.append(member);
        }
        team.append(node('p','rocket-stat-caption',s.favoriteTeam?battles(s.favoriteTeam.battles)+' together':'Play a three-Pokémon team to begin.'));
        const decided=s.online.total-s.online.noContests;
        const winRate=card('Online win rate','win-rate');winRate.append(node('strong','rocket-stat-value',decided?s.online.winRate.toFixed(1)+'%':'—'),node('p','rocket-stat-caption',decided?'Of '+decided.toLocaleString()+' completed matches':'No completed online matches'));
        const matches=card('Online matches','online-matches'),counts=node('div','rocket-stat-counts');matches.append(counts);
        for(const [label,value,kind]of [['Total',s.online.total,'total'],['Wins',s.online.wins,'wins'],['Losses',s.online.losses,'losses']]){const count=node('div','rocket-stat-count');count.dataset.count=kind;count.append(node('strong','',value.toLocaleString()),node('span','',label));counts.append(count);}
        if(s.online.draws)matches.append(node('p','rocket-stat-caption',s.online.draws.toLocaleString()+(s.online.draws===1?' draw':' draws')));
        if(s.online.noContests)matches.append(node('p','rocket-stat-caption',s.online.noContests.toLocaleString()+' No Contest'));
        for(const [label,key]of [['Current win streak','current'],['Highest win streak','best']]){
          const streak=card(label,key+'-win-streak');
          streak.append(node('strong','rocket-stat-value',s.streaks[key].toLocaleString()));
        }
        const sweeps=card('Clean Sweeps','clean-sweeps');sweeps.append(node('strong','rocket-stat-value',s.achievements.cleanSweeps.toLocaleString()),node('p','rocket-stat-caption','ONLINE WINS WITH YOUR WHOLE TEAM STANDING.'));
        const aces=card('Ace','aces');aces.append(node('strong','rocket-stat-value',s.achievements.aces.toLocaleString()),node('p','rocket-stat-caption','ONLINE WINS WITH NO DAMAGE TAKEN.'));
        const playtime=card('Playtime','playtime');playtime.append(node('strong','rocket-stat-value',hours.toLocaleString()+'h '+minutes+'m'));
        for(const [label,key]of [['Story','story'],['Cards','cards'],['Pokédex discovery','pokedex']]){
          const box=card(label,key),value=s.completion[key],percent=value&&Number.isFinite(value.percent)?Math.max(0,Math.min(100,value.percent)):0;
          box.append(node('strong','rocket-stat-value',value?percent.toFixed(1)+'%':'—'));
          const track=node('div','rocket-stat-progress'),fill=node('span');track.setAttribute('role','progressbar');track.setAttribute('aria-label',label+' completion');track.setAttribute('aria-valuemin','0');track.setAttribute('aria-valuemax','100');track.setAttribute('aria-valuenow',String(percent));fill.style.width=percent+'%';track.append(fill);box.append(track,node('p','rocket-stat-caption',value?value.done.toLocaleString()+' / '+value.total.toLocaleString()+(key==='story'?' stages':key==='cards'?' cards':' discovered'):'No progress available'));
        }
        target.append(node('p','rocket-profile-notice',s.notice+(s.persisted?'':' Changes could not be saved on this device.')));
        arenaRocketBadges.render(target,s);
      }
    }
    function boot(){
      get();syncStoryBadge(true);const style=document.createElement('style');style.textContent=`
        .rocket-profile-screen{--career-pad:clamp(12px,3vw,48px);box-sizing:border-box;position:fixed;inset:0;padding:0;margin:0;width:100%;height:100%;height:100dvh;max-width:none;max-height:none;border:0;border-radius:0;background:var(--ui-bg,#11172b);color:var(--ui-text,#f8f8f8);font:700 14px/1.45 Silkscreen,monospace;overflow:hidden;font-synthesis:none;text-rendering:optimizeSpeed;image-rendering:pixelated}
        .rocket-profile-screen[open]{display:flex;flex-direction:column}.rocket-profile-screen::backdrop{background:#080b12e8}
        .rocket-profile-header{display:flex;align-items:center;gap:16px;flex:0 0 auto;padding:16px var(--career-pad);background:var(--ui-panel,#272f55)}
        .rocket-profile-emblem{display:grid;place-items:center;flex:0 0 auto;width:56px;height:56px;border:2px solid var(--ui-frame-hi,#b4b8d3);border-radius:0;color:#ef3340;background:var(--ui-input-bg,#10152a);font:italic 900 40px/1 Silkscreen,monospace}
        .rocket-profile-identity{min-width:0;flex:1}.rocket-profile-eyebrow{margin:0 0 6px;color:var(--ui-text,#f8f8f8);font-size:12px;letter-spacing:0}
        .rocket-profile-identity h1{margin:0;font:700 clamp(20px,3vw,30px)/1.2 Silkscreen,monospace;overflow-wrap:anywhere;letter-spacing:0;text-transform:uppercase}
        .rocket-profile-actions{display:flex;align-items:center;gap:10px;flex-wrap:wrap}.rocket-profile-actions button{padding:10px 13px;min-height:40px;border:2px solid var(--ui-frame-hi,#b4b8d3);border-radius:0;box-shadow:2px 2px 0 var(--ui-outline,#080b18);background:var(--ui-panel,#272f55);color:var(--ui-text,#f8f8f8);font:700 14px/1.4 Silkscreen,monospace;cursor:pointer}.rocket-profile-actions button:hover{background:var(--ui-cell-selected,#343e70)}
        .rocket-profile-screen :focus-visible{outline:3px solid var(--ui-cursor,#f87818);outline-offset:-3px}
        .rocket-collection-cards{display:grid;grid-template-columns:repeat(auto-fill,minmax(110px,1fr));gap:12px}.rocket-collection-cards figure{margin:0;display:flex;flex-direction:column;align-items:center;gap:8px;padding:10px;background:var(--ui-panel,#272f55);text-align:center}.rocket-collection-cards figcaption{font-size:11px;overflow-wrap:anywhere}.rocket-profile-tabs{overflow-x:auto;display:flex;align-items:stretch;flex:0 0 auto;padding:0 var(--career-pad);border-bottom:2px solid var(--ui-frame,#8b94b9);background:var(--ui-panel-shade,#1a223d)}
        .rocket-profile-tabs button{min-width:86px;padding:9px 17px 7px;border:0;border-bottom:4px solid transparent;background:transparent;color:var(--ui-text-muted,#bbc1df);font:inherit;cursor:pointer}
        .rocket-profile-tabs button:hover{background:var(--ui-panel,#272f55);color:var(--ui-text,#fff)}
        .rocket-profile-tabs button[aria-selected=true]{background:var(--ui-panel,#272f55);border-color:var(--ui-cursor,#f87818);color:var(--ui-text,#fff)}
        .rocket-profile-page{box-sizing:border-box;min-height:0;min-width:0;flex:1 1 0;overflow:auto;overscroll-behavior:contain;scrollbar-gutter:stable;padding:16px var(--career-pad);scroll-padding:16px}
        .rocket-profile-page[hidden],.rocket-profile-actions button[hidden]{display:none}
        #rocket-page-history{position:relative;padding:0;overflow:hidden;scrollbar-gutter:auto}
        .rocket-profile{display:block;flex:0 0 auto;width:100%;max-width:none;min-width:0;box-sizing:border-box;container-type:inline-size;white-space:normal;text-align:left;font:700 14px/1.45 Silkscreen,monospace;color:var(--ui-text,#f8f8f8);padding:0 2px 12px}
        .rocket-profile *{box-sizing:border-box}
        .rocket-stats-grid{display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:12px}
        .rocket-profile-card{grid-column:span 2;min-width:0;padding:16px;border:2px solid var(--ui-frame-hi,#b4b8d3);border-radius:0;background:var(--ui-panel,#272f55);box-shadow:inset 0 0 0 2px var(--ui-outline,#080b18),2px 2px 0 var(--ui-outline,#080b18)}
        .rocket-profile-card.rocket-stat-feature{grid-column:span 3}
        .rocket-stat-label{font:700 14px/1.4 Silkscreen,monospace;letter-spacing:0;text-transform:uppercase;color:var(--ui-text,#f8f8f8);margin:0 0 14px}
        .rocket-stat-value{display:block;font-size:clamp(24px,4.4cqi,36px);line-height:1.2;font-weight:700;letter-spacing:0;font-variant-numeric:tabular-nums;overflow-wrap:anywhere}
        .rocket-stat-caption{display:block;color:var(--ui-text-muted,#bbc1df);font-size:12px;line-height:1.5;margin:9px 0 0;overflow-wrap:anywhere}
        .rocket-stat-favorite{display:flex;align-items:center;gap:14px;min-height:96px}
        .rocket-stat-mon-detail{min-width:0}.rocket-stat-mon-name{display:block;font-size:18px;line-height:1.3;overflow-wrap:anywhere}
        .rocket-stat-portrait{display:flex;align-items:center;justify-content:center;width:80px;height:80px;flex:0 0 auto;border:2px solid var(--ui-frame,#8b94b9);border-radius:0;background:var(--ui-input-bg,#10152a);overflow:hidden}
        .rocket-stat-portrait img{display:block;width:64px;height:64px;object-fit:contain;image-rendering:pixelated}
        .rocket-stat-empty,.rocket-stat-missing{font-size:28px;font-weight:700;color:#737789}
        .rocket-stat-party{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px}.rocket-stat-member{min-width:0;text-align:center}
        .rocket-stat-member .rocket-stat-portrait{width:100%;height:72px}.rocket-stat-team-name{display:block;margin-top:7px;font-size:12px;line-height:1.35;overflow-wrap:anywhere}
        .rocket-stat-team-card>.rocket-stat-caption{margin-top:12px}
        .rocket-stat-counts{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:7px}.rocket-stat-count{padding:9px 3px;border:2px solid var(--ui-outline,#080b18);background:var(--ui-input-bg,#10152a);border-radius:0;text-align:center;min-width:0}
        .rocket-stat-count strong{display:block;font-size:24px;line-height:1.25;font-variant-numeric:tabular-nums;overflow-wrap:anywhere}.rocket-stat-count span{display:block;font-size:12px;color:var(--ui-text,#f8f8f8);margin-top:5px}
        .rocket-stat-count[data-count="wins"] strong{color:#80e070}.rocket-stat-count[data-count="losses"] strong{color:#ff7878}
        .rocket-stat-progress{height:10px;border:2px solid var(--ui-outline,#080b18);background:var(--ui-input-bg,#10152a);border-radius:0;overflow:hidden;margin-top:18px}.rocket-stat-progress>span{display:block;height:100%;background:var(--ui-accent,#f8d830)}
        .rocket-profile-notice{font-size:11px;line-height:1.5;color:var(--ui-text-muted,#bbc1df);margin:14px 2px 0}
        @container(max-width:680px){.rocket-profile-card{grid-column:span 3}.rocket-stat-team-card{grid-column:span 6!important}.rocket-stat-feature:not(.rocket-stat-team-card){grid-column:span 6}.rocket-stat-favorite{min-height:80px}.rocket-stat-member .rocket-stat-portrait{height:76px}.rocket-stat-value{font-size:28px}}
        @container(max-width:390px){.rocket-profile-card{grid-column:span 6;padding:14px}.rocket-stat-party{gap:7px}.rocket-stat-portrait img{width:56px;height:56px}.rocket-stat-team-name{font-size:11px}}
        @media(max-width:650px),(max-height:500px){.rocket-profile-header{padding:8px var(--career-pad);gap:8px}.rocket-profile-emblem{width:34px;height:34px;font-size:24px}.rocket-profile-identity h1{font-size:17px}.rocket-profile-eyebrow{font-size:10px;margin-bottom:2px}.rocket-profile-actions{gap:5px}.rocket-profile-actions button{font-size:11px;min-height:34px;padding:5px 7px}.rocket-profile-tabs button{min-width:74px;padding:6px 12px 4px}.rocket-profile-page{padding:10px var(--career-pad)}}
      `;document.head.append(style);
      document.addEventListener('mousemove',event=>{if(event.isTrusted){tick();lastMouse=performance.now();}},{passive:true});
      document.addEventListener('visibilitychange',()=>{flush();lastTime=performance.now();});window.addEventListener('pagehide',flush);
      window.addEventListener('storage',event=>{if(event.key==='arena.rocket.profile.v1')get().refresh();});
      window.addEventListener('pagehide',closeProfile);
      window.setInterval(()=>{tick();render();},1000);
    }
    function dataReplaced(value){
      pendingMs=0;fieldTime.clear();careerGeneration++;nextStoryCheck=0;lastTime=lastSaved=performance.now();
      render();for(const fn of observers)try{fn(value);}catch{}return value;
    }
    const unlockCode=code=>globalThis.ArenaRocketAccess?.unlock(code)===true;
    const importSecretCode=code=>globalThis.rocketCloset?.toggle(code)||globalThis.ArenaRocketAccess?.toggle(code)||null;
    const api={open:openProfile,summary,career,awardBadge:id=>get().awardBadge(id),equipBadge:(id,slot)=>get().equipBadge(id,slot),unequipBadge:id=>get().unequipBadge(id),createHistory:record=>get().createHistory(record),updateHistory:(id,patch)=>get().updateHistory(id,patch),listHistory:()=>get().listHistory(),subscribeBattle(fn){battleObservers.add(fn);return()=>battleObservers.delete(fn);},exportCode:async()=>{flush();return get().exportCode();},snapshot:()=>{flush();return get().snapshot();},validateCode:code=>get().validateCode(code),replaceValidated:snapshot=>dataReplaced(get().replaceValidated(snapshot)),unlockCode,importSecretCode,importCode:async code=>importSecretCode(code)?summary():dataReplaced(await get().importCode(code)),reset:()=>dataReplaced(get().reset()),subscribe(fn){observers.add(fn);return()=>observers.delete(fn);}};
    globalThis.ArenaRocketProfile=Object.freeze(api);queueMicrotask(boot);
    const safe=fn=>(...args)=>{try{return fn(...args);}catch(error){console.warn('[rocket-profile] Recording unavailable',error);}};
    return{onlinePrepared:safe(onlinePrepared),onlineSnapshot:safe(onlineSnapshot),onlineInterrupted:safe(onlineInterrupted),battleTick:safe(battleTick),battleFrame:safe(battleFrame),soloRematch:scene=>scenes.delete(scene),onlineResult:safe(onlineResult),onlineEnded:safe(onlineEnded),forfeit:safe(forfeit),html,render:safe(render)};
  }
  function patch(source){
    if(source.includes('function createRocketProfile('))throw Error('Rocket profile already applied.');
    const replace=(before,after)=>{const parts=source.split(before);if(parts.length!==2)throw Error('Unsupported Rocket profile anchor: '+before.slice(0,85));source=parts.join(after);};
    replace('function _r(e,t){return e[Math.floor(t()*e.length)%e.length]}',createRocketProfile.toString()+'\n'+createRocketAchievements.toString()+'\n'+createRocketProfileBadges.toString()+'\nconst arenaRocketBadges=createRocketProfileBadges();\nconst arenaRocketProfile=('+createArenaRocketRuntime.toString()+')();\nfunction _r(e,t){return e[Math.floor(t()*e.length)%e.length]}');
    replace('this.battle=a,', 'this.battle=a,arenaRocketProfile.onlinePrepared(this,e,a,t),');
    replace('this.render=Ww(this.you,e,this.combat),this.predicted=', 'this.render=Ww(this.you,e,this.combat),arenaRocketProfile.onlineSnapshot(this,this.render,Zw(this.you,e.ev,e.ffa)),this.predicted=');
    replace('resumeAt(e){this.pending=[]', 'resumeAt(e){arenaRocketProfile.onlineInterrupted(this);this.pending=[]');
    replace('setConnected(e){this.connected!==e', 'setConnected(e){e||arenaRocketProfile.onlineInterrupted(this);this.connected!==e');
    replace('this.battle.applyResult(e.winner,e.reason),this.battle.setInputEnabled', 'this.battle.applyResult(e.winner,e.reason),arenaRocketProfile.onlineResult(this,e),this.battle.setInputEnabled');
    replace('t.result&&(this.result=t.result.reason,a.applyResult(t.result.winner,t.result.reason))', 't.result&&(this.result=t.result.reason,a.applyResult(t.result.winner,t.result.reason),arenaRocketProfile.onlineResult(this,t.result))');
    replace('leaveTo(e){this.active&&', 'leaveTo(e){arenaRocketProfile.forfeit(this);this.active&&');
    replace('end(e,t){if(!this.active)return;', 'end(e,t){if(!this.active)return;arenaRocketProfile.onlineEnded(this,e,t);');
    replace('let r=this.world.getState();r.phase===`fight`&&!this.paused', 'let r=this.world.getState();arenaRocketProfile.battleTick(this,r);r.phase===`fight`&&!this.paused');
    replace('rematch(){if(this.world instanceof bc){this.guidance=', 'rematch(){if(this.world instanceof bc){arenaRocketProfile.soloRematch(this);this.guidance=');
    replace('this.controls.consumeSample(),c=t.state;for(let e of c.fighters)', 'this.controls.consumeSample(),c=t.state,arenaRocketProfile.battleFrame(this,c,t.events);for(let e of c.fighters)');
    replace('function FE(){return oE(AE(),EE,_E??void 0)}', 'function FE(){return oE(AE(),EE,_E??void 0).filter(group=>group!==`profile`)}');
    return source;
  }
  const api={patch,createRocketProfile,createRocketAchievements,createArenaRocketRuntime};globalThis.ArenaRocketProfileAdapter=Object.freeze(api);
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})();
