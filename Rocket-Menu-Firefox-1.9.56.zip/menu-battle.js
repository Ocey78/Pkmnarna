// A separate six-fighter exhibition world for the native main menu only.
(() => {
  'use strict';

  function arenaMenuWorldType() {
    return class ArenaMenuWorld extends bc {
      constructor(ids, seed) {
        if (ids.length !== 6 || new Set(ids).size !== 6) throw Error('Menu battle needs six distinct species.');
        super({seed, stageId:'grass_rect', playerSpeciesId:ids[0], opponentSpeciesId:ids[3],
          partyIds:[ids[0]], opponentPartyIds:[ids[3]], ai:true, playerAi:true,
          difficulty:'hard', arenaSoloMods:false});
        this.arenaSoloMods = false;
        this.menuMembers = new Map();
        this.menuMemories = new Map();
        this.menuRespawns = new Map();
        this.menuTargets = new Map();
        this.respawnCount = 0;
        this.disposed = false;
        this.menuFighters = ids.map((species, i) => {
          const id = `menu-${i < 3 ? 'A' : 'B'}${i % 3}`;
          const point = this.spawnPoint(i);
          const fighter = this.makeFighter(id, dn(species), point.x, point.y, i < 3 ? 0 : Math.PI);
          fighter.menuTeam = i < 3 ? 'A' : 'B';
          this.menuMembers.set(id, this.membersFrom([species], null));
          this.menuMemories.set(id, Yo());
          return fighter;
        });
        // The native multi-target combat branches use `third` as their switch.
        // All target enumeration is supplied by this isolated six-actor world.
        this.player = this.menuFighters[0];
        this.opponent = this.menuFighters[3];
        this.third = this.menuFighters[1];
        this.party = this.menuMembers.get(this.player.id);
        this.foeParty = this.menuMembers.get(this.opponent.id);
        this.thirdParty = this.menuMembers.get(this.third.id);
        this.supply = null;
      }
      spawnPoint(index) {
        return {x:Ca/2 + (index < 3 ? -175 : 175), y:wa/2 + (index % 3 - 1)*150};
      }
      fighters() { return this.menuFighters || []; }
      fighterOf(id) {
        const actor = this.menuFighters?.find(fighter => fighter.id === id);
        if (!actor) throw Error('Unknown menu fighter.');
        return actor;
      }
      partyOf(id) { return this.menuMembers?.get(id) || []; }
      activeOf() { return 0; }
      cooldownOf() { return 0; }
      lockOf() { return 0; }
      memberLoadout(id, species) { return un(species.id).slice(); }
      trySwitch() {}
      canMega() { return false; }
      tryMega() {}
      localOption() { return false; }
      waivesLocalCooldowns() { return false; }
      enemies(actor) { return this.fighters().filter(other => other.menuTeam !== actor.menuTeam && other.hp > 0); }
      nearestEnemy(actor) {
        return this.enemies(actor).sort((a,b) => Math.hypot(a.x-actor.x,a.y-actor.y)-Math.hypot(b.x-actor.x,b.y-actor.y))[0] || null;
      }
      landHit(actor, target, ...args) {
        return actor.menuTeam === target.menuTeam ? 0 : super.landHit(actor,target,...args);
      }
      landBasic(actor, target, ...args) {
        return actor.menuTeam === target.menuTeam ? 0 : super.landBasic(actor,target,...args);
      }
      spawnZone(actor, move, x, y) {
        const spec = Go(move) ? Wo : so(move);
        if (!spec || this.disposed) return;
        this.zones = this.zones.filter(zone => zone.owner !== actor.id);
        const zone = {id:this.nextZone++,owner:actor.id,ownerEntry:actor.entry,move,x,y,r:spec.r,
          warnTicks:spec.warnTicks,hitTicks:spec.hitTicks,age:0,fresh:true,cursor:0,book:null};
        this.zones.push(zone);
        this.events.push({type:'ultZone',id:zone.id,x,y,r:zone.r,warnTicks:zone.warnTicks,hitTicks:zone.hitTicks,move});
      }
      respawn() {
        this.menuFighters.forEach((actor,index) => {
          if (actor.hp > 0) return;
          if (!this.menuRespawns.has(actor.id)) {
            this.menuRespawns.set(actor.id,this.tick+84);
            actor.cast=null;actor.pendingAction=null;
            this.bullets=this.bullets.filter(bullet=>bullet.owner!==actor.id);
            this.zones=this.zones.filter(zone=>zone.owner!==actor.id);
            return;
          }
          if (this.tick < this.menuRespawns.get(actor.id)) return;
          const point=this.spawnPoint(index), team=actor.menuTeam;
          Object.assign(actor,this.makeFighter(actor.id,dn(actor.speciesId),point.x,point.y,index<3?0:Math.PI));
          actor.menuTeam=team;actor.iframeMs=700;
          this.menuMembers.set(actor.id,this.membersFrom([actor.speciesId],null));
          this.menuMemories.set(actor.id,Yo());
          this.menuRespawns.delete(actor.id);
          this.respawnCount++;
          this.events.push({type:'menuRespawn',actor:actor.id,x:actor.x,y:actor.y});
        });
      }
      step() {
        if (this.disposed) return {state:this.getState(),events:[]};
        this.events=[];this.tick++;this.inputFrame++;this.elapsedMs+=q;
        for (const knock of this.pendingKnocks) {
          const actor=this.fighterOf(knock.target);
          if(actor.hp>0&&actor.entry===knock.entry)this.knock(actor,knock.vx,knock.vy,knock.amount);
        }
        this.pendingKnocks=[];
        this.respawn();
        const commands=this.menuFighters.map((actor,index)=>{
          const target=this.nearestEnemy(actor);
          this.menuTargets.set(actor.id,target?.id||null);
          if(actor.hp<=0||!target)return{actor,target,command:bo()};
          return{actor,target,command:ms({tick:this.tick,seed:this.seed^(Math.imul(index+1,2654435769)>>>0),
            self:this.aiBody(actor),foe:this.aiBody(target),tuning:this.tuning,memory:this.menuMemories.get(actor.id),canMega:false})};
        });
        for (const {actor,target,command} of commands) {
          if(actor.hp<=0||!target)continue;
          this.tickFighterUltPassive(actor,this.ultPassivePerSec*q/1000);
          this.advance(actor,command,target,rc(actor.speciesId,actor.x,actor.y),{x:target.x,y:target.y,hp:target.hp});
        }
        this.updateBullets();this.updateZones();this.separate();this.respawn();
        return{state:this.getState(),events:this.events};
      }
      getState() {
        return {tick:this.tick,inputFrame:this.inputFrame,phase:'fight',elapsedMs:this.elapsedMs,
          fighters:this.fighters().map(actor=>({...this.snapshot(actor),menuTeam:actor.menuTeam})),
          projectiles:this.bullets.map(b=>({id:b.id,owner:b.owner,move:b.move,x:b.x,y:b.y,vx:b.vx,vy:b.vy,radius:b.radius,basic:b.basic})),
          zones:this.zones.map(zone=>this.zoneState(zone)),items:[]};
      }
      dispose() {
        this.disposed=true;this.events=[];this.bullets=[];this.zones=[];this.pendingKnocks=[];
        this.menuRespawns.clear();this.menuMemories.clear();this.menuTargets.clear();
        for(const fighter of this.fighters()){fighter.cast=null;fighter.pendingAction=null;}
      }
    };
  }

  function arenaMenuSeed() {
    const values=new Uint32Array(1);
    if(globalThis.crypto?.getRandomValues)globalThis.crypto.getRandomValues(values);
    else values[0]=(Date.now()^Math.floor(Math.random()*0x100000000))>>>0;
    return values[0]||1;
  }
  function arenaMenuShuffle(seed) {
    const random=lo(seed), ids=rn.map(species=>species.id);
    for(let index=ids.length-1;index>0;index--){const other=Math.floor(random()*(index+1));[ids[index],ids[other]]=[ids[other],ids[index]];}
    return ids;
  }
  function arenaMenuCurrent(scene, session) {
    return scene.alive && scene.arenaMenuSession===session && !session.abort.signal.aborted;
  }
  function arenaMenuImage(url, session) {
    const key=oi(url);
    let pending=session.imageLoads.get(key);
    if(!pending){pending=arenaMenuFetchImage(key,session);session.imageLoads.set(key,pending);pending.catch(()=>session.imageLoads.delete(key));}
    return pending;
  }
  async function arenaMenuFetchImage(url, session) {
    const abort=new AbortController(), stop=()=>abort.abort();
    session.abort.signal.addEventListener('abort',stop,{once:true});
    const timer=setTimeout(stop,9000);session.timers.add(timer);
    try {
      const response=await fetch(url,{signal:abort.signal});
      if(!response.ok)throw Error('Menu sprite unavailable.');
      const image=await createImageBitmap(await response.blob());
      if(session.abort.signal.aborted){image.close();throw Error('Menu closed.');}
      session.images.add(image);
      return image;
    } finally {
      clearTimeout(timer);session.timers.delete(timer);
      session.abort.signal.removeEventListener('abort',stop);
    }
  }
  async function arenaMenuLoadActor(scene, session, id, index) {
    let clips=null;
    try { clips=await pp(id); } catch {}
    if(!arenaMenuCurrent(scene,session))return null;
    const art={}, poses=['idle','walk','shoot','charge','hurt','faint'];
    if(clips) {
      // Two workers per actor bound image decoding without changing the shared
      // native battle texture/cache loader or owning any Phaser textures.
      let next=0;
      await Promise.all([0,1].map(async()=>{
        while(next<poses.length&&arenaMenuCurrent(scene,session)){
          const pose=poses[next++], clip=clips[pose];
          if(!clip)continue;
          try{art[pose]={clip,source:await arenaMenuImage(clip.src,session)};}catch{}
        }
      }));
    }
    if(!arenaMenuCurrent(scene,session))return null;
    if(!art.idle) {
      try {
        const source=await arenaMenuImage(yp({id}),session);
        art.idle={source,clip:{frameWidth:source.width,frameHeight:source.height,frames:1,rows:1,durations:[1],anchor:[source.width/2,source.height*.82]}};
      } catch { return null; }
    }
    for(const pose of poses)art[pose]??=art.idle;
    const view=document.createElement('canvas'),shadow=document.createElement('canvas');
    view.className='menu-mon';shadow.className='menu-shadow';
    view.dataset.menuFighter=String(index);view.dataset.species=id;
    view.style.pointerEvents=shadow.style.pointerEvents='none';
    return{id,index,view,shadow,art,pose:'idle',poseTick:0,lastX:NaN,lastY:NaN,entry:0,drawn:''};
  }
  async function arenaMenuBattleStart(scene) {
    arenaMenuBattleDispose(scene);
    const layer=scene.root?.querySelector('.menu-cast');
    if(!layer)return;
    layer.replaceChildren();layer.style.pointerEvents='none';
    const session={abort:new AbortController(),timers:new Set(),images:new Set(),imageLoads:new Map(),world:null,accumulator:0,state:null,flashes:[],seed:arenaMenuSeed(),effects:null};
    scene.arenaMenuSession=session;scene.actors=[];
    scene.game.canvas.dataset.exhibit='loading';
    const deadline=setTimeout(()=>{if(arenaMenuCurrent(scene,session)&&!session.world){arenaMenuBattleDispose(scene);scene.game.canvas.dataset.exhibit='unavailable';}},30000);
    session.timers.add(deadline);
    const ids=arenaMenuShuffle(session.seed), actors=[];
    // Only two actors load at a time; failed artwork is replaced by another
    // randomly ordered native species, with a bounded number of candidates.
    for(let start=0;start<18&&actors.length<6&&arenaMenuCurrent(scene,session);start+=2){
      const found=await Promise.all(ids.slice(start,start+Math.min(2,6-actors.length)).map(id=>arenaMenuLoadActor(scene,session,id,0)));
      for(const actor of found)if(actor)actors.push(actor);
    }
    if(!arenaMenuCurrent(scene,session))return;
    if(actors.length!==6){scene.game.canvas.dataset.exhibit='unavailable';return;}
    actors.forEach((actor,index)=>{actor.index=index;actor.view.dataset.menuFighter=String(index);layer.append(actor.shadow,actor.view);});
    const effects=document.createElement('canvas');effects.className='menu-battle-effects';effects.setAttribute('aria-hidden','true');
    effects.style.cssText='position:absolute;inset:0;pointer-events:none;image-rendering:pixelated;z-index:0';
    layer.prepend(effects);session.effects=effects;
    const World=arenaMenuWorldType();session.world=new World(actors.map(actor=>actor.id),session.seed);
    clearTimeout(deadline);session.timers.delete(deadline);
    session.state=session.world.getState();scene.actors=actors;
    scene.game.canvas.dataset.exhibit='battle';scene.game.canvas.dataset.menuBattleCount='6';
    scene.game.canvas.dataset.menuBattleRoster=actors.map(actor=>actor.id).join(',');
  }
  function arenaMenuBattleDispose(scene) {
    const session=scene.arenaMenuSession;
    if(!session)return;
    scene.arenaMenuSession=null;session.abort.abort();
    for(const timer of session.timers)clearTimeout(timer);
    session.timers.clear();session.world?.dispose();
    for(const image of session.images)image.close?.();
    session.images.clear();session.imageLoads.clear();session.flashes=[];session.effects?.remove();
    for(const actor of scene.actors||[]){actor.view.remove();actor.shadow.remove();}
    scene.actors=[];
    delete scene.game.canvas.dataset.menuBattleCount;delete scene.game.canvas.dataset.menuBattleRoster;
    delete scene.game.canvas.dataset.menuBattleAlive;delete scene.game.canvas.dataset.menuBattleRespawns;delete scene.game.canvas.dataset.menuBattleTick;
  }
  function arenaMenuBattleStep(scene, delta) {
    const session=scene.arenaMenuSession;
    if(!session?.world||!arenaMenuCurrent(scene,session))return;
    if(document.hidden||scene.leaving){session.accumulator=0;return;}
    session.accumulator+=Math.min(100,Math.max(0,Number(delta)||0));
    while(session.accumulator>=q){
      const next=session.world.step();session.state=next.state;session.accumulator-=q;
      for(const event of next.events)if(event.type==='hit'||event.type==='menuRespawn')session.flashes.push({...event,until:session.world.tick+12});
    }
    session.flashes=session.flashes.filter(event=>event.until>session.world.tick).slice(-60);
    scene.game.canvas.dataset.menuBattleAlive=String(session.state.fighters.filter(actor=>actor.hp>0).length);
    scene.game.canvas.dataset.menuBattleRespawns=String(session.world.respawnCount);
    scene.game.canvas.dataset.menuBattleTick=String(session.world.tick);
  }
  function arenaMenuProjection(scene, ring) {
    const size=scene.stageSize();let field=OT(size.width,size.height,{x:ring.cx,y:ring.cy});
    if(scene.sharedHome)try{
      const frame=window.frameElement, image=frame?.closest('[data-game-window]')?.querySelector('.hero-bg img');
      if(frame&&image){const a=frame.getBoundingClientRect(),b=image.getBoundingClientRect();if(b.width>0&&b.height>0){
        field={x:b.left-a.left,y:b.top-a.top,w:b.width,h:b.height};
        // Parent scenery is already mirrored; project into the original box
        // before the matching cast-layer mirror is applied.
        if(frame.getAttribute('data-rocket-menu-active')==='1')field.x=size.width-field.x-field.w;
      }}
    }catch{}
    return {width:size.width,height:size.height,scale:ring.scale,
      x:value=>field.x+value/Ca*field.w,y:value=>field.y+value/wa*field.h,
      sx:field.w/Ca,sy:field.h/wa};
  }
  function arenaMenuPaintActor(scene, actor, ring) {
    const session=scene.arenaMenuSession, state=session?.state?.fighters[actor.index];
    if(!state)return;
    actor.view.dataset.fighter=state.id;actor.view.dataset.team=state.menuTeam;
    actor.view.dataset.hp=String(state.hp);actor.view.dataset.entry=String(state.entry);
    actor.view.dataset.worldX=String(Math.round(state.x));actor.view.dataset.worldY=String(Math.round(state.y));
    const moved=Math.hypot(state.x-actor.lastX,state.y-actor.lastY)>.1;
    const hurt=session.flashes.some(event=>event.target===state.id&&event.type==='hit'&&event.amount>0);
    let pose=vp({hp:state.hp,hurt,cast:state.cast,justShotMs:state.justShotMs,moving:moved,basicCooldownMs:0,sparkCooldownMs:0,shootTicks:1});
    if(pose!==actor.pose||actor.entry!==state.entry){actor.pose=pose;actor.poseTick=state.tick??session.state.tick;actor.entry=state.entry;}
    actor.view.dataset.pose=pose;
    const {clip,source}=actor.art[pose]||actor.art.idle;
    const age=session.state.tick-actor.poseTick, span=gp(clip.durations), column=hp(['faint','hurt','shoot'].includes(pose)?Math.min(age,span-1):age,clip.durations);
    const row=clip.rows>1?mp(state.cast==='idle'?state.facing:state.castFacing):0, frame=row*clip.frames+column;
    const signature=pose+':'+frame;
    if(actor.drawn!==signature){
      const w=clip.frameWidth,h=clip.frameHeight;
      const lit=rocketFighterMaterial(source,(frame%clip.frames)*w,Math.floor(frame/clip.frames)*h,w,h);
      if(lit)CX(actor.view,lit,0,1,w,h);
      else CX(actor.view,source,frame,clip.frames,w,h);
      actor.drawn=signature;
    }
    const projection=arenaMenuProjection(scene,ring), x=projection.x(state.x),y=projection.y(state.y),scale=projection.scale;
    const anchor=clip.anchor||[clip.frameWidth/2,clip.frameHeight*.82];
    Object.assign(actor.view.style,{width:clip.frameWidth*scale+'px',height:clip.frameHeight*scale+'px',
      left:Math.round(x-anchor[0]*scale)+'px',top:Math.round(y-anchor[1]*scale)+'px',zIndex:String(Math.max(2,Math.round(y)*2+1)),
      opacity:state.hp<=0?'.45':state.iframeMs>0&&Math.floor(session.state.tick/4)%2===0?'.55':'1'});
    const shadow=actor.shadow,width=Math.max(16,Math.round(state.radius*scale*1.5)),height=Math.max(6,Math.round(scale*3));
    if(shadow.width!==width||shadow.height!==height||shadow.dataset.team!==state.menuTeam){
      shadow.width=width;shadow.height=height;shadow.dataset.team=state.menuTeam;
      const context=shadow.getContext('2d');if(context){context.clearRect(0,0,width,height);BQ(context,width,height,OQ);context.fillStyle=state.menuTeam==='A'?'#70c8ff':'#ff8b82';context.fillRect(Math.floor(width/2)-3,height-2,6,2);}
    }
    Object.assign(shadow.style,{width:width+'px',height:height+'px',left:Math.round(x-width/2)+'px',top:Math.round(y-height/2)+'px',zIndex:String(Math.max(1,Math.round(y)*2))});
    actor.lastX=state.x;actor.lastY=state.y;
  }
  function arenaMenuPaintEffects(scene,ring) {
    const session=scene.arenaMenuSession,canvas=session?.effects,state=session?.state;
    if(!canvas||!state)return;
    const p=arenaMenuProjection(scene,ring);
    if(canvas.width!==p.width||canvas.height!==p.height){canvas.width=p.width;canvas.height=p.height;canvas.style.width=p.width+'px';canvas.style.height=p.height+'px';}
    const context=canvas.getContext('2d');if(!context)return;
    context.clearRect(0,0,p.width,p.height);context.imageSmoothingEnabled=false;
    const colors={fire:'#ff9657',water:'#65baff',electric:'#ffe96b',grass:'#8ee76c',ice:'#a6ffff',poison:'#d29bfa',psychic:'#ff9ac8',dark:'#ad99db',ghost:'#ab9fed',fighting:'#efb584',normal:'#f3e4c8',dragon:'#9fafff',fairy:'#ffc0df',steel:'#bcd4e0',ground:'#dcb16a',rock:'#c9b999',bug:'#cee979',flying:'#c4dfff'};
    const color=move=>colors[V(move).typeName]||'#f8f8f8';
    for(const zone of state.zones){context.strokeStyle=color(zone.move);context.globalAlpha=zone.age<zone.warnTicks?.5:.85;context.lineWidth=3;context.beginPath();context.ellipse(p.x(zone.x),p.y(zone.y),zone.r*p.sx,zone.r*p.sy,0,0,Math.PI*2);context.stroke();}
    context.globalAlpha=1;
    for(const actor of session.world.fighters())if(actor.hp>0&&actor.cast?.phase==='active'&&['stream','beam'].includes(actor.cast.shape)){
      const length=Re(V(actor.cast.moveId)),angle=actor.cast.facing??actor.facing;
      context.strokeStyle=color(actor.cast.moveId);context.lineWidth=Math.max(3,ring.scale*2);context.beginPath();context.moveTo(p.x(actor.x),p.y(actor.y));context.lineTo(p.x(actor.x+Math.cos(angle)*length),p.y(actor.y+Math.sin(angle)*length));context.stroke();
    }
    for(const bullet of state.projectiles){const x=p.x(bullet.x),y=p.y(bullet.y),radius=Math.max(3,bullet.radius*p.sx);context.fillStyle=color(bullet.move);context.fillRect(Math.round(x-radius),Math.round(y-radius),Math.ceil(radius*2),Math.ceil(radius*2));context.fillStyle='#ffffff';context.fillRect(Math.round(x)-1,Math.round(y)-1,3,3);}
    for(const event of session.flashes){const radius=(12-(event.until-state.tick))*2+4;context.strokeStyle=event.type==='menuRespawn'?'#b8f5ff':'#fff5c4';context.lineWidth=2;context.beginPath();context.arc(p.x(event.x),p.y(event.y),radius,0,Math.PI*2);context.stroke();}
  }

  function patch(original) {
    let source=original;
    if(source.includes('function arenaMenuWorldType()'))throw Error('Unsupported menu battle: already applied.');
    function replace(before,after){const parts=source.split(before);if(parts.length!==2)throw Error('Unsupported menu battle anchor: '+before.slice(0,70));source=parts.join(after);}
    function method(start,end,replacement){const from=source.indexOf(start),to=source.indexOf(end,from);if(from<0||to<0||source.indexOf(start,from+1)>=0)throw Error('Unsupported menu battle method: '+start);source=source.slice(0,from)+replacement+source.slice(to);}
    replace('for(let e of this.actors)this.paintActor(e,r.ring)', 'arenaMenuBattleStep(this,t);for(let e of this.actors)this.paintActor(e,r.ring);arenaMenuPaintEffects(this,r.ring)');
    replace('this.root?.remove(),this.root=null,this.actors=[]', 'arenaMenuBattleDispose(this),this.root?.remove(),this.root=null,this.actors=[]');
    replace('!this.sharedHome){this.loadRing();try{await VQ(this)}', 'true){this.loadRing();try{await VQ(this)}');
    method('async loadRing(){','async mountActor(', 'async loadRing(){await arenaMenuBattleStart(this)}');
    method('paintActor(e,t){','onKey=e=>', 'paintActor(e,t){arenaMenuPaintActor(this,e,t)}');
    const helpers=[arenaMenuWorldType,arenaMenuSeed,arenaMenuShuffle,arenaMenuCurrent,arenaMenuImage,arenaMenuFetchImage,arenaMenuLoadActor,
      arenaMenuBattleStart,arenaMenuBattleDispose,arenaMenuBattleStep,arenaMenuProjection,arenaMenuPaintActor,arenaMenuPaintEffects];
    replace('var M1=class extends FQ',helpers.map(helper=>helper.toString()).join('\n')+'\nvar M1=class extends FQ');
    return source;
  }
  const api=Object.freeze({patch,worldSource:()=>arenaMenuWorldType.toString()});
  globalThis.ArenaMenuBattleAdapter=api;
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})();
