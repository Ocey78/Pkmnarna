// Add connection choices to the native settings navigation and row controls.
(() => {
  'use strict';

  function createRocketGameSettings() {
    const choices = [['auto','AUTO'],['cloud','FORCE CLOUD'],['direct','FORCE DIRECT']];

    function markup() {
      if (!document.getElementById('rocket-game-settings-style')) {
        const style = document.createElement('style');
        style.id = 'rocket-game-settings-style';
        style.textContent = `
          #settings [data-kind="connection"]{flex-wrap:wrap;align-content:center;row-gap:10px}
          #settings .rocket-connection-fields{flex:1 1 380px;min-width:0;margin-left:auto}
          #settings .rocket-connection-choices{display:flex;flex-wrap:wrap;justify-content:flex-end;gap:4px}
          #settings.is-pc .rocket-connection-choices .seg-btn{min-width:0;height:52px;font-size:24px;line-height:24px;padding:0 10px}
          #settings .rocket-connection-note{margin:8px 0 0;font:14px/1.5 Silkscreen,monospace;
            color:var(--ui-text-dim);white-space:normal;text-align:right}
          #settings.is-phone .rocket-connection-fields{flex-basis:280px}
          #settings.is-phone .rocket-connection-choices .seg-btn{min-width:0;font-size:16px;line-height:16px;padding:0 6px}
          #settings.is-phone .rocket-connection-note{font-size:12px}
          @media(max-width:700px){#settings .rocket-connection-choices{justify-content:flex-start}
            #settings .rocket-connection-note{text-align:left}}
        `;
        document.head.append(style);
      }
      const mode = rocketConnectionMode.get();
      const buttons = choices.map(([value,label]) =>
        '<button type="button" class="px seg-btn' + (mode === value ? ' is-on' : '') +
        '" data-value="' + value + '" aria-pressed="' + String(mode === value) + '">' + label + '</button>').join('');
      const note = 'Applies when you join or create a room.' +
        (mode === 'direct' ? ' Direct requires a working peer connection. Cloud matches are declined.' : '');
      return '<div class="rocket-connection-fields"><div class="seg rocket-connection-choices" role="group" aria-label="Connection">' +
        buttons + '</div><p class="rocket-connection-note">' + note + '</p></div>';
    }

    function set(mode) {
      if (!choices.some(([value]) => value === mode)) return;
      const restoreFocus = document.activeElement?.closest?.('#settings [data-kind="connection"]');
      rocketConnectionMode.set(mode);
      NE();
      WE();
      if (restoreFocus) lE?.querySelector('[data-kind="connection"] [data-value="' + mode + '"]')?.focus({preventScroll:true});
    }

    function cycle(direction) {
      const index = choices.findIndex(([value]) => value === rocketConnectionMode.get());
      set(choices[(Math.max(0,index) + direction + choices.length) % choices.length][0]);
    }

    function setBodies(enabled) {
      const restoreFocus=document.activeElement?.closest?.('#settings [data-kind="keepFainted"]');
      rocketFaintedBodies.set(enabled);
      NE();WE();
      if(restoreFocus)lE?.querySelector('[data-kind="keepFainted"] [data-value="'+(enabled?'on':'off')+'"]')?.focus({preventScroll:true});
    }

    function key(event) {
      if (!pE || (event.key !== 'Enter' && event.key !== ' ')) return false;
      const button = event.target?.closest?.('#settings [data-kind="connection"] [data-value],#settings [data-kind="keepFainted"] [data-value]');
      if (!button) return false;
      event.preventDefault();
      event.stopPropagation();
      if (!event.repeat) {
        if(button.closest('[data-kind="keepFainted"]'))setBodies(button.dataset.value==='on');
        else set(button.dataset.value);
      }
      return true;
    }

    return {markup,set,cycle,key,setBodies};
  }

  function patch(source) {
    function replace(before,after) {
      const parts = source.split(before);
      if (parts.length !== 2) throw Error('Unsupported Game settings anchor: ' + before);
      source = parts.join(after);
    }
    replace('iE={profile:`PROFILE`,', 'iE={game:`GAME`,profile:`PROFILE`,');
    replace('function aE(e,t,n){', 'function aE(e,t,n){if(e===`game`)return[`connection`,`keepFainted`];');
    replace('function FE(){return oE(AE(),EE,_E??void 0).filter(group=>group!==`profile`)}',
      'function FE(){return[`game`,...oE(AE(),EE,_E??void 0).filter(group=>group!==`profile`&&group!==`game`)]}');
    replace('hE=`profile`,gE=0', 'hE=`game`,gE=0');
    replace('function gD(e){switch(e){', 'function gD(e){switch(e){case`keepFainted`:return`KEEP FAINTED BODIES`;case`connection`:return`CONNECTION`;');
    replace('function _D(e,t){', 'function _D(e,t){if(e===`keepFainted`)return yD(rocketFaintedBodies.get());if(e===`connection`)return rocketGameSettings.markup();');
    replace('function ND(e){let t=PE()[gE];', 'function ND(e){let t=PE()[gE];if(t?.kind===`keepFainted`){rocketGameSettings.setBodies(e===`on`);return;}if(t?.kind===`connection`){rocketGameSettings.set(e);return;}');
    replace('function DD(e){let t=PE()[gE];', 'function DD(e){let t=PE()[gE];if(t?.kind===`keepFainted`){rocketGameSettings.setBodies(!rocketFaintedBodies.get());return;}if(t?.kind===`connection`){rocketGameSettings.cycle(e);return;}');
    replace('function KD(){let e=PE()[gE];', 'function KD(){let e=PE()[gE];if(e?.kind===`keepFainted`){rocketGameSettings.setBodies(!rocketFaintedBodies.get());return;}if(e?.kind===`connection`){rocketGameSettings.cycle(1);return;}');
    replace('function GD(e){', 'function GD(e){if(rocketGameSettings.key(e))return;');
    replace('function BD(){', 'function BD(){rocketFaintedBodies.set(false);');
    return 'const rocketGameSettings=(' + createRocketGameSettings.toString() + ')();\n' + source;
  }

  globalThis.ArenaGameSettingsAdapter = Object.freeze({patch});
  if (typeof module !== 'undefined' && module.exports) module.exports = {patch};
})();
