// The background script verifies the game build. These changes run inside its
// native battle world. The cooldown adapter marks worlds created by solo play.
(() => {
  'use strict';

  function localOption(actor, key) {
    return this.arenaSoloMods === true && actor === this.player && arenaModEnabled(key);
  }

  function aimAttack(actor, command, foe) {
    if (!foe || foe.hp <= 0 || !this.localOption(actor, 'aim')) return command;
    if (!command.buttons.basic && !command.buttons.attacks.some(Boolean)) return command;
    const origin = rc(actor.speciesId, actor.x, actor.y);
    const target = rc(foe.speciesId, foe.x, foe.y);
    const aim = { x: target.x - origin.x, y: target.y - origin.y };
    // Native dash *attacks* take their direction from the movement stick. This
    // copy is local to the cast, after ordinary movement and dodge input.
    return { ...command, aim, move: aim, buttons: { ...command.buttons, snapAim: true } };
  }

  function patch(original) {
    let source = original;
    function replace(anchor, replacement) {
      const at = source.indexOf(anchor);
      if (at < 0 || source.indexOf(anchor, at + anchor.length) !== -1) {
        throw new Error('Unsupported game build. Missing or ambiguous combat anchor: ' + anchor.slice(0, 70));
      }
      source = source.slice(0, at) + replacement + source.slice(at + anchor.length);
    }
    // Embed as class methods so both helpers use the current world and fighter.
    const methods = [localOption, aimAttack].map(fn => fn.toString().replace(/^function /, '')).join('\n');
    replace('bodyRange(e){let t=Qe(e.loadout)', methods + '\nbodyRange(e){let t=Qe(e.loadout)');
    replace('let a=Qe(e.loadout),o=a[0]?.basicFallback?null:a[0]?.loadoutIndex??null,s=vc(e.loadout);',
      't=this.aimAttack(e,t,n);let a=Qe(e.loadout),o=a[0]?.basicFallback?null:a[0]?.loadoutIndex??null,s=vc(e.loadout);');
    // Ground-targeted ultimates use floor coordinates rather than body centers.
    // Keep the stock reach clamp and the original wind-up and impact behavior.
    replace('zonePoint(e,t,n,r,i){let a=i,o=Re(r)',
      'zonePoint(e,t,n,r,i){if(n.hp>0&&this.localOption(e,"aim"))t={...t,aim:{x:n.x-i.x,y:n.y-i.y}};let a=i,o=Re(r)');

    // The game uses hurt() for direct hits, recoil, zone hits and status ticks.
    replace('hurt(e,t,n,r=!0,i={}){if(i.direct', 'hurt(e,t,n,r=!0,i={}){if(this.localOption(e,"god"))return;if(i.direct');
    // Scripted knockouts use a direct HP setter instead of hurt(). Preserve
    // healing, roster setup and HP for the other team.
    replace('let r=this.partyOf(e)[t];if(!r||(r.hp=Math.max(0,n)',
      'let r=this.partyOf(e)[t];if(e==="player"&&t===this.activeOf(e)&&n<this.player.hp&&this.localOption(this.player,"god"))return;if(!r||(r.hp=Math.max(0,n)');

    // hasteMul is shared by ground locomotion and its reported walkSpeed.
    // Projectile velocity, dash distance, knockback and timers use other paths.
    replace('n=e.itemSpeedMs>0?Eo:1;return Math.max(t,n)',
      'n=e.itemSpeedMs>0?Eo:1;return Math.max(t,n)*(this.localOption(e,"speed")?2:1)');
    return source;
  }

  const api = Object.freeze({ patch });
  globalThis.ArenaCombatAdapter = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})();
