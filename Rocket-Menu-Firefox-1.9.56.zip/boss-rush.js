// A private solo encounter built on the native arena, party and effect systems.
(() => {
  'use strict';

  function createArenaBossDifficulty(){
    const levels=Object.freeze([
      {id:'easy',label:'Easy',health:.65,damage:.6,speed:.75,size:.8},
      {id:'normal',label:'Normal',health:1,damage:1,speed:1,size:1},
      {id:'hard',label:'Hard',health:1.3,damage:1.2,speed:1.15,size:1.1},
      {id:'expert',label:'Expert',health:1.65,damage:1.45,speed:1.3,size:1.2},
      {id:'champion',label:'Champion',health:2,damage:1.7,speed:1.5,size:1.3}
    ].map(Object.freeze)),choices=new Map(),open=new WeakMap(),prefix='arena.rocket.boss-difficulty.';
    function get(boss){
      let id=choices.get(boss);if(!id)try{id=localStorage.getItem(prefix+boss);}catch{}
      return levels.find(level=>level.id===id)||levels[1];
    }
    function choose(scene,boss,launch){
      if(open.has(scene))return;
      if(!document.getElementById('rocket-boss-difficulty-style')){
        const style=document.createElement('style');style.id='rocket-boss-difficulty-style';
        style.textContent=`
          .rocket-boss-difficulty{position:absolute;inset:0;z-index:1000;display:grid;place-items:center;background:#07132699;padding:12px;box-sizing:border-box}
          .rocket-boss-difficulty-panel{box-sizing:border-box;width:min(440px,100%);max-height:100%;overflow:auto;padding:16px;
            background:var(--ui-panel,#192c4c);border:4px solid var(--ui-frame-hi,#61799e);box-shadow:0 0 0 3px var(--ui-outline,#071326);color:var(--ui-text,#fff)}
          .rocket-boss-difficulty h2,.rocket-boss-difficulty h3{margin:0 0 12px;text-align:center;display:flex;justify-content:center}
          .rocket-boss-difficulty-list{display:grid;gap:8px}
          .rocket-boss-difficulty button{display:flex;justify-content:center;align-items:center;width:100%;min-height:42px;padding:10px 8px;
            border:3px solid var(--ui-frame-hi,#61799e);border-radius:0;background:var(--menu-btn,#285085);color:var(--ui-text,#fff);
            box-shadow:inset 0 -4px var(--menu-btn-shade,#102b50);cursor:pointer}
          .rocket-boss-difficulty button:focus-visible,.rocket-boss-difficulty button:hover{outline:2px solid var(--rw-gold-hi,#ffe298);outline-offset:1px}
          .rocket-boss-difficulty button[data-selected="true"]{border-color:var(--rw-gold-hi,#ffe298)}
          .rocket-boss-difficulty-detail{min-height:40px;margin:12px 0;text-align:center;font:12px/1.6 Silkscreen,monospace}
          @media(max-height:540px){.rocket-boss-difficulty-panel{padding:10px}.rocket-boss-difficulty-list{grid-template-columns:1fr 1fr}.rocket-boss-difficulty h2,.rocket-boss-difficulty h3{margin-bottom:8px}}
        `;document.head.append(style);
      }
      const previous=document.activeElement,leaving=scene.leaving;
      scene.leaving=true;
      const root=document.createElement('section');root.className='rocket-boss-difficulty';
      root.setAttribute('role','dialog');root.setAttribute('aria-modal','true');root.setAttribute('aria-label','Boss difficulty');
      const panel=document.createElement('div');panel.className='rocket-boss-difficulty-panel';
      const title=document.createElement('h2'),subtitle=document.createElement('h3');
      const encounter=boss==='eon'?{name:'LATIOS & LATIAS',hp:4000}:boss==='mewtwo'?{name:'MEWTWO',hp:6500}:{name:'RAYQUAZA',hp:6000};
      Iy(title,encounter.name,{scale:2});Iy(subtitle,'DIFFICULTY',{scale:2});
      const list=document.createElement('div');list.className='rocket-boss-difficulty-list';
      const detail=document.createElement('div');detail.className='rocket-boss-difficulty-detail';detail.setAttribute('aria-live','polite');
      const selected=get(boss),buttons=[];
      const describe=level=>{detail.textContent=Math.round(encounter.hp*level.health).toLocaleString()+' HP'+(boss==='eon'?' EACH':'')+
        ' · '+Math.round(level.damage*100)+'% DAMAGE\n'+Math.round(level.speed*100)+'% SPEED · '+Math.round(level.size*100)+'% ATTACK SIZE';detail.style.whiteSpace='pre-line';};
      let closed=false;
      const close=()=>{
        if(closed)return;closed=true;root.remove();open.delete(scene);scene.leaving=leaving;
        window.removeEventListener('keydown',keys,true);scene.events?.off('shutdown',close);
        if(previous?.isConnected)previous.focus({preventScroll:true});
      };
      const keys=event=>{
        event.stopImmediatePropagation();
        if(event.key==='Escape'){event.preventDefault();close();return;}
        const index=buttons.indexOf(document.activeElement);
        if(['ArrowDown','ArrowUp','Tab'].includes(event.key)){
          event.preventDefault();const direction=event.key==='ArrowUp'||event.key==='Tab'&&event.shiftKey?-1:1;
          buttons[(Math.max(0,index)+direction+buttons.length)%buttons.length].focus();
        }
      };
      for(const level of levels){
        const button=document.createElement('button');button.type='button';button.dataset.selected=String(level.id===selected.id);
        Iy(button,level.label.toUpperCase(),{scale:2});button.addEventListener('focus',()=>describe(level));button.addEventListener('pointerenter',()=>describe(level));
        button.addEventListener('click',()=>{choices.set(boss,level.id);try{localStorage.setItem(prefix+boss,level.id);}catch{}close();TT.ui('confirm');launch();});
        list.append(button);buttons.push(button);
      }
      const back=document.createElement('button');back.type='button';Iy(back,'BACK',{scale:2});back.addEventListener('click',close);buttons.push(back);
      panel.append(title,subtitle,list,detail,back);root.append(panel);(document.getElementById('app')||document.body).append(root);
      open.set(scene,close);scene.events?.once('shutdown',close);window.addEventListener('keydown',keys,true);
      describe(selected);buttons[levels.indexOf(selected)].focus({preventScroll:true});
    }
    return Object.freeze({levels,get,choose});
  }

  function createArenaBossRush() {
    const source='rocket-boss-rush',stage='rocket-sky-pillar',hp=6000,scale=2;

    function register(scene){
      const manager=scene.scene.manager;
      if(!manager.keys[source])manager.add(source,arenaBossRushSceneType(),false);
    }
    function start(scene){
      arenaBossDifficulty.choose(scene,'rayquaza',()=>{register(scene);scene.scene.start('pick',{source});});
    }
    function launch(scene,team){
      if(scene.started||!Array.isArray(team)||team.length!==3)return;
      register(scene);scene.started=true;TT.ui('confirm');
      scene.scene.start(source,{
        source,stageId:stage,difficulty:'hard',seed:Rk(team[0]),
        playerSpeciesId:team[0],partyIds:team.slice(),partyLoadouts:arenaBossTeams.loadouts(team),
        opponentSpeciesId:'rayquaza',opponentPartyIds:['rayquaza']
      });
    }
    function center(actor,x=actor.x,y=actor.y){
      const point=rc(actor.speciesId,x,y),factor=actor.rocketBossScale||1;
      return factor===1?point:{x:point.x,y:y-(y-point.y)*factor};
    }
    function hud(scene,state){
      const boss=state.fighters.find(fighter=>fighter.id==='opponent');
      if(!boss||!Z.hud)return;
      let view=scene.rocketBossHud;
      if(!view){
        if(!document.getElementById('rocket-boss-rush-style')){
          const style=document.createElement('style');style.id='rocket-boss-rush-style';
          style.textContent=`
            .hud.rocket-boss-rush .timer,.hud.rocket-boss-rush .cluster.foe,.hud.rocket-boss-rush .rocket-foe-party,
            .hud.rocket-boss-rush .rocket-active-health[data-side="opponent"]{display:none!important}
            .hud.rocket-boss-rush .cluster.player,.hud.rocket-boss-rush>.party{translate:0 var(--rocket-boss-offset,78px)}
            .rocket-boss-health{position:absolute;box-sizing:border-box;left:50%;top:8px;
              transform:translateX(-50%);width:min(760px,calc(100% - 24px));padding:8px 12px;
              border:3px solid var(--ui-frame-hi,#61799e);background:var(--ui-panel,#192c4c);
              box-shadow:0 0 0 2px var(--ui-outline,#071326),inset 0 -3px #102039;
              color:var(--ui-text,#fff);font:700 14px/1.4 Silkscreen,monospace;pointer-events:none;z-index:4}
            .rocket-boss-health[hidden]{display:none}
            .rocket-boss-heading{display:flex;justify-content:space-between;gap:12px;align-items:center;margin-bottom:5px}
            .rocket-boss-name{color:#8bf0ae}.rocket-boss-value{font-size:12px;white-space:nowrap}
            .rocket-boss-level{font-size:9px;color:var(--ui-text-dim,#a5bbd7);margin-top:3px}
            .rocket-boss-track{height:26px;border:2px solid #071326;background:#071326;overflow:hidden}
            .rocket-boss-fill{height:100%;width:100%;background:linear-gradient(#a3ed75 0 27%,#55c756 27% 74%,#2a8c49 74%);transform-origin:left}
            .rocket-boss-health.is-mega .rocket-boss-name{color:#f4cf72}
            .rocket-boss-health.is-mega .rocket-boss-fill{background:linear-gradient(#ffe9a0 0 27%,#e6ba48 27% 74%,#a7792a 74%)}
            .rocket-boss-health.is-enraged .rocket-boss-name{color:#ffb594}
            .rocket-boss-health.is-enraged .rocket-boss-fill{background:linear-gradient(#ffd099 0 27%,#f17447 27% 74%,#ab393d 74%)}
            .hud.is-mobile .rocket-boss-health{padding:5px 8px;font-size:11px;width:calc(100% - 112px);top:6px}
            .hud.is-mobile .rocket-boss-track{height:22px}.hud.is-mobile .rocket-boss-value{font-size:10px}
            @media(max-height:440px){.rocket-boss-health{padding:4px 8px;font-size:11px}.rocket-boss-heading{margin-bottom:3px}.rocket-boss-track{height:20px}}
          `;document.head.append(style);
        }
        const root=document.createElement('section');root.className='rocket-boss-health';
        root.setAttribute('role','progressbar');root.setAttribute('aria-valuemin','0');root.setAttribute('aria-valuemax',String(hp));
        const heading=document.createElement('div');heading.className='rocket-boss-heading';
        const name=document.createElement('span');name.className='rocket-boss-name';
        const value=document.createElement('span');value.className='rocket-boss-value';heading.append(name,value);
        const track=document.createElement('div');track.className='rocket-boss-track';
        const fill=document.createElement('div');fill.className='rocket-boss-fill';track.append(fill);
        const level=document.createElement('div');level.className='rocket-boss-level';root.append(heading,track,level);
        const host=Z.hud;host.classList.add('rocket-boss-rush');host.append(root);
        view=scene.rocketBossHud={root,name,value,fill,level,host,last:'',layoutAt:0};
        scene.events.once('shutdown',()=>{root.remove();host.classList.remove('rocket-boss-rush');host.style.removeProperty('--rocket-boss-offset');scene.rocketBossHud=null;});
      }
      view.root.hidden=state.phase!=='fight';
      const maximum=boss.maxHp,level=scene.world.bossDifficulty||arenaBossDifficulty.get('rayquaza');
      const health=Math.max(0,Math.ceil(boss.hp)),mega=boss.speciesId==='rayquazamega',enraged=!!state.rocketBossAttack?.enraged,key=health+':'+mega+':'+enraged+':'+maximum+':'+level.id;
      if(view.last!==key){
        view.last=key;view.name.textContent=(mega?'MEGA RAYQUAZA':'RAYQUAZA')+(enraged?' · ENRAGED':'');
        view.level.textContent=level.label.toUpperCase();
        view.value.textContent=health.toLocaleString()+' / '+maximum.toLocaleString();
        view.fill.style.transform='scaleX('+Math.max(0,Math.min(1,boss.hp/maximum))+')';
        view.root.setAttribute('aria-valuemax',String(maximum));
        view.root.classList.toggle('is-mega',mega);view.root.setAttribute('aria-valuenow',String(health));
        view.root.classList.toggle('is-enraged',enraged);
        view.root.setAttribute('aria-label',(mega?'Mega Rayquaza':'Rayquaza')+' boss health');
      }
      if(performance.now()>=view.layoutAt){
        view.layoutAt=performance.now()+250;
        if(!view.root.hidden){
          const width=view.host.clientWidth;let left=12,right=width-12;
          for(const node of view.host.querySelectorAll('.party,.cluster.player')){
            if(node.offsetWidth&&node.offsetHeight)left=Math.max(left,node.offsetLeft+node.offsetWidth+12);
          }
          const pause=view.host.querySelector('.pause');
          if(pause?.offsetWidth&&pause.offsetHeight)right=Math.min(right,pause.offsetLeft-10);
          const alongside=right-left>=340;
          view.root.style.left=(alongside?(left+right)/2:width/2)+'px';
          view.root.style.width=(alongside?Math.min(760,right-left):Math.max(180,width-(pause?.offsetWidth?112:24)))+'px';
          view.host.style.setProperty('--rocket-boss-offset',alongside?'0px':(view.root.offsetHeight+10)+'px');
        }
      }
    }
    return Object.freeze({source,stage,hp,scale,start,launch,center,hud});
  }

  function arenaBossRushWorldType(){
    return class RocketRayquazaWorld extends bc {
      constructor(options={}){
        super({...options,ai:true,playerAi:false,cpuSwitch:false,rosterForms:true,difficulty:'hard',clock:'countup',
          stageId:arenaBossRush.stage,arenaCpuMode:null,thirdPartyIds:undefined,thirdPartyLoadouts:undefined,
          story:null,bossAdvantage:undefined,partyHpRatio:null,opponentSpeciesId:'rayquaza',
          opponentPartyIds:['rayquaza'],opponentPartyLoadouts:[un('rayquaza').slice()]});
        this.bossDifficulty=arenaBossDifficulty.get('rayquaza');this.arenaBossRush=true;this.configureBoss();
      }
      configureBoss(){
        this.bossMega=false;this.bossMegaPending=false;this.bossTransforming=false;this.foeMegaUsed=false;
        this.opponent.hp=Math.round(arenaBossRush.hp*this.bossDifficulty.health);this.resizeBoss(this.opponent);
        this.foeParty[0].hp=this.opponent.maxHp;
        this.ai=false;this.cpuSwitch=false;this.tuning=Jo('hard');this.aiMemory=Yo();
        rocketBossAttacks.reset(this);
      }
      resizeBoss(actor){
        const species=dn(actor.speciesId);
        actor.maxHp=Math.round(arenaBossRush.hp*this.bossDifficulty.health);actor.rocketBossScale=arenaBossRush.scale;
        actor.radius=species.radius*arenaBossRush.scale;
        const point=Ia(actor.x,actor.y,actor.radius,this.combat,actor.x,actor.y);actor.x=point.x;actor.y=point.y;
        const member=this.foeParty?.[0];
        if(member)member.species={...species,maxHp:actor.maxHp,radius:actor.radius};
      }
      reset(){super.reset();if(this.arenaBossRush)this.configureBoss();}
      adopt(actor,species,health){
        super.adopt(actor,species,health);
        if(this.arenaBossRush&&actor.id==='opponent')this.resizeBoss(actor);
      }
      canMega(side){
        if(this.arenaBossRush&&side==='opponent')return this.bossTransforming===true&&this.phase==='fight'&&this.opponent.hp>0&&!this.foeMegaUsed;
        return super.canMega(side);
      }
      rocketAutoProtectThreat(ms,predict){return rocketBossAttacks.autoProtectThreat(this,ms,predict);}
      hurt(actor,amount,move,guarded=true,detail={}){
        if(this.arenaBossRush&&actor.id==='opponent'&&detail.direct&&rocketBossAttacks.invulnerable(this))return;
        // Normalize the native HP-based damage formula so extra boss health
        // really adds durability rather than proportionally boosting player hits.
        if(this.arenaBossRush&&actor.id==='opponent'&&amount>0)amount=Math.max(1,Math.round(amount/(6*this.bossDifficulty.health)));
        super.hurt(actor,amount,move,guarded,detail);
        if(this.arenaBossRush&&actor.id==='opponent'&&!this.bossMega&&actor.hp>0&&actor.hp<=actor.maxHp/2)this.bossMegaPending=true;
      }
      step(...commands){
        const previousTick=this.tick,result=super.step(...commands),actor=this.opponent;
        // Finish the current hit and its status/KO handling before changing form.
        if(this.bossMegaPending&&this.phase==='fight'&&actor.hp>0){
          const health=actor.hp,previous={cast:actor.cast,pendingAction:actor.pendingAction,recoverMs:actor.recoverMs,
            iframeMs:actor.iframeMs,dodgeVx:actor.dodgeVx,dodgeVy:actor.dodgeVy},eventIndex=this.events.length;
          this.bossTransforming=true;
          actor.cast=null;actor.pendingAction=null;actor.recoverMs=0;actor.iframeMs=0;actor.dodgeVx=actor.dodgeVy=0;
          try{super.tryMega(actor);}finally{this.bossTransforming=false;}
          if(actor.speciesId==='rayquazamega'){
            this.bossMega=true;this.bossMegaPending=false;actor.hp=health;
            this.resizeBoss(actor);this.rememberHp(actor);
            if(result.events!==this.events)result.events.push(...this.events.slice(eventIndex));
            result.state=this.getState();
          }else Object.assign(actor,previous);
        }
        const extraEvents=this.events.length;
        rocketBossAttacks.step(this);
        if(this.tick!==previousTick&&this.stopTicks===0&&this.phase==='fight')this.resolveKnockouts();
        if(result.events!==this.events)result.events.push(...this.events.slice(extraEvents));
        result.state=this.getState();
        return result;
      }
      snapshot(actor){
        const state=super.snapshot(actor);
        if(this.arenaBossRush&&actor.id==='opponent')state.rocketBossScale=arenaBossRush.scale;
        return state;
      }
      aiBody(actor){
        const body=super.aiBody(actor);
        if(this.arenaBossRush&&actor.id==='opponent')body.rocketBossScale=arenaBossRush.scale;
        return body;
      }
      enemies(actor){
        const enemies=super.enemies(actor);
        return this.arenaBossRush&&actor.id==='player'&&rocketBossAttacks.invulnerable(this)
          ?enemies.filter(enemy=>enemy.id!=='opponent'):enemies;
      }
      separate(){
        if(this.arenaBossRush&&rocketBossAttacks.invulnerable(this))return;
        super.separate();
      }
      getState(){
        const state=super.getState();
        if(this.arenaBossRush){state.rocketBossRush=true;rocketBossAttacks.snapshot(this,state);}
        return state;
      }
    };
  }

  function arenaBossRushSceneType(){
    return class RocketRayquazaScene extends RY {
      constructor(){super('rocket-boss-rush');this.rocketBossRush=true;}
      init(data){
        super.init({...data,net:null,source:'cpu',difficulty:'hard',cpuSwitch:false,arenaCpuMode:null,
          stageId:arenaBossRush.stage,story:null,run:null,encounter:null});
        this.battleSource=arenaBossRush.source;this.aiEnabled=true;this.assist=null;
        this.rocketBossBadgeGranted=false;
        this.debugKo=this.debugUlt=false;this.debugFaint=this.debugBall=null;this.debugSwitchSlot=null;
      }
      async create(){
        // The native critical-load list already includes Vk([rayquaza]), so
        // both Rayquaza forms are ready before the countdown finishes.
        arenaAudioWorkshop.prepareBossMusic();
        const epoch=this.loadEpoch;await super.create();
        if(!this.alive||!this.ready||epoch!==this.loadEpoch)return;
        Z.onRepick=()=>{Lq();Z.hideResult();this.scene.start('pick',{source:arenaBossRush.source});};
        arenaBossRush.hud(this,this.world.getState());
      }
      draw(state){
        rocketBossVfx.beforeDraw(this);super.draw(state);rocketBossVfx.draw(this,state);arenaBossRush.hud(this,state);
        if(state.phase==='fight')arenaAudioWorkshop.bossMusic(state.rocketBossAttack?.enraged?3:this.world.bossMega?2:1);
      }
      stackAnchor(species,x,y){
        const boss=this.world?.opponent,player=this.world?.player;
        if(boss&&species===boss.speciesId&&(species!==player?.speciesId||
            Math.hypot(x-boss.x,y-boss.y)<Math.hypot(x-player.x,y-player.y)))
          return this.hudPoint(x,y-Qs[ec(species)]*arenaBossRush.scale);
        return super.stackAnchor(species,x,y);
      }
      settleMatch(phase){
        Fl(phase,0);Z.setResultCoins(null,false);Z.setResultStars(null);
        if(phase!=='victory'){this.rocketBossBadgeGranted=false;return;}
        const level=this.world?.bossDifficulty?.id,profile=globalThis.ArenaRocketProfile;
        if(!this.rocketBossBadgeGranted&&['expert','champion'].includes(level)&&profile?.awardBadge){
          this.rocketBossBadgeGranted=true;
          try{profile.awardBadge('rayquaza-'+level);}catch(error){console.warn('[rocket-profile] Boss badge could not be recorded',error);}
        }
      }
      noteCollection(){}
      lightRow(){}
      noteOwnRow(){}
    };
  }

  function patch(source){
    const once=(before,after)=>{
      const parts=source.split(before);if(parts.length!==2)throw Error('Unsupported Boss Rush anchor: '+before.slice(0,90));
      source=parts.join(after);
    };
    once('launch(e,t){if(this.started||e.length<3)return;',
      'launch(e,t){if(this.source===arenaBossRush.source){arenaBossRush.launch(this,e);return}if(this.started||e.length<3)return;');
    once('showPick(e,t=`quick`,offline=false){this.arenaRosterOffline=offline;',
      'showPick(e,t=`quick`,offline=false){this.rocketBossPick=t===arenaBossRush.source;this.arenaRosterOffline=offline;');
    once('let e=t===`cpu`?El(_l(Yy())):K(`menu.pickBanner.${t}`);',
      'let e=t===arenaBossRush.source?`BOSS RUSH - RAYQUAZA / SKY PILLAR`:t===`cpu`?El(_l(Yy())):K(`menu.pickBanner.${t}`);');
    once('const enabled = ui => ui.arenaRosterOffline === true;',
      'const enabled = ui => ui.arenaRosterOffline === true && !ui.rocketBossPick;');
    once('this.world=new (this.rocketLobbyTraining?arenaTrainingWorldType():arenaCpuWorldType())(',
      'this.world=new (this.rocketBossRush?arenaBossRushWorldType():this.rocketLobbyTraining?arenaTrainingWorldType():arenaCpuWorldType())(');
    once('function pk(e,t,n,r,i,a=!1,o=!1,s=null,c=!1,l=null){',
      'function pk(e,t,n,r,i,a=!1,o=!1,s=null,c=!1,l=null){e.rocketBossScale=t.rocketBossScale||1;');
    once('function bk(e){e.sprite.setScale(QO(yk(e),ec(e.speciesId)))}',
      'function bk(e){e.sprite.setScale(QO(yk(e),ec(e.speciesId))*(e.rocketBossScale||1))}');
    once('s=QO(yk(e),ec(e.speciesId)),c=Math.max(1,Math.round(o*s*i.scaleStep))',
      's=QO(yk(e),ec(e.speciesId))*(e.rocketBossScale||1),c=Math.max(1,Math.round(o*s*i.scaleStep))');
    let centers=0;
    source=source.replace(/\brc\(([\w$]+(?:\.[\w$]+)*)\.speciesId,\s*([\w$]+(?:\.[\w$]+)*)\.x,\s*\2\.y\)/g,
      (_,actor,point)=>{centers++;return 'arenaBossRush.center('+actor+(actor===point?'':','+point+'.x,'+point+'.y')+')';});
    if(centers<10)throw Error('Unsupported Boss Rush actor centers.');
    once('let o=fM(a.speciesId,a.x,a.y);r.cx=o.x,r.cy=o.y',
      'let o=arenaBossRush.center(a);r.cx=o.x,r.cy=o.y');
    once('hudObstacles(){let e=[', 'hudObstacles(){let e=[`.rocket-boss-health`,');
    return 'const arenaBossDifficulty=('+createArenaBossDifficulty.toString()+')();\nconst arenaBossRush=('+createArenaBossRush.toString()+')();globalThis.arenaBossRush=arenaBossRush;\n'+
      arenaBossRushWorldType.toString()+'\n'+arenaBossRushSceneType.toString()+'\n'+source;
  }
  globalThis.ArenaBossRushAdapter=Object.freeze({patch});
  if(typeof module!=='undefined'&&module.exports)module.exports={patch};
})();
