'use strict';

// A successful native DIRECT connection supplies the identity of the other
// seat. This protocol sends no invitation secret, move choices or save data.
function createLobbySharing(validTeam, changed) {
  const sessions = new WeakMap();
  const tag = 'arena-lobby-lineup';

  function roomPeer(c) {
    const room = c?.room, peer = c?.peer;
    if (!c?.active || c.mode !== 'room' || c.battle ||
        !room || !['open', 'lobby', 'countdown'].includes(room.state) ||
        (room.mode !== undefined && room.mode !== 'duel') || room.seats?.length !== 2 ||
        !['A', 'B'].includes(c.you) || room.you !== c.you ||
        typeof c.code !== 'string' || !/^[23456789ABCDEFGHJKMNPQRSTUVWXYZ]{6}$/.test(c.code) ||
        room.code !== c.code || !room.seats.every(seat => seat?.present === true) ||
        typeof peer?.offer?.id !== 'string' || !/^[a-f0-9]{8}$/.test(peer.offer.id)) return null;
    return peer;
  }
  function channel(c) {
    const peer = roomPeer(c);
    return peer && !c.linkDown && c.connectionLabel === 'DIRECT' && peer.available() ? peer : null;
  }
  function existing(c) {
    const s = sessions.get(c);
    if (!s || s.peer !== roomPeer(c) || s.room !== c.code || s.offer !== c.peer.offer.id || s.seat !== c.you) return null;
    return s;
  }
  function legal(ids) {
    return Array.isArray(ids) && ids.length === 3 &&
      ids.every(id => typeof id === 'string' && /^[a-z0-9-]{1,32}$/.test(id)) && validTeam(ids);
  }
  function send(s, op, species) {
    const packet = { t: tag, v: 1, r: s.room, o: s.offer, op };
    if (species !== undefined) packet.species = species.slice();
    return s.peer.send(packet) === true;
  }
  function publish(c, s) {
    if (!s.compatible) return;
    const own = c.room.seats[c.you === 'A' ? 0 : 1];
    const ids = s.enabled && !own.editing && legal(c.team) ? c.team : null;
    const signature = ids ? ids.join(',') : '';
    if (signature !== s.sent && send(s, ids ? 'lineup' : 'withdraw', ids || undefined)) s.sent = signature;
  }
  function close(c) {
    if (sessions.delete(c)) changed();
  }
  function refresh(c) {
    const peer = channel(c);
    if (!peer) {
      const s = existing(c);
      if (!s) close(c);
      else if (s.online) {
        // Keep the user's decision for a brief outage on this same native
        // offer. Clear the remote disclosure and ask again after reconnect.
        Object.assign(s,{online:false,hello:false,compatible:false,sent:'',received:null});
        changed();
      }
      return null;
    }
    let s = existing(c);
    if (!s) {
      s = { peer, room: c.code, offer: peer.offer.id, seat: c.you, enabled: false, online: true,
        compatible: false, hello: false, sent: '', received: null };
      sessions.set(c, s);
      changed();
    } else if (!s.online) { s.online = true; changed(); }
    if (!s.hello) s.hello = send(s, 'hello');
    publish(c, s);
    return s;
  }
  function set(c, enabled) {
    const s = refresh(c) || (enabled === false && existing(c));
    if (!s || typeof enabled !== 'boolean') return false;
    if (s.enabled !== enabled) {
      s.enabled = enabled;
      if (s.online) publish(c, s);
      changed();
    }
    return true;
  }
  function receive(c, message) {
    const peer = channel(c);
    if (!peer || message?.t !== tag || message.v !== 1 || message.r !== c.code || message.o !== peer.offer.id) return;
    // A remote command cannot address the local seat or opt it in. Only a packet
    // with a complete native-legal team constitutes a new species disclosure.
    const op = message.op;
    if (!['hello','ack','lineup','withdraw','identity'].includes(op)) return;
    if (Object.keys(message).length !== (['lineup','identity'].includes(op) ? 6 : 5)) return;
    if (op === 'lineup' && !legal(message.species)) return;
    if(op==='identity' && (typeof message.clientId!=='string'||!/^[a-zA-Z0-9_-]{8,32}$/.test(message.clientId)))return;
    const s = refresh(c);
    if (!s) return;
    const newlyCompatible = !s.compatible;
    s.compatible = true;
    if(op==='hello'||op==='ack'){
      const id=c.client?.clientId;
      if(typeof id==='string'&&/^[a-zA-Z0-9_-]{8,32}$/.test(id))s.peer.send({t:tag,v:1,r:s.room,o:s.offer,op:'identity',clientId:id});
    }
    if (op === 'hello') {
      // The receiver may have started listening after our initial hello. Give it
      // the current state, including a withdrawal if sharing is currently off.
      send(s, 'ack');
      s.sent = undefined;
    }
    let different = false;
    if(op==='identity'){different=s.remoteId!==message.clientId;s.remoteId=message.clientId;}
    if (op === 'lineup' || op === 'withdraw') {
      const next = op === 'lineup' ? message.species : null;
      different = (s.received?.join(',') || '') !== (next?.join(',') || '');
      if (different) s.received = next?.slice() || null;
    }
    publish(c,s);
    if (newlyCompatible || different) changed();
  }
  function forSeat(c, seat) {
    const s = existing(c);
    if (!s || !channel(c) || !['A', 'B'].includes(seat)) return null;
    if (c.room.seats[seat === 'A' ? 0 : 1].editing) return null;
    if (seat === c.you) return s.enabled && legal(c.team) ? c.team.slice() : null;
    return s.received?.slice() || null;
  }
  return {
    set, refresh, close, receive, forSeat,
    identity:(c,seat)=>seat!==c.you&&channel(c)?existing(c)?.remoteId||null:null,
    shared: c => existing(c)?.enabled === true,
    available: c => !!channel(c),
    compatible: c => !!channel(c) && existing(c)?.compatible === true
  };
}

function patchLineupSharing(original) {
  let source = original;
  function replace(before, after) {
    const parts = source.split(before);
    if (parts.length !== 2) throw Error('Unsupported game. Missing or ambiguous lineup anchor: ' + before.slice(0,70));
    source = parts.join(after);
  }
  // Only _w's ordered RTCDataChannel gets a new message type. The official
  // service socket, its parsers, transport selection and native timers stay stock.
  replace('try{let t=JSON.parse(e);if(!t||typeof t!=`object`)return;',
    'try{let t=JSON.parse(e);if(!t||typeof t!=`object`)return;if(t.t==="arena-lobby-lineup"){this.on.data(t);return}');
  replace('t?.direct&&this.battle&&!this.result&&(e.t===`in`?',
    'if(e.t==="arena-lobby-lineup"){arenaLobbyShare.receive(this,e);return}t?.direct&&this.battle&&!this.result&&(e.t===`in`?');
  replace('this.roomReceivedAt=performance.now(),this.you=e.you,e.secret&&',
    'this.roomReceivedAt=performance.now(),this.you=e.you,arenaLobbyShare.refresh(this),e.secret&&');
  replace('e.mode===`cloud`&&this.closePeer(),this.mode===`room`&&this.paintRoom()',
    'e.mode===`cloud`&&this.closePeer(),arenaLobbyShare.refresh(this),this.mode===`room`&&this.paintRoom()');
  replace('uT(this.team)&&this.client?.send({t:`team`',
    'arenaLobbyShare.refresh(this);uT(this.team)&&this.client?.send({t:`team`');
  replace('health:n=>{this.peer===t&&this.active&&',
    'health:n=>{if(this.peer===t&&this.active)arenaLobbyShare.refresh(this);this.peer===t&&this.active&&');
  // Retry a send that failed under backpressure on the next ordinary network
  // update. Once state has arrived, normal pings produce zero extra packets.
  replace('ping:e=>{this.authority&&(this.authority.pingMs=e)}',
    'ping:e=>{if(this.peer===t&&this.active)arenaLobbyShare.refresh(this);this.authority&&(this.authority.pingMs=e)}');
  replace('this.peer?.close(),this.peer=null,this.authority=null,window.clearTimeout(this.syncTimer)',
    'arenaLobbyShare.close(this);this.peer?.close(),this.peer=null,this.authority=null,window.clearTimeout(this.syncTimer)');
  replace('if(!this.client||!this.active||this.battle?.matchId===e.matchId)return;',
    'if(!this.client||!this.active||this.battle?.matchId===e.matchId)return;arenaLobbyShare.close(this);');
  replace('this.lifetime.close(),this.battle?.stop()',
    'this.lifetime.close(),arenaLobbyShare.close(this),this.battle?.stop()');
  const prelude = 'const arenaLobbyShare=(' + createLobbySharing.toString() +
    ')(ids=>uT(ids),()=>document.dispatchEvent(new Event("arena-lineup-change")));\n';
  return prelude + source;
}

const ArenaLineupShareAdapter = Object.freeze({ patch: patchLineupSharing });
if (typeof module !== 'undefined' && module.exports) module.exports = { ArenaLineupShareAdapter, createLobbySharing };
