// Local menu access is separate from profile exports and native game data.
(() => {
  'use strict';
  function installRocketAccess() {
    const storageKey='arena.rocket.menu-access.v1';
    const keys=['cooldowns','aim','autoprotect','god','speed','rapidfire','norecovery','supereffective','anymove'];
    let unlocked=false;
    function read(){try{return localStorage.getItem(storageKey)==='unlocked';}catch{return false;}}
    function publish(reset=false){
      const doc=document.documentElement;
      if(reset)for(const key of keys)doc.setAttribute('data-arena-mod-'+key,'off');
      doc.setAttribute('data-arena-mod-aim','off');
      doc.setAttribute('data-arena-rocket-access',unlocked?'unlocked':'locked');
      document.dispatchEvent(new Event('arena-rocket-access'));
      document.dispatchEvent(new Event('arena-mod-settings'));
    }
    function setAccess(next){
      const value=next?'unlocked':'locked';
      try{localStorage.setItem(storageKey,value);if(localStorage.getItem(storageKey)!==value)throw Error('Not retained');}
      catch{throw Error('Firefox could not save Rocket Menu access. Allow site storage and try again.');}
      const changed=unlocked!==next;unlocked=next;publish(changed);
    }
    function unlock(code){
      if(code!=='SNEAKYGIO14')return false;
      setAccess(true);return true;
    }
    function toggle(code){
      if(code!=='SNEAKYGIO14')return null;
      setAccess(!unlocked);
      return unlocked?'Rocket Menu unlocked. Choose your switches in the menu.':'Rocket Menu locked. Menu switches are off.';
    }
    unlocked=read();
    const api=Object.freeze({isUnlocked:()=>unlocked,unlock,toggle});
    globalThis.ArenaRocketAccess=api;
    window.addEventListener('storage',event=>{
      if(event.key!==storageKey&&event.key!==null)return;
      const next=read();if(next===unlocked)return;
      unlocked=next;publish(true);
    });
    // A new game always starts with every menu switch off, including old saves.
    publish(true);
    return api;
  }
  const api=Object.freeze({prelude:()=> '('+installRocketAccess.toString()+')();\n'});
  globalThis.ArenaRocketAccessAdapter=api;
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})();
