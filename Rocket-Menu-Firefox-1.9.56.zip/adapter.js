// Patch points belong to the single client build verified by the background
// script. arenaModEnabled is the enclosing mod menu's live setting reader.
(() => {
  'use strict';

  function patch(original) {
    let source = original;
    function replace(anchor, replacement) {
      const index = source.indexOf(anchor);
      if (index < 0 || source.indexOf(anchor, index + anchor.length) !== -1) {
        throw new Error('Unsupported game build. Missing or ambiguous cooldown anchor: ' + anchor.slice(0, 70));
      }
      source = source.slice(0, index) + replacement + source.slice(index + anchor.length);
    }

    // Only the local arena scene opts in, after its network branch has already
    // returned. All network worlds and automated player simulations retain the
    // original timers. Other solo menu features share this explicit world flag.
    replace('ai:this.aiEnabled,difficulty:this.difficulty,cpuSwitch:g,gated:!0',
      'ai:this.aiEnabled,arenaSoloMods:!this.net,difficulty:this.difficulty,cpuSwitch:g,gated:!0');
    replace('this.playerAi=e.playerAi??!1,this.debugEffect=e.debugEffect??null',
      'this.playerAi=e.playerAi??!1,this.arenaSoloMods=e.arenaSoloMods===true&&!this.playerAi&&e.thirdPartyIds===undefined,this.debugEffect=e.debugEffect??null');
    replace('tryAttack(e,t,n,r,i){if(e.cast||e.hp<=0)return;',
      'waivesLocalCooldowns(fighter){return this.arenaSoloMods&&fighter===this.player&&arenaModEnabled("cooldowns")}tryAttack(e,t,n,r,i){if(e.cast||e.hp<=0)return;');

    // Refill before native attack checks, including when enabled mid-battle.
    replace('advance(e,t,n,r,i){for(let t of vc(e.loadout))',
      'advance(e,t,n,r,i){if(this.waivesLocalCooldowns(e)){e.cds.fill(0);e.basicCd=0;e.dodgeCd=0;e.ultCharge=100;this.rememberUlt(e)}for(let t of vc(e.loadout))');
    replace('d||(e.cds[l]=m?500:p.cooldownMs)', 'd||(e.cds[l]=this.waivesLocalCooldowns(e)?0:m?500:p.cooldownMs)');
    replace('e.basicCd=500,this.startBasic(e,null,t,n)', 'e.basicCd=this.waivesLocalCooldowns(e)?0:500,this.startBasic(e,null,t,n)');
    replace('return e.dodgeCd=se,e.iframeMs=300', 'return e.dodgeCd=this.waivesLocalCooldowns(e)?0:se,e.iframeMs=300');
    replace('d&&(e.ultCharge=0,this.rememberUlt(e))',
      'd&&(e.ultCharge=this.waivesLocalCooldowns(e)?100:0,this.rememberUlt(e))');
    // Solo effects and the training prompt normally detect an ultimate by its
    // meter dropping. Use the actual ultimate slot when charge stays full.
    replace('(u||this.enforcedUltimateGate)&&Qe(o.moves.map(e=>e.id))[4]?.moveId===a.move',
      '(u||this.enforcedUltimateGate||arenaModEnabled("cooldowns"))&&Qe(o.moves.map(e=>e.id))[4]?.moveId===a.move');
    replace('a.ultCharge>=100&&o.ultCharge<a.ultCharge&&l.some(e=>e.type===`cast`&&!e.basic)',
      'a.ultCharge>=100&&l.some(e=>e.type===`cast`&&!e.basic&&(o.ultCharge<a.ultCharge||arenaModEnabled("cooldowns")&&e.move===Qe(a.moves.map(move=>move.id))[4]?.moveId))');

    // Native inputs and the HUD share these snapshots. Preserve the move data
    // itself; its stock cooldown is also used when assigning moves to slots.
    // A snapshot can be requested during countdown, hit stop or a team switch.
    // Refill the real fighter and saved party member before publishing either.
    replace('snapshot(e){return{id:e.id,entry:e.entry',
      'snapshot(e){let free=this.waivesLocalCooldowns(e);if(free){e.ultCharge=100;this.rememberUlt(e)}return{id:e.id,entry:e.entry');
    replace('maxEnergy:100,dodgeCooldownMs:e.dodgeCd,iframeMs:e.iframeMs', 'maxEnergy:100,dodgeCooldownMs:free?0:e.dodgeCd,iframeMs:e.iframeMs');
    replace('castBasic:e.cast?.basic===!0,basicCooldownMs:e.basicCd', 'castBasic:e.cast?.basic===!0,basicCooldownMs:free?0:e.basicCd');
    replace('moves:vc(e.loadout).map(t=>wc(e,t))', 'moves:vc(e.loadout).map(t=>wc(e,t,free))');
    replace('function wc(e,t){let n=V(e.loadout[t]??``)', 'function wc(e,t,free=false){let n=V(e.loadout[t]??``)');
    replace('cooldownMs:o?0:e.cds[t],maxCooldownMs:o?0:a?500:n.cooldownMs', 'cooldownMs:free||o?0:e.cds[t],maxCooldownMs:free||o?0:a?500:n.cooldownMs');
    return source;
  }

  const api = Object.freeze({patch});
  globalThis.ArenaCooldownAdapter = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})();
