// Bake the arena material once. Phaser keeps drawing the battle and its UI in Canvas.
(() => {
  'use strict';

  function createRocketArenaMaterial() {
    const cache = new Map();
    const budget = 10 * 1024 * 1024;
    let pixels = 0, baker;
    const finishes = {
      grass_rect:   {palette:[.026,.021,-.006], material:[2.8,.13,.035,.22], sky:'#182c47', sun:'#fff0c5'},
      forest_rect:  {palette:[.022,.026,-.007], material:[2.6,.14,.035,.20], sky:'#142f38', sun:'#eaf1b6'},
      ice_rect:     {palette:[.004,.024,.041], material:[2.0,.08,.14,.31], sky:'#243b69', sun:'#e4f6ff'},
      seaside_rect: {palette:[.015,.025,.031], material:[2.2,.09,.10,.27], sky:'#213d60', sun:'#fff2cc'},
      volcanic_rect:{palette:[.047,.009,-.011], material:[2.9,.15,.045,.31], sky:'#30263c', sun:'#ffd2a7'},
      ruins_rect:   {palette:[.028,.015,-.005], material:[3.0,.15,.065,.23], sky:'#26344d', sun:'#ffebc7'},
      courtyard:    {palette:[.030,.019,-.008], material:[3.1,.15,.075,.24], sky:'#23334d', sun:'#ffedca'},
      'rock-gym':   {palette:[.018,.018,.005], material:[3.1,.15,.055,.20], sky:'#273246', sun:'#f9edc9'},
      temple:       {palette:[.041,.022,-.008], material:[2.6,.11,.08,.26], sky:'#303249', sun:'#fff1c7'},
      'rocket-sky-pillar':{palette:[.028,.022,.006], material:[2.8,.13,.065,.20], sky:'#7199b3', sun:'#fff4d9'},
      'rocket-city-square':{palette:[.006,.013,.026], material:[2.5,.10,.08,.20], sky:'#25344f', sun:'#ffe1a5'}
    };

    function createBaker() {
      const target = document.createElement('canvas');
      const gl = target.getContext('webgl', {alpha:true, antialias:false, depth:false, stencil:false,
        premultipliedAlpha:true, preserveDrawingBuffer:false, powerPreference:'low-power'});
      if (!gl) return null;
      const program = gl.createProgram();
      function compile(type, source) {
        const shader = gl.createShader(type);
        gl.shaderSource(shader,source);
        gl.compileShader(shader);
        if (!gl.getShaderParameter(shader,gl.COMPILE_STATUS)) {
          gl.deleteShader(shader);
          throw Error('Arena material shader unavailable');
        }
        gl.attachShader(program,shader);
        gl.deleteShader(shader);
      }
      try {
        compile(gl.VERTEX_SHADER,`attribute vec2 corner;
          varying mediump vec2 uv;
          void main(){uv=corner*0.5+0.5;gl_Position=vec4(corner,0.0,1.0);}`);
        compile(gl.FRAGMENT_SHADER,`
          #ifdef GL_FRAGMENT_PRECISION_HIGH
          precision highp float;
          #else
          precision mediump float;
          #endif
          varying mediump vec2 uv;
          uniform sampler2D art;
          uniform vec2 texel;
          uniform vec4 region;
          uniform vec3 palette;
          uniform vec4 material;
          uniform float turf;
          float luminance(vec3 c){return dot(c,vec3(0.299,0.587,0.114));}
          vec4 sampleAt(vec2 offset){return texture2D(art,clamp(uv+offset*texel,vec2(0.0),vec2(1.0)));}
          float heightOf(vec4 c,float center){return mix(center,luminance(c.rgb),smoothstep(0.05,0.95,c.a));}
          void main(){
            vec4 sampleColor=texture2D(art,uv);
            vec3 rgb=sampleColor.rgb;
            float luma=luminance(rgb);
            vec4 north=sampleAt(vec2(0.0,1.0)),south=sampleAt(vec2(0.0,-1.0));
            vec4 west=sampleAt(vec2(-1.0,0.0)),east=sampleAt(vec2(1.0,0.0));
            vec4 nw=sampleAt(vec2(-1.0,1.0)),ne=sampleAt(vec2(1.0,1.0));
            vec4 sw=sampleAt(vec2(-1.0,-1.0)),se=sampleAt(vec2(1.0,-1.0));
            float n=heightOf(north,luma),s=heightOf(south,luma);
            float w=heightOf(west,luma),e=heightOf(east,luma);
            float hNW=heightOf(nw,luma),hNE=heightOf(ne,luma);
            float hSW=heightOf(sw,luma),hSE=heightOf(se,luma);
            vec2 slope=vec2(2.0*(w-e)+hNW+hSW-hNE-hSE,2.0*(s-n)+hSW+hSE-hNW-hNE)*0.25;
            // A shallow normal retains printed markings while bringing out stone edges and turf texture.
            vec3 normal=normalize(vec3(clamp(slope,vec2(-0.32),vec2(0.32))*material.x,1.0));
            vec3 keyLight=normalize(vec3(-0.48,0.62,0.78));
            float relief=clamp(dot(normal,keyLight)-keyLight.z,-0.29,0.23);
            float localMean=(n+s+w+e)*0.1875+(hNW+hNE+hSW+hSE)*0.0625;
            float crevice=smoothstep(0.018,0.21,max(0.0,localMean-luma))*material.y;
            // Broad neighbors contribute only their bright color; the original texture is never blurred.
            vec4 broadN=sampleAt(vec2(0.0,4.0)),broadS=sampleAt(vec2(0.0,-4.0));
            vec4 broadW=sampleAt(vec2(-4.0,0.0)),broadE=sampleAt(vec2(4.0,0.0));
            vec3 bloom=(max(broadN.rgb-0.72,0.0)*broadN.a+max(broadS.rgb-0.72,0.0)*broadS.a+
              max(broadW.rgb-0.72,0.0)*broadW.a+max(broadE.rgb-0.72,0.0)*broadE.a)*0.25;
            vec2 world=region.xy+vec2(uv.x,1.0-uv.y)*region.zw;
            float light=1.0-smoothstep(0.10,0.98,distance(world,vec2(0.35,0.26)));
            float green=smoothstep(0.01,0.16,rgb.g-max(rgb.r,rgb.b));
            float stripe=(step(0.5,fract(world.x*6.0))-0.5)*green*turf;
            rgb=mix(vec3(luma),rgb,1.10);
            rgb=(rgb-0.42)*1.06+0.42;
            rgb*=0.89+0.18*light+0.09*stripe+relief*0.53;
            rgb*=1.0-crevice;
            rgb+=vec3(-0.014,0.003,0.030)*(1.0-luma)*(1.10-0.38*light);
            rgb+=palette*light*smoothstep(0.15,0.78,luma);
            vec3 halfLight=normalize(keyLight+vec3(0.0,0.0,1.0));
            float gloss=pow(max(dot(normal,halfLight),0.0),22.0)*material.z;
            rgb+=vec3(1.0,0.97,0.89)*gloss*smoothstep(0.34,0.84,luma)*(0.35+0.65*light);
            rgb+=bloom*material.w*(1.0-smoothstep(0.76,1.0,luma));
            gl_FragColor=vec4(clamp(rgb,0.0,1.0)*sampleColor.a,sampleColor.a);
          }`);
        gl.linkProgram(program);
        if (!gl.getProgramParameter(program,gl.LINK_STATUS)) throw Error('Arena material could not link');
      } catch {
        gl.deleteProgram(program);
        gl.getExtension('WEBGL_lose_context')?.loseContext();
        return null;
      }
      gl.useProgram(program);
      const corners = gl.createBuffer();
      gl.bindBuffer(gl.ARRAY_BUFFER,corners);
      gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,-1,1,1,1]),gl.STATIC_DRAW);
      const position = gl.getAttribLocation(program,'corner');
      gl.enableVertexAttribArray(position);
      gl.vertexAttribPointer(position,2,gl.FLOAT,false,0,0);
      const tex = gl.createTexture();
      gl.bindTexture(gl.TEXTURE_2D,tex);
      for (const edge of [gl.TEXTURE_WRAP_S,gl.TEXTURE_WRAP_T]) gl.texParameteri(gl.TEXTURE_2D,edge,gl.CLAMP_TO_EDGE);
      for (const filter of [gl.TEXTURE_MIN_FILTER,gl.TEXTURE_MAG_FILTER]) gl.texParameteri(gl.TEXTURE_2D,filter,gl.NEAREST);
      gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,true);
      const max=gl.getParameter(gl.MAX_TEXTURE_SIZE);
      const loc=Object.fromEntries(['texel','region','palette','material','turf'].map(name=>[name,gl.getUniformLocation(program,name)]));
      return function bake(input, out, id, region, width, height) {
        if (gl.isContextLost() || Math.max(width,height)>max) return false;
        target.width=out.canvas.width; target.height=out.canvas.height;
        try {
          gl.viewport(0,0,target.width,target.height);
          if (gl.drawingBufferWidth!==target.width || gl.drawingBufferHeight!==target.height) return false;
          gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,input);
          gl.uniform2f(loc.texel,1/width,1/height);
          gl.uniform4fv(loc.region,region);
          const finish=finishes[id]||finishes.ruins_rect;
          gl.uniform3fv(loc.palette,finish.palette);
          gl.uniform4fv(loc.material,finish.material);
          gl.uniform1f(loc.turf,id==='grass_rect'?1:0);
          gl.drawArrays(gl.TRIANGLE_STRIP,0,4);
          if (gl.getError()!==gl.NO_ERROR || gl.isContextLost()) return false;
          out.drawImage(target,0,0);
          return true;
        } finally {
          gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,1,1,0,gl.RGBA,gl.UNSIGNED_BYTE,null);
          target.width=target.height=1;
        }
      };
    }

    function surface(image, id, region=[0,0,1,1]) {
      const width=image?.naturalWidth||image?.width, height=image?.naturalHeight||image?.height;
      if (!width||!height||image.complete===false) return image;
      let entries=cache.get(image);
      const key=id+'|'+region.join(',');
      if (entries?.has(key)) return entries.get(key);
      const scale=Math.min(1,2304/Math.max(width,height),Math.sqrt(4*1024*1024/(width*height)));
      const canvas=document.createElement('canvas');
      canvas.width=Math.max(1,Math.round(width*scale));canvas.height=Math.max(1,Math.round(height*scale));
      const ctx=canvas.getContext('2d');
      if (!ctx) return image;
      let baked=false;
      try {
        if (baker===undefined) baker=createBaker();
        baked=baker?.(image,ctx,id,region,width,height);
      } catch { /* A restricted texture can still use the native 2D compositor. */ }
      if (!baked) {
        ctx.imageSmoothingEnabled=false;
        ctx.filter='contrast(1.08) saturate(1.12)';
        ctx.drawImage(image,0,0,canvas.width,canvas.height);
        ctx.filter='none';
        const finish=finishes[id]||finishes.ruins_rect;
        const sun=ctx.createLinearGradient(-region[0]/region[2]*canvas.width,-region[1]/region[3]*canvas.height,
          (1-region[0])/region[2]*canvas.width,(1-region[1])/region[3]*canvas.height);
        sun.addColorStop(0,finish.sun+'22');sun.addColorStop(.48,finish.sun+'04');sun.addColorStop(1,finish.sky+'30');
        ctx.globalCompositeOperation='source-atop';
        ctx.fillStyle=sun;ctx.fillRect(0,0,canvas.width,canvas.height);
        ctx.globalCompositeOperation='source-over';
      }
      if (!entries) cache.set(image,entries=new Map());
      entries.set(key,canvas);pixels+=canvas.width*canvas.height;
      while(pixels>budget&&cache.size) {
        const first=cache.keys().next().value;
        const stored=cache.get(first),firstKey=stored.keys().next().value,result=stored.get(firstKey);
        pixels-=result.width*result.height;stored.delete(firstKey);
        if(!stored.size)cache.delete(first);
      }
      return canvas;
    }
    function ground(sprite,id,region) {
      const texture=sprite.frame?.source?.image;
      const floor=surface(texture,id,region);
      if (floor && floor!==texture) sprite.rocketBakedArt=floor;
      return sprite;
    }
    function draw(ctx,object,source,sx,sy,sw,sh,x,y,w,h) {
      const floor=object.rocketBakedArt;
      if (floor) {
        const rw=floor.width/(source.naturalWidth||source.width),rh=floor.height/(source.naturalHeight||source.height);
        ctx.drawImage(floor,sx*rw,sy*rh,sw*rw,sh*rh,x,y,w,h);
      } else {
        const frame=object.rocketLitFighter&&!object.isTinted&&rocketFighterMaterial(source,sx,sy,sw,sh);
        if(frame) ctx.drawImage(frame,0,0,frame.width,frame.height,x,y,w,h);
        else ctx.drawImage(source,sx,sy,sw,sh,x,y,w,h);
      }
    }
    return {surface,ground,draw};
  }

  function patch(source,light,fighter) {
    const replace=(before,after)=>{
      const pieces=source.split(before);
      if(pieces.length!==2)throw Error('Unsupported arena material anchor: '+before);
      source=pieces.join(after);
    };
    const floor='this.add.image(0,0,su(e)).setOrigin(0,0).setDepth(0).setDisplaySize(Ca,wa)';
    replace(floor,'rocketArenaMaterial.ground('+floor+',e)');
    const actor='function pk(e,t,n,r,i,a=!1,o=!1,s=null,c=!1,l=null){';
    replace(actor,actor+'e.sprite.rocketLitFighter=true;');
    const pixels='a.drawImage(t.source.image,l,u,d,f,_,v,w,T)';
    replace(pixels,'((e.rocketBakedArt||e.rocketLitFighter)?rocketArenaMaterial.draw(a,e,t.source.image,l,u,d,f,_,v,w,T):'+pixels+')');
    const menu='kT(i,this.textures.get(TQ).getSourceImage(),{x:n.ring.cx,y:n.ring.cy})';
    replace(menu,'kT(i,rocketArenaMaterial.surface(this.textures.get(TQ).getSourceImage(),"grass_rect"),{x:n.ring.cx,y:n.ring.cy})');
    return 'const rocketPaintStageLight=('+light.toString()+'),rocketFighterMaterial=('+fighter.toString()+');\n'+
      'const rocketArenaMaterial=('+createRocketArenaMaterial.toString()+')();\n'+source;
  }
  globalThis.ArenaShadingAdapter=Object.freeze({patch});
})();
