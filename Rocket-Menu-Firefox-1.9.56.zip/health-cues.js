// Low-health presentation for the local player's HUD and on-field Pokémon.
(() => {
  'use strict';

  function createArenaHealthCues() {
    const vignettes = new WeakMap();
    const masks = new WeakMap();

    function below(fighter, fraction) {
      return !!fighter && fighter.hp > 0 && fighter.hp < fighter.maxHp * fraction;
    }

    function frame(scene, state) {
      const fighting = state.phase === 'fight';
      const show = fighting && !scene.net?.spectating() && below(state.fighters[0], .4);
      let vignette = vignettes.get(scene);
      if (show && !vignette && Z.hud) {
        vignette = document.createElement('div');
        vignette.setAttribute('aria-hidden', 'true');
        vignette.style.cssText = 'position:absolute;inset:0;pointer-events:none;' +
          'background:radial-gradient(ellipse at center,transparent 58%,rgba(150,12,31,.10) 83%,rgba(148,8,27,.24) 100%)';
        Z.hud.prepend(vignette);
        vignettes.set(scene, vignette);
        scene.events.once('shutdown', () => {
          vignette.remove();
          vignettes.delete(scene);
        });
      }
      if (vignette && vignette.hidden === show) vignette.hidden = !show;
      if (!fighting) return 0;
      if (ei().display.reduceFlash || Wq()) return .14;
      return .12 * (1 - Math.cos(2 * Math.PI * scene.time.now / 2000));
    }

    function mark(sprite, fighter, pulse, switching) {
      sprite.rocketHealthPulse = !switching && below(fighter, .3) ? pulse : 0;
    }

    // Phaser's Canvas sprite renderer doesn't apply WebGL tints. Use the
    // current frame's alpha as a mask and reuse one scratch canvas per sprite.
    function paint(context, sprite, image, sx, sy, sw, sh, x, y, w, h) {
      if (sprite.isTinted) return;
      let mask = masks.get(sprite);
      if (!mask) {
        const canvas = document.createElement('canvas');
        mask = {canvas, ctx:canvas.getContext('2d')};
        masks.set(sprite, mask);
      }
      if (!mask.ctx) return;
      if (mask.image !== image || mask.sx !== sx || mask.sy !== sy ||
          mask.canvas.width !== sw || mask.canvas.height !== sh) {
        const {canvas, ctx} = mask;
        if (canvas.width !== sw) canvas.width = sw;
        if (canvas.height !== sh) canvas.height = sh;
        ctx.clearRect(0, 0, sw, sh);
        ctx.drawImage(image, sx, sy, sw, sh, 0, 0, sw, sh);
        ctx.globalCompositeOperation = 'source-in';
        ctx.fillStyle = '#ff3345';
        ctx.fillRect(0, 0, sw, sh);
        ctx.globalCompositeOperation = 'source-over';
        mask.image = image;
        mask.sx = sx;
        mask.sy = sy;
      }
      context.save();
      context.globalAlpha *= sprite.rocketHealthPulse;
      context.drawImage(mask.canvas, x, y, w, h);
      context.restore();
    }
    return {frame, mark, paint};
  }

  function patch(source) {
    function replace(before, after) {
      const parts = source.split(before);
      if (parts.length !== 2) throw Error('Unsupported battle renderer for low-health cues.');
      source = parts.join(after);
    }
    const draw = 'draw(e){this.combatNow=e.tick*q;';
    replace(draw, draw + 'const rocketHealthPulse=arenaHealthCues.frame(this,e);');
    const actor = 'this.megaFx?.paintActor(n.id,r.sprite,r.speciesId===n.speciesId&&!this.artLoading.has(n.id),!p&&!s)';
    replace(actor, actor + ',arenaHealthCues.mark(r.sprite,n,rocketHealthPulse,!!s||o||this.artLoading.has(n.id))');
    const pixels = 'a.drawImage(t.source.image,l,u,d,f,_,v,w,T)';
    replace(pixels, pixels + ',e.rocketHealthPulse>0&&arenaHealthCues.paint(a,e,t.source.image,l,u,d,f,_,v,w,T)');
    return 'const arenaHealthCues=(' + createArenaHealthCues.toString() + ')();\n' + source;
  }

  const api = Object.freeze({patch});
  globalThis.ArenaHealthCuesAdapter = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})();
