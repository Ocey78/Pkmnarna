// Aim uses observed motion and the native move definitions before local input is submitted.
(() => {
  'use strict';

  function createRocketSmartAim() {
    const memories = new WeakMap(), marker = Symbol('rocket-aim');

    function observe(scene, state, actor) {
      const clock = state.tick * q;
      let memory = memories.get(scene);
      if (!memory || memory.world !== scene.world || memory.entry !== actor.entry ||
          memory.species !== actor.speciesId || clock < memory.clock) {
        memory = {world:scene.world, entry:actor.entry, species:actor.speciesId,
          clock:-Infinity, bodies:new Map(), target:null};
        memories.set(scene, memory);
      }
      if (clock === memory.clock) return memory;
      const bodies = new Map();
      for (const body of state.fighters) {
        const old = memory.bodies.get(body.id), dt = (clock - memory.clock) / 1000;
        let vx = 0, vy = 0, rawX = 0, rawY = 0;
        if (old && old.entry === body.entry && old.species === body.speciesId && dt > 0 && dt < .3) {
          const dx = body.x - old.x, dy = body.y - old.y;
          const limit = Math.max(120, Math.min(520, (body.walkSpeed || 0) * 1.35));
          // Require two coherent samples. Corrections, dodges, stops and reversals
          // must not leave a fast, stale velocity pointing away from the opponent.
          const speed = Math.hypot(dx, dy) / dt;
          if (speed >= 8 && speed <= limit) {
            rawX = dx / dt; rawY = dy / dt;
            const oldSpeed = Math.hypot(old.rawX || 0, old.rawY || 0);
            if (oldSpeed >= 8 && Math.abs(speed - oldSpeed) <= Math.max(40, speed * .45) &&
                rawX * old.rawX + rawY * old.rawY > speed * oldSpeed * .65) {
              const blend = old.vx || old.vy ? Math.min(1, dt * 36) : 1;
              vx = old.vx + (rawX - old.vx) * blend;
              vy = old.vy + (rawY - old.vy) * blend;
            }
          }
        }
        if (body.hp <= 0 || body.switchMs > 0 || body.ailment === 'sleep' || body.ailment === 'freeze') vx = vy = rawX = rawY = 0;
        bodies.set(body.id, {x:body.x,y:body.y,entry:body.entry,species:body.speciesId,vx,vy,rawX,rawY});
      }
      memory.clock = clock; memory.bodies = bodies;
      return memory;
    }

    function attack(actor, command) {
      const slots = Qe(actor.moves.map(move => move.id));
      let chosen = null, pending = null;
      // Match native cast precedence when several buttons are held together.
      for (let index = actor.moves.length - 1; index >= 0; index--) {
        if (!command.buttons.attacks[index]) continue;
        const slot = tt(slots, index);
        if (!slot) continue;
        pending ||= slot;
        // Native advance ticks cooldowns before casting and accepts recovery
        // buffers. A recovering/airborne actor still needs an aimed command.
        const ready = slot.role === 'ultimate' ? actor.ultCharge >= 100 : (actor.moves[index].cooldownMs || 0) <= q;
        if (ready) { chosen = slot; break; }
      }
      if (!chosen && command.buttons.basic && slots[0]?.basicFallback && (actor.basicCooldownMs || 0) <= q) chosen = slots[0];
      chosen ||= pending || (command.buttons.basic && slots[0]?.basicFallback ? slots[0] : null);
      if (!chosen) return null;
      const move = chosen.moveId ? V(chosen.moveId) : null;
      if (chosen.role === 'basic') {
        const species = dn(actor.speciesId);
        const shape = Ya({move, speciesTypes:species.types, atk:species.atk, spa:species.spa}).shape;
        return {shape, range:shape === 'melee' ? 140 : 380, speed:shape === 'bolt' ? 560 : 0,
          windup:0, radius:6, flight:10, basic:true};
      }
      if (!move || move.shape === 'self' || move.shape === 'ring' ||
          (chosen.role === 'ultimate' && Go(move.id))) return null;
      const zone = chosen.role === 'ultimate' && so(move.id);
      return {shape:zone ? 'ground' : move.shape, range:Re(move) + (move.shape === 'melee' ? 96 : 0),
        speed:move.shape === 'bolt' || move.shape === 'hex' ? move.speed : 0,
        windup:zone ? .16 + (zone.warnTicks + (zone.hitTicks[0] || 0)) * q / 1000 : Math.max(0, move.windupMs || 0) / 1000,
        radius:zone ? zone.r : Math.max(1, move.radius || 6), flight:Math.max(0, move.ttlMs || 0) / 1000,
        dashSpeed:move.dashSpeed || 0, basic:false};
    }

    function intercept(origin, point, velocity, move, actorRadius) {
      const delay = Math.min(.35, move.windup + (move.shape === 'melee' ? .05 : 0));
      const rx = point.x + velocity.vx * delay - origin.x;
      const ry = point.y + velocity.vy * delay - origin.y;
      let travel = 0;
      if (move.speed > 0) {
        const spawn = actorRadius + move.radius + 2;
        const a = velocity.vx * velocity.vx + velocity.vy * velocity.vy - move.speed * move.speed;
        const b = 2 * (rx * velocity.vx + ry * velocity.vy - move.speed * spawn);
        const c = rx * rx + ry * ry - spawn * spawn;
        const discriminant = b * b - 4 * a * c;
        if (c > 0) {
          if (Math.abs(a) < .001) travel = b < 0 ? -c / b : Infinity;
          else if (discriminant < 0) travel = Infinity;
          else {
            const root = Math.sqrt(discriminant), t1 = (-b - root) / (2 * a), t2 = (-b + root) / (2 * a);
            travel = Math.min(t1 > 0 ? t1 : Infinity, t2 > 0 ? t2 : Infinity);
          }
          if (!Number.isFinite(travel) || travel > move.flight) return {x:point.x,y:point.y,seconds:delay};
        }
      } else if (move.shape === 'dash' && move.dashSpeed > 0) {
        travel = Math.min(.35, Math.hypot(rx, ry) / move.dashSpeed);
      }
      const speed = Math.hypot(velocity.vx, velocity.vy);
      const lead = Math.min(.35, delay + travel, Math.min(72, move.range * .2) / Math.max(1, speed));
      return {x:point.x + velocity.vx * lead, y:point.y + velocity.vy * lead, seconds:lead};
    }

    function rocketSmartAim(scene, state, command) {
      if (!command) return command;
      // The symbol survives native object copies while the wire encoder retains its ordinary fields.
      const result = {...command, [marker]:scene};
      // Native Controls > Auto Aim is the single switch, independent of Rocket cheats.
      if (!ei().controls.autoAim) return result;
      const actor = state?.fighters?.[0];
      if (!actor || state.phase !== 'fight' || !Number.isFinite(state.tick)) return result;
      const memory = observe(scene, state, actor);
      if (!scene.controls?.acceptsPress() ||
          (typeof arenaKeybinds !== 'undefined' && arenaKeybinds.blocked()) ||
          scene.net?.spectating() || actor.hp <= 0 || actor.switchMs > 0 ||
          command.switchSlot !== null || command.buttons.dodge || command.buttons.mega) return result;
      const move = attack(actor, command);
      if (!move || !(move.range > 0)) return result;
      const origin = rc(actor.speciesId, actor.x, actor.y), bounds = state.arena?.combat;
      let best = null, fallback = null;
      for (const foe of state.fighters) {
        if (foe.id === actor.id || foe.hp <= 0 || foe.switchMs > 0 ||
            (actor.arenaCpuTeam !== undefined && actor.arenaCpuTeam === foe.arenaCpuTeam)) continue;
        const observed = memory.bodies.get(foe.id);
        if (!observed || !Number.isFinite(foe.x) || !Number.isFinite(foe.y)) continue;
        const body = move.shape === 'ground' ? {x:foe.x,y:foe.y} : rc(foe.speciesId, foe.x, foe.y);
        const bodyDistance = Math.hypot(body.x - origin.x, body.y - origin.y);
        const fallbackScore = bodyDistance / Math.max(1, move.range) - (memory.target === foe.id ? .15 : 0);
        if (!fallback || fallbackScore < fallback.score) fallback = {id:foe.id, point:body, score:fallbackScore};
        let point = intercept(origin, body, observed, move, actor.radius);
        if (bounds) {
          const bodyLift = move.shape === 'ground' ? 0 : foe.y - body.y;
          point.x = Math.max(bounds.left + foe.radius, Math.min(bounds.right - foe.radius, point.x));
          point.y = Math.max(bounds.top + foe.radius - bodyLift, Math.min(bounds.bottom - foe.radius - bodyLift, point.y));
        }
        const allowance = foe.radius + (move.shape === 'ground' ? move.radius * .65 : move.speed > 0 ? actor.radius + move.radius : 0);
        // Do not aim past a reachable enemy just because its projected position
        // crosses the move's range. Use its actual position in that case.
        if (Math.hypot(point.x - origin.x, point.y - origin.y) > move.range + allowance) point = {...body,seconds:0};
        const distance = Math.hypot(point.x - origin.x, point.y - origin.y);
        if (distance > move.range + allowance || foe.iframeMs > point.seconds * 1000 + 40) continue;
        if (bounds?.rocks?.length && move.shape !== 'ground' &&
            typeof arenaReferenceArenas !== 'undefined' &&
            arenaReferenceArenas.blocksShot(bounds.rocks, origin.x, origin.y, {x:point.x,y:point.y,radius:move.radius})) continue;
        const aimLength = Math.hypot(command.aim.x, command.aim.y);
        const alignment = aimLength >= 4 && distance > 0
          ? (command.aim.x * (point.x - origin.x) + command.aim.y * (point.y - origin.y)) / (aimLength * distance) : 1;
        let score = distance / Math.max(1, move.range) + (1 - alignment) * .12;
        if (memory.target === foe.id) score -= .22;
        if (foe.cast === 'active' && foe.castMove && V(foe.castMove).status === 'protect') score += .8;
        if (!best || score < best.score) best = {id:foe.id, point, score};
      }
      best ||= fallback;
      if (!best) {
        memory.target = null;
        return result;
      }
      memory.target = best.id;
      const aim = {x:best.point.x - origin.x, y:best.point.y - origin.y};
      const length = Math.hypot(aim.x, aim.y);
      if (length === 0) return result;
      if (length < 4) { aim.x *= 4 / length; aim.y *= 4 / length; }
      result.aim = aim;
      result.buttons = {...command.buttons, snapAim:true};
      if (move.shape === 'dash') {
        const aimLength = Math.hypot(aim.x, aim.y);
        result.move = {x:aim.x / aimLength, y:aim.y / aimLength};
      }
      return result;
    }
    rocketSmartAim.marker = marker;
    rocketSmartAim.refresh = (world, actor, command) => {
      const scene = command[marker];
      if (!scene || !ei().controls.autoAim || typeof world.getState !== 'function' ||
          (!command.buttons.basic && !command.buttons.attacks.some(Boolean))) return command;
      const state = world.getState();
      // Re-aim a locally buffered attack when it actually casts. Remote helper
      // inputs keep their transmitted aim and never inherit this scene reference.
      return state.fighters[0]?.id === actor.id ? rocketSmartAim(scene, state, command) : command;
    };
    return rocketSmartAim;
  }

  function preserveAim(source) {
    const guard = 'if(command?.buttons?.snapAim&&Math.hypot(command.aim.x,command.aim.y)>=4)return command;';
    for (const anchor of ['aimAttack(actor, command, foe) {', 'aimOnlineCommand(command, sending) {']) {
      const parts = source.split(anchor);
      if (parts.length !== 2) throw Error('Unsupported smart aim input method.');
      source = parts.join(anchor + guard);
    }
    const zone = 'if(n.hp>0&&this.localOption(e,"aim"))t={...t,aim:{x:n.x-i.x,y:n.y-i.y}};';
    const parts = source.split(zone);
    if (parts.length !== 2) throw Error('Unsupported smart aim ground target.');
    return parts.join('if(n.hp>0&&this.localOption(e,"aim")&&!(t.buttons.snapAim&&Math.hypot(t.aim.x,t.aim.y)>=4))t={...t,aim:{x:n.x-i.x,y:n.y-i.y}};');
  }

  function patch(source) {
    function exposeSetting(before, after) {
      const parts = source.split(before);
      if (parts.length !== 2) throw Error('Unsupported game build. Could not expose Auto Aim in Controls.');
      source = parts.join(after);
    }
    source = preserveAim(source);
    source = source.replace('aimAttack(actor, command, foe) {',
      'aimAttack(actor, command, foe) {if(command?.[rocketSmartAim.marker])return rocketSmartAim.refresh(this,actor,command);');
    source = source.replace('aimOnlineCommand(command, sending) {',
      'aimOnlineCommand(command, sending) {if(command?.[rocketSmartAim.marker])return command;');
    exposeSetting('if(t===`pc`)return n.autoAim?[`hints`,`autoAim`,`holdToAim`,`keys`]:[`hints`,`holdToAim`,`keys`];',
      'if(t===`pc`)return[`hints`,`autoAim`,`holdToAim`,`keys`];');
    exposeSetting('n.autoAim&&e.push(`autoAim`)', 'e.push(`autoAim`)');
    source = source.replace('this.localOption(e,"aim")&&!(t.buttons.snapAim',
      'this.localOption(e,"aim")&&!t[rocketSmartAim.marker]&&!(t.buttons.snapAim');
    const step = 'let e=this.net?this.netPresented??c:c,t=this.world.step(s);';
    const parts = source.split(step);
    if (parts.length !== 2) throw Error('Unsupported smart aim battle input.');
    return 'const rocketSmartAim=(' + createRocketSmartAim.toString() + ')();\n' +
      parts.join('s=rocketSmartAim(this,c,s);' + step);
  }

  function helperSource() {
    return 'globalThis.ArenaSmartAimAdapter={patch:(' + preserveAim.toString() + ')};';
  }

  globalThis.ArenaSmartAimAdapter = Object.freeze({patch,helperSource});
  if (typeof module !== 'undefined' && module.exports) module.exports = {patch,helperSource};
})();
