'use strict';

// The snapshot is supplied by the sender and validated against native room metadata.
// A shared link cannot report changes that happened before its recipient connected.
function createArenaLineupInvite(env) {
  const roomCode = /^[23456789ABCDEFGHJKMNPQRSTUVWXYZ]{6}$/;
  const speciesId = /^[a-z0-9][a-z0-9-]{0,47}$/;
  const lifetime = 10 * 60 * 1000;
  const validName = name => typeof name === 'string' && name.length > 0 &&
    name.length <= 64 && name.trim() === name && !/[\u0000-\u001f\u007f-\u009f\u202a-\u202e\u2066-\u2069]/u.test(name);
  const validIds = ids => Array.isArray(ids) && ids.length === 3 && new Set(ids).size === 3 &&
    ids.every(id => typeof id === 'string' && speciesId.test(id));
  const seatIndex = seat => seat === 'A' ? 0 : seat === 'B' ? 1 : seat === 'C' ? 2 : -1;
  function capture() {
    try {
      if (typeof env.hash !== 'string' || env.hash.length > 4096) return null;
      const params = new URLSearchParams(env.hash.replace(/^#/,''));
      if (params.getAll('room').length !== 1 || params.getAll('lineup').length !== 1 || params.getAll('k').length > 1) return null;
      const raw = params.get('lineup');
      if (!raw || raw.length > 512) return null;
      const value = JSON.parse(raw);
      if (!value || value.v !== 1 || !roomCode.test(value.code) ||
          params.get('room').toUpperCase() !== value.code || seatIndex(value.seat) < 0 ||
          !validName(value.name) || !validIds(value.ids) || !Number.isSafeInteger(value.at) || value.at <= 0) return null;
      return {code:value.code, seat:value.seat, name:value.name, ids:value.ids.slice(),
        at:value.at, key:params.get('k') || null};
    } catch { return null; }
  }
  let snapshot = capture(), owner = null;
  function clear(c) {
    if (!snapshot || (owner && owner !== c) || (!owner && c?.code !== snapshot.code)) return;
    snapshot = null;
    owner = null;
  }
  function eligible(c) {
    const r = c?.room;
    return c?.active && r && !c.battle && !c.result && !c.linkDown &&
      ['open','lobby','countdown'].includes(r.state) && r.code === c.code && r.you === c.you &&
      roomCode.test(c.code) && seatIndex(c.you) >= 0 && Array.isArray(r.seats) && r.seats.length === (r.mode === 'ffa3' ? 3 : 2) &&
      seatIndex(c.you) < r.seats.length &&
      !r.seats.some(row => row?.rematch);
  }
  function update(c) {
    if (!snapshot || !c?.room) return;
    const age = env.now()-snapshot.at;
    const remote = c.room.seats?.[seatIndex(snapshot.seat)];
    if ((owner && owner !== c) || !eligible(c) || snapshot.code !== c.code ||
        (snapshot.key && snapshot.key !== c.key) || snapshot.seat === c.you ||
        !remote?.present || remote.editing || remote.name !== snapshot.name ||
        age < -60_000 || age > lifetime || !env.validTeam(snapshot.ids)) {
      snapshot = null;
      owner = null;
      return;
    }
    owner = c;
  }
  function forSeat(c,seat) {
    update(c);
    return snapshot && owner === c && snapshot.seat === seat ? snapshot.ids.slice() : null;
  }
  function urlFor(c) {
    if (!eligible(c) || c.room.state === 'countdown') return null;
    const me = c.room.seats[seatIndex(c.you)];
    if (!me?.present || me.editing || !validName(me.name) || !validIds(c.team) || !env.validTeam(c.team)) return null;
    const native = new URL(env.makeInvite(c));
    const params = new URLSearchParams(native.hash.slice(1));
    if (params.get('room')?.toUpperCase() !== c.code) return null;
    params.set('lineup',JSON.stringify({v:1,code:c.code,seat:c.you,name:me.name,ids:c.team.slice(),at:env.now()}));
    native.hash = params.toString();
    return native.href;
  }
  function mount(c,section) {
    section?.querySelector('[data-arena-copy-lineup]')?.remove();
  }
  return {update,forSeat,mount,clear,urlFor};
}

const ArenaLineupInviteAdapter = Object.freeze({
  patch(source) {
    function insert(needle,replacement) {
      const at = source.indexOf(needle);
      if (at < 0 || source.indexOf(needle,at+needle.length) >= 0) throw Error('Unsupported lineup-invite client anchor.');
      source = source.slice(0,at)+replacement+source.slice(at+needle.length);
    }
    // Observe each native snapshot, including while team editing hides the room renderer.
    const room = 'this.roomReceivedAt=performance.now(),this.you=e.you,';
    insert(room,room+'arenaLineupInvite.update(this),');
    const closed = 'this.client.onClose(this.lifetime.guard(e=>{';
    insert(closed,closed+'arenaLineupInvite.clear(this);');
    const start = 'beginMatch(e,t){if(!this.client||!this.active||this.battle?.matchId===e.matchId)return;';
    insert(start,start+'arenaLineupInvite.clear(this);');
    const stop = 'this.networkSetup?.finish(`leave`),this.finishNetwork(`leave`),this.lifetime.close()';
    insert(stop,'arenaLineupInvite.clear(this),'+stop);
    // The constructor captures the room fragment before native boot normalizes the URL.
    // Game catalog symbols are intentionally looked up only on use, after initialization.
    return 'const arenaLineupInvite=('+createArenaLineupInvite.toString()+')({' +
      'hash:location.hash,now:()=>Date.now(),validTeam:ids=>uT(ids),' +
      'makeInvite:c=>eT(location,c.code,c.key),copy:text=>navigator.clipboard.writeText(text),' +
      'manualCopy:text=>window.prompt("Copy this invitation with your team:",text),' +
      'notify:text=>fO(ZD(),text)});\n'+source;
  }
});
if (typeof module !== 'undefined' && module.exports) module.exports={ArenaLineupInviteAdapter,createArenaLineupInvite};

