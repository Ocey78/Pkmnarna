// The menu exhibition uses the game's own combat painters and texture sheets.
(() => {
  'use strict';

  function arenaMenuVfxLoader(scene, session) {
    // Use the native deduplicated asset queue. A private event facade prevents
    // polished-art loaders from taking ownership of another scene's load cycle.
    const listeners=new Map();let files=[];
    const api={
      on(name,fn){const list=listeners.get(name)||[];list.push({fn,once:false});listeners.set(name,list);return api;},
      once(name,fn){const list=listeners.get(name)||[];list.push({fn,once:true});listeners.set(name,list);return api;},
      off(name,fn){listeners.set(name,(listeners.get(name)||[]).filter(item=>item.fn!==fn));return api;},
      spritesheet(key,url,config){files.push({key,url,frameWidth:config.frameWidth,frameHeight:config.frameHeight});return api;},
      image(key,url){files.push({key,url});return api;},
      start(){
        const batch=files;files=[];
        const emit=(name,value)=>{for(const item of [...(listeners.get(name)||[])]){if(item.once)api.off(name,item.fn);item.fn(value);}};
        if(session.abort.signal.aborted){queueMicrotask(()=>{for(const file of batch)emit('loaderror',file);emit('complete');});return api;}
        vz(cH(scene),batch).then(result=>{
          for(const key of [...result.failed,...result.absent])emit('loaderror',{key});
          emit('complete');
        },()=>{for(const file of batch)emit('loaderror',file);emit('complete');});
        return api;
      }
    };
    return api;
  }

  function arenaMenuVfxStart(scene, session) {
    if(!arenaMenuCurrent(scene,session)||session.nativeVfx)return;
    const fx={objects:new Set(),actors:new Map(),disposed:false,frames:0,events:0,texture:null,front:null};
    session.nativeVfx=fx;
    try {
      // All game objects belong to the existing menu scene, but are detached
      // from its display/update lists and rendered only into this private target.
      const proxy=Object.create(scene);
      proxy.add={};
      for(const method of ['graphics','image','sprite','tileSprite'])proxy.add[method]=(...args)=>{
        if(fx.disposed)throw Error('Menu effects closed.');
        const object=scene.add[method](...args);
        object.removeFromDisplayList();object.removeFromUpdateList?.();
        fx.objects.add(object);return object;
      };
      proxy.load=arenaMenuVfxLoader(scene,session);
      const key='arena-menu-vfx-'+session.seed+'-'+Date.now();
      fx.texture=scene.textures.addDynamicTexture(key,2,2);
      if(!fx.texture?.canvas)throw Error('Menu effects require the native Canvas renderer.');
      proxy.cameras={main:fx.texture.camera};
      fx.proxy=proxy;
      fx.art=new _q(proxy,false,true,true,JK(false,''),true);
      // This native hook only controls the optional art-laboratory page.
      fx.art.hideLabDuringDischarge=()=>{};
      fx.moves=new GV(proxy);fx.fire=new kz(proxy,fx.actors);
      fx.status=new yq(proxy);fx.zones=new Yq(proxy,true);
      fx.arenaEffects=createRocketArenaEffects();
      if(scene.sharedHome){
        fx.ground=document.createElement('canvas');
        fx.ground.setAttribute('aria-hidden','true');
        fx.ground.style.cssText='position:absolute;pointer-events:none;image-rendering:pixelated;z-index:0';
        session.effects.before(fx.ground);
      }
      fx.front=document.createElement('canvas');
      fx.front.className='menu-native-vfx-front';fx.front.setAttribute('aria-hidden','true');
      fx.front.style.cssText='position:absolute;inset:0;pointer-events:none;image-rendering:pixelated;z-index:2147483000';
      session.effects.after(fx.front);
      session.effects.dataset.renderer='native';
      scene.game.canvas.dataset.menuVfx='native';
      const moves=[...new Set(session.state.fighters.flatMap(actor=>actor.moves.map(move=>move.id)))];
      fx.assets=Promise.allSettled([Rz(cH(scene),moves),qV(cH(scene),moves),fx.art.loadPolished()]).then(()=>{
        if(!fx.disposed&&arenaMenuCurrent(scene,session))scene.game.canvas.dataset.menuVfxAssets='ready';
      });
    } catch(error) {
      arenaMenuVfxDispose(scene,session);
      scene.game.canvas.dataset.menuVfx='unavailable';
      console.warn('[arena-menu] Native move art unavailable',error);
    }
  }

  function arenaMenuVfxNote(scene, session, before, next) {
    const fx=session.nativeVfx;
    if(!fx||fx.disposed||!arenaMenuCurrent(scene,session))return;
    const events=next.events,state=next.state,now=state.tick*q;
    fx.arenaEffects.note(before,state,events);
    fx.events+=events.filter(event=>event.type==='cast'||event.type==='hit').length;
    fx.art.note(before,state,events);fx.status.note(before,state,events);
    fx.fire.noteCombat(events);
    const zones=fx.art.thunderFieldEnabled?events.filter(event=>!(event.type==='ultZone'&&Go(event.move))&&!(event.type==='hit'&&event.zone&&Go(event.move))):events;
    fx.zones.note(zones,state.tick);
    // Yq combines an actual reticle painter with an optional impact sound.
    // The menu is intentionally silent; only this instance marks cues consumed.
    for(const zone of fx.zones.lives)zone.voiced=true;
    for(const event of events)if(event.type==='hit'&&event.amount>0&&event.zone!==true&&event.basic!==true&&(!fx.art||event.chip||!Pe(event.move))){
      fx.fire.burst(event.chip?'burn-chip':event.move,event.target,event.x,event.y,now,event.actor);
      if(!event.chip)fx.moves.hit(event.move,event.x,event.y,now);
    }
  }

  function arenaMenuVfxPaint(scene, ring) {
    const session=scene.arenaMenuSession,fx=session?.nativeVfx,state=session?.state;
    if(!fx||fx.disposed||!state||!arenaMenuCurrent(scene,session)||document.hidden||scene.leaving)return;
    try {
      const p=arenaMenuProjection(scene,ring),now=state.tick*q,reduced=ei().display.reduceFlash||Wq();
      if(fx.ground&&scene.textures.exists(TQ)){
        if(!fx.groundReady){
          const floor=rocketArenaMaterial.surface(scene.textures.get(TQ).getSourceImage(),'grass_rect');
          fx.ground.width=floor.width;fx.ground.height=floor.height;
          fx.ground.getContext('2d').drawImage(floor,0,0);
          fx.groundReady=true;
        }
        const box=[p.x(0),p.y(0),p.sx*Ca,p.sy*wa],key=box.join(',');
        if(fx.groundBox!==key){
          const [x,y,w,h]=box;
          Object.assign(fx.ground.style,{left:x+'px',top:y+'px',width:w+'px',height:h+'px'});
          fx.groundBox=key;
        }
      }
      const zones=fx.zones.sync(state.tick,now,true,()=>{},fx.art.owned,reduced);
      const fallback=LU(state);
      fx.moves.sync(fallback,now,true);fx.art.sync(state,now,true,reduced);
      fx.status.sync(state,true,reduced);fx.fire.sync(fallback,now,true,zones);
      const texture=fx.texture;
      if(texture.width!==p.width||texture.height!==p.height)texture.setSize(p.width,p.height,false);
      texture.camera.setOrigin(0,0).setZoom(p.sx,p.sy).setScroll(-p.x(0)/p.sx,-p.y(0)/p.sy);
      texture.camera.roundPixels=true;
      const objects=[...fx.objects].filter(object=>object.scene&&object.visible!==false&&object.alpha!==0).sort((a,b)=>a.depth-b.depth);
      for(const [canvas,front] of [[session.effects,false],[fx.front,true]]){
        if(canvas.width!==p.width||canvas.height!==p.height){canvas.width=p.width;canvas.height=p.height;}
        canvas.style.width=p.width+'px';canvas.style.height=p.height+'px';
        const context=canvas.getContext('2d');if(!context)continue;
        const renderer=scene.game.renderer,previousContext=renderer.currentContext;
        try{texture.clear().draw(objects.filter(object=>(object.depth>=4)===front)).render();}
        finally{renderer.setContext(previousContext);}
        context.clearRect(0,0,p.width,p.height);context.imageSmoothingEnabled=false;
        if(!front){
          context.save();
          try{
            context.setTransform(p.sx,0,0,p.sy,p.x(0),p.y(0));
            rocketPaintStageLight(context,state,{timeMs:now,reduced});
          }finally{context.restore();}
        }
        context.drawImage(texture.canvas,0,0);
        if(front){
          context.save();
          try{
            context.setTransform(p.sx,0,0,p.sy,p.x(0),p.y(0));
            fx.arenaEffects.paint(context,state,now);
          }finally{context.restore();}
        }
      }
      fx.frames++;
      session.effects.dataset.frames=String(fx.frames);
      session.effects.dataset.events=String(fx.events);
      session.effects.dataset.objects=String(objects.length);
      session.effects.dataset.polished=String(fx.art.polishedDraws.length);
    }catch(error){
      arenaMenuVfxDispose(scene,session);
      scene.game.canvas.dataset.menuVfx='unavailable';
      console.warn('[arena-menu] Native move renderer stopped',error);
    }
  }

  function arenaMenuVfxDispose(scene,session) {
    const fx=session?.nativeVfx;
    if(!fx||fx.disposed)return;
    fx.disposed=true;
    for(const name of ['art','moves','fire','status','zones'])try{fx[name]?.destroy();}catch{}
    for(const object of fx.objects)if(object.scene)try{object.destroy();}catch{}
    fx.objects.clear();fx.actors.clear();fx.front?.remove();fx.ground?.remove();
    fx.texture?.destroy();fx.texture=null;
    for(const canvas of [session.effects,fx.front]){const context=canvas?.getContext('2d');context?.clearRect(0,0,canvas.width,canvas.height);}
    delete scene.game.canvas.dataset.menuVfx;delete scene.game.canvas.dataset.menuVfxAssets;
  }

  function patch(original) {
    let source=original;
    if(source.includes('function arenaMenuVfxStart('))throw Error('Native menu effects already applied.');
    const replace=(before,after)=>{const parts=source.split(before);if(parts.length!==2)throw Error('Unsupported native menu effects anchor: '+before.slice(0,80));source=parts.join(after);};
    replace('session.state=session.world.getState();scene.actors=actors;',
      'session.state=session.world.getState();scene.actors=actors;arenaMenuVfxStart(scene,session);');
    replace('scene.arenaMenuSession=null;session.abort.abort();',
      'arenaMenuVfxDispose(scene,session);scene.arenaMenuSession=null;session.abort.abort();');
    replace('const next=session.world.step();session.state=next.state;session.accumulator-=q;',
      'const before=session.state,next=session.world.step();arenaMenuVfxNote(scene,session,before,next);session.state=next.state;session.accumulator-=q;');
    const start=source.indexOf('function arenaMenuPaintEffects('),end=source.indexOf('var M1=class extends FQ',start);
    if(start<0||end<start)throw Error('Unsupported native menu effects painter.');
    // Remove the old approximation completely, retaining helpers that later
    // adapters may append between it and the native menu scene declaration.
    let depth=0,finish=-1,body=source.indexOf('{',start);
    for(let index=body;index<end;index++){if(source[index]==='{')depth++;else if(source[index]==='}'&&--depth===0){finish=index+1;break;}}
    if(finish<0)throw Error('Unsupported native menu effects body.');
    source=source.slice(0,start)+'function arenaMenuPaintEffects(scene,ring){arenaMenuVfxPaint(scene,ring)}'+source.slice(finish);
    const helpers=[arenaMenuVfxLoader,arenaMenuVfxStart,arenaMenuVfxNote,arenaMenuVfxPaint,arenaMenuVfxDispose];
    replace('var M1=class extends FQ',helpers.map(fn=>fn.toString()).join('\n')+'\nvar M1=class extends FQ');
    return source;
  }
  const api=Object.freeze({patch});globalThis.ArenaMenuVfxAdapter=api;
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})();
