// Native knockout and result presentation for local simultaneous CPU teams.
(() => {
  'use strict';

  function arenaCpuFinishNote(finisher, state, events, actors, now) {
    const battle = state.cpuBattle;
    const fighters = state.fighters;
    const ended = state.phase !== 'fight';
    const transition = finisher.prevPhase === 'fight' && ended;
    const fallen = [];

    // A participant is an on-field fighter, never another participant's bench.
    // Keep the native ghost, cry, impact and faint animation for every identity.
    for (const fighter of fighters) {
      const previous = finisher.prevUp.get(fighter.id);
      const alive = fighter.hp > 0;
      finisher.prevUp.set(fighter.id, [alive]);
      if (!previous?.[0] || alive) continue;
      fallen.push(fighter);
      finisher.lastFaint = fighter.id;
      finisher.knock(fighter.id, state, actors, now, ended);
    }

    if (transition && !finisher.finale) {
      const winningTeam = battle.winnerTeam;
      const survivors = winningTeam == null ? [] : fighters.filter(
        fighter => fighter.arenaCpuTeam === winningTeam && fighter.hp > 0
      );
      const winner = survivors.find(fighter => fighter.id === 'player') ?? survivors[0];
      // Elimination can end the human's FFA before one rival team wins. In that
      // case there is no claimed winner: the native camera stays on the loser.
      const isLoser = fighter => state.phase === 'defeat'
        ? fighter.arenaCpuTeam === battle.playerTeam
        : state.phase === 'victory'
          ? fighter.arenaCpuTeam !== battle.playerTeam
          : true;
      const last = fighters.find(fighter => fighter.id === finisher.lastFaint);
      const loser = [...fallen].reverse().find(isLoser)
        ?? (last && isLoser(last) ? last : null)
        ?? fighters.find(fighter => fighter.hp <= 0 && isLoser(fighter));
      finisher.finale = {
        at: now,
        result: state.phase,
        winner: winner?.id ?? null,
        loser: loser?.id ?? null,
        curtain: false
      };
    }
    finisher.prevPhase = state.phase;
  }

  function patch(original) {
    let source = original;
    function replace(before, after) {
      const parts = source.split(before);
      if (parts.length !== 2) throw Error('Unsupported game build. Could not update CPU team finishes.');
      source = parts.join(after);
    }
    replace('note(e,t,n,r){let i=e.ffa?e.ffa.teams.map(e=>({id:e.id,party:e.party}))',
      'note(e,t,n,r){if(e.cpuBattle){arenaCpuFinishNote(this,e,t,n,r);return}let i=e.ffa?e.ffa.teams.map(e=>({id:e.id,party:e.party}))');
    replace('this.hooks.cry(a.speciesId),this.hooks.hudKo(e),Jv(e)',
      'this.hooks.cry(a.speciesId),(!t.cpuBattle||e===`player`)&&this.hooks.hudKo(e),Jv(e)');
    replace('stats(e){return e.phase===`fight`||e.ffa?null:qv(e.phase,e.party,e.foeParty,this.credits)}',
      'stats(e){return e.phase===`fight`||e.ffa||e.cpuBattle?null:qv(e.phase,e.party,e.foeParty,this.credits)}');
    return arenaCpuFinishNote.toString() + '\n' + source;
  }

  const api = Object.freeze({patch});
  globalThis.ArenaCpuFinishAdapter = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})();
