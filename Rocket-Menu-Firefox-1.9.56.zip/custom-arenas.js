// Offline stage art, field boundaries and rock footprints share one transform.
(() => {
  'use strict';

  function makeRocketArenas(images, scenery) {
    const stages = new Map();
    const labels = new Map();
    const files = new Map();
    const preference = 'rocket-reference-arena-v1';

    function add(id, name, size, center, field, backdrop, rocks = []) {
      const [w,h] = size, worldW = 2048, worldH = 1280;
      const scale = Math.max(worldW / w, worldH / h);
      const x = Math.min(0, Math.max(worldW - w * scale, worldW/2 - center[0]*scale));
      const y = Math.min(0, Math.max(worldH - h * scale, worldH/2 - center[1]*scale));
      const foot = loop => loop.map(([px,py]) => ({x:x+px*scale, y:y+py*scale}));
      const combat = {left:x+field[0]*scale,top:y+field[1]*scale,
        right:x+field[2]*scale,bottom:y+field[3]*scale};
      if (rocks.length) combat.rocks = rocks.map(foot);
      const file = 'rocket-arenas/' + id + '.jpg', labelKey = 'stages.rocket.' + id;
      files.set(file, images[id]); labels.set(labelKey, name);
      const source=scenery[id];
      const objects=source.objects.map(object=>{
        return {key:'rocket-prop-'+id+'-'+object.image,x:x+object.x*scale,y:y+object.y*scale,
          w:object.w*scale,h:object.h*scale,foot:y+object.depthY*scale};
      });
      const floor='rocket-ground-'+id;
      const queue=[{key:floor,url:source.ground},...source.textures.map((url,i)=>({key:'rocket-prop-'+id+'-'+i,url}))];
      stages.set(id, {id,file,labelKey,backdrop,combat,art:{x,y,w:w*scale,h:h*scale},floor,objects,queue,
        layered:new WeakSet(),loads:new WeakMap()});
    }
    add('courtyard','Courtyard',[3080,2380],[1539,1260],[281,565,2697,1950],'#44464b');
    add('rock-gym','Rock Gym',[638,480],[319,240],[55,55,582,424],'#4b4943',[
      [[161,162],[170,146],[200,113],[212,109],[226,119],[246,126],[267,129],
       [270,135],[243,160],[229,189],[214,201],[193,207],[179,202],[166,190]],
      [[402,120],[406,112],[414,112],[458,135],[468,144],[468,164],[464,191],
       [456,205],[449,209],[440,206],[429,190],[418,166],[406,147]],
      [[290,312],[306,306],[334,300],[365,289],[375,289],[386,297],[398,322],
       [401,337],[395,350],[382,365],[363,373],[339,375],[320,369],[305,350]],
      [[311,236],[314,231],[322,231],[326,235],[326,244],[321,248],[314,248],[311,244]]
    ]);
    add('temple','Temple Court',[640,495],[320,248],[32,90,606,432],'#c0ab6f');

    function selected() {
      const query = new URLSearchParams(location.search).get('stage');
      if (query && (stages.has(query) || ru.includes(query))) return query;
      let saved;
      try { saved = localStorage.getItem(preference); } catch {}
      return stages.has(saved) ? saved : fu();
    }
    function remember(id) {
      try {
        if (stages.has(id)) localStorage.setItem(preference,id);
        else localStorage.removeItem(preference);
      } catch {}
    }

    // Find the real closest edge, including concave corners, and retain the
    // side of the edge. A circle inside the footprint must move *out* of it.
    function contact(x,y,radius,loop) {
      let inside=false, best=Infinity, hitX=0, hitY=0, edgeX=0, edgeY=0;
      for (let i=0,j=loop.length-1;i<loop.length;j=i++) {
        const a=loop[j],b=loop[i],dx=b.x-a.x,dy=b.y-a.y;
        if ((a.y>y)!==(b.y>y) && x<(b.x-a.x)*(y-a.y)/(b.y-a.y)+a.x) inside=!inside;
        const t=Math.max(0,Math.min(1,((x-a.x)*dx+(y-a.y)*dy)/(dx*dx+dy*dy)));
        const px=a.x+t*dx, py=a.y+t*dy, distance=(x-px)**2+(y-py)**2;
        if (distance<best) { best=distance; hitX=px;hitY=py;edgeX=dx;edgeY=dy; }
      }
      if (!inside && best>=radius*radius) return null;
      const distance=Math.sqrt(best), sign=inside ? -1 : 1;
      if (distance>0.00001) return {x:hitX+sign*(x-hitX)*radius/distance,y:hitY+sign*(y-hitY)*radius/distance};
      const length=Math.hypot(edgeX,edgeY);
      return {x:hitX+edgeY*radius/length,y:hitY-edgeX*radius/length};
    }
    function constrain(x,y,radius,rocks,startX=x,startY=y) {
      const dx=x-startX,dy=y-startY, steps=Math.max(1,Math.ceil(Math.hypot(dx,dy)/Math.max(6,radius*.6)));
      let px=startX,py=startY;
      for (let i=0;i<steps;i++) {
        px+=dx/steps; py+=dy/steps;
        for (const rock of rocks) {
          const hit=contact(px,py,radius,rock);
          if (hit) {px=hit.x;py=hit.y;}
        }
      }
      return {x:px,y:py};
    }
    function blocksShot(rocks,x,y,bullet) {
      const radius=Math.max(1,bullet.radius), dx=bullet.x-x, dy=bullet.y-y;
      const steps=Math.max(1,Math.ceil(Math.hypot(dx,dy)/Math.max(4,radius)));
      for (let i=0;i<=steps;i++) {
        if (rocks.some(rock=>contact(x+dx*i/steps,y+dy*i/steps,radius,rock))) return true;
      }
      return false;
    }
    async function load(scene,stage,progress) {
      const textures=scene.textures, stageKey=su(stage.id);
      if (textures.exists(stageKey)) return true;
      progress?.track(stageKey);
      let loading=stage.loads.get(textures);
      if (!loading) {
        loading=(async()=>{
          try {
            await vz(scene,stage.queue);
            if (stage.queue.every(file=>textures.exists(file.key))) {
              for (const file of stage.queue) textures.get(file.key).setFilter(G.Textures.FilterMode.NEAREST);
              // Publish the native stage texture only once every solid prop is visible.
              stage.layered.add(textures);
              textures.addImage(stageKey,textures.get(stage.floor).getSourceImage());
            }
          } catch {}
          if (!textures.exists(stageKey)) {
            stage.layered.delete(textures);
            await vz(scene,[{key:stageKey,url:files.get(stage.file)}]);
          }
          return textures.exists(stageKey);
        })().catch(()=>false).finally(()=>stage.loads.delete(textures));
        stage.loads.set(textures,loading);
      }
      const ready=await loading;
      if (ready) progress?.finish(stageKey);
      else progress?.resetInflight(stageKey);
      return ready;
    }
    function place(scene,stage) {
      const art=stage.art;
      const ground=scene.add.image(art.x,art.y,su(stage.id)).setOrigin(0,0).setDepth(0).setDisplaySize(art.w,art.h);
      rocketArenaMaterial.ground(ground,stage.id,[art.x/Ca,art.y/wa,art.w/Ca,art.h/wa]);
      if (!stage.layered.has(scene.textures)) return;
      scene.rocketArenaScenery=true;
      scene.events.once('shutdown',()=>{scene.rocketArenaScenery=false;});
      for (const prop of stage.objects) {
        // Actors occupy native depth 4. Use a fraction of that band to keep
        // Y ordering independent of overhead move effects at depth 5.
        const sprite=scene.add.image(prop.x,prop.y,prop.key).setOrigin(0,0)
          .setDisplaySize(prop.w,prop.h).setDepth(4+prop.foot/1000000);
        rocketArenaMaterial.ground(sprite,stage.id,[prop.x/Ca,prop.y/wa,prop.w/Ca,prop.h/wa]);
      }
    }
    return {stages,labels,files,selected,remember,constrain,blocksShot,load,place};
  }

  function patch(source, assets, scenery) {
    const ids=['courtyard','rock-gym','temple'];
    if (ids.some(id=>typeof assets?.[id]!=='string' || !assets[id])) throw Error('Missing Rocket arena art.');
    if (ids.some(id=>!scenery?.[id]?.ground || !Array.isArray(scenery[id].objects))) throw Error('Missing Rocket arena scenery.');
    function replace(before,after) {
      const i=source.indexOf(before);
      if (i<0 || source.indexOf(before,i+before.length)>=0) throw Error('Unsupported custom arena anchor: '+before.slice(0,70));
      source=source.slice(0,i)+after+source.slice(i+before.length);
    }
    // Keep the native random stage/network ID list (ru) and native save separate.
    replace('function su(e){return`stage-${e}`}', 'ou.push(...arenaReferenceArenas.stages.values());function su(e){return`stage-${e}`}');
    replace('function ai(e){let t=e.replace(', 'function ai(e){if(e.startsWith("rocket-arenas/"))return arenaReferenceArenas.files.get(e);let t=e.replace(');
    replace('function K(e){let t=va(ha[ga],e);','function K(e){if(arenaReferenceArenas.labels.has(e))return arenaReferenceArenas.labels.get(e);let t=va(ha[ga],e);');
    replace('function Pa(e){return e&&Na[e]||Ma}', 'function Pa(e){return arenaReferenceArenas.stages.get(e)?.combat || e&&Na[e] || Ma}');
    const ground='this.add.image(0,0,su(e)).setOrigin(0,0).setDepth(0).setDisplaySize(Ca,wa)';
    replace(ground,'arenaReferenceArenas.stages.has(e)?arenaReferenceArenas.place(this,arenaReferenceArenas.stages.get(e)):'+ground);
    replace('async function pH(e,t,n){let r=cu(t),i=su(r.id),a={key:i,url:ai(r.file)};',
      'async function pH(e,t,n){let r=cu(t),i=su(r.id),a={key:i,url:ai(r.file)};if(r.queue){const ready=await arenaReferenceArenas.load(e,r,n);hH(e,ai(`vfx/fire/stat_down_tag.png`),`stat-down`);return ready}');
    replace('this.paintRecover(r,n,e.tick,t);let g=this.paintWindup(r,n,t)',
      'this.paintRecover(r,n,e.tick,t);if(this.rocketArenaScenery){const z=4+(c?.y??n.y)/1000000;if(r.sprite.depth!==z)r.sprite.setDepth(z)}let g=this.paintWindup(r,n,t)');
    replace('function Ia(e,t,n,r=Ma){let i=Fa(n,r);return{x:Math.min(i.maxX,Math.max(i.minX,e)),y:Math.min(i.maxY,Math.max(i.minY,t))}}',
      'function Ia(e,t,n,r=Ma,startX,startY){let i=Fa(n,r),x=Math.min(i.maxX,Math.max(i.minX,e)),y=Math.min(i.maxY,Math.max(i.minY,t));return r.rocks?arenaReferenceArenas.constrain(x,y,n,r.rocks,startX,startY):{x,y}}');
    replace('Ia(e+o.x*r*Sa,t+o.y*r*Sa,i,a)', 'Ia(e+o.x*r*Sa,t+o.y*r*Sa,i,a,e,t)');
    // Pass the starting point through the native dash, lunge, knockback and
    // separation paths. This sweeps large displacements and slides at rocks.
    for (const [prefix,actor] of [
      ['e.x+e.dodgeVx*Sa,e.y+e.dodgeVy*Sa','e'],
      ['e.x+t.vx*Sa,e.y+t.vy*Sa','e'],
      ['e.x+t/i*r,e.y+n/i*r','e'],
      ['e.x-s*o,e.y-c*o','e'],['t.x+s*o,t.y+c*o','t']
    ]) {
      const before='Ia('+prefix+','+actor+'.radius,this.combat';
      replace(before+')',before+','+actor+'.x,'+actor+'.y)');
    }
    const lunge='Ia(e.x+Math.cos(n.facing)*r,e.y+Math.sin(n.facing)*r,e.radius,this.combat)';
    if(source.split(lunge).length!==3)throw Error('Unsupported rock collision for melee lunges.');
    source=source.split(lunge).join(lunge.slice(0,-1)+',e.x,e.y)');
    replace('t.ttl<=0||t.basic&&t.flown>=380||t.x<-20','t.ttl<=0||this.combat.rocks&&arenaReferenceArenas.blocksShot(this.combat.rocks,n,r,t)||t.basic&&t.flown>=380||t.x<-20');
    replace('r={id:this.nextItemId++,kind:e,x:n.x,y:n.y,phase:`warn`','r={id:this.nextItemId++,kind:e,...Ia(n.x,n.y,16,this.combat),phase:`warn`');
    replace('stageId:fu(),source:`quick`','stageId:arenaReferenceArenas.selected(),source:`quick`');
    replace('stageId:fu(),source:this.source','stageId:arenaReferenceArenas.selected(),source:this.source');
    replace('lH(this,e,fu(),{bst:this.source===`cpu`})','lH(this,e,arenaReferenceArenas.selected(),{bst:this.source===`cpu`})');
    replace("stageId:fu(), opponentPartyIds:yo(partyIds, seed)","stageId:arenaReferenceArenas.selected(), opponentPartyIds:yo(partyIds, seed)");
    replace('this.onRoster?.(V_(this.pickTeam),fu())','this.onRoster?.(V_(this.pickTeam),this.arenaRosterOffline?arenaReferenceArenas.selected():fu())');
    const packed={};
    for (const id of ids) {
      const stage=scenery[id], textures=new Map();
      const objects=stage.objects.map(({image,x,y,w,h,depthY})=>{
        if (!textures.has(image)) textures.set(image,textures.size);
        return {image:textures.get(image),x,y,w,h,depthY};
      });
      packed[id]={ground:stage.ground,objects,textures:[...textures.keys()]};
    }
    return 'const arenaReferenceArenas=('+makeRocketArenas.toString()+')('+JSON.stringify(assets)+','+JSON.stringify(packed)+');\n'+source;
  }
  const api=Object.freeze({patch});globalThis.ArenaCustomArenasAdapter=api;
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})();
