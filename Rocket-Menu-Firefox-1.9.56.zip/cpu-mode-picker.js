(() => {
  'use strict';

  function createArenaCpuModes() {
    const key='poke2d.cpu.mode';
    const modes=[['classic','CLASSIC'],['ffa','FFA'],['5v5','5V5'],['4v4','4V4'],
      ['3v3v3','3V3V3'],['3v3','3V3'],['2v2','2V2'],['2v2v2v2','2V2V2V2']];
    let value={id:'classic',count:3},loaded=false;
    function normalize(raw){
      const id=modes.some(([id])=>id===raw?.id)?raw.id:'classic';
      const count=Number.isFinite(raw?.count)?Math.max(3,Math.min(12,Math.floor(raw.count))):3;
      return {id,count};
    }
    function storage(){try{return globalThis.localStorage??null;}catch{return null;}}
    function load(store){
      loaded=true;
      try{const text=store?.getItem(key);if(text)value=normalize(JSON.parse(text));}catch{}
    }
    function selection(){if(!loaded)load(storage());return {...value};}
    function save(store,next){value=normalize(next);loaded=true;try{store?.setItem(key,JSON.stringify(value));}catch{}}
    function mount(layer,options){
      const difficulty=layer.querySelector('.diff-panel');if(!difficulty)return;
      load(options.storage);
      layer.classList.add('arena-cpu-modes');
      layer.setAttribute('role','dialog');layer.setAttribute('aria-modal','true');layer.setAttribute('aria-label','CPU battle setup');
      difficulty.setAttribute('role','group');
      const style=document.createElement('style');
      style.textContent=`
        .diff-layer.arena-cpu-modes{box-sizing:border-box;padding:16px;overflow:hidden}
        .arena-cpu-modes .cpu-mode-layout{position:relative;z-index:1;display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);align-items:start;gap:20px;width:min(840px,100%);max-height:100%;min-height:0;box-sizing:border-box;padding:8px;overflow:auto;overscroll-behavior:contain}
        .arena-cpu-modes .cpu-mode-layout>.diff-panel,.arena-cpu-modes .cpu-mode-panel{position:relative;width:100%;min-width:0}
        .arena-cpu-modes .cpu-mode-body{display:grid;gap:12px;padding:16px;min-width:0}
        .arena-cpu-modes .cpu-mode-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;min-width:0}
        .arena-cpu-modes .cpu-mode-btn{appearance:none;box-sizing:border-box;position:relative;display:block;width:100%;min-width:0;min-height:44px;margin:0;padding:0 12px;border:0;border-radius:0;background:var(--ui-panel);color:var(--ui-text);font:700 16px/1 Silkscreen,monospace;cursor:pointer;box-shadow:inset 2px 0 var(--ui-frame-hi),inset 0 2px var(--ui-frame-hi),inset -2px 0 var(--ui-panel-shade),inset 0 -2px var(--ui-panel-shade)}
        .arena-cpu-modes .cpu-mode-btn[aria-pressed=true]{background:var(--ui-cell-selected);outline:2px solid var(--ui-select);outline-offset:2px;box-shadow:inset 2px 2px var(--ui-frame-hi),inset -2px -4px var(--ui-panel-shade),0 0 0 4px var(--ui-outline)}
        .arena-cpu-modes .cpu-mode-btn:focus-visible,.arena-cpu-modes .cpu-mode-count select:focus-visible{outline:2px solid var(--ui-text);outline-offset:3px}
        .arena-cpu-modes .cpu-mode-btn canvas{max-width:calc(100% - 24px);height:auto!important;image-rendering:pixelated;pointer-events:none}
        .arena-cpu-modes .cpu-mode-count{display:flex;flex-wrap:wrap;align-items:center;gap:10px;min-width:0;color:var(--ui-text);font:700 14px/1.4 Silkscreen,monospace}
        .arena-cpu-modes .cpu-mode-count[hidden]{display:none}
        .arena-cpu-modes .cpu-mode-count select{box-sizing:border-box;min-width:64px;height:36px;border:2px solid var(--ui-frame-hi);border-radius:0;background:var(--ui-input-bg);color:var(--ui-text);font:700 16px/1 Silkscreen,monospace;padding:4px}
        .arena-cpu-modes .cpu-mode-note{margin:2px 0 0;color:var(--ui-text-dim);font:12px/1.5 Silkscreen,monospace;overflow-wrap:anywhere}
        @media(max-width:720px){.arena-cpu-modes .cpu-mode-layout{grid-template-columns:minmax(0,1fr);width:min(428px,100%);gap:16px}.diff-layer.arena-cpu-modes{padding:8px}}
      `;
      layer.append(style);
      const layout=document.createElement('div');layout.className='cpu-mode-layout';
      const panel=document.createElement('section');panel.className='cpu-mode-panel gba-shell';panel.setAttribute('aria-label','Modes');
      panel.innerHTML='<div class="gba-groove"><div class="gba-core"><div class="gba-body">'+
        '<div class="diff-title cpu-mode-title" aria-label="MODES"></div><div class="cpu-mode-body">'+
        '<div class="cpu-mode-grid" role="group" aria-label="CPU battle mode"></div>'+ 
        '<label class="cpu-mode-count" hidden><span>FFA PLAYERS</span><select aria-label="Total FFA players"></select></label>'+ 
        '<p class="cpu-mode-note">Choose a mode, then a difficulty to start.</p></div></div></div></div>';
      layout.append(difficulty,panel);layer.append(layout);
      const grid=panel.querySelector('.cpu-mode-grid'),countRow=panel.querySelector('.cpu-mode-count'),count=countRow.querySelector('select');
      for(let number=3;number<=12;number++){
        const option=document.createElement('option');option.value=String(number);option.textContent=String(number);count.append(option);
      }
      function paint(){
        if(!layer.isConnected)return;
        const title=panel.querySelector('.cpu-mode-title');
        title.replaceChildren(rE('MODES',{font:'Silkscreen',px:8,weight:700,color:WQ('--ui-on-frame','#10142A'),scale:2}));
        for(const button of grid.querySelectorAll('[data-cpu-mode]')){
          button.setAttribute('aria-pressed',String(button.dataset.cpuMode===value.id));
          GQ(button,modes.find(([id])=>id===button.dataset.cpuMode)[1]);
        }
        countRow.hidden=value.id!=='ffa';count.value=String(value.count);
      }
      for(const [id,label] of modes){
        const button=document.createElement('button');button.type='button';button.className='cpu-mode-btn';
        button.dataset.cpuMode=id;button.setAttribute('aria-label',label);button.setAttribute('aria-pressed',String(value.id===id));
        button.addEventListener('click',()=>{save(options.storage,{...value,id});AZ();paint();});grid.append(button);
      }
      count.addEventListener('change',()=>{save(options.storage,{...value,count:Number(count.value)});AZ();paint();});
      paint();document.fonts?.ready?.then(()=>{if(layer.isConnected)paint();});
    }
    function keydown(layer,event){
      const target=event.target instanceof Element?event.target:null;
      if(!target?.closest('.cpu-mode-panel')||!layer.contains(target))return false;
      if(event.key==='Escape')return false;
      // Mode/count controls must not trigger UQ's Enter/A difficulty shortcut.
      // Tab and select's own arrow handling retain their normal browser behavior.
      event.stopImmediatePropagation();
      const button=target.closest('[data-cpu-mode]');
      if(!button)return true;
      if(event.key==='Enter'||event.key===' '){event.preventDefault();if(!event.repeat)button.click();return true;}
      const buttons=[...layer.querySelectorAll('[data-cpu-mode]')],index=buttons.indexOf(button);
      const steps={ArrowLeft:-1,ArrowRight:1,ArrowUp:-2,ArrowDown:2};
      if(Object.hasOwn(steps,event.key)){
        event.preventDefault();const next=buttons[(index+steps[event.key]+buttons.length)%buttons.length];next.focus();next.click();
      }
      return true;
    }
    return {selection,normalize,mount,keydown};
  }

  function patch(source){
    const replace=(before,after)=>{const parts=source.split(before);if(parts.length!==2)throw Error('Unsupported CPU mode picker anchor: '+before.slice(0,70));source=parts.join(after);};
    replace('e.parent.appendChild(r),ly();let i=r.querySelector(`.diff-dither`);',
      'e.parent.appendChild(r),arenaCpuModes.mount(r,e),ly();let i=r.querySelector(`.diff-dither`);');
    replace('d=i=>{if(n)return;let a=i.key.toLowerCase();',
      'd=i=>{if(n)return;if(arenaCpuModes.keydown(r,i))return;let a=i.key.toLowerCase();');
    replace('source:this.source,difficulty:t};this.scene.start(`arena`,a)',
      'source:this.source,difficulty:t,arenaCpuMode:this.source===`cpu`?arenaCpuModeSelection():null};this.scene.start(`arena`,a)');
    return 'const arenaCpuModes=('+createArenaCpuModes.toString()+')();\nfunction arenaCpuModeSelection(){return arenaCpuModes.selection()}\n'+source;
  }
  const api=Object.freeze({patch});globalThis.ArenaCpuModePickerAdapter=api;
  if(typeof module!=='undefined'&&module.exports)module.exports={patch,createArenaCpuModes};
})();
