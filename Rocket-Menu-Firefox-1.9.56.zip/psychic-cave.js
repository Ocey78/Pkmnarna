// Private Mewtwo chamber: native-scale layered masonry, carved stone and mineral light.
(() => {
  'use strict';
  function createArenaPsychicCave() {
    const id='rocket-psychic-cave',width=2048,height=1280;
    const combat={left:220,top:330,right:1828,bottom:1120,rocks:[]};
    const stage=Object.freeze({id,labelKey:'stages.rocket.psychicCave',file:'rocket-private/psychic-cave',backdrop:'#17141f'});
    const key=name=>id+'-'+name;
    function random(seed){return()=>{seed|=0;seed=seed+0x6D2B79F5|0;let n=Math.imul(seed^seed>>>15,1|seed);n=n+Math.imul(n^n>>>7,61|n)^n;return((n^n>>>14)>>>0)/4294967296;};}
    function poly(c,p,fill,stroke,w=2){c.beginPath();c.moveTo(...p[0]);for(const q of p.slice(1))c.lineTo(...q);c.closePath();c.fillStyle=fill;c.fill();if(stroke){c.strokeStyle=stroke;c.lineWidth=w;c.stroke();}}
    function line(c,p,color,w=2){c.beginPath();c.moveTo(...p[0]);for(const q of p.slice(1))c.lineTo(...q);c.strokeStyle=color;c.lineWidth=w;c.stroke();}
    function oval(c,x,y,rx,ry,color,stroke,w=2){c.beginPath();c.ellipse(x,y,rx,ry,0,0,Math.PI*2);c.fillStyle=color;c.fill();if(stroke){c.lineWidth=w;c.strokeStyle=stroke;c.stroke();}}
    function block(c,x,y,w,h,rng,dark=false){
      const colors=dark?['#494338','#51493d','#594e40','#605345']:['#766a54','#80715a','#88775c','#7e7059'];
      const chip=2+Math.floor(rng()*3)*2;
      poly(c,[[x+chip,y+2],[x+w-4,y+2],[x+w-2,y+chip],[x+w-2,y+h-4],[x+w-chip,y+h-2],[x+4,y+h-2],[x+2,y+h-chip],[x+2,y+chip]],colors[Math.floor(rng()*colors.length)]);
      line(c,[[x+chip,y+3],[x+w-5,y+3]],dark?'#9e8b644e':'#c7b28b62');
      line(c,[[x+w-3,y+chip],[x+w-3,y+h-4],[x+5,y+h-3]],'#29252168');
      for(let i=0;i<Math.ceil(w*h/200);i++){const px=Math.floor((x+5+rng()*(w-10))/2)*2,py=Math.floor((y+5+rng()*(h-10))/2)*2;c.fillStyle=i%2?'#e6c59016':'#211d271b';c.fillRect(px,py,2+(i%3)*2,2);}
      if(rng()<.24){const px=x+w*(.3+rng()*.4);line(c,[[px,y+2],[px-4,y+h*.4],[px+6,y+h*.56],[px+2,y+h*.8]],'#302c2c80');}
    }
    function masonry(c,x,y,w,h,rng,bw=70,bh=40,dark=false){c.save();c.beginPath();c.rect(x,y,w,h);c.clip();c.fillStyle='#302c29';c.fillRect(x,y,w,h);for(let row=0,py=y;py<y+h;py+=bh,row++)for(let px=x-row%2*bw/2;px<x+w;px+=bw)block(c,px,py,bw,bh,rng,dark);c.restore();}
    function glyph(c,x,y,size,variant,color){
      const p=variant%4;c.strokeStyle=color;c.lineWidth=2;c.strokeRect(x,y,size,size);
      if(p===0){line(c,[[x+4,y+size/2],[x+size-4,y+size/2]],color);line(c,[[x+size/2,y+3],[x+size/2,y+size-3]],color);}
      if(p===1)line(c,[[x+3,y+size-4],[x+size/2,y+4],[x+size-3,y+size-4],[x+3,y+size-4]],color);
      if(p===2){c.strokeRect(x+4,y+4,size-8,size-8);c.fillStyle=color;c.fillRect(x+size/2-1,y+size/2-1,2,2);}
      if(p===3)line(c,[[x+3,y+4],[x+size-4,y+4],[x+size-4,y+size/2],[x+4,y+size/2],[x+4,y+size-4]],color);
    }
    function crystal(c,x,y,size,flip=false){
      c.save();c.translate(x,y);if(flip)c.scale(-1,1);
      oval(c,0,7,size*.8,size*.32,'#11101c70');
      poly(c,[[-size*.32,0],[-size*.44,-size*.64],[-size*.08,-size*1.12],[size*.23,-size*.63],[size*.22,2]],'#79578e','#282038');
      poly(c,[[-size*.08,-size*1.12],[size*.23,-size*.63],[size*.22,2],[-size*.06,-size*.17]],'#bea4d7');
      poly(c,[[size*.14,5],[size*.21,-size*.47],[size*.54,-size*.66],[size*.62,-size*.2],[size*.44,6]],'#82649b','#322641');
      line(c,[[-size*.08,-size],[size*.01,-size*.23]],'#f6dfff',2);
      line(c,[[size*.51,-size*.57],[size*.47,-size*.04]],'#dac8ef',2);c.restore();
    }
    function floor(c){
      const rng=random(150201);c.fillStyle='#27222b';c.fillRect(0,0,width,height);
      c.fillStyle='#74664f';c.fillRect(184,295,1680,857);
      // Low-contrast sandstone tiles merge into a worn, open fighting floor.
      for(let row=0,y=300;y<1154;y+=58,row++)for(let x=186-row%2*44;x<1864;x+=88)block(c,x,y,88,58,rng);
      c.fillStyle='#a18a6633';c.fillRect(220,330,1608,790);
      for(let i=0;i<2800;i++){const x=220+Math.floor(rng()*804)*2,y=330+Math.floor(rng()*395)*2;c.fillStyle=i%3?'#dabd8213':'#2a243019';c.fillRect(x,y,i%5?2:6,2);}
      // A recessed ancient seal, never an obstacle or raised combat prop.
      const cx=1024,cy=710;
      for(const [r,w,a] of [[226,12,'#302c3140'],[216,3,'#d4b88b55'],[176,5,'#44384470'],[169,2,'#cfb28b44'],[48,6,'#44384466']])oval(c,cx,cy,r,r*.68,'#00000000',a,w);
      for(let i=0;i<16;i++){const a=i*Math.PI/8,x=cx+Math.cos(a)*198,y=cy+Math.sin(a)*135;glyph(c,x-7,y-7,14,i,'#4b3d4e88');}
      poly(c,[[cx,cy-108],[cx+75,cy],[cx,cy+108],[cx-75,cy]],'#65536712','#4b3e4f66',3);
      line(c,[[cx-94,cy],[cx+94,cy]],'#d7baa13b');line(c,[[cx,cy-90],[cx,cy+90]],'#d7baa13b');
      // Thick boundary masonry and rim shadows describe the real combat edge.
      for(const [x,y,w,h] of [[180,302,1688,28],[180,1120,1688,44],[180,330,40,790],[1828,330,40,790]])masonry(c,x,y,w,h,rng,64,28,true);
      c.fillStyle='#19162436';c.fillRect(220,330,1608,18);c.fillRect(220,330,14,790);c.fillRect(1814,330,14,790);
      for(const [x,y,rx,ry] of [[260,407,175,120],[1780,438,195,145],[260,1010,145,110],[1785,1020,145,110]]){
        const g=c.createRadialGradient(x,y,0,x,y,rx);g.addColorStop(0,'#b67ce12b');g.addColorStop(.6,'#975ed412');g.addColorStop(1,'#8e5dca00');c.save();c.translate(x,y);c.scale(1,ry/rx);c.translate(-x,-y);c.fillStyle=g;c.fillRect(x-rx,y-rx,rx*2,rx*2);c.restore();
      }
      // Sand scuffs and small chips at the edge, without hidden collision geometry.
      for(let i=0;i<150;i++){const x=230+rng()*1580,y=i%2?341+rng()*22:1080+rng()*30;line(c,[[x,y],[x+8+rng()*20,y-2]],i%3?'#c2a47839':'#40372d43',2);}
    }
    function facade(c){
      const rng=random(150202);c.fillStyle='#17151d';c.fillRect(0,0,2048,330);
      // Natural stacked rock surrounds a symmetrical, hand-carved doorway.
      for(let row=0,y=18;y<288;y+=47,row++)for(let x=-45+row%2*55;x<2050;x+=110){const w=100+rng()*22;block(c,x,y,w,55,rng,true);line(c,[[x+5,y+19],[x+w*.5,y+17],[x+w-8,y+21]],'#18151d55');}
      masonry(c,635,58,778,262,rng,84,44,true);
      poly(c,[[784,308],[784,138],[816,106],[1232,106],[1264,138],[1264,308]],'#08090e','#29232e',8);
      poly(c,[[816,290],[816,142],[840,120],[1208,120],[1232,142],[1232,290]],'#101019');
      c.fillStyle='#24202b';c.fillRect(836,140,376,148);
      const dark=c.createLinearGradient(0,138,0,290);dark.addColorStop(0,'#07080d');dark.addColorStop(1,'#2b2234');c.fillStyle=dark;c.fillRect(836,140,376,148);
      line(c,[[1024,144],[1024,280]],'#74607840',2);
      // Lintel and interlocked carving bands echo the reference's sealed chamber.
      masonry(c,752,78,544,54,rng,90,54);
      c.fillStyle='#302831';c.fillRect(773,91,502,29);
      for(let i=0;i<19;i++)glyph(c,781+i*25,97,16,i,'#a28a68');
      line(c,[[756,80],[1290,80]],'#bfa57d',4);line(c,[[758,129],[1292,129]],'#1a1720',4);
      for(const x of [692,1272]){
        masonry(c,x,112,84,202,rng,84,45);
        for(const y of [136,183,230]){c.fillStyle='#352f30';c.fillRect(x+13,y,58,27);glyph(c,x+31,y+5,17,y,'#ad9570');line(c,[[x+18,y+22],[x+66,y+22]],'#6a5a48');}
        masonry(c,x-12,282,108,36,rng,108,36);masonry(c,x-8,100,100,24,rng,100,24);
      }
      for(const [x,y,s] of [[300,285,55],[1700,282,60],[576,297,33],[1445,295,35]])crystal(c,x,y,s,x>1024);
      // The arch threshold meets the open floor without a walk-through door.
      for(let i=0;i<3;i++){const y=284+i*12; c.fillStyle=['#6b5d4e','#8f7a5e','#a38c68'][i];c.fillRect(786-i*8,y,476+i*16,12);line(c,[[786-i*8,y+11],[1262+i*8,y+11]],'#2b2630',2);}
      const shade=c.createLinearGradient(0,0,0,130);shade.addColorStop(0,'#080a11db');shade.addColorStop(1,'#080a1100');c.fillStyle=shade;c.fillRect(0,0,2048,130);
    }
    function side(c,mirror=false){
      if(mirror){c.translate(220,0);c.scale(-1,1);}const rng=random(mirror?150204:150203);
      c.fillStyle='#17151c';c.fillRect(0,0,220,840);
      for(let row=0,y=0;y<840;y+=74,row++){
        const edge=194+rng()*24;
        poly(c,[[0,y-8],[edge-25,y-8],[edge,y+13],[edge-5,y+59],[edge-28,y+76],[0,y+78]],['#3c3532','#484039','#51473c'][row%3],'#1d1b24',4);
        line(c,[[22,y+22],[110,y+17],[edge-9,y+25]],'#9c886049',3);
        line(c,[[44,y+49],[edge-18,y+53]],'#211e27a0',4);
        for(let i=0;i<15;i++){c.fillStyle=i%2?'#c4a77d12':'#14131d2a';c.fillRect(15+rng()*160,y+10+rng()*45,4+rng()*10,2);}
      }
      for(const [y,size] of [[122,39],[500,45],[727,32]])crystal(c,176,y,size);
      const shade=c.createLinearGradient(0,0,170,0);shade.addColorStop(0,'#080a11bd');shade.addColorStop(1,'#080a1100');c.fillStyle=shade;c.fillRect(0,0,170,840);
    }
    function texture(scene,name,w,h,paint){
      if(scene.textures.exists(name))return;const canvas=document.createElement('canvas');canvas.width=w;canvas.height=h;
      const pixel=document.createElement('canvas');pixel.width=Math.ceil(w/2);pixel.height=Math.ceil(h/2);const low=pixel.getContext('2d'),ctx=canvas.getContext('2d');
      if(!low||!ctx)throw Error('Psychic Cave canvas unavailable');low.imageSmoothingEnabled=false;low.scale(pixel.width/w,pixel.height/h);paint(low);
      ctx.imageSmoothingEnabled=false;ctx.drawImage(pixel,0,0,w,h);const result=scene.textures.addCanvas(name,canvas);if(!result)throw Error('Psychic Cave texture unavailable');result.setFilter(G.Textures.FilterMode.NEAREST);
    }
    async function load(scene,progress){const name=su(id);progress?.track(name);try{texture(scene,name,width,height,floor);texture(scene,key('rear'),2048,330,facade);texture(scene,key('west'),220,840,c=>side(c));texture(scene,key('east'),220,840,c=>side(c,true));progress?.finish(name);return true;}catch(error){progress?.resetInflight(name);console.warn('[Rocket Menu] Could not prepare Psychic Cave.',error);return false;}}
    function place(scene){
      if(!scene.textures.exists(su(id)))return;const ground=scene.add.image(0,0,su(id)).setOrigin(0,0).setDepth(0);rocketArenaMaterial.ground(ground,id);scene.rocketArenaScenery=true;
      for(const [name,x,y,foot] of [['rear',0,0,328],['west',0,320,1158],['east',1828,320,1158]]){const sprite=scene.add.image(x,y,key(name)).setOrigin(0,0).setDepth(4+foot/1000000);rocketArenaMaterial.ground(sprite,id,[x/width,y/height,sprite.displayWidth/width,sprite.displayHeight/height]);}
      scene.events.once('shutdown',()=>{scene.rocketArenaScenery=false;});
    }
    return Object.freeze({id,width,height,combat,stage,load,place});
  }
  function patch(source){const once=(before,after)=>{const parts=source.split(before);if(parts.length!==2)throw Error('Unsupported Psychic Cave anchor: '+before);source=parts.join(after);};
    once('function cu(e){','function cu(e){if(e===arenaPsychicCave.id)return arenaPsychicCave.stage;');
    once('function Pa(e){','function Pa(e){if(e===arenaPsychicCave.id)return arenaPsychicCave.combat;');
    once('function K(e){','function K(e){if(e===arenaPsychicCave.stage.labelKey)return "Psychic Cave";');
    once('async function pH(e,t,n){','async function pH(e,t,n){if(t===arenaPsychicCave.id){const ready=await arenaPsychicCave.load(e,n);hH(e,ai(`vfx/fire/stat_down_tag.png`),`stat-down`);return ready}');
    once('placeGround(e){','placeGround(e){if(e===arenaPsychicCave.id){if(!this.groundPlaced&&this.alive&&this.textures.exists(su(e))){this.groundPlaced=true;arenaPsychicCave.place(this)}return}');
    return 'const arenaPsychicCave=('+createArenaPsychicCave.toString()+')();globalThis.arenaPsychicCave=arenaPsychicCave;\n'+source;
  }
  const api=Object.freeze({patch});globalThis.ArenaPsychicCaveAdapter=api;if(typeof module!=='undefined'&&module.exports)module.exports=api;
})();
