'use strict';
const site = 'https://poke2darena.com';
const supportedPath = rocketGameBuilds.clientPath;
const pinnedHash = rocketGameBuilds.clientHash;
const launchUrl = site + '/play-online/?arenaModLaunch=14';
const loadIssues = new Map(), repairAttempts = new Set(), documentEntries = new Map();
const verified = new Set([pinnedHash, rocketGameBuilds.fullRosterHash]);
const maxSourceBytes = 8 * 1024 * 1024;
let pinnedGame = null, cachedGame = null;
const documentKey = (tabId,frameId)=>tabId+':'+frameId;

// Fixed local soundtrack routes work in both normal and recovery launches.
browser.webRequest.onBeforeRequest.addListener(details=>{
  const match = /^\/play-online\/rocket-menu-audio\/(boss-rayquaza-[123]\.mp3|boss-eon\.mp3|boss-sync\.json)$/.exec(new URL(details.url).pathname);
  if(details.method==='GET' && match)
    return {redirectUrl:browser.runtime.getURL('audio/'+match[1])};
}, {urls:[site+'/play-online/rocket-menu-audio/*'],types:['xmlhttprequest']}, ['blocking']);

function arenaPage(value) {
  try {
    const url = new URL(value);
    if (url.origin !== site || !['/play-online/','/play-online'].includes(url.pathname)) return null;
    url.hash = ''; return url;
  } catch { return null; }
}
async function sourceHash(bytes) {
  const digest = new Uint8Array(await crypto.subtle.digest('SHA-256',bytes));
  return Array.from(digest,b=>b.toString(16).padStart(2,'0')).join('');
}
async function readGameBytes(response) {
  if (Number(response.headers.get('content-length')) > maxSourceBytes) throw Error('Game source exceeds the loader limit.');
  const reader = response.body.getReader(), parts = []; let length = 0;
  try {
    for (;;) {
      const next = await reader.read(); if (next.done) break;
      length += next.value.byteLength;
      if (length > maxSourceBytes) { await reader.cancel(); throw Error('Game source exceeds the loader limit.'); }
      parts.push(next.value);
    }
  } finally { reader.releaseLock(); }
  const bytes = new Uint8Array(length); let offset = 0;
  for (const part of parts) { bytes.set(part,offset); offset += part.byteLength; }
  return bytes;
}
async function verifyCachedSource(record) {
  if (record?.hash !== pinnedHash || record.path !== supportedPath || typeof record.source !== 'string' ||
      record.source.length > maxSourceBytes) return null;
  const bytes = new TextEncoder().encode(record.source);
  if (bytes.length > maxSourceBytes || await sourceHash(bytes) !== pinnedHash) return null;
  return record.source;
}
async function cachedGameSource() {
  if (cachedGame) return cachedGame;
  try {
    const data = await browser.storage.local.get(rocketGameBuilds.cacheKey);
    cachedGame = await verifyCachedSource(data[rocketGameBuilds.cacheKey]);
  } catch {}
  return cachedGame;
}
async function rememberGameSource(source) {
  // Callers checked the exact original bytes against pinnedHash.
  cachedGame = source;
  try { await browser.storage.local.set({[rocketGameBuilds.cacheKey]:{
    hash:pinnedHash,path:supportedPath,source,savedAt:Date.now()
  }}); } catch {} // A storage failure must not prevent playing a verified download.
}
function compatibleGameSource() {
  if (!pinnedGame) pinnedGame = (async()=>{
    const cached = await cachedGameSource(); if (cached) return cached;
    const response = await fetch(site+supportedPath,{cache:'no-store',credentials:'omit',redirect:'error',signal:AbortSignal.timeout(20000)});
    if (!response.ok) throw Error('The verified engine is unavailable and there is no saved copy (HTTP '+response.status+'). Update Rocket Menu.');
    const bytes = await readGameBytes(response);
    if (await sourceHash(bytes) !== pinnedHash)
      throw Error('The compatible engine fingerprint changed and no verified cached copy is available. Update Rocket Menu.');
    const source = new TextDecoder('utf-8',{fatal:true,ignoreBOM:true}).decode(bytes);
    await rememberGameSource(source); return source;
  })().catch(error=>{pinnedGame=null;throw error;});
  return pinnedGame;
}

// Read the parser's actual entry tag before forwarding those HTML bytes.
// An index-*.js filename alone is insufficient: imported chunks stay native.
function observeGameDocument(details) {
  const page = arenaPage(details.url);
  if (details.method !== 'GET' || details.tabId < 0 || !page) return;
  if(details.frameId===0)for(const key of documentEntries.keys())if(key.startsWith(details.tabId+':'))documentEntries.delete(key);
  const record = {url:page.href,entry:null,metadata:null};
  documentEntries.set(documentKey(details.tabId,details.frameId),record);
  let filter;
  try { filter = browser.webRequest.filterResponseData(details.requestId); } catch { return; }
  const decoder = new TextDecoder(); let html = '';
  function readEntry() {
    if (record.entry || html.length > 512 * 1024) return;
    const parsed = new DOMParser().parseFromString(html,'text/html');
    const baseTag = parsed.querySelector('base[href]'); let base = page.href;
    try { if (baseTag) base = new URL(baseTag.getAttribute('href'),page).href; } catch {}
    for (const script of parsed.scripts) {
      if ((script.getAttribute('type') || '').trim().toLowerCase() !== 'module' || !script.hasAttribute('src')) continue;
      try {
        const url = new URL(script.getAttribute('src'),base);
        if (url.origin === site && /^\/play-online\/assets\/index-[a-z0-9_-]+\.js$/i.test(url.pathname)) {
          record.entry = url.href; break;
        }
      } catch {}
    }
  }
  filter.ondata = ({data})=>{
    if (!record.entry && html.length <= 512 * 1024) {
      html += decoder.decode(data,{stream:true});
      try { readEntry(); } catch {}
    }
    filter.write(data);
  };
  filter.onstop = ()=>filter.close();
}
browser.webRequest.onBeforeRequest.addListener(observeGameDocument,
  {urls:[site+'/play-online*'],types:['main_frame','sub_frame']},['blocking']);

async function siteMetadata(record) {
  if (!record?.entry) return {version:'Unknown',build:'Unknown'};
  if (record.metadata) return record.metadata;
  const known = rocketGameBuilds.releases[new URL(record.entry).pathname];
  if (known) return record.metadata = known;
  try {
    const response = await fetch(record.entry,{cache:'no-store',credentials:'omit',redirect:'error',signal:AbortSignal.timeout(8000)});
    if (response.ok) {
      const bytes = await readGameBytes(response);
      record.metadata = rocketGameBuilds.readMetadata(new TextDecoder('utf-8',{fatal:true}).decode(bytes));
    }
  } catch {}
  return record.metadata || {version:'Unknown',build:'Unknown'};
}
function launchPrefix(metadata,warning) {
  return 'document.documentElement.setAttribute("data-arena-site-version",'+JSON.stringify(metadata.version)+');'+
    'document.documentElement.setAttribute("data-arena-site-build",'+JSON.stringify(metadata.build)+');'+
    'document.dispatchEvent(new Event("arena-site-metadata"));\n'+(warning ?
    'document.documentElement.setAttribute("data-arena-update-warning",'+JSON.stringify(warning)+');'+
    'document.dispatchEvent(new Event("arena-site-update"));\n' : '');
}
function patchResponse(details) {
  if (details.method !== 'GET' || details.tabId < 0) return;
  const doc = arenaPage(details.documentUrl || details.originUrl); if (!doc) return;
  const record = documentEntries.get(documentKey(details.tabId,details.frameId));
  if (!record || record.url !== doc.href || record.entry !== new URL(details.url).href) return;
  const entryPath = new URL(record.entry).pathname;
  loadIssues.delete(details.tabId);
  if (doc.searchParams.get('arenaModLaunch') === '14') return {cancel:true};
  let filter;
  try { filter = browser.webRequest.filterResponseData(details.requestId); } catch {
    loadIssues.set(details.tabId,'Firefox could not apply Rocket Menu to this tab. Automatic repair will attempt one reload.'); return;
  }
  const parts = []; let length = 0, passthrough = false;
  filter.ondata = ({data})=>{
    if (passthrough) return;
    parts.push(data); length += data.byteLength;
    if (length > maxSourceBytes) {
      passthrough = true;
      for (const part of parts) filter.write(part);
      parts.length = 0;
      loadIssues.set(details.tabId,'The new game entry exceeds the loader limit. The normal game was left intact; update Rocket Menu.');
      filter.disconnect();
    }
  };
  filter.onstop = async()=>{
    if (passthrough) return;
    const original = new Uint8Array(length); let offset = 0;
    for (const part of parts) { original.set(new Uint8Array(part),offset); offset += part.byteLength; }
    parts.length = 0; let result = original;
    try {
      const hash = await sourceHash(original);
      const originalText = new TextDecoder('utf-8',{fatal:true,ignoreBOM:true}).decode(original);
      record.metadata = rocketGameBuilds.readMetadata(originalText);
      let stock;
      if (entryPath === supportedPath && verified.has(hash)) {
        stock = originalText;
        if (hash === pinnedHash) await rememberGameSource(stock);
      } else stock = await compatibleGameSource();
      const known = rocketGameBuilds.deployments[entryPath] === hash;
      const warning = entryPath !== supportedPath || !verified.has(hash)
        ? entryPath + (known ? '' : '#'+hash.slice(0,12)) : '';
      // Unknown code is inspected as text, never executed as the replacement.
      result = new TextEncoder().encode(launchPrefix(record.metadata,warning)+patchModMenu(stock));
    } catch (error) { loadIssues.set(details.tabId,'Rocket Menu could not activate. '+error.message); }
    try { filter.write(result); } finally { filter.close(); }
  };
}
browser.webRequest.onBeforeRequest.addListener(patchResponse,
  {urls:[site+'/play-online/assets/index-*.js*'],types:['script']},['blocking']);
browser.tabs.onRemoved.addListener(id=>{loadIssues.delete(id);repairAttempts.delete(id);for(const key of documentEntries.keys())if(key.startsWith(id+':'))documentEntries.delete(key);});

async function repairArenaTab(sender) {
  const id = sender.tab?.id;
  if (!Number.isInteger(id) || repairAttempts.has(id)) return {repaired:false,reason:'already-attempted'};
  const page = arenaPage(sender.url || sender.tab.url); if (!page) return {repaired:false,reason:'wrong-page'};
  const current = await browser.tabs.get(id).catch(()=>null); if (!current) return {repaired:false,reason:'closed-tab'};
  if (!arenaPage(current.url) || current.url !== (sender.tab.url || page.href)) return {repaired:false,reason:'navigated'};
  if (repairAttempts.has(id)) return {repaired:false,reason:'already-attempted'};
  repairAttempts.add(id); page.searchParams.set('arenaModLaunch','14'); loadIssues.delete(id);
  try {
    if (current.url === page.href) await browser.tabs.reload(id,{bypassCache:true});
    else await browser.tabs.update(id,{url:page.href});
    return {repaired:true};
  } catch { return {repaired:false,reason:'reload-failed'}; }
}
browser.runtime.onMessage.addListener((message,sender)=>{
  if (sender.id !== browser.runtime.id) return;
  if (message?.type === 'arena-mod-load-issue' && sender.tab) return Promise.resolve(loadIssues.get(sender.tab.id)||'');
  if (message?.type === 'arena-mod-repair-tab') return repairArenaTab(sender);
  if (message?.type === 'arena-mod-open-fresh') return browser.tabs.create({url:launchUrl}).then(()=>true);
  if (message?.type === 'arena-compatible-engine-cache' && sender.tab && arenaPage(sender.url))
    return Promise.all([compatibleGameSource().catch(()=>null),siteMetadata(documentEntries.get(documentKey(sender.tab.id,sender.frameId)))]).then(([source,metadata])=>({
      engine:source ? {source,hash:pinnedHash,path:supportedPath} : null,metadata
    }));
});
