// Keep native battles and room transports alive when the browser loses focus.
(() => {
  'use strict';

  function rocketBackgroundPlayBoot(game) {
    // Game.start binds these instance methods after preBoot. The native game
    // already uses a setTimeout frame loop. Leave that loop, real visibility,
    // focus events, audio muting and explicit game.pause()/resume() untouched.
    // In particular, returning to the tab must not resume a manually paused game.
    game.onHidden = function () {};
    game.onVisible = function () { this.loop.resetDelta(); };
    // Browsers can still throttle/suspend hidden pages. This prevents the game's
    // own deactivation; it cannot promise foreground frame rates in the background.
  }

  function patch(source) {
    function replace(before, after, label) {
      const parts = source.split(before);
      if (parts.length !== 2) throw Error('Unsupported game build for background play: ' + label + '.');
      source = parts.join(after);
    }

    replace(
      'callbacks:{preBoot:e=>{arenaReplayVfxGame=e;',
      'callbacks:{preBoot:e=>{rocketBackgroundPlayBoot(e);arenaReplayVfxGame=e;',
      'game visibility lifecycle'
    );

    // Native controls already release attacks, joystick, previews and switch
    // requests on blur/hidden. Also clear movement keys for visibility changes
    // that do not deliver a window blur or the corresponding keyup events.
    replace(
      'o=()=>{this.blurred=!0,this.joystick.reset(),this.pointerInside=!1,this.releaseAttacks(),this.switchSlot=null,this.megaLatch=!1,this.touchAims.fill(null)}',
      'o=()=>{this.blurred=!0,this.keyboard.held.clear(),this.joystick.reset(),this.pointerInside=!1,this.releaseAttacks(),this.switchSlot=null,this.megaLatch=!1,this.touchAims.fill(null)}',
      'release held input'
    );

    // A hidden tab is not a lost link. Keep the actual socket, peer-health
    // reports and authority pump alive; cancel the local held command instead.
    // Existing native reconnects and all real transport failure checks remain.
    replace(
      'onVisible=()=>{this.active&&(document.visibilityState===`hidden`?(this.cancelCloudProbe(),this.linkDown=!0,this.battle?.setConnected(!1),this.authority?.setState(!1,15e3),this.directStart&&!this.result&&(this.needsSync=!0,this.client?.send({t:`direct-health`,m:this.directStart.matchId,up:!1})),this.client?.background()):this.client?.connect())};',
      'onVisible=()=>{this.active&&(document.visibilityState===`hidden`?this.battle?.cancelBufferedInput():this.client?.connect())};',
      'room background disconnect'
    );
    replace(
      'document.visibilityState!==`hidden`&&this.client?.send({t:`direct-health`,m:e.start.matchId,up:this.peer?.available()??!1})',
      'this.client?.send({t:`direct-health`,m:e.start.matchId,up:this.peer?.available()??!1})',
      'direct recovery health'
    );
    replace(
      'let r=!this.linkDown&&document.visibilityState!==`hidden`&&this.peer?.available(),i=e.frozenMs??(r?null:15e3);',
      'let r=!this.linkDown&&this.peer?.available(),i=e.frozenMs??(r?null:15e3);',
      'direct transport state'
    );

    // Connection selection still uses the game's real probe measurements.
    // Let a probe complete if the user changes tabs while waiting in a lobby.
    replace(
      'probeCloud(e){if(this.probed||!this.client||this.mode!==`room`||document.visibilityState===`hidden`||!this.room||![`open`,`lobby`].includes(this.room.state))return;',
      'probeCloud(e){if(this.probed||!this.client||this.mode!==`room`||!this.room||![`open`,`lobby`].includes(this.room.state))return;',
      'background connection probe'
    );
    replace(
      'r&&this.active&&this.mode===`room`&&document.visibilityState!==`hidden`&&t.send({t:`cloud-report`,id:e.id,samples:r})',
      'r&&this.active&&this.mode===`room`&&t.send({t:`cloud-report`,id:e.id,samples:r})',
      'background probe completion'
    );

    // Training follows room packets and explicit Leave/Ready actions. Its native
    // battle controls handle lost focus without closing the practice scene.
    replace(
      "// The native controller backgrounds its connection when the page is hidden.\n      session.visibility = () => { if (document.hidden) close(session, true, false); };\n      document.addEventListener('visibilitychange', session.visibility);",
      '// Keep practice active across tab changes; native controls release held input.',
      'training visibility listener'
    );
    replace(
      "      document.removeEventListener('visibilitychange', session.visibility);\n",
      '',
      'training visibility cleanup'
    );

    return rocketBackgroundPlayBoot.toString() + '\n' + source;
  }

  const api = Object.freeze({patch});
  globalThis.ArenaBackgroundPlayAdapter = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})();
