(() => {
  'use strict';

  function createArenaKeybinds() {
    const definitions=[
      ['up','Move up','KeyW'],['left','Move left','KeyA'],['down','Move down','KeyS'],['right','Move right','KeyD'],
      ['basic','Basic attack',null],['move2','Move 2 / Heat',null],['mobility','Dash / Protect','Space'],
      ['skill','Skill / Cooldown','KeyQ'],['ultimate','Ultimate / Charge','KeyE'],['cycle','Next Pokémon','KeyR'],
      ['mega','Mega evolution','KeyF'],['team1','Team slot 1','Digit1'],['team2','Team slot 2','Digit2'],['team3','Team slot 3','Digit3']
    ];
    const defaults=Object.fromEntries(definitions.map(([id,,code])=>[id,code]));
    const aliases={ArrowUp:'up',ArrowLeft:'left',ArrowDown:'down',ArrowRight:'right',Numpad1:'team1',Numpad2:'team2',Numpad3:'team3'};
    const slots=['basic','move2','mobility','skill','ultimate'];
    let cachedRaw,cached,editing=null,settingsRoot=null,styled=false;
    function valid(code){return typeof code==='string'&&/^(Key[A-Z]|Digit[0-9]|Numpad[0-9]|Arrow(Up|Down|Left|Right)|Space|Shift(Left|Right)|Minus|Equal|Bracket(Left|Right)|Backslash|Semicolon|Quote|Backquote|Comma|Period|Slash)$/.test(code);}
    function normalize(raw){
      const result={},used=new Set();
      for(const [id,,fallback] of definitions){
        const value=raw&&typeof raw==='object'&&!Array.isArray(raw)&&Object.hasOwn(raw,id)?raw[id]:fallback;
        const code=value===null?null:valid(value)?value:fallback;
        result[id]=code&&!used.has(code)?code:null;
        if(result[id])used.add(result[id]);
      }
      return result;
    }
    function read(){const raw=ei().controls.keybinds;if(!cached||raw!==cachedRaw){cachedRaw=raw;cached=normalize(raw);}return cached;}
    function action(code){
      if(!code)return null;
      const bindings=read();
      for(const [id] of definitions)if(bindings[id]===code)return id;
      const alias=aliases[code];
      return alias&&bindings[alias]===defaults[alias]?alias:null;
    }
    function label(code,short=false){
      if(!code)return 'NONE';
      if(/^Key/.test(code))return code.slice(3);
      if(/^Digit/.test(code))return code.slice(5);
      if(/^Numpad/.test(code))return (short?'N':'NUM ')+code.slice(6);
      const labels={Space:'SPACE',ArrowUp:'UP',ArrowDown:'DOWN',ArrowLeft:'LEFT',ArrowRight:'RIGHT',
        ShiftLeft:short?'LSHFT':'LEFT SHIFT',ShiftRight:short?'RSHFT':'RIGHT SHIFT',Minus:'-',Equal:'=',BracketLeft:'[',
        BracketRight:']',Backslash:'\\',Semicolon:';',Quote:"'",Backquote:'`',Comma:',',Period:'.',Slash:'/'};
      return labels[code]||code;
    }
    function hud(slot,kind='short'){
      const code=read()[slots[slot]];
      if(slot<2){
        if(kind==='glyph')return slot===0?'mouse-left':'mouse-right';
        const mouse=kind==='long'?(slot===0?'Left click':'Right click'):(slot===0?'LMB':'RMB');
        return kind==='long'&&code?mouse+' / '+label(code):mouse;
      }
      return label(code,kind!=='long');
    }
    function blocked(event){
      if(event&&(event.ctrlKey||event.metaKey||event.altKey))return true;
      if(editing||document.documentElement.classList.contains('settings-open'))return true;
      let active=document.activeElement;
      while(active?.shadowRoot?.activeElement)active=active.shadowRoot.activeElement;
      const nodes=event?.composedPath?.()||[event?.target,active];
      return nodes.some(node=>node instanceof Element&&
        (node.isContentEditable||node.closest('input,textarea,select,[contenteditable="true"],[role="dialog"],[data-rocket-keybinds],#panel')));
    }
    function movement(event){
      const id=action(event.code);
      return {up:'w',left:'a',down:'s',right:'d'}[id]??null;
    }
    function attack(code){const id=action(code);return id==='cycle'?'switch':slots.includes(id)?slots.indexOf(id):null;}
    function team(code){const id=action(code);return id&&/^team[123]$/.test(id)?Number(id.slice(4))-1:null;}
    function save(bindings){ni(settings=>{settings.controls.keybinds=normalize(bindings);return settings;});}
    function escape(text){return String(text).replace(/[&<>"']/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));}
    function markup(){
      const bindings=read();
      return '<section data-rocket-keybinds aria-label="Keyboard controls"><div class="rocket-keybind-head"><h3>KEYBOARD CONTROLS</h3>'+ 
        '<button type="button" class="px" data-key-reset>RESET KEYS</button></div><div class="rocket-keybind-grid">'+
        definitions.map(([id,title])=>'<div class="rocket-keybind-row"><span>'+title+'</span><button type="button" class="px" data-key-bind="'+id+'" aria-label="Change '+title+' binding">'+
          escape(label(bindings[id]))+'</button><button type="button" class="px rocket-key-clear" data-key-clear="'+id+'" aria-label="Clear '+title+' binding">×</button></div>').join('')+
        '</div><p class="rocket-keybind-status" role="status">Choose a key to edit. Escape cancels. Duplicate keys swap.</p>'+ 
        '<p class="rocket-keybind-note">Mouse aiming and left/right clicks stay available. Default movement also accepts arrows; default team keys also accept the number pad.</p></section>';
    }
    function status(text){const node=settingsRoot?.querySelector('.rocket-keybind-status');if(node)node.textContent=text;}
    function cancel(){const id=editing;editing=null;if(id){const button=settingsRoot?.querySelector('[data-key-bind="'+id+'"]');if(button){button.textContent=label(read()[id]);button.removeAttribute('aria-pressed');}status('Choose a key to edit. Escape cancels. Duplicate keys swap.');}return id;}
    function focus(id){settingsRoot?.querySelector('[data-key-bind="'+id+'"]')?.focus({preventScroll:true});}
    function click(event){
      const target=event.target instanceof Element?event.target:null;
      if(!target?.closest('[data-rocket-keybinds]'))return;
      const button=target.closest('button');if(!button)return;
      event.preventDefault();event.stopPropagation();
      if(button.hasAttribute('data-key-reset')){cancel();save(defaults);status('Default keys restored.');return;}
      const clear=button.dataset.keyClear;
      if(clear&&Object.hasOwn(defaults,clear)){cancel();save({...read(),[clear]:null});focus(clear);return;}
      const id=button.dataset.keyBind;if(!Object.hasOwn(defaults,id))return;
      cancel();editing=id;button.textContent='PRESS KEY';button.setAttribute('aria-pressed','true');
      button.focus({preventScroll:true});status('Press the new key. Escape cancels. Ctrl, Alt and browser shortcuts are reserved.');
    }
    function settingsKey(event){
      if(!settingsRoot||!pE||hE!=='controls'){cancel();return false;}
      if(editing){
        if(event.ctrlKey||event.metaKey||event.altKey)return false;
        event.preventDefault();event.stopImmediatePropagation();
        if(event.repeat)return true;
        if(event.key==='Escape'){cancel();return true;}
        if(!valid(event.code)){status('Use a letter, number, arrow, Space, Shift or punctuation key. Escape cancels.');return true;}
        const id=editing,bindings={...read()},old=bindings[id],other=Object.keys(bindings).find(key=>key!==id&&bindings[key]===event.code);
        if(other)bindings[other]=old;
        bindings[id]=event.code;editing=null;save(bindings);focus(id);status('Key saved'+(other?' — swapped with '+definitions.find(row=>row[0]===other)[1]+'.':'.'));
        return true;
      }
      const target=event.target instanceof Element?event.target:null;
      if(!target?.closest('[data-rocket-keybinds]')||event.key==='Escape')return false;
      if((event.key==='Enter'||event.key===' ')&&!event.repeat){event.preventDefault();event.stopImmediatePropagation();target.closest('button')?.click();}
      // Keep native Settings arrows/Enter from changing an unrelated row while
      // keyboard focus is inside the key editor; normal Tab navigation remains.
      return true;
    }
    function mount(root){
      if(!root?.querySelector('[data-rocket-keybinds]')){cancel();return;}
      if(settingsRoot!==root){settingsRoot=root;root.addEventListener('click',click,true);}
      if(editing){const id=editing;editing=null;const button=root.querySelector('[data-key-bind="'+id+'"]');button?.click();}
      if(styled)return;styled=true;
      const style=document.createElement('style');style.textContent=`
        #settings:has([data-rocket-keybinds]) .shell{grid-template-rows:auto minmax(0,1fr)}
        #settings:has([data-rocket-keybinds]) .panel{height:auto;min-height:0;align-self:stretch}
        #settings:has([data-rocket-keybinds]) .rows{flex:1 1 0;min-height:0;overflow-y:auto;overflow-x:hidden;overscroll-behavior:contain;scrollbar-gutter:stable}
        #settings:has([data-rocket-keybinds]) .rows>*{flex-shrink:0}
        #settings .rows>[data-rocket-keybinds]{flex-shrink:0;min-width:0;width:100%;box-sizing:border-box;margin-top:12px;color:var(--ui-text);font:12px/1.4 Silkscreen,monospace}
        #settings .rocket-keybind-head{display:flex;flex-wrap:wrap;gap:8px;align-items:center;justify-content:space-between;margin-bottom:10px}
        #settings .rocket-keybind-head h3{margin:0;font:700 14px/1.4 Silkscreen,monospace}
        #settings .rocket-keybind-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:6px 12px}
        #settings .rocket-keybind-row{display:grid;grid-template-columns:minmax(0,1fr) 96px 28px;align-items:center;gap:5px;min-width:0;padding:6px;border:2px solid var(--ui-frame-hi);background:var(--ui-panel);box-shadow:inset 0 0 0 1px var(--ui-outline)}
        #settings [data-rocket-keybinds] button{position:static;width:auto;min-width:0;max-width:100%;height:auto;min-height:30px;padding:4px;border:2px solid var(--ui-frame-hi);border-radius:0;background:var(--ui-panel);color:var(--ui-text);font:700 11px/1.4 Silkscreen,monospace;cursor:pointer;overflow-wrap:anywhere}
        #settings [data-rocket-keybinds] button:focus-visible,#settings [data-key-bind][aria-pressed=true]{outline:2px solid var(--ui-cursor);outline-offset:2px}
        #settings .rocket-keybind-status,#settings .rocket-keybind-note{margin:10px 0;white-space:normal;overflow-wrap:anywhere;font:12px/1.5 Silkscreen,monospace}
        @media(max-width:1000px),(max-height:560px){#settings .rocket-keybind-grid{grid-template-columns:minmax(0,1fr)}}
      `;document.head.append(style);
    }
    function party(root){
      for(const badge of root?.querySelectorAll('[data-team-hotkey]')||[]){
        const button=badge.closest('[data-slot]'),index=Number(button?.dataset.slot),code=read()['team'+(index+1)];
        badge.textContent=label(code,true);badge.hidden=!code;
        if(code)button.setAttribute('aria-keyshortcuts',code==='Space'?'Space':label(code));else button.removeAttribute('aria-keyshortcuts');
      }
      const mega=root?.querySelector('.mega-hint');if(mega)mega.textContent=label(read().mega,true)+' MEGA';
    }
    return {normalize,action,movement,attack,team,blocked,hud,label,read,markup,mount,settingsKey,party,cancel};
  }

  function patch(source){
    function replace(before,after,count=1){const parts=source.split(before);if(parts.length!==count+1)throw Error('Unsupported key binding anchor: '+before.slice(0,70));source=parts.join(after);}
    function between(start,end,replacement){const at=source.indexOf(start),to=source.indexOf(end,at+start.length);if(at<0||to<0||source.indexOf(start,at+1)>=0)throw Error('Unsupported key binding function: '+start);source=source.slice(0,at)+replacement+source.slice(to);}
    replace('controls:{stick:`fixed`,','controls:{keybinds:arenaKeybinds.normalize(),stick:`fixed`,');
    replace('controls:{stick:Nr(o?.stick,n.controls.stick),','controls:{keybinds:arenaKeybinds.normalize(o?.keybinds),stick:Nr(o?.stick,n.controls.stick),');
    between('function Qm(e){','function th(e){',
      'function Qm(e){return arenaKeybinds.action(e.code)===`mega`}function $m(e){return arenaKeybinds.attack(e)}function eh(e){return arenaKeybinds.team(e)}');
    between('function fU(e){','var pU=', 'function fU(e){return arenaKeybinds.movement(e)}');
    replace('attach(e){let t=e=>{let t=fU(e);','attach(e){let t=e=>{if(arenaKeybinds.blocked(e))return;let t=fU(e);');
    replace('getMove(){let e=0,t=0;return(this.held.has(`a`)', 'getMove(){if(arenaKeybinds.blocked()){this.held.clear();return{x:0,y:0}}let e=0,t=0;return(this.held.has(`a`)');
    replace('let i=e=>{if(e.ctrlKey||e.metaKey||e.altKey)return;if(typeof Element',
      'let i=e=>{if(arenaKeybinds.blocked(e))return;if(typeof Element');
    replace('},a=e=>{let t=$m(e.code);','},a=e=>{if(arenaKeybinds.blocked(e)){this.releaseAttacks();this.clearPreview();this.keyboard.held.clear();return}let t=$m(e.code);');
    replace('this.detachSettings=ii(()=>this.releaseAttacks()),','this.detachSettings=ii(()=>{this.releaseAttacks();this.clearPreview();this.keyboard.held.clear();this.switchSlot=null;this.megaLatch=false;}),');
    between('function aD(){','function oD(){','function aD(){return arenaKeybinds.markup()}');
    replace('hE===`controls`&&e===`pc`?PE().map', 'hE===`controls`?PE().map');
    replace('pD(),requestAnimationFrame(()=>{GE(lE)})','arenaKeybinds.mount(lE),pD(),requestAnimationFrame(()=>{GE(lE)})');
    replace('function GD(e){','function GD(e){if(arenaKeybinds.settingsKey(e))return;');
    replace('function BE(){','function BE(){arenaKeybinds.cancel();');
    replace('function nh(e){return Zm[e]??``}','function nh(e){return arenaKeybinds.hud(e,`long`)}');
    replace('key:Ym[e],move:', 'key:arenaKeybinds.hud(e),move:');
    replace('a.textContent=Ym[r];','a.textContent=arenaKeybinds.hud(r);');
    replace('r.textContent=Ym[e];','r.textContent=arenaKeybinds.hud(e);');
    replace('ob[t]', 'arenaKeybinds.hud(t,`glyph`)',2);
    replace('function Lg(e){return{w:e.startsWith(`mouse-`)?11:e===`SPACE`?45:13,h:12}}',
      'function Lg(e){return{w:e.startsWith(`mouse-`)?11:Math.max(13,Math.min(61,5+e.length*8)),h:12}}');
    replace('e.slots.map(t=>t===1?`RMB`:t===3?`Q`:e.dodge?`SPACE DODGE`:`SPACE`)',
      'e.slots.map(t=>arenaKeybinds.hud(t)+(e.dodge&&t===2?` DODGE`:``))');
    replace('renderParty(e){let t=this.root?.querySelector(`.party-cells`);',
      'renderParty(e){arenaKeybinds.party(this.root);let t=this.root?.querySelector(`.party-cells`);');
    return 'const arenaKeybinds=('+createArenaKeybinds.toString()+')();\n'+source;
  }
  const api=Object.freeze({patch});globalThis.ArenaKeybindsAdapter=api;
  if(typeof module!=='undefined'&&module.exports)module.exports={patch,createArenaKeybinds};
})();
