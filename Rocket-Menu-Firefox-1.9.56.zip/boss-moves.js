// Player-controlled, offline boss techniques. Native cooldowns, move roles,
// type damage, Protect and party switching remain authoritative.
(() => {
  'use strict';
  function createArenaBossMoves(){
    const worlds=new WeakMap(),tau=Math.PI*2,clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
    let registered=false;
    const catalog=[
      ['rayquaza-dash','Dragon Rush','rayquaza','dragon-rush','dash',100,4200],
      ['rayquaza-breath','Sky Dragon Breath','rayquaza','dragon-breath','breath',80,4700],
      ['rayquaza-plasma','Plasma Barrage','rayquaza','energy-ball','plasma',100,5000],
      ['rayquaza-skyfall','Meteor Skyfall','rayquaza','draco-meteor','skyfall',135,9000],
      ['eon-laser','Eon Plasma Laser','eon','luster-purge','laser',100,5000],
      ['eon-ice','Eon Ice Beam','eon','ice-beam','ice',90,4200],
      ['eon-steelwing','Steel Wing Charge','eon','steel-wing','steelwing',90,4000],
      ['eon-twin-dive','Twin Dive','eon','fly','dive',110,6500],
      ['eon-hurricane','Eon Hurricane','eon','hurricane','hurricane',110,6200],
      ['eon-psy-bombs','Orbiting Psybombs','eon','psychic','psybombs',100,6000],
      ['eon-dragon-cross','Dragon Cross','eon','dragon-pulse','cross',110,6500],
      ['eon-safeguard','Eon Status Field','eon','calm-mind','safeguard',0,9500],
      ['eon-heal','Eon Recovery','eon','calm-mind','heal',0,8500],
      ['mewtwo-shadow-clones','Shadow Clone Volley','mewtwo','shadow-ball','shadowclones',95,6500],
      ['mewtwo-radial','Psychic Laser Circle','mewtwo','psychic','radial',110,7000],
      ['mewtwo-teleport-crunch','Teleport Crunch','mewtwo','crunch','teleport',90,6500],
      ['mewtwo-rock','Psychic Rock Throw','mewtwo','rock-slide','rock',95,4200],
      ['mewtwo-aura','Charged Aura Sphere','mewtwo','aura-sphere','aura',100,5000],
      ['mewtwo-turrets','Psychic Clone Lasers','mewtwo','psystrike','turrets',120,8000]
    ].map(([suffix,name,boss,base,kind,power,cooldownMs])=>({id:'rocket-boss-'+suffix,name,boss,base,kind,power,cooldownMs}));
    const byId=new Map(catalog.map(entry=>[entry.id,entry]));
    const isMove=id=>typeof id==='string'&&byId.has(id);
    const baseMove=id=>byId.get(id)?.base??id;
    const enabled=()=>typeof rocketCloset!=='undefined'&&rocketCloset.getBossMoves?.()===true;
    const point=a=>({x:a.x,y:a.y}),center=a=>arenaBossRush.center(a),angle=(a,b)=>Math.atan2(b.y-a.y,b.x-a.x);
    const distance=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
    function register(){
      if(registered)return;
      for(const entry of catalog){
        const base=V(entry.base),utility=entry.power===0;
        const move={...base,...entry,catalogId:entry.id.replace(/-/g,''),typeName:utility?'psychic':base.typeName,
          shape:utility?'self':base.shape,status:utility?'calm':'none',category:utility?'status':base.category,
          secondaryAilment:entry.kind==='ice'?'freeze':null,secondaryChance:entry.kind==='ice'?.1:0,
          windupMs:entry.kind==='aura'?1000:350,recoverMs:260,range:750,radius:28,speed:650,ttlMs:2200,
          tickMs:180,ticks:7,activeMs:1100,halfAngle:.16,dashSpeed:1050,dashMs:480,recoilRatio:0,drainRatio:0,energy:32};
        // Do not add these to Ne()/the ordinary species pool. The Closet picker
        // explicitly exposes them, while saved data can always resolve IDs.
        De[entry.id]=move;Ae.set(move.catalogId,move);Object.assign(entry,{typeName:move.typeName,category:move.category,shape:move.shape});
      }
      registered=true;
    }
    function offline(w){return !w.net&&(w.arenaSoloMods===true||w.arenaTraining===true||w.arenaBossRush===true||w.arenaEonBoss===true||w.arenaMewtwoBoss===true||!!w.arenaCpuFighters||w.ai===true);}
    function state(w){
      let s=worlds.get(w);
      if(!s||w.tick<s.lastTick){s={clock:0,lastTick:w.tick-1,nextId:1,attacks:new Map(),projectiles:[],beams:[],clones:[],impacts:[],fieldUntil:0};worlds.set(w,s);}
      return s;
    }
    function bounds(w,p,r=24){const c=w.combat;return Ia(clamp(p.x,c.left+r,c.right-r),clamp(p.y,c.top+r,c.bottom-r),r,c,p.x,p.y);}
    function blocked(w,a,b,r=3){return !!(w.combat.rocks?.length&&typeof arenaReferenceArenas!=='undefined'&&arenaReferenceArenas.blocksShot(w.combat.rocks,a.x,a.y,{...b,radius:r}));}
    function foes(w,actor){return w.enemies(actor).filter(target=>target.hp>0);}
    function impact(s,kind,p,radius,lifeMs=450){s.impacts.push({id:s.nextId++,kind,...point(p),radius,ageMs:0,lifeMs});if(s.impacts.length>70)s.impacts.shift();}
    function phase(a,name,ms){a.phase=name;a.elapsedMs=0;a.durationMs=ms;a.progress=0;}
    function finish(w,s,actor,a){
      s.attacks.delete(actor.id);s.clones=s.clones.filter(c=>c.attackId!==a.id);s.beams=s.beams.filter(b=>b.attackId!==a.id);
      if(actor.cast?.rocketBossId===a.id){actor.cast=null;actor.recoverMs=Math.max(actor.recoverMs,260);}
    }
    function damage(w,actor,target,move,factor=1){
      if(w.phase!=='fight'||actor.hp<=0||target.hp<=0||target.iframeMs>0)return false;
      if(target.protectMs>0){w.events.push({type:'block',target:target.id,x:target.x,y:target.y});return true;}
      const amount=Math.max(1,Math.round(w.damage(actor,target,move,false)*factor));
      w.landHit(actor,target,move,false,amount);return true;
    }
    function illusionContact(w,predicate){return w.arenaMewtwoBoss&&typeof rocketMewtwoCombat!=='undefined'&&rocketMewtwoCombat.clonesHit(w,predicate);}
    function blast(w,s,actor,a,p,radius,factor=1,kind=a.kind){
      impact(s,kind,p,radius,600);
      if(illusionContact(w,c=>distance(center(c),p)<=radius+c.radius))return;
      for(const target of foes(w,actor))if(distance(center(target),p)<=radius+target.radius&&!blocked(w,p,center(target)))damage(w,actor,target,a.moveId,factor);
    }
    function projectile(w,s,actor,a,kind,from,facing,opts={}){
      const velocity=opts.speed??(kind==='hurricane'?350:kind==='rock'?620:800),radius=opts.radius??(kind==='hurricane'?60:kind==='rock'?35:kind==='ice'?23:29);
      s.projectiles.push({id:s.nextId++,actorId:actor.id,ownerEntry:actor.entry,attackId:a.id,moveId:a.moveId,kind,x:from.x,y:from.y,prevX:from.x,prevY:from.y,
        vx:Math.cos(facing)*velocity,vy:Math.sin(facing)*velocity,radius,ageMs:0,lifeMs:opts.lifeMs??3000,factor:opts.factor??1,phase:opts.orbit?'orbit':'flying',
        orbitAngle:facing,orbitRadius:opts.orbit?85:0,launchMs:opts.orbit?650:0,target:point(a.target),nextHit:0});
      if(s.projectiles.length>100)s.projectiles.shift();
    }
    function beam(w,s,actor,a,id,from,facing,width,length=1000){
      const c=w.combat,dx=Math.cos(facing),dy=Math.sin(facing);let d=length;
      if(dx>0)d=Math.min(d,(c.right-from.x)/dx);else if(dx<0)d=Math.min(d,(c.left-from.x)/dx);
      if(dy>0)d=Math.min(d,(c.bottom-from.y)/dy);else if(dy<0)d=Math.min(d,(c.top-from.y)/dy);
      s.beams.push({id,attackId:a.id,actorId:actor.id,kind:a.kind,from:point(from),to:{x:from.x+dx*Math.max(0,d),y:from.y+dy*Math.max(0,d)},width,phase:a.phase==='active'?'active':'warning',progress:a.progress});
    }
    function makeClones(w,s,actor,a,count,kind){
      for(let i=0;i<count;i++){
        const theta=i*tau/count+a.facing,p=bounds(w,{x:a.target.x+Math.cos(theta)*180,y:a.target.y+Math.sin(theta)*180},actor.radius);
        s.clones.push({id:s.nextId++,attackId:a.id,actorId:actor.id,ownerEntry:actor.entry,kind,...point(p),speciesId:actor.speciesId,
          facing:angle(p,a.target),alpha:0,ageMs:0,lifeMs:3500,rocketBossScale:actor.rocketBossScale||1});
      }
    }
    function start(w,actor,move,input,target,ult=false){
      if(!isMove(move.id))return false;
      if(!offline(w)||actor!==w.player||!enabled())return false;
      const s=state(w),entry=byId.get(move.id),origin=center(actor),dir=w.direction(actor,input,target,move),facing=Math.atan2(dir.y,dir.x);
      const aim=center(target),range=Math.min(700,distance(origin,aim));
      const targetPoint=bounds(w,{x:origin.x+Math.cos(facing)*range,y:origin.y+Math.sin(facing)*range},actor.radius);
      const a={id:s.nextId++,actorId:actor.id,ownerEntry:actor.entry,speciesId:actor.speciesId,moveId:move.id,kind:entry.kind,phase:'windup',
        elapsedMs:0,durationMs:entry.kind==='aura'?1000:400,progress:0,origin,target:point(targetPoint),facing,radius:ult?155:125,width:ult?48:32,alpha:1,flyHeight:0,ult,
        nextHit:0,hits:new Set(),passes:0};
      if(a.kind==='teleport'){phase(a,'fadeout',350);a.target=bounds(w,{x:target.x-Math.cos(target.facing)*100,y:target.y-Math.sin(target.facing)*100},actor.radius);}
      if(a.kind==='skyfall'||a.kind==='dive')phase(a,'rise',450);
      if(a.kind==='shadowclones')makeClones(w,s,actor,a,ult?8:6,'shadow');
      if(a.kind==='turrets')makeClones(w,s,actor,a,ult?5:3,'turret');
      if(a.kind==='safeguard'||a.kind==='heal')a.durationMs=280;
      s.attacks.set(actor.id,a);actor.facing=facing;actor.dodgeVx=actor.dodgeVy=0;
      actor.cast={rocketBoss:true,rocketBossId:a.id,moveId:move.id,shape:'dash',phase:'active',facing,ms:100000,
        ticksLeft:0,tickDebt:0,tickMs:0,range:750,halfAngle:.16,knockback:0,dashMs:0,vx:0,vy:0,hit:false,recoilRatio:0,ult,basic:false,basicType:'',basicPct:0,groundX:null,groundY:null};
      // The game's basic role normally uses 500ms regardless of move metadata.
      // Boss techniques retain their actual cooldown even if assigned there.
      if(!ult){const index=actor.loadout.findIndex((id,i)=>id===move.id&&input.buttons.attacks[i]);if(index>=0)actor.cds[index]=Math.max(actor.cds[index]||0,move.cooldownMs);else actor.basicCd=Math.max(actor.basicCd||0,move.cooldownMs);}
      w.events.push({type:'cast',actor:actor.id,move:move.id,x:actor.x,y:actor.y,arenaUltimate:ult,rocketBossMove:true});return true;
    }
    function effects(w,s){
      s.impacts=s.impacts.filter(p=>(p.ageMs+=q)<p.lifeMs);
      s.projectiles=s.projectiles.filter(p=>{
        const actor=w.fighterOf(p.actorId);if(!actor||actor.entry!==p.ownerEntry||actor.hp<=0)return false;
        p.ageMs+=q;if(p.ageMs>=p.lifeMs)return false;
        const from=point(p);p.prevX=p.x;p.prevY=p.y;
        if(p.phase==='orbit'){
          const c=center(actor),theta=p.orbitAngle+p.ageMs*.005;p.x=c.x+Math.cos(theta)*p.orbitRadius;p.y=c.y+Math.sin(theta)*p.orbitRadius;
          if(p.ageMs<p.launchMs)return true;
          p.phase='flying';const theta2=angle(p,p.target);p.vx=Math.cos(theta2)*780;p.vy=Math.sin(theta2)*780;
          p.prevX=p.x;p.prevY=p.y;return true;
        }
        p.x+=p.vx*Sa;p.y+=p.vy*Sa;
        const c=w.combat;if(!Number.isFinite(p.x+p.y)||p.x<c.left-p.radius||p.x>c.right+p.radius||p.y<c.top-p.radius||p.y>c.bottom+p.radius||blocked(w,from,p,p.radius))return false;
        if(illusionContact(w,clone=>oc(from,p,center(clone),p.radius+clone.radius)!==null))return false;
        const targets=foes(w,actor).filter(t=>oc(from,p,center(t),p.radius+t.radius)!==null);
        if(p.kind==='hurricane'){
          if(s.clock>=p.nextHit){p.nextHit=s.clock+240;for(const target of targets)damage(w,actor,target,p.moveId,.22);}
          return true;
        }
        for(const target of targets)if(damage(w,actor,target,p.moveId,p.factor)){impact(s,p.kind,center(target),p.radius*1.8);return false;}
        return true;
      });
    }
    function castTick(w,s,actor,a){
      a.elapsedMs+=q;a.progress=clamp(a.elapsedMs/a.durationMs,0,1);a.origin=center(actor);actor.facing=a.facing;
      if(a.phase==='recover'){if(a.progress>=1)finish(w,s,actor,a);return;}
      const clones=s.clones.filter(c=>c.attackId===a.id);
      for(const clone of clones){clone.ageMs+=q;clone.alpha=a.phase==='windup'?Math.min(1,a.progress*2):1;}
      if(a.kind==='dash'||a.kind==='steelwing'){
        if(a.phase==='windup'&&a.progress>=1)phase(a,'active',a.kind==='dash'?460:370);
        else if(a.phase==='active'){
          const from=point(actor),p=Ia(actor.x+Math.cos(a.facing)*1100*Sa,actor.y+Math.sin(a.facing)*1100*Sa,actor.radius,w.combat,actor.x,actor.y);
          actor.x=p.x;actor.y=p.y;
          if(!illusionContact(w,c=>oc(from,p,c,actor.radius+c.radius+15)!==null))for(const target of foes(w,actor)){
            const key=target.id+':'+target.entry;
            if(!a.hits.has(key)&&oc(from,p,target,actor.radius+target.radius+15)!==null&&damage(w,actor,target,a.moveId,1.1))a.hits.add(key);
          }
          if(a.progress>=1||distance(from,p)<1){
            if(a.kind==='dash'&&a.ult&&a.passes++<1){a.facing+=Math.PI;a.hits.clear();phase(a,'windup',250);}
            else phase(a,'recover',260);
          }
        }
      }else if(['breath','laser','radial','cross','turrets'].includes(a.kind)){
        if(a.phase==='windup'&&a.progress>=1){phase(a,'active',a.kind==='turrets'?2200:a.kind==='radial'?1900:1400);a.nextHit=0;}
        if(a.phase==='windup'||a.phase==='active'){
          const phaseAngle=a.facing+(a.kind==='radial'?a.elapsedMs*.00032:Math.sin(a.progress*Math.PI*2)*.1);
          if(a.kind==='radial'){const count=a.ult?10:6;for(let i=0;i<count;i++)beam(w,s,actor,a,a.id+'-'+i,a.origin,phaseAngle+i*tau/count,16);}
          else if(a.kind==='cross'){
            for(const turn of [-Math.PI/4,Math.PI/4]){const theta=a.facing+turn,from=bounds(w,{x:a.target.x-Math.cos(theta)*260,y:a.target.y-Math.sin(theta)*260});beam(w,s,actor,a,a.id+'-'+turn,from,theta,a.width,520);}
          }else if(a.kind==='turrets'){for(const clone of clones)beam(w,s,actor,a,a.id+'-'+clone.id,center({...actor,...clone}),clone.facing,a.width);}
          else beam(w,s,actor,a,String(a.id),a.origin,phaseAngle,a.kind==='breath'?a.width*2:a.width,800);
          if(a.phase==='active'&&a.elapsedMs>=a.nextHit){
            a.nextHit+=180;const lines=s.beams.filter(b=>b.attackId===a.id);
            if(!illusionContact(w,c=>lines.some(b=>oc(b.from,b.to,center(c),b.width/2+c.radius)!==null)))for(const target of foes(w,actor)){
              const p=center(target);if(lines.some(b=>oc(b.from,b.to,p,b.width/2+target.radius)!==null&&!blocked(w,b.from,p)))damage(w,actor,target,a.moveId,a.kind==='radial'?.18:.2);
            }
          }
          if(a.phase==='active'&&a.progress>=1){phase(a,'recover',300);s.clones=s.clones.filter(c=>c.attackId!==a.id);}
        }
      }else if(a.kind==='skyfall'||a.kind==='dive'){
        if(a.phase==='rise'){a.flyHeight=a.progress*300;actor.iframeMs=Math.max(actor.iframeMs,75);if(a.progress>=1)phase(a,'mark',650);}
        else if(a.phase==='mark'){a.flyHeight=300;actor.iframeMs=Math.max(actor.iframeMs,75);if(a.progress>=1){a.from=point(actor);phase(a,'fall',350);}}
        else if(a.phase==='fall'){
          actor.iframeMs=Math.max(actor.iframeMs,75);const t=a.progress*a.progress;a.flyHeight=300*(1-t);
          const p=bounds(w,{x:a.from.x+(a.target.x-a.from.x)*t,y:a.from.y+(a.target.y-a.from.y)*t},actor.radius);actor.x=p.x;actor.y=p.y;
          if(a.progress>=1){a.flyHeight=0;blast(w,s,actor,a,center(actor),a.radius,1.4);
            if(a.kind==='dive')blast(w,s,actor,a,bounds(w,{x:actor.x-Math.sin(a.facing)*110,y:actor.y+Math.cos(a.facing)*110}),a.radius*.8,.55,'dive');
            if(a.kind==='skyfall'&&a.ult)for(let i=0;i<4;i++){const theta=i*Math.PI/2;blast(w,s,actor,a,bounds(w,{x:actor.x+Math.cos(theta)*180,y:actor.y+Math.sin(theta)*180}),90,.35,'meteor');}
            phase(a,'recover',400);
          }
        }
      }else if(a.kind==='teleport'){
        if(a.phase==='fadeout'){a.alpha=1-a.progress;if(a.progress>.55)actor.iframeMs=Math.max(actor.iframeMs,75);if(a.progress>=1){actor.x=a.target.x;actor.y=a.target.y;const target=foes(w,actor).sort((l,r)=>distance(l,actor)-distance(r,actor))[0];if(target)a.facing=angle(center(actor),center(target));phase(a,'fadein',350);}}
        else if(a.phase==='fadein'){a.alpha=a.progress;if(a.progress<.45)actor.iframeMs=Math.max(actor.iframeMs,75);if(a.progress>=1){a.alpha=1;phase(a,'windup',320);}}
        else if(a.phase==='windup'&&a.progress>=1){blast(w,s,actor,a,{x:a.origin.x+Math.cos(a.facing)*65,y:a.origin.y+Math.sin(a.facing)*65},95,1.2,'crunch');phase(a,'recover',320);}
      }else if(a.phase==='windup'){
        if(a.kind==='aura'||a.kind==='rock')a.origin={x:a.origin.x-Math.cos(a.facing)*45-Math.sin(a.facing)*25,y:a.origin.y-Math.sin(a.facing)*45+Math.cos(a.facing)*25-8};
        if(a.progress>=1){
          if(a.kind==='safeguard'){
            s.fieldUntil=s.clock+5000;impact(s,'safeguard',{x:(w.combat.left+w.combat.right)/2,y:(w.combat.top+w.combat.bottom)/2},Math.hypot(w.combat.right-w.combat.left,w.combat.bottom-w.combat.top),5000);
          }else if(a.kind==='heal'){
            actor.hp=Math.min(actor.maxHp,actor.hp+Math.ceil((actor.maxHp-actor.hp)*.08));w.rememberHp(actor);
            const enemyIds=new Set(foes(w,actor).map(t=>t.id));
            for(const ally of w.fighters())if(ally!==actor&&ally.hp>0&&!enemyIds.has(ally.id)){ally.hp=Math.min(ally.maxHp,ally.hp+Math.ceil((ally.maxHp-ally.hp)*.04));w.rememberHp(ally);}
            impact(s,'heal',center(actor),95,800);
          }else if(a.kind==='shadowclones'){
            for(const clone of clones)projectile(w,s,actor,a,'shadow',center({...actor,...clone}),clone.facing,{factor:.4,radius:22});
            s.clones=s.clones.filter(c=>c.attackId!==a.id);
          }else if(a.kind==='psybombs'){
            for(let i=0;i<(a.ult?7:5);i++)projectile(w,s,actor,a,'psy-bomb',a.origin,i*tau/(a.ult?7:5),{orbit:true,factor:.38,radius:24});
          }else{
            const kind=a.kind==='plasma'?'plasma':a.kind==='ice'?'ice':a.kind==='hurricane'?'hurricane':a.kind==='rock'?'rock':'aura';
            if(a.kind==='plasma'&&a.ult)for(let i=0;i<4;i++)projectile(w,s,actor,a,kind,a.origin,a.facing+(i-1.5)*.24,{factor:.6});
            else projectile(w,s,actor,a,kind,a.origin,a.facing,{factor:a.kind==='aura'?1.35:1});
          }
          phase(a,'recover',300);
        }
      }
    }
    function tick(w){
      const s=worlds.get(w);if(!s||s.lastTick===w.tick)return;
      if(w.tick<s.lastTick){worlds.delete(w);return;}s.lastTick=w.tick;
      if(w.phase!=='fight'||!offline(w)){s.attacks.clear();s.projectiles=[];s.beams=[];s.clones=[];s.impacts=[];s.fieldUntil=0;return;}
      s.clock+=q;s.beams=[];effects(w,s);
      for(const [id,a] of [...s.attacks]){
        const actor=w.fighterOf(id);
        if(!actor||actor.hp<=0||actor.entry!==a.ownerEntry||actor.cast?.rocketBossId!==a.id||actor.ailment==='sleep'||actor.ailment==='freeze'){
          if(actor)finish(w,s,actor,a);else s.attacks.delete(id);continue;
        }
        castTick(w,s,actor,a);
      }
      if(s.fieldUntil>s.clock)for(const actor of w.fighters())if(actor.hp>0){actor.ailment=null;actor.ailmentMs=actor.ailmentClock=0;actor.ailmentMove=null;actor.statusGraceMs=Math.max(actor.statusGraceMs||0,75);}
    }
    function immune(w){const s=worlds.get(w);return !!(s&&w.tick>=s.lastTick&&w.phase==='fight'&&s.fieldUntil>s.clock);}
    function snapshot(w){
      const s=worlds.get(w);if(!s||w.phase!=='fight')return{};
      return{rocketBossPlayerMoves:{attacks:[...s.attacks.values()].map(a=>{const {hits,...rest}=a;return structuredClone(rest);}),
        projectiles:structuredClone(s.projectiles),beams:structuredClone(s.beams),clones:structuredClone(s.clones),impacts:structuredClone(s.impacts)}};
    }
    return Object.freeze({entries:()=>catalog.map(e=>({...e})),enabled,isMove,baseMove,register,start,tick,immune,snapshot,offline});
  }
  function patch(source){
    const once=(before,after)=>{const parts=source.split(before);if(parts.length!==2)throw Error('Unsupported boss move anchor: '+before.slice(0,90));source=parts.join(after);};
    once('var ze=1.45;','arenaBossMoves.register();var ze=1.45;');
    once('startMove(e,t,n,r,i,a,o){','startMove(e,t,n,r,i,a,o){if(arenaBossMoves.isMove(t.id)){if(arenaBossMoves.start(this,e,t,n,r,i))return;t=V(arenaBossMoves.baseMove(t.id))}');
    once('startBasic(e,t,n,r){','startBasic(e,t,n,r){if(t&&arenaBossMoves.isMove(t.id)){if(arenaBossMoves.start(this,e,t,n,r,false))return;t=V(arenaBossMoves.baseMove(t.id))}');
    once('updateCast(e,t){let n=e.cast;','updateCast(e,t){if(e.cast?.rocketBoss)return;let n=e.cast;');
    once('updateBullets(){let e=[];for(let t of this.bullets){','updateBullets(){arenaBossMoves.tick(this);let e=[];for(let t of this.bullets){');
    once('items:this.supply?[{...this.supply}]:[]}}knockOutOpponent(){','items:this.supply?[{...this.supply}]:[],...arenaBossMoves.snapshot(this)}}knockOutOpponent(){');
    once('resistsHex(e,t){let n=lt(t.status),','resistsHex(e,t){if(arenaBossMoves.immune(this))return true;let n=lt(t.status),');
    once('applyHex(e,t){let n=lt(t.status);','applyHex(e,t){if(arenaBossMoves.immune(this))return;let n=lt(t.status);');
    once('trySecondary(e,t){','trySecondary(e,t){if(arenaBossMoves.immune(this))return;');
    once('function uN(e){return(rN[e]??e).replace(/-/g,``)}','function uN(e){e=arenaBossMoves.baseMove(e);return(rN[e]??e).replace(/-/g,``)}');
    return 'const arenaBossMoves=('+createArenaBossMoves.toString()+')();globalThis.arenaBossMoves=arenaBossMoves;\n'+source;
  }
  const api=Object.freeze({patch});globalThis.ArenaBossMovesAdapter=api;
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})();
